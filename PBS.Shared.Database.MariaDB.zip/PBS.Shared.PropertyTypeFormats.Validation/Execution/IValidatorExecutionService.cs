﻿using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Service used for validator execution
    /// </summary>
    public interface IValidatorExecutionService
    {
        /// <summary>
        /// Executes provided validator with data and parameters
        /// </summary>
        /// <param name="validatorKey">Validator key</param>
        /// <param name="validationData">Data to validate, could be value of <see cref="PropertyValue"/> or reference of <see cref="PropertyValue"/></param>
        /// <param name="validator">Actual Validator implementation object</param>
        /// <param name="validatorParameters">Validator parameters provider by <see cref="PropertyType"/></param>
        /// <returns>Execution result</returns>
        public ValueTask<ValidationExecutionResult> ExecuteValidatorAsync(string validatorKey, IValidator validator, object? validationData, object validatorParameters);
    }
}
