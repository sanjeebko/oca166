﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Logging;
using PBS.Shared.PropertyTypeFormats.Validation.Helpers;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidatorExecutionService : IValidatorExecutionService
    {
        private readonly ILogger _logger;

        public ValidatorExecutionService(ILogger<ValidatorExecutionService> logger)
        {
            _logger = logger;
        }

        public async ValueTask<ValidationExecutionResult> ExecuteValidatorAsync(string validatorKey, IValidator validator, object? validationData, object validatorParameters)
        {
            Requires.NotNull(validatorKey, nameof(validatorKey));
            Requires.NotNull(validator, nameof(validator));

            using var _ = _logger.WithProperties(new Dictionary<string, object>
            {
                { "ValidatorKey", validatorKey },
                { "ValidatorParameters", validatorParameters }
            });

            _logger.LogDebug("Attempting to execute validator");
            if (validationData is null && !IsDefaultValidatorParameter(validatorParameters))
            {
                _logger.LogError("Validator data and parameters were invalid");
                return ValidationServiceHelper.BuildFailedValidatorValidationExecutionResultFromString(validatorKey, "Validator data is null");
            }
            _logger.LogDebug("Validator data and parameters are valid, executing validator");

            try
            {
                ValidatorValidationResult validatorValidationResult = await validator.PerformValidationAsync(new ValidatorValidationRequest(validationData, validatorParameters));

                return ConvertValidatorValidationResultToValidationExecutionResult(validatorKey, validatorValidationResult);
            }
            catch (Exception e)
            {
                _logger.LogTrace(e, "Validator validation failed");
                return new ValidationExecutionResult(Source: validatorKey, IsSuccessful: false, ErrorString: e.Message);
            }
        }

        private static bool IsDefaultValidatorParameter(object validatorParameters)
        {
            return validatorParameters is ValidatorArgs.Default;
        }

        private static ValidationExecutionResult ConvertValidatorValidationResultToValidationExecutionResult(string validatorKey, ValidatorValidationResult validationResult) => new ValidationExecutionResult(Source: validatorKey, IsSuccessful: validationResult.IsSuccessful, ErrorString: validationResult.ErrorString);
    }
}
