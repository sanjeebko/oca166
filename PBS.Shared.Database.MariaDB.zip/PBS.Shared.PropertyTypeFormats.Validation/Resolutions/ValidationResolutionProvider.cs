﻿using Microsoft.Extensions.Logging;
using PBS.Shared.PropertyTypeFormats.Validation.Helpers;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Base class for providers
    /// </summary>
    public abstract class ValidationResolutionProvider : IValidationResolutionProvider
    {
        protected readonly ILogger Logger;
        protected readonly IValidatorFactory ValidatorFactory;
        protected readonly IValidatorExecutionService ValidatorExecutionService;

        protected ValidationResolutionProvider(
            ILogger logger,
            IValidatorFactory validatorFactory,
            IValidatorExecutionService validatorExecutionService)
        {
            Logger = logger;
            ValidatorFactory = validatorFactory;
            ValidatorExecutionService = validatorExecutionService;
        }


        public abstract ValueTask<ValidationResolutionResult> PerformValidationAsync(ValidationRequest request);

        protected virtual async ValueTask<ValidationExecutionResult> ExecuteValidatorAsync(object? data, string validatorKey, object validatorParameters)
        {
            IValidator? validator = ValidatorFactory.ResolveValidator(validatorKey);

            if (validator == null)
                return ValidationServiceHelper.BuildFailedValidatorValidationExecutionResultFromString(validatorKey, "Validator failed to be resolved");

            return await ValidatorExecutionService.ExecuteValidatorAsync(validatorKey, validator, data, validatorParameters);
        }
    }
}
