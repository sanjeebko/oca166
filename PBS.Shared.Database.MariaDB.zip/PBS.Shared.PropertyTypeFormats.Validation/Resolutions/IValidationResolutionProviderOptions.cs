﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Provider options for all registered <see cref="IValidationResolutionProvider"/>
    /// </summary>
    public interface IValidationResolutionProviderOptions
    {
        /// <summary>
        /// Get's option entries of all registered providers
        /// </summary>
        IEnumerable<ValidationResolutionProviderOptionEntry> GetAllProvidersOptionEntries();
    }
}