﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Factory used to resolve <see cref="IValidationResolutionProvider"/> which are registered using <see cref="IValidationRegistrationBuilder"/>
    /// </summary>
    public interface IValidationResolutionProviderFactory
    {
        /// <summary>
        /// Get's provider by registered identifier
        /// </summary>
        /// <param name="identifier">Unique identifier for provider</param>
        /// <returns>Provider if it was found using <param name="identifier"></param> or null if it is not found</returns>
        IValidationResolutionProvider? GetProvider(string identifier);

        /// <summary>
        /// Gets all registered providers
        /// </summary>
        /// <returns>Collection of providers</returns>
        IEnumerable<IValidationResolutionProvider> GetAllProviders();
    }
}
