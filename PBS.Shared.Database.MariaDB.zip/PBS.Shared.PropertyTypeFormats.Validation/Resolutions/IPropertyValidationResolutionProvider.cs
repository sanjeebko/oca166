﻿namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Empty interface used for limiting single property validation resolution provider
    /// </summary>
    public interface IPropertyValidationResolutionProvider : IValidationResolutionProvider
    {
    }
}