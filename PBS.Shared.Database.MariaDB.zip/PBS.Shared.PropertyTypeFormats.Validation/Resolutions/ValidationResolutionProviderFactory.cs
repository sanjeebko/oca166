﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidationResolutionProviderFactory : IValidationResolutionProviderFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IOptions<IValidationResolutionProviderOptions> _mappings;

        public ValidationResolutionProviderFactory(IServiceProvider serviceProvider, IOptions<IValidationResolutionProviderOptions> mappings)
        {
            _serviceProvider = serviceProvider;
            _mappings = mappings;
        }

        public IValidationResolutionProvider? GetProvider(string identifier)
        {
            Type? providerType = _mappings.Value.GetAllProvidersOptionEntries().FirstOrDefault(option => option.Identifier == identifier)?.Type;

            return providerType is not null && _serviceProvider.GetService(providerType) is IValidationResolutionProvider provider ? provider : default;
        }

        public IEnumerable<IValidationResolutionProvider> GetAllProviders()
        {
            foreach (ValidationResolutionProviderOptionEntry optionEntry in _mappings.Value.GetAllProvidersOptionEntries())
            {
                if (_serviceProvider.GetService(optionEntry.Type) is IValidationResolutionProvider provider)
                    yield return provider;
            }
        }
    }
}