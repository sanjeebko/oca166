﻿using Microsoft.Extensions.Options;
using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidationResolutionProviderOptions : IOptions<IValidationResolutionProviderOptions>, IValidationResolutionProviderOptions
    {
        public IValidationResolutionProviderOptions Value => this;

        private readonly List<ValidationResolutionProviderOptionEntry> _mappings = new List<ValidationResolutionProviderOptionEntry>();

        public void RegisterProvider<T>(string? identifier = null) where T : IValidationResolutionProvider
        {
            Type providerType = typeof(T);

            if (_mappings.Any(e => e.Type == providerType))
                throw new ValidationResolutionRegistrationException($"Provider {providerType.FullName} already added");
            _mappings.Add(new ValidationResolutionProviderOptionEntry(identifier, providerType));
        }

        public IEnumerable<ValidationResolutionProviderOptionEntry> GetAllProvidersOptionEntries()
        {
            return _mappings.ToList();
        }
    }
}
