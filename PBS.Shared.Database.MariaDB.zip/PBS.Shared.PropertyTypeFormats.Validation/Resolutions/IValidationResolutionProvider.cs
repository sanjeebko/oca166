﻿using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Base interface for implementing provider
    /// </summary>
    public interface IValidationResolutionProvider
    {
        /// <summary>
        /// Runs validation of provided properties
        /// </summary>
        /// <param name="request">Validation request</param>
        /// <returns>Validation result containing validation errors if any</returns>
        ValueTask<ValidationResolutionResult> PerformValidationAsync(ValidationRequest request);
    }
}
