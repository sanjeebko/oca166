﻿using System;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public record ValidationResolutionProviderOptionEntry(string? Identifier, Type Type);
}