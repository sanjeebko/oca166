﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.PropertyTypeFormats.Validation.Exceptions
{
    [Serializable]
    public class ValidatorRegistrationException : Exception
    {
        public ValidatorRegistrationException()
        { }

        public ValidatorRegistrationException(string? message) : base(message)
        { }

        protected ValidatorRegistrationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }
    }
}
