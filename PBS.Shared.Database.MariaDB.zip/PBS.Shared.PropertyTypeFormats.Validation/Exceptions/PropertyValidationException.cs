﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.PropertyTypeFormats.Validation.Exceptions
{
    [Serializable]
    public class PropertyValidationException : ValidationException
    {
        public PropertyValidationException()
        { }

        public PropertyValidationException(string property, string? message) : base(property, message)
        { }

        protected PropertyValidationException(SerializationInfo info, StreamingContext context)
        : base(info, context)
        { }
    }
}
