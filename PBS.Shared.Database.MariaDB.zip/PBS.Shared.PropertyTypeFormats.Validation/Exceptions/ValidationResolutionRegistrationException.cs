﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.PropertyTypeFormats.Validation.Exceptions
{
    [Serializable]
    public class ValidationResolutionRegistrationException : Exception
    {
        public ValidationResolutionRegistrationException()
        { }

        public ValidationResolutionRegistrationException(string? message) : base(message)
        { }

        protected ValidationResolutionRegistrationException(SerializationInfo info, StreamingContext context)
            : base(info, context)
        { }
    }
}
