﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.PropertyTypeFormats.Validation.Exceptions
{
    [Serializable]
    public class ValidationException : Exception
    {
        public string ValidationSource { get; } = string.Empty;

        public ValidationException()
        {
        }

        public ValidationException(string source, string? message) : base(message)
        {
            ValidationSource = source;
        }

        protected ValidationException(SerializationInfo info, StreamingContext context)
        : base(info, context)
        { }
    }
}
