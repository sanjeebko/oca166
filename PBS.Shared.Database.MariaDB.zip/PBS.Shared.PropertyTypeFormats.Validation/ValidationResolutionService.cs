﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Logging;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidationResolutionService : IValidationResolutionService
    {
        private readonly ILogger _logger;
        private readonly IValidationResolutionProviderFactory _validationResolutionProviderFactory;

        public ValidationResolutionService(
            ILogger<ValidationResolutionService> logger,
            IValidationResolutionProviderFactory validationResolutionProviderFactory)
        {
            _logger = logger;
            _validationResolutionProviderFactory = validationResolutionProviderFactory;
        }

        public async ValueTask<ValidationResolutionResults> PerformValidationAsync(ValidationRequest request)
        {
            List<IValidationResolutionProvider> validationResolutionProviders = ResolveValidationResolutionProviders(request);

            if (!validationResolutionProviders.Any())
            {
                throw new InvalidOperationException("There are none registered validation resolution providers to run validation");
            }

            List<ValidationResolutionResult> indexedResults = new();

            foreach (IValidationResolutionProvider validationResolutionProvider in validationResolutionProviders)
            {
                using var _ = _logger.WithProperty("{ValidationResolutionProviderType}", validationResolutionProvider.GetType().Name);
                _logger.LogTrace("Running validation");

                ValidationResolutionResult validationResolutionResult = await validationResolutionProvider.PerformValidationAsync(request);

                _logger.LogTrace("Validation completed");

                if (validationResolutionResult.IsSuccessful)
                    continue;

                indexedResults.Add(validationResolutionResult);
                if (!request.ContinueOnFailedValidation)
                    break;
            }

            return new ValidationResolutionResults { Format = request.Format, Results = indexedResults };
        }

        private List<IValidationResolutionProvider> ResolveValidationResolutionProviders(ValidationRequest request)
        {
            if (!request.ValidationResolutionProviders.Any())
                return _validationResolutionProviderFactory.GetAllProviders().ToList();

            var filteredProvider = new List<IValidationResolutionProvider>();
            foreach (var providerKey in request.ValidationResolutionProviders)
            {
                IValidationResolutionProvider? resolvedProvider = _validationResolutionProviderFactory.GetProvider(providerKey);
                if (resolvedProvider is not null)
                    filteredProvider.Add(resolvedProvider);
            }

            return filteredProvider;
        }
    }
}
