﻿using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using System;
using System.Linq;
using System.Reflection;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidationRegistrationBuilder :
        IValidationRegistrationBuilder,
        IValidationResolutionProviderBuilder,
        IDomainObjectReferenceValidationBuilder,
        IValidatorRegistrationOptions,
        IValidationResolutionProviderRegistrationOptions
    {
        private readonly ValidatorOptions _validatorOptions;
        private readonly ValidationResolutionProviderOptions _validationResolutionProviderOptions;
        private readonly PropertyDomainObjectReferenceValidationProviderOptions _propertyDomainObjectReferenceValidationProviderOptions;

        public ValidationRegistrationBuilder(
            ValidatorOptions validatorOptions,
            ValidationResolutionProviderOptions validationResolutionProviderOptions,
            PropertyDomainObjectReferenceValidationProviderOptions propertyDomainObjectReferenceValidationProviderOptions)
        {
            _validatorOptions = validatorOptions;
            _validationResolutionProviderOptions = validationResolutionProviderOptions;
            _propertyDomainObjectReferenceValidationProviderOptions = propertyDomainObjectReferenceValidationProviderOptions;
        }


        #region Validators

        public IValidationResolutionProviderBuilder ConfigureValidators(Action<IValidatorRegistrationOptions>? configure = null)
        {
            configure?.Invoke(this);
            return this;
        }

        public IValidatorRegistrationOptions RegisterDefaultValidators()
        {
            RegisterValidatorsFromAssembly(GetType().Assembly);
            return this;
        }

        public IValidatorRegistrationOptions RegisterValidatorsFromAssembly(params Assembly[] assemblies)
        {
            _validatorOptions.RegisterValidatorsFromAssembly(assemblies);
            return this;
        }

        public IValidatorRegistrationOptions RegisterValidator<T>(string? validatorKey = null) where T : IValidator
        {
            _validatorOptions.RegisterValidator<T>(validatorKey);
            return this;
        }

        #endregion

        #region ValidationResolution

        public void ConfigureValidationResolution(Action<IValidationResolutionProviderRegistrationOptions>? configure = null) => configure?.Invoke(this);

        public IDomainObjectReferenceValidationBuilder RegisterPropertyProvider<T>() where T : class, IPropertyValidationResolutionProvider
        {
            if (!IsValidationResolutionProviderType<T>())
                throw new ValidationResolutionRegistrationException($"Provider {typeof(T).FullName} does not implement {nameof(IValidationResolutionProvider)} interface");

            if (IsPropertyValidationResolutionProviderRegistered())
                throw new ValidationResolutionRegistrationException($"Provider {nameof(IPropertyValidationResolutionProvider)} already registered");

            if (typeof(T) == typeof(PropertyValidationResolutionProvider))
            {
                _validationResolutionProviderOptions.RegisterProvider<PropertyValidationResolutionProvider>();
                return this;
            }

            MethodInfo? addProviderMethod = _validationResolutionProviderOptions.GetType().GetMethod(nameof(ValidationResolutionProviderOptions.RegisterProvider))?.MakeGenericMethod(typeof(T));
            addProviderMethod?.Invoke(_validationResolutionProviderOptions, new object?[] { string.Empty });
            return this;
        }

        public void RegisterProvider<T>(string? identifier = null) where T : class, IValidationResolutionProvider
        {
            if (IsPropertyValidationResolutionProviderType<T>() && IsPropertyValidationResolutionProviderRegistered())
                throw new ValidationResolutionRegistrationException("Property validation resolution provider was already registered");
            _validationResolutionProviderOptions.RegisterProvider<T>(identifier);
        }

        #region DomainObjectReferences

        public IDomainObjectReferenceValidationBuilder RegisterDomainObjectReferenceValidationProvider<T>(string domain) where T : IPropertyDomainObjectReferenceValidationProvider
        {
            _propertyDomainObjectReferenceValidationProviderOptions.RegisterProvider<T>(domain);
            return this;
        }

        #endregion

        #endregion

        private bool IsPropertyValidationResolutionProviderRegistered() => _validationResolutionProviderOptions.GetAllProvidersOptionEntries().FirstOrDefault(optionEntry => typeof(IPropertyValidationResolutionProvider).IsAssignableFrom(optionEntry.Type)) != null;
        private static bool IsPropertyValidationResolutionProviderType<T>() => typeof(IPropertyValidationResolutionProvider).IsAssignableFrom(typeof(T));
        private static bool IsValidationResolutionProviderType<T>() => typeof(IValidationResolutionProvider).IsAssignableFrom(typeof(T));
    }
}