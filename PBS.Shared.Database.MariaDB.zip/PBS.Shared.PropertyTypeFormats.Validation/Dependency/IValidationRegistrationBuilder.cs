﻿using System;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Registration builder for property format types validation framework
    /// </summary>
    public interface IValidationRegistrationBuilder
    {
        /// <summary>
        /// Configures validator <see cref="IValidator"/> registration
        /// </summary>
        /// <param name="configure">Configuration action</param>
        /// <returns>Returns <see cref="IValidationResolutionProviderBuilder"/> for configuring <see cref="IValidationResolutionProvider"/> provider registration</returns>
        IValidationResolutionProviderBuilder ConfigureValidators(Action<IValidatorRegistrationOptions>? configure = null);
    }
}