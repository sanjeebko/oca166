﻿using System;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Registration builder for validation resolution providers <see cref="IValidationResolutionProvider"/>
    /// </summary>
    public interface IValidationResolutionProviderBuilder
    {
        /// <summary>
        /// Configures validation resolution providers <see cref="IValidationResolutionProvider"/> registration
        /// </summary>
        /// <param name="configure">Configuration action</param>
        void ConfigureValidationResolution(Action<IValidationResolutionProviderRegistrationOptions>? configure = null);
    }
}