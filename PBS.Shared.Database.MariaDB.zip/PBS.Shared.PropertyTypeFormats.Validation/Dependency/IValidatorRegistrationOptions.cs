﻿using System.Reflection;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Registration options for validators
    /// </summary>
    public interface IValidatorRegistrationOptions
    {
        /// <summary>
        /// Registers all default validators found in this assembly
        /// </summary>
        IValidatorRegistrationOptions RegisterDefaultValidators();

        /// <summary>
        /// Registers validators <see cref="IValidator"/> from provided assemblies <param name="assemblies"></param>
        /// </summary>
        /// <param name="assemblies">Assemblies to scan for validator implementation</param>
        IValidatorRegistrationOptions RegisterValidatorsFromAssembly(params Assembly[] assemblies);

        /// <summary>
        /// Registers provided validator <see cref="IValidator"/> type
        /// </summary>
        /// <typeparam name="T">Type of validator</typeparam>
        /// <param name="validatorKey">Optional validator key <see cref="ValidatorKeys"/>, if <param name="validatorKey"></param> is not provided, validator definition attribute <see cref="ValidatorDefinitionAttribute"/> on provided validator type will be used to acquire validator key </param>
        IValidatorRegistrationOptions RegisterValidator<T>(string? validatorKey = null) where T : IValidator;
    }
}