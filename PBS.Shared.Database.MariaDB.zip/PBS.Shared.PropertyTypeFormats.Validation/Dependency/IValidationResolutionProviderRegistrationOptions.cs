﻿
namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Registration for validation resolution providers
    /// </summary>
    public interface IValidationResolutionProviderRegistrationOptions
    {
        /// <summary>
        /// Registers property validation resolution provider
        /// Library comes with already implemented property validation provider <see cref="PropertyValidationResolutionProvider"/>, this method can be used to
        /// replace default property validation provider or to configure default one.
        /// If default provider should be replaced, it's mandatory that new property validation provider implements <see cref="IPropertyValidationResolutionProvider"/> interface
        /// </summary>
        /// <remarks>
        /// Only one provider that implements <see cref="IPropertyValidationResolutionProvider"/> is allowed to be registered.
        /// This method can be called only once.
        /// </remarks>
        /// <exception cref="Exceptions.ValidationResolutionRegistrationException">Throws when <see cref="T"/> does not implement <see cref="IValidationResolutionProvider"/> </exception>
        /// <exception cref="Exceptions.ValidationResolutionRegistrationException">Throws when <see cref="IPropertyValidationResolutionProvider"/> is already registered</exception>
        /// <typeparam name="T">Provider type</typeparam>
        /// <returns>Domain object reference validation builder which can be used to register <see cref="IPropertyDomainObjectReferenceValidationProvider"/></returns>
        IDomainObjectReferenceValidationBuilder RegisterPropertyProvider<T>() where T : class, IPropertyValidationResolutionProvider;

        /// <summary>
        /// Registers validation resolution provider
        /// </summary>
        /// <exception cref="Exceptions.ValidationResolutionRegistrationException">Throws when <see cref="T"/> implement <see cref="IPropertyValidationResolutionProvider"/> and it is already registered</exception>
        /// <exception cref="Exceptions.ValidationResolutionRegistrationException">Throws when same type <see cref="T"/> is already registered</exception>
        /// <typeparam name="T">Type of provider</typeparam>
        /// <param name="identifier">Optional provider identifier, identifier can be used to resolve specific provider using <see cref="IValidationResolutionProviderFactory"/></param>
        void RegisterProvider<T>(string? identifier = null) where T : class, IValidationResolutionProvider;
    }
}