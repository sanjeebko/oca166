﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public static class ValidationRegistration
    {
        public static IServiceCollection AddPropertyValidationSupport(this IServiceCollection services, Action<IValidationRegistrationBuilder>? configure = null)
        {
            services.AddSingleton<IValidatorExecutionService, ValidatorExecutionService>();
            services.AddTransient<IValidatorFactory, ValidatorFactory>();
            services.AddTransient<IValidationResolutionService, ValidationResolutionService>();
            services.AddTransient<IValidationResolutionProviderFactory, ValidationResolutionProviderFactory>();
            services.AddTransient<IPropertyDomainObjectReferenceValidationProviderFactory, PropertyDomainObjectReferenceValidationProviderFactory>();

            ValidatorOptions validatorOptions = new();
            ValidationResolutionProviderOptions validationResolutionProviderOptions = new();
            PropertyDomainObjectReferenceValidationProviderOptions propertyDomainObjectReferenceValidationProviderOptions = new();

            services.AddSingleton<IOptions<IValidatorOptions>>(validatorOptions);
            services.AddSingleton<IOptions<IValidationResolutionProviderOptions>>(validationResolutionProviderOptions);
            services.AddSingleton<IOptions<IPropertyDomainObjectReferenceValidationProviderOptions>>(propertyDomainObjectReferenceValidationProviderOptions);

            configure?.Invoke(new ValidationRegistrationBuilder(validatorOptions, validationResolutionProviderOptions, propertyDomainObjectReferenceValidationProviderOptions));

            RegisterValidators(services, validatorOptions);
            RegisterValidationResolutionProviders(services, validationResolutionProviderOptions);
            RegisterDomainObjectReferenceValidationProviders(services, propertyDomainObjectReferenceValidationProviderOptions);

            return services;
        }

        private static void RegisterValidators(IServiceCollection services, ValidatorOptions validatorOptions)
        {
            foreach ((string _, Type validatorType) in validatorOptions.GetAllValidators())
                services.AddTransient(validatorType);
        }

        private static void RegisterDomainObjectReferenceValidationProviders(IServiceCollection services, PropertyDomainObjectReferenceValidationProviderOptions propertyDomainObjectReferenceValidationProviderOptions)
        {
            // because we can add multiple providers for same domain, and same type of provider for multiple domains we need to make distinct lit of types for di registration
            foreach (Type providerType in propertyDomainObjectReferenceValidationProviderOptions.GetAllProviderTypes().Values.SelectMany(types => types).Distinct())
                services.AddTransient(providerType);
        }

        private static void RegisterValidationResolutionProviders(IServiceCollection services, ValidationResolutionProviderOptions validationResolutionProviderOptions)
        {
            IEnumerable<Type> registeredValidationResolutionProviderTypes = validationResolutionProviderOptions.GetAllProvidersOptionEntries().Select(entry => entry.Type).ToList();

            // by default we want to support property validation so if no property validation providers are registered, we need to register default one
            if (!registeredValidationResolutionProviderTypes.Any(providerType => typeof(IPropertyValidationResolutionProvider).IsAssignableFrom(providerType)))
                validationResolutionProviderOptions.RegisterProvider<PropertyValidationResolutionProvider>();

            foreach (var optionEntry in validationResolutionProviderOptions.GetAllProvidersOptionEntries())
                services.AddTransient(optionEntry.Type);
        }
    }
}
