﻿namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Additional registration builder for <see cref="IPropertyValidationResolutionProvider"/>
    /// used to register optional <see cref="IPropertyDomainObjectReferenceValidationProvider"/>
    /// </summary>
    public interface IDomainObjectReferenceValidationBuilder
    {
        /// <summary>
        /// Registers domain object reference validation provider which is used in <see cref="PropertyValidationResolutionProvider"/> for validating property value in case
        /// if property value is domain object reference.
        /// </summary>
        /// <typeparam name="T">Type of provider</typeparam>
        /// <param name="domain">Domain for which this provider will be registered.</param>
        /// <remarks>
        /// Validation of domain object reference will be run only if registered provider for referenced domain is found.
        /// Multiple providers for same domain can be added.
        /// Same type of provider can be added to multiple domains
        /// </remarks>
        IDomainObjectReferenceValidationBuilder RegisterDomainObjectReferenceValidationProvider<T>(string domain) where T : IPropertyDomainObjectReferenceValidationProvider;
    }
}