﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    public record ValidationExecutionResults(IEnumerable<ValidationExecutionResult> Results);
}