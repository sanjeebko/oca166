﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    public record PropertyValidationExecutionResults(string Property, IEnumerable<ValidationExecutionResult> Results) : ValidationExecutionResults(Results);
}