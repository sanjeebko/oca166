﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    /// <summary>
    /// Validation Request
    /// </summary>
    public record ValidationRequest
    {
        /// <summary>
        /// Optional Format name of a object which implements <see cref="ITypeFormat"/>
        /// </summary>
        public string? Format { get; set; }
        /// <summary>
        /// Flag when false will stop running other validation resolution providers <see cref="IValidationResolutionProvider"/> on first validation error
        /// </summary>
        public bool ContinueOnFailedValidation { get; set; } = true;
        /// <summary>
        /// Properties to validate
        /// </summary>
        public IDictionary<string, PropertyValue> Properties { get; set; } = new Dictionary<string, PropertyValue>();
        /// <summary>
        /// Property formats of provided <see cref="Properties"/>
        /// </summary>
        public IDictionary<string, PropertyFormat> PropertyFormats { get; set; } = new Dictionary<string, PropertyFormat>();
        /// <summary>
        /// Optional filter which can be used to restrict validation to defined provider identifiers, if none is defined then validation will be performed by all registered <see cref="IValidationResolutionProvider"/>
        /// </summary>
        public IEnumerable<string> ValidationResolutionProviders { get; set; } = Enumerable.Empty<string>();
    }
}
