﻿namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    public record ValidationExecutionResult(string Source, bool IsSuccessful, string ErrorString);
}
