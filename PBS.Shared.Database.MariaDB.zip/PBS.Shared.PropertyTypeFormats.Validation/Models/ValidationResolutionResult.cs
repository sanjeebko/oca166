﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    /// <summary>
    /// Immutable Result of validation resolution provider <see cref="IValidationResolutionProvider"/>
    /// </summary>
    public record ValidationResolutionResult(string? Format, bool IsSuccessful, IEnumerable<ValidationExecutionResults> ValidationErrors);
}
