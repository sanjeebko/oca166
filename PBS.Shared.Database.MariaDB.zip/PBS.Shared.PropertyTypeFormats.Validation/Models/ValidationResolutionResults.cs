﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation.Models
{
    /// <summary>
    /// Immutable aggregated result of all validation resolution providers
    /// </summary>
    public record ValidationResolutionResults
    {
        /// <summary>
        /// Defines outcome of all <see cref="ValidationResolutionResult"/>, returns true if all Results are successful, or false if any of them is not successful 
        /// </summary>
        public bool IsSuccessful => !Results.Any() || Results.All(p => p.IsSuccessful);

        /// <summary>
        /// Format provided in request <see cref="ValidationRequest"/>
        /// </summary>
        public string? Format { get; init; }

        /// <summary>
        /// Validation resolution results of all registered <see cref="IValidationResolutionProvider"/> providers
        /// </summary>
        public IEnumerable<ValidationResolutionResult> Results { get; init; } = Enumerable.Empty<ValidationResolutionResult>();
    }
}