﻿using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.RequiredValidator
{
    [ValidatorDefinition(ValidatorKeys.Required)]
    public class RequiredValidator : IValidator
    {
        public ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            if (validatorValidationRequest.ValidationData is null)
                return CreateExecutionResult(false, "Data provided to required validator is null");

            if (validatorValidationRequest.ValidationData is string str)
                return CreateExecutionResult(!string.IsNullOrWhiteSpace(str), "data provided is an empty string");

            if (validatorValidationRequest.ValidationData is object[] objArray)
                return CreateExecutionResult(objArray.Length > 0, "data provided is an empty array");

            return CreateExecutionResult(true);

        }

        private static ValueTask<ValidatorValidationResult> CreateExecutionResult(bool success, string errorString = "") =>
            ValueTask.FromResult(new ValidatorValidationResult { IsSuccessful = success, ErrorString = success ? "" : errorString });
    }
}
