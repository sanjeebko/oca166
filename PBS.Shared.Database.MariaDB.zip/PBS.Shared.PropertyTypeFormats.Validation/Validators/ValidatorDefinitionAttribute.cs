﻿using System;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    [AttributeUsage(AttributeTargets.Class)]
    public class ValidatorDefinitionAttribute : Attribute
    {
        public ValidatorDefinitionAttribute(string validatorKey)
        {
            ValidatorKey = validatorKey;
        }

        public string ValidatorKey { get; init; }
    }
}
