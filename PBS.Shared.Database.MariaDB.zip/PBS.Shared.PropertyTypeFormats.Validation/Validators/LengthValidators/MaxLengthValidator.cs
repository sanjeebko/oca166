﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.LengthValidators
{
    [ValidatorDefinition(ValidatorKeys.MaxLength)]
    public class MaxLengthValidator : IValidator
    {
        public ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            if (validatorValidationRequest.ValidatorParameters is not int maxLength)
            {
                throw new ArgumentException("Max Length Validator parameters must be an integer value");
            }

            if (validatorValidationRequest.ValidationData is object[] dataArray)
            {
                return ValidateObjectArrayCount(dataArray, maxLength);
            }
            return ValidateStringLength(validatorValidationRequest.ValidationData, maxLength);
        }

        private static ValueTask<ValidatorValidationResult> CreateResult(bool success, string errorString = "") => ValueTask.FromResult(new ValidatorValidationResult
        {
            IsSuccessful = success,
            ErrorString = success ? "" : errorString
        });

        private static ValueTask<ValidatorValidationResult> ValidateObjectArrayCount(object[] dataArray, int maxLength)
            => CreateResult(
                dataArray.Length <= maxLength,
                CreateCollectionError(maxLength, dataArray.Length)
                );

        private static ValueTask<ValidatorValidationResult> ValidateStringLength(object? validationData, int maxLength)
        {
            if (validationData is string stringData)
            {
                return CreateResult(stringData.Length <= maxLength, CreateStringError(maxLength, stringData.Length));
            }
            throw new ArgumentException("data is not allowed type, must be of type: string");
        }

        private static string CreateStringError(int maxLength, int currentLength) => $"string length is longer than the allowed maximum length, maximum length allowed: {maxLength}, length provided: {currentLength}";
        private static string CreateCollectionError(int maxLength, int currentLength) => $"collection count is longer than the allowed maximum count, maximum count allowed: {maxLength}, count provided: {currentLength}";

    }
}
