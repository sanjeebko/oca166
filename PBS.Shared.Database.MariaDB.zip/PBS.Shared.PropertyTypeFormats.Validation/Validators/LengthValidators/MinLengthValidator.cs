﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.LengthValidators
{
    [ValidatorDefinition(ValidatorKeys.MinLength)]
    public class MinLengthValidator : IValidator
    {
        public ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            if (validatorValidationRequest.ValidatorParameters is not int minLength)
            {
                throw new ArgumentException("Min Length Validator parameters must be an integer value");
            }

            if (validatorValidationRequest.ValidationData is object[] dataArray)
            {
                return ValidateObjectArrayCount(dataArray, minLength);
            }
            return ValidateStringLength(validatorValidationRequest.ValidationData, minLength);
        }

        private static ValueTask<ValidatorValidationResult> CreateResult(bool success, string errorString = "") => ValueTask.FromResult(new ValidatorValidationResult
        {
            IsSuccessful = success,
            ErrorString = success ? "" : errorString
        });

        private static ValueTask<ValidatorValidationResult> ValidateObjectArrayCount(object[] dataArray, int minLength)
            => CreateResult(
                dataArray.Length >= minLength,
                CreateCollectionError(minLength, dataArray.Length)
                );

        private static ValueTask<ValidatorValidationResult> ValidateStringLength(object? validationData, int minLength)
        {
            if (validationData is string stringData)
            {
                return CreateResult(stringData.Length >= minLength, CreateStringError(minLength, stringData.Length));
            }
            throw new ArgumentException("data is not allowed type, must be of type: string");
        }

        private static string CreateStringError(int minLength, int currentLength) => $"string length is shorter than the allowed minimum length, minimum length allowed: {minLength}, length provided: {currentLength}";
        private static string CreateCollectionError(int minLength, int currentLength) => $"collection count is shorter than the allowed minimum count, minimum count allowed: {minLength}, count provided: {currentLength}";

    }
}
