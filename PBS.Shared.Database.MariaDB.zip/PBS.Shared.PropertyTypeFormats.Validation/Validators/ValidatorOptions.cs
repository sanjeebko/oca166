﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidatorOptions : IOptions<IValidatorOptions>, IValidatorOptions, IValidatorOptionsRegistration
    {
        private readonly ConcurrentDictionary<string, Type> _validators = new ConcurrentDictionary<string, Type>();

        private readonly MethodInfo _addValidatorMethod = typeof(ValidatorOptions).GetMethod(nameof(RegisterValidator)) ?? throw new InvalidOperationException($"Failed to get {nameof(RegisterValidator)} method info");

        public IValidatorOptions Value => this;

        public void RegisterValidatorsFromAssembly(params Assembly[] assemblies)
        {
            foreach (var validatorType in LookupPropertyValidatorTypes(assemblies))
            {
                MethodInfo? addValidatorMethod = _addValidatorMethod?.MakeGenericMethod(validatorType);
                addValidatorMethod?.Invoke(this, new object?[] { string.Empty });
            }
        }

        public void RegisterValidator<T>(string? validatorKey = null) where T : IValidator
        {
            Type validatorType = typeof(T);

            validatorKey ??= string.Empty;

            if (string.IsNullOrWhiteSpace(validatorKey))
            {
                ValidatorDefinitionAttribute? definitionAttribute = validatorType.GetCustomAttribute<ValidatorDefinitionAttribute>();

                if (string.IsNullOrWhiteSpace(definitionAttribute?.ValidatorKey))
                    return;
                validatorKey = definitionAttribute.ValidatorKey;
            }

            _validators.GetOrAdd(validatorKey, validatorType);
        }


        private static IEnumerable<Type> LookupPropertyValidatorTypes(IEnumerable<Assembly?> assemblies)
        {
            List<Type> types = new();

            foreach (Assembly? assembly in assemblies)
            {
                if (assembly == null) continue;
                types.AddRange(GetTypesImplementingValidatorFromAssembly(assembly));
            }

            return types.Distinct().ToList();
        }

        private static IEnumerable<Type> GetTypesImplementingValidatorFromAssembly(Assembly assembly)
        {
            Type lookupType = typeof(IValidator);

            return assembly.GetTypes().Where(type => !type.IsAbstract && !type.IsInterface && type.GetCustomAttribute<ValidatorDefinitionAttribute>() is not null && lookupType.IsAssignableFrom(type));
        }

        public Type? GetValidatorType(string validatorKey)
        {
            return _validators.TryGetValue(validatorKey, out Type? type) ? type : null;
        }

        public IReadOnlyDictionary<string, Type> GetAllValidators()
        {
            return _validators;
        }
    }
}
