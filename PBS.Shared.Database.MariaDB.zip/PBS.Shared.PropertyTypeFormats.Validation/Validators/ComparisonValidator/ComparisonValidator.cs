﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.ComparisonValidator
{
    public abstract class ComparisonValidator<TLeftOperand, TRightOperand> : IValidator
    {
        private const string DataName = "Data";
        private const string ParametersName = "Parameters";

        protected abstract string ErrorString { get; }

        protected bool PerformComparison(string validatorName, object? validationData, object validatorParameters, Func<TLeftOperand, TRightOperand, bool> operation)
        {
            var leftOperand = GetOperandValue<TLeftOperand>(validatorName, DataName, validationData);
            var rightOperand = GetOperandValue<TRightOperand>(validatorName, ParametersName, validatorParameters);

            return PerformOperation(leftOperand, rightOperand, operation);
        }

        private static bool PerformOperation(TLeftOperand leftOperand, TRightOperand rightOperand, Func<TLeftOperand, TRightOperand, bool> operation)
            => operation.Invoke(leftOperand, rightOperand);

        protected virtual object? ProcessOperandValue(object? data) => data;

        protected virtual T GetOperandValue<T>(string validatorName, string dataName, object? data)
        {
            var processedData = ProcessOperandValue(data);

            if (processedData is T typedData)
                return typedData;

            throw new ArgumentException($"{validatorName} {dataName} must be a {GetSanitisedTypeName<T>()} value and is a {data?.GetType().Name ?? "null"} value");
        }

        private static string GetSanitisedTypeName<T>() => Type.GetTypeCode(typeof(T)) switch
        {
            TypeCode.Int32 => "number",
            _ => typeof(T).Name
        };

        protected ValidatorValidationResult CreateExecutionResult(bool operationResult)
        {
            return new ValidatorValidationResult
            {
                IsSuccessful = operationResult,
                ErrorString = operationResult ? string.Empty : ErrorString
            };
        }

        public abstract ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest);
    }
}
