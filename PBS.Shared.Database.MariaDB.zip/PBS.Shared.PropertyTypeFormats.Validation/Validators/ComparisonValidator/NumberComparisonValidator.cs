﻿using PBS.Shared.PropertyTypeFormats.Validation.Helpers;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.ComparisonValidator
{
    public abstract class NumberComparisonValidator : ComparisonValidator<int, int>
    {
        protected int LeftOperand { get; set; }
        protected int RightOperand { get; set; }
        protected abstract bool Operation { get; }

        protected bool PerformOperandOperation(int leftOperand, int rightOperand)
        {
            LeftOperand = leftOperand;
            RightOperand = rightOperand;
            return Operation;
        }

        protected override object? ProcessOperandValue(object? data)
        {
            return PropertyTypeValidationHelper.ConvertObjectPropertyToNumber(data);
        }
    }
}
