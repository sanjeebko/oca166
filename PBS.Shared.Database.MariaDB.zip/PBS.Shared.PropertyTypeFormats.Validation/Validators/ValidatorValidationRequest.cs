﻿namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public record ValidatorValidationRequest(object? ValidationData, object ValidatorParameters);
}
