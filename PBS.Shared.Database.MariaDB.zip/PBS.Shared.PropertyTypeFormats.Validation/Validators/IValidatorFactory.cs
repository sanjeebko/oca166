﻿namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Factory for validator resolution
    /// </summary>
    public interface IValidatorFactory
    {
        /// <summary>
        /// Resolves validator with provided key
        /// </summary>
        /// <param name="validatorKey">Validator key defined in registration part</param>
        /// <returns>Validator implementation based on key, or null if not found</returns>
        IValidator? ResolveValidator(string validatorKey);
    }
}
