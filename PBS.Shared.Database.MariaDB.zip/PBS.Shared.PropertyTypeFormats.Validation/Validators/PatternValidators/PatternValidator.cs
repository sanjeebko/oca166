﻿using System;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.PatternValidators
{
    [ValidatorDefinition(ValidatorKeys.Pattern)]
    public class PatternValidator : IValidator
    {
        public ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            ValidateParameters(validatorValidationRequest.ValidatorParameters);
            string patternString = (string)validatorValidationRequest.ValidatorParameters;

            Regex? pattern = CreatePatternMatcher(patternString);

            if (pattern is null)
                return CreateExecuteResult(false, "Pattern provided is not a valid pattern format");

            if (validatorValidationRequest.ValidationData is string stringData)
                return CreateExecuteResult(pattern.Match(stringData).Success, $"Provided string data did not match pattern {patternString}");

            throw new ArgumentException("Provided data is not string type, only string types can be processed in the pattern validator");
        }

        private static ValueTask<ValidatorValidationResult> CreateExecuteResult(bool success, string errorString = "") =>
            ValueTask.FromResult(new ValidatorValidationResult { IsSuccessful = success, ErrorString = success ? "" : errorString });

        private static void ValidateParameters(object validationParameters)
        {
            if (validationParameters is not string)
                throw new ArgumentException("Validation parameters are not compatible with a pattern");
        }

        private static Regex? CreatePatternMatcher(string patternString)
        {
            try
            {
                Regex pattern = new Regex(patternString);
                return pattern;
            }
            catch
            {
                return null;
            }
        }
    }
}
