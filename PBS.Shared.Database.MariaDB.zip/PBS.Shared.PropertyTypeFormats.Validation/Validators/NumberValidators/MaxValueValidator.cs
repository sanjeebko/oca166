﻿using PBS.Shared.PropertyTypeFormats.Validation.Validators.ComparisonValidator;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.NumberValidators
{
    [ValidatorDefinition(ValidatorKeys.Max)]
    public class MaxValueValidator : NumberComparisonValidator
    {
        protected override string ErrorString => $"Must be {RightOperand} or smaller.";
        protected override bool Operation => LeftOperand <= RightOperand;

        public override ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            bool result = PerformComparison(nameof(MaxValueValidator), validatorValidationRequest.ValidationData, validatorValidationRequest.ValidatorParameters, PerformOperandOperation);
            return ValueTask.FromResult(CreateExecutionResult(result));
        }
    }
}
