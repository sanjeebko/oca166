﻿using PBS.Shared.PropertyTypeFormats.Validation.Validators.ComparisonValidator;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators.NumberValidators
{
    [ValidatorDefinition(ValidatorKeys.Min)]
    public class MinValueValidator : NumberComparisonValidator
    {
        protected override string ErrorString => $"Must be {RightOperand} or greater.";
        protected override bool Operation => LeftOperand >= RightOperand;

        public override ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            bool result = PerformComparison(nameof(MinValueValidator), validatorValidationRequest.ValidationData, validatorValidationRequest.ValidatorParameters, PerformOperandOperation);
            return ValueTask.FromResult(CreateExecutionResult(result));
        }
    }
}
