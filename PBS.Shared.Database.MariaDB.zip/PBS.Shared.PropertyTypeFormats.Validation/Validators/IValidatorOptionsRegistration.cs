﻿using System.Reflection;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Registration options for validators
    /// </summary>
    public interface IValidatorOptionsRegistration
    {
        /// <summary>
        /// Registers validators from provided assemblies
        /// </summary>
        /// <param name="assemblies"></param>
        void RegisterValidatorsFromAssembly(params Assembly[] assemblies);

        /// <summary>
        /// Registers validator
        /// </summary>
        /// <typeparam name="T">Type of validator implementation</typeparam>
        /// <param name="validatorKey">Optional validator key, if not provider <see cref="ValidatorDefinitionAttribute"/> will be used</param>
        void RegisterValidator<T>(string? validatorKey = null) where T : IValidator;
    }
}