﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Validator registration options
    /// </summary>
    public interface IValidatorOptions
    {
        /// <summary>
        /// Get's validator type based on provided key
        /// </summary>
        /// <param name="validatorKey">Validator key</param>
        /// <returns>Type of validator if found or null</returns>
        Type? GetValidatorType(string validatorKey);

        /// <summary>
        /// Get's all registered validators
        /// </summary>
        IReadOnlyDictionary<string, Type> GetAllValidators();
    }
}