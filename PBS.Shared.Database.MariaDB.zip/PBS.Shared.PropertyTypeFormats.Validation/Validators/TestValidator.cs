﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation.Validators
{
    [ValidatorDefinition(ValidatorKeys.DemoValidator)]
    public class TestValidator : IValidator
    {
        public ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest)
        {
            if (validatorValidationRequest.ValidationData is not bool convertedData)
                throw new ArgumentException($"{nameof(TestValidator)} cannot process non boolean type");

            bool parameter = (bool)validatorValidationRequest.ValidatorParameters;

            return ValueTask.FromResult(BuildResolutionResult(convertedData == parameter, parameter));
        }

        private static ValidatorValidationResult BuildResolutionResult(bool result, bool parameters) =>
            new ValidatorValidationResult
            {
                IsSuccessful = result,
                ErrorString = result ? "" : $"Data did not match parameters, expected to equal {parameters}"
            };
    }
}
