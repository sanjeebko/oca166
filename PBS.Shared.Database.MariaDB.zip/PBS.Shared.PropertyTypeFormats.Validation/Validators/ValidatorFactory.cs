﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using PBS.Shared.Logging;
using System;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class ValidatorFactory : IValidatorFactory
    {
        private readonly ILogger _logger;
        private readonly IServiceProvider _serviceProvider;
        private readonly IOptions<IValidatorOptions> _options;

        public ValidatorFactory(ILogger<ValidatorFactory> logger, IServiceProvider serviceProvider, IOptions<IValidatorOptions> options)
        {
            _logger = logger;
            _serviceProvider = serviceProvider;
            _options = options;
        }

        public IValidator? ResolveValidator(string validatorKey)
        {
            _logger.WithProperty("PropertyValidatorTag", validatorKey);
            _logger.LogTrace("Resolving validator");

            Type? validatorType = _options.Value.GetValidatorType(validatorKey);

            if (validatorType is not null && _serviceProvider.GetService(validatorType) is IValidator validator)
                return validator;

            _logger.LogDebug("Validator Tag {ValidatorTag} could not be resolved into a Property Validator", validatorKey);
            return default;
        }
    }
}
