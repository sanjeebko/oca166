﻿using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Base interface for validator implementation
    /// </summary>
    public interface IValidator
    {
        /// <summary>
        /// Runs validation
        /// </summary>
        /// <param name="validatorValidationRequest">Validator request</param>
        /// <returns>Validation result</returns>
        ValueTask<ValidatorValidationResult> PerformValidationAsync(ValidatorValidationRequest validatorValidationRequest);
    }
}
