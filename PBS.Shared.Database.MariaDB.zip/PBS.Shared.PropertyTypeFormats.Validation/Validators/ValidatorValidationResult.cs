﻿namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Immutable validator execution result <see cref="IValidator"/>
    /// </summary>
    public record ValidatorValidationResult
    {
        /// <summary>
        /// Defines true or false if validation is successful, in case that there are some validation errors this will be set to false otherwise to true
        /// </summary>
        public bool IsSuccessful { get; init; }
        /// <summary>
        /// Validation error message provided by <see cref="IValidator"/>
        /// </summary>
        public string ErrorString { get; init; } = string.Empty;
    }
}
