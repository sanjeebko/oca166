﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Domain object reference validation provider factory
    /// </summary>
    public interface IPropertyDomainObjectReferenceValidationProviderFactory
    {
        /// <summary>
        /// Checks if providers are registered for defined domain <param name="domain"></param>
        /// </summary>
        /// <param name="domain">Lookup domain</param>
        /// <returns>True if there are registered providers for defined domain or false if there are none</returns>
        bool ContainsProvidersForDomain(string domain);

        /// <summary>
        /// Resolve providers based on domain <param name="domain"></param>
        /// </summary>
        /// <param name="domain">Domain for which provider is registered</param>
        /// <returns>Collection of providers, multiple providers can be registered for same domain</returns>
        IEnumerable<IPropertyDomainObjectReferenceValidationProvider> ResolveProviders(string domain);
    }
}
