﻿using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Base interface for domain object reference validation
    /// </summary>
    public interface IPropertyDomainObjectReferenceValidationProvider
    {
        /// <summary>
        /// Validates domain object reference
        /// </summary>
        /// <param name="propertyName">Property name</param>
        /// <param name="propertyValue">Property value</param>
        ValueTask ValidateDomainObjectReferenceAsync(string propertyName, PropertyValue propertyValue);
    }
}
