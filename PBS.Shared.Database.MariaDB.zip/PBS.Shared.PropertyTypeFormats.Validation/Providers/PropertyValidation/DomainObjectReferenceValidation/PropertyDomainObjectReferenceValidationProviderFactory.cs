﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class PropertyDomainObjectReferenceValidationProviderFactory : IPropertyDomainObjectReferenceValidationProviderFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IOptions<IPropertyDomainObjectReferenceValidationProviderOptions> _options;

        public PropertyDomainObjectReferenceValidationProviderFactory(IServiceProvider serviceProvider, IOptions<IPropertyDomainObjectReferenceValidationProviderOptions> options)
        {
            _serviceProvider = serviceProvider;
            _options = options;
        }

        public bool ContainsProvidersForDomain(string domain)
        {
            return !string.IsNullOrWhiteSpace(domain) && _options.Value.GetAllProviderTypes().ContainsKey(domain);
        }

        public IEnumerable<IPropertyDomainObjectReferenceValidationProvider> ResolveProviders(string? domain)
        {
            if (string.IsNullOrWhiteSpace(domain))
                return Enumerable.Empty<IPropertyDomainObjectReferenceValidationProvider>();

            List<IPropertyDomainObjectReferenceValidationProvider> providers = new();

            if (_options.Value.GetAllProviderTypes().TryGetValue(domain, out IEnumerable<Type>? domainProviderTypes))
            {
                foreach (var providerType in domainProviderTypes)
                    if (_serviceProvider.GetService(providerType) is IPropertyDomainObjectReferenceValidationProvider validationProvider)
                        providers.Add(validationProvider);
            }

            return providers;
        }
    }
}