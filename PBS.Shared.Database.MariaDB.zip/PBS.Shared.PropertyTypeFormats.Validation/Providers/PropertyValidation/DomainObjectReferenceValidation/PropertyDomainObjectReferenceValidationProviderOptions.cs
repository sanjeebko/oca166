﻿using Microsoft.Extensions.Options;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class PropertyDomainObjectReferenceValidationProviderOptions : IOptions<IPropertyDomainObjectReferenceValidationProviderOptions>, IPropertyDomainObjectReferenceValidationProviderOptions
    {
        private readonly Dictionary<string, List<Type>> _mappings = new Dictionary<string, List<Type>>();

        public IPropertyDomainObjectReferenceValidationProviderOptions Value => this;

        public void RegisterProvider<T>(string domain) where T : IPropertyDomainObjectReferenceValidationProvider
        {
            Requires.NotNull(domain, nameof(domain));

            Type providerType = typeof(T);

            if (!_mappings.ContainsKey(domain))
                _mappings.Add(domain, new List<Type>());

            List<Type> domainProviderTypes = _mappings[domain];

            if (domainProviderTypes.Contains(providerType))
                return;
            domainProviderTypes.Add(providerType);
        }

        public IReadOnlyDictionary<string, IEnumerable<Type>> GetAllProviderTypes() => _mappings.ToDictionary(pair => pair.Key, pair => pair.Value.AsEnumerable());
    }
}
