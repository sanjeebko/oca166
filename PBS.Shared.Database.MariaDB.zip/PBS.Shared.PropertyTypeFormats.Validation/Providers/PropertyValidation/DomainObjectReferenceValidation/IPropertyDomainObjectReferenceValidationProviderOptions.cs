﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public interface IPropertyDomainObjectReferenceValidationProviderOptions
    {
        /// <summary>
        /// Get's all registered providers types
        /// </summary>
        IReadOnlyDictionary<string, IEnumerable<Type>> GetAllProviderTypes();
    }
}