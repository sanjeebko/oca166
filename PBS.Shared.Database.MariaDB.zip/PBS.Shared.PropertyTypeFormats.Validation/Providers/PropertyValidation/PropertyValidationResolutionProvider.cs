﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Logging;
using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using PBS.Shared.PropertyTypeFormats.Validation.Helpers;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class PropertyValidationResolutionProvider : ValidationResolutionProvider, IPropertyValidationResolutionProvider
    {
        private readonly IPropertyDomainObjectReferenceValidationProviderFactory _domainObjectReferenceValidationProviderFactory;

        public PropertyValidationResolutionProvider(
            ILogger<PropertyValidationResolutionProvider> logger,
            IValidatorFactory validatorFactory,
            IValidatorExecutionService validatorExecutionService,
            IPropertyDomainObjectReferenceValidationProviderFactory domainObjectReferenceValidationProviderFactory) : base(logger, validatorFactory, validatorExecutionService)
        {
            _domainObjectReferenceValidationProviderFactory = domainObjectReferenceValidationProviderFactory;
        }

        public override async ValueTask<ValidationResolutionResult> PerformValidationAsync(ValidationRequest request)
        {
            try
            {
                IEnumerable<PropertyValidationExecutionResults> validationResult = await ValidatePropertiesAsync(request);

                return new ValidationResolutionResult(Format: request.Format, IsSuccessful: !validationResult.Any(), ValidationErrors: validationResult);
            }
            catch (PropertyValidationException e)
            {
                Logger.LogTrace(e, "Property validation failed");
                return new ValidationResolutionResult(Format: request.Format, IsSuccessful: false, ValidationErrors: ValidationServiceHelper.BuildPropertyValidationExecutionResultsFromException(e));
            }
        }

        protected virtual async ValueTask<IReadOnlyList<PropertyValidationExecutionResults>> ValidatePropertiesAsync(ValidationRequest validationRequest)
        {
            List<PropertyValidationExecutionResults> indexedResults = new();

            foreach ((string propertyName, PropertyFormat propertyFormat) in validationRequest.PropertyFormats)
            {
                if (IsPropertyMissing(validationRequest, propertyName))
                {
                    indexedResults.Add(new PropertyValidationExecutionResults(propertyName, new List<ValidationExecutionResult> { ValidationServiceHelper.BuildFailedValidatorValidationExecutionResultFromString(ValidatorKeys.Required, "Required Property is missing") }));
                    continue;
                }

                IEnumerable<ValidationExecutionResult> validationResults = await ExecutePropertyValidationAsync(validationRequest, propertyName, propertyFormat);

                if (validationResults.Any())
                    indexedResults.Add(new PropertyValidationExecutionResults(propertyName, validationResults));
            }
            return indexedResults;
        }

        private static bool IsPropertyMissing(ValidationRequest validationRequest, string propertyName) => !validationRequest.Properties.ContainsKey(propertyName);

        protected virtual async ValueTask<IReadOnlyList<ValidationExecutionResult>> ExecutePropertyValidationAsync(ValidationRequest validationRequest, string propertyName, PropertyFormat propertyFormat)
        {
            List<ValidationExecutionResult> validatorExecutionResults = new();

            List<PropertyValue> propertyValues = new() { validationRequest.Properties[propertyName] };

            for (int i = 0; i != propertyValues.Count; ++i)
            {
                PropertyValue propertyValue = propertyValues[i];
                PropertyType? propertyType = propertyFormat.Types.FirstOrDefault(type => type.Name == propertyValue.Type);

                if (propertyType == null)
                    throw new PropertyValidationException(propertyName, "Property Type provided does not match provided format types");
                if (propertyType.Name is null)
                    throw new PropertyValidationException(propertyName, "Property Type has a missing name value");

                await ValidatePropertyTypeAsync(propertyFormat, propertyType, propertyValue);

                validatorExecutionResults.AddRange(await ExecuteValidatorsAsync(propertyValue, propertyType.Validators));
            }

            return validatorExecutionResults.Where(result => !result.IsSuccessful).ToList();
        }

        protected virtual async ValueTask ValidatePropertyTypeAsync(PropertyFormat propertyFormat, PropertyType propertyType, PropertyValue propertyValue)
        {
            string propertyName = propertyFormat.Name ?? "Missing property Name";
            using var _ = Logger.WithProperty("{PropertyFormatName}", propertyName);
            Logger.LogTrace("Validating property");

            PropertyTypeValidationHelper.ValidatePropertyTypeIsAllowedType(propertyName, propertyValue);

            if (propertyValue.IsDomainObjectReference())
            {
                Requires.NotNull(propertyValue.Reference);

                string domain = DomainObjectReferences.GetDomainFromReference(propertyValue.Reference);

                if (_domainObjectReferenceValidationProviderFactory.ContainsProvidersForDomain(domain))
                {
                    await ValidateDomainObjectReferenceAsync(domain, propertyName, propertyValue);
                    return;
                }
            }

            propertyValue.Value = PropertyTypeValidationHelper.ValidatePropertyValueIsCorrectType(propertyName, propertyType, propertyValue.Value);
            PropertyTypeValidationHelper.ValidatePropertyValueIsAccepted(propertyName, propertyValue.Value, propertyType.AcceptedValues);

            Logger.LogTrace("property validated successfully");
        }

        private async ValueTask ValidateDomainObjectReferenceAsync(string domain, string propertyName, PropertyValue propertyValue)
        {
            try
            {
                IEnumerable<IPropertyDomainObjectReferenceValidationProvider> domainObjectReferenceValidationProviders = _domainObjectReferenceValidationProviderFactory.ResolveProviders(domain).ToList();
                foreach (IPropertyDomainObjectReferenceValidationProvider domainReferenceValidationProvider in domainObjectReferenceValidationProviders)
                    await domainReferenceValidationProvider.ValidateDomainObjectReferenceAsync(propertyName, propertyValue);
            }
            catch (PropertyValidationException)
            {
                throw;
            }
            catch (Exception e)
            {
                Logger.LogTrace(e, "Error occurred while validating {PropertyName} with domain reference validation providers for domain {Domain}", propertyName, domain);
                throw new PropertyValidationException(property: propertyName, message: e.Message);
            }
        }

        protected virtual async ValueTask<IReadOnlyList<ValidationExecutionResult>> ExecuteValidatorsAsync(PropertyValue propertyValue, IDictionary<string, object> propertyTypeValidators)
        {
            List<ValidationExecutionResult> resolutionResults = new();
            foreach ((string validatorKey, object validatorParameters) in propertyTypeValidators)
            {
                object? data = propertyValue.ContainsReferences() ? propertyValue.Reference : propertyValue.Value;
                resolutionResults.Add(await ExecuteValidatorAsync(data, validatorKey, validatorParameters));
            }
            return resolutionResults;
        }
    }
}