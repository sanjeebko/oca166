﻿using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using PBS.Shared.PropertyTypeFormats.Validation.Helpers;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public static class PropertyValidationHelper
    {
        private const string ErrorSeparationCharacter = ";";

        public static string BuildErrorStringFromValidationErrors(this ValidationResolutionResults validationResults)
        {
            Dictionary<string, List<ValidationExecutionResult>> propertyErrors = ExtractPropertyValidationExecutionResults(validationResults.Results);

            var builder = new StringBuilder();

            foreach (var error in propertyErrors)
                builder.Append($"{error.Key}: {string.Join(", ", error.Value.Select(result => $"{result.Source} - {result.ErrorString}"))}. {ErrorSeparationCharacter}");

            return builder.ToString();
        }

        public static Dictionary<string, List<ValidationExecutionResult>> ExtractPropertyValidationExecutionResults(IEnumerable<ValidationResolutionResult> results)
        {
            return results.AsEnumerable()
                .SelectMany(validationResolutionResult => validationResolutionResult.ValidationErrors)
                .OfType<PropertyValidationExecutionResults>()
                .ToDictionary(propertyValidationExecutionResults => propertyValidationExecutionResults.Property, propertyValidationExecutionResults => propertyValidationExecutionResults.Results.ToList());
        }

        public static List<ValidationExecutionResults> BuildObjectValidationExecutionResultsFromException(ValidationException e) => new()
        {
            new ValidationExecutionResults(ValidationServiceHelper.BuildValidationExecutionResultCollectionFromException(e))
        };
    }
}
