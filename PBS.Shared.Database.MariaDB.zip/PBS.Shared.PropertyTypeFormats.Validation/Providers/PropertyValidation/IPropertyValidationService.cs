﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public interface IPropertyValidationService
    {
        ValueTask ValidateAsync(string formatTypeName, IReadOnlyDictionary<string, PropertyValue> properties);
    }
}