﻿using PBS.Shared.ErrorHandling;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    public class PropertyValidationService : IPropertyValidationService
    {
        private readonly IValidationResolutionService _validationResolutionService;

        public PropertyValidationService(IValidationResolutionService validationResolutionService)
        {
            _validationResolutionService = validationResolutionService;
        }

        public async ValueTask ValidateAsync(string formatTypeName, IReadOnlyDictionary<string, PropertyValue> properties)
        {
            var formats = TypeFormats.Instance.GetTypeFormat(formatTypeName)?.Properties ?? throw new InvalidOperationException($"Format {formatTypeName} could not be found");
            ValidationRequest request = BuildValidationRequest(formatTypeName, properties, formats);

            ValidationResolutionResults result = await _validationResolutionService.PerformValidationAsync(request);

            if (result.IsSuccessful)
                return;

            throw new EntityValidationException(result.BuildErrorStringFromValidationErrors());
        }

        private static ValidationRequest BuildValidationRequest(string formatTypeName, IReadOnlyDictionary<string, PropertyValue> properties, IDictionary<string, PropertyFormat> formats) => new()
        {
            Format = formatTypeName,
            Properties = new Dictionary<string, PropertyValue>(properties),
            PropertyFormats = formats
        };

    }
}
