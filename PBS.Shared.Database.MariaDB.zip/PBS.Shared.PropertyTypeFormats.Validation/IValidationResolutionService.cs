﻿using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Validation
{
    /// <summary>
    /// Validation service for validating <see cref="PropertyValue"/> against <see cref="PropertyFormat"/> using registered <see cref="IValidationResolutionProvider"/> and validators <see cref="IValidator"/>
    /// </summary>
    public interface IValidationResolutionService
    {
        /// <summary>
        /// Performs validation based on request parameters.
        /// Validation is perform by using provided properties in request and validating them through all registered <see cref="IValidationResolutionProvider"/> providers.
        /// By default validation will be performed with property validation provider which validates provided properties against provided formats in <param name="request"></param> and executing any defined validator for that property
        /// If other providers are registered, like provider to validation <see cref="ITypeFormat"/> object, then same request will be run on that provider implementation
        /// </summary>
        /// <param name="request">Validation request</param>
        /// <returns>Result <see cref="ValidationResolutionResults"/> which contains collection of <see cref="ValidationResolutionResult"/> return by <see cref="IValidationResolutionProvider"/> implemented providers
        /// </returns>
        /// <remarks>
        /// If all results are successful then this response will be marked as successful
        /// </remarks>
        ValueTask<ValidationResolutionResults> PerformValidationAsync(ValidationRequest request);
    }
}
