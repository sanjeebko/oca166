﻿using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using PBS.Shared.PropertyTypeFormats.Validation.Models;
using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.Validation.Helpers
{
    public static class ValidationServiceHelper
    {
        public static ValidationExecutionResult BuildFailedValidatorValidationExecutionResultFromString(string validatorKey, string message) => new ValidationExecutionResult(Source: validatorKey, IsSuccessful: false, ErrorString: message);

        public static List<PropertyValidationExecutionResults> BuildPropertyValidationExecutionResultsFromException(PropertyValidationException e) => new List<PropertyValidationExecutionResults>
        {
            new PropertyValidationExecutionResults(e.ValidationSource, BuildValidationExecutionResultCollectionFromException(e))
        };

        public static List<ValidationExecutionResult> BuildValidationExecutionResultCollectionFromException(ValidationException e) => new List<ValidationExecutionResult>
        {
            new ValidationExecutionResult(Source: e.ValidationSource, IsSuccessful: false, ErrorString: e.Message)
        };
    }
}
