﻿using PBS.Shared.PropertyTypeFormats.Validation.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats.Validation.Helpers
{
    public static class PropertyTypeValidationHelper
    {
        public static void ValidatePropertyTypeIsAllowedType(string propertyName, PropertyValue value)
        {
            if (!PropertyTypes.AllowedPropertyTypes.Contains(GetPropertyTypeFromPropertyValue(propertyName, value)))
            {
                throw new PropertyValidationException(propertyName, "Does not have a valid type");
            }
        }

        public static string GetPropertyTypeFromPropertyValue(string propertyName, PropertyValue propertyValue)
        {
            if (propertyValue.Type is null)
                throw new ArgumentException($"Property {propertyName} has empty property type");
            return propertyValue.Type;
        }

        public static void ValidatePropertyValueIsAccepted(string propertyName, object? value, IEnumerable<object> acceptedValues)
        {
            if (!acceptedValues.Any())
                return;

            if (!acceptedValues.Contains(value))
                throw new PropertyValidationException(propertyName, "Value is not an accepted type");
        }

        public static object? ValidatePropertyValueIsCorrectType(string propertyName, PropertyType propertyType, object? propertyValue)
        {
            if (string.IsNullOrEmpty(propertyValue?.ToString()))
                return null;

            object? result = propertyType.Name switch
            {
                PropertyTypes.StringValue => ConvertObjectPropertyType<string>(propertyValue),
                PropertyTypes.NumberValue => ConvertObjectPropertyToNumber(propertyValue),
                PropertyTypes.BooleanValue => ConvertObjectPropertyTypeToBoolean(propertyValue),
                _ => throw new ArgumentException("Property Type is not a basic type")
            };

            if (result == null)
                throw new PropertyValidationException(property: propertyName, message: $"Value is not the correct type, expected {propertyType.Name}");
            return result;
        }

        public static T? ConvertObjectPropertyType<T>(object? value) where T : class
        {
            if (value is T valueT)
                return valueT;
            return default;
        }

        public static bool? ConvertObjectPropertyTypeToBoolean(object? value)
        {
            if (value is bool boolean)
                return boolean;
            return null;
        }

        public static int? ConvertObjectPropertyToNumber(object? value)
        {
            if (value is int number)
                return number;
            return int.TryParse(value?.ToString(), out number) ? number : null;
        }
    }
}
