﻿using System.Linq;
using System.Runtime.InteropServices;

namespace PBS.Shared.RemoteShare
{
    public class RemoteShareRuntimeInformationService : IRemoteShareRuntimeInformationService
    {
        private readonly OSPlatform[] _osPlatforms = new OSPlatform[] { OSPlatform.Linux, OSPlatform.Windows, OSPlatform.FreeBSD, OSPlatform.OSX};

        public bool IsOSPlatform(OSPlatform platform) => RuntimeInformation.IsOSPlatform(platform);

        public OSPlatform GetOSPlatform() => _osPlatforms.FirstOrDefault(osPlatform => IsOSPlatform(osPlatform));
    }
}
