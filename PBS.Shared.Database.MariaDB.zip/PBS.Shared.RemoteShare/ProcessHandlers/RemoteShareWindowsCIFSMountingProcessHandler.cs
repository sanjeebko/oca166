﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare.Exceptions;
using PBS.Shared.RemoteShare.Factory;
using System.IO;

namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public class RemoteShareWindowsCIFSMountingProcessHandler : RemoteShareProcessHandler
    {
        public RemoteShareWindowsCIFSMountingProcessHandler(ILogger logger, IRemoteProcessFactory mountProcessFactory) : base(logger, mountProcessFactory) { }

        private const string ViableDriveLetters = "ZYXWVUTSRQPONMLKJIHGFED";

        protected override string GetMountingCommand() => "net";

        protected override string GetUnMountingCommand() => "net";

        protected override string GetResultPath(string targetPath) => FindAvailableWindowsDriveLetter();

        protected override string GetUnMountingArgs(string targetPath) => $" use  {targetPath} /delete";

        private static string FindAvailableWindowsDriveLetter()
        {
            foreach (char c in ViableDriveLetters)
            {
                if (!Directory.Exists($"{c}:" + Path.DirectorySeparatorChar))
                    return $"{c}:";
            }

            throw new FileMountFailedException("No available windows drive letters");
        }

        protected override string GetMountingArgs(FileShareCredentials fileShareCredentials, string localStoragePath)
        {
            string? user = string.IsNullOrEmpty(fileShareCredentials.UserDomain) ? fileShareCredentials.UserName : $"{fileShareCredentials.UserDomain}\\{fileShareCredentials.UserName}";

            return $"use {localStoragePath} \"{fileShareCredentials.MountPath}\" /user:\"{user}\" \"{fileShareCredentials.Password}\"";
        }
    }
}
