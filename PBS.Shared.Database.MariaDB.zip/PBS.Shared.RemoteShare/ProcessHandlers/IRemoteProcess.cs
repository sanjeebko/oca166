namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public interface IRemoteProcess
    {
        int ExitCode { get; }
        string GetErrorString();
        bool Start();
        bool WaitForExit(int milliseconds);
    }
}
