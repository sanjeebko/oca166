﻿namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public interface IRemoteShareMountingProcessHandler
    {
        string MountDrive(FileShareCredentials credentials, string localStorageLocation, bool useCurrentDirectoryExtension = false);

        bool UnMountDrive(string path);
    }
}
