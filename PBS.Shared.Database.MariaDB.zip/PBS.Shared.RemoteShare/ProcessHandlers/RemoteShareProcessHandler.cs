﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare.Exceptions;
using PBS.Shared.RemoteShare.Factory;
using System;

namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public abstract class RemoteShareProcessHandler : IRemoteShareMountingProcessHandler
    {
        private const int MountingTimeout = 10000;
        private readonly ILogger _logger;
        private readonly IRemoteProcessFactory _remoteProcessFactory;

        protected RemoteShareProcessHandler(ILogger logger, IRemoteProcessFactory remoteProcessFactory)
        {
            _logger = logger;
            _remoteProcessFactory = remoteProcessFactory;
        }

        protected abstract string GetMountingCommand();

        protected abstract string GetMountingArgs(FileShareCredentials fileShareCredentials, string localStoragePath);

        protected abstract string GetUnMountingCommand();

        protected abstract string GetUnMountingArgs(string targetPath);

        protected abstract string GetResultPath(string targetPath);

        private string GetMountPathResultPath(string localStoragePath, bool useCurrentDirectoryExtension)
        {
            return useCurrentDirectoryExtension ? localStoragePath : GetResultPath(localStoragePath);
        }

        public string MountDrive(FileShareCredentials credentials, string localStorageLocation, bool useCurrentDirectoryExtension = false)
        {
            string localStoragePath = GetMountPathResultPath(localStorageLocation, useCurrentDirectoryExtension);

            try
            {
                string mountingCommand = GetMountingCommand();
                string mountingArgs = GetMountingArgs(credentials, localStoragePath);
                _logger.LogDebug("Attempting to mount the drive with the command {MountingCommand} {MountingArgs}", mountingCommand, ObfuscatePassword(credentials, mountingArgs));
                var mountProcess = _remoteProcessFactory.GetProcessForMount(mountingCommand, mountingArgs);

                if (!mountProcess.Start())
                    SantiseMessageAndThrowException(mountProcess);

                if (!mountProcess.WaitForExit(MountingTimeout))
                    throw new NetworkConnectionTimeOutException($"Network connection timed out after {TimeSpan.FromMilliseconds(MountingTimeout)}.");

                if (mountProcess.ExitCode != OSErrorCodeHelper.SuccessErrorCode)
                    SantiseMessageAndThrowException(mountProcess);

                return localStoragePath;
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Mount drive failed due to OS Error.");
                throw;
            }
        }

        public bool UnMountDrive(string path)
        {
            try
            {
                string unmountingCommand = GetUnMountingCommand();
                string unmountingArgs = GetUnMountingArgs(path);
                _logger.LogDebug("Attempting to unmount the drive with the command {MountingCommand} {MountingArgs}", unmountingCommand, unmountingArgs);
                var unmountProcess = _remoteProcessFactory.GetProcessForMount(unmountingCommand, unmountingArgs);

                if (!unmountProcess.Start())
                    SantiseMessageAndThrowException(unmountProcess);

                if (!unmountProcess.WaitForExit(MountingTimeout))
                    throw new NetworkConnectionTimeOutException($"Network connection timed out.");

                if (unmountProcess.ExitCode != OSErrorCodeHelper.SuccessErrorCode && unmountProcess.ExitCode != OSErrorCodeHelper.GetPermissionDeniedErrorCode())
                    SantiseMessageAndThrowException(unmountProcess);

                return true;
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Unmount drive failed due to OS Error.");
                throw;
            }
        }

        private static string GetProcessErrorText(IRemoteProcess process)
        {
            try
            {
                return process.GetErrorString();
            }
            catch
            {
                throw new FileMountFailedException("File mount failed due to OS Error, unable to get error text from OS.");
            }
        }

        private static string ObfuscatePassword(FileShareCredentials credentials, string mountArgString)
        {
            if (credentials.Password == null)
                return mountArgString;

            string replacementString = new string('*', credentials.Password.Length);
            return mountArgString.Replace(credentials.Password, replacementString);
        }

        private static void SantiseMessageAndThrowException(IRemoteProcess process)
        {
            OSErrorCodeHelper.GetOSException(process.ExitCode, out Exception? foundException);
            throw foundException ?? new FileMountFailedException(GetProcessErrorText(process));
        }
    }
}
