﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare.Factory;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public class RemoteShareLinuxCIFSMountingProcessHandler : RemoteShareProcessHandler
    {
        public RemoteShareLinuxCIFSMountingProcessHandler(ILogger logger, IRemoteProcessFactory mountProcessFactory) : base(logger, mountProcessFactory) { }

        private const string UserMountOption = "user";
        private const string PasswordMountOption = "password";
        private const string DomainMountOption = "domain";

        protected override string GetMountingCommand() => "mount";

        protected override string GetUnMountingCommand() => "umount";

        protected override string GetUnMountingArgs(string targetPath) => targetPath;

        protected override string GetResultPath(string targetPath) => GenerateFolderPath(targetPath);

        private static string GenerateFolderPath(string targetPath)
        {
            string candidateFileString;
            do
            {
                candidateFileString = @$"{targetPath}/{Guid.NewGuid().ToString("N")[..7]}";
            }
            while (Directory.Exists(candidateFileString));
            Directory.CreateDirectory(candidateFileString);
            return candidateFileString;
        }

        protected override string GetMountingArgs(FileShareCredentials fileShareCredentials, string localStoragePath)
        {
            var mountOptions = (new Dictionary<string, string?>()
            {
                [UserMountOption] = fileShareCredentials.UserName,
                [PasswordMountOption] = fileShareCredentials.Password,
                [DomainMountOption] = fileShareCredentials.UserDomain,
            })
                .Where(pair => !string.IsNullOrWhiteSpace(pair.Value))
                .Select(pair => $"{pair.Key}={pair.Value}");

            return $"-t cifs -o {string.Join(",", mountOptions)} \"//{fileShareCredentials.MountPath}\" \"{localStoragePath}\"";
        }
    }
}
