﻿using System.Diagnostics;

namespace PBS.Shared.RemoteShare.ProcessHandlers
{
    public class RemoteProcess : IRemoteProcess
    {
        private readonly Process _process;

        public RemoteProcess(Process process)
        {
            _process = process;
        }

        public int ExitCode => _process.ExitCode;

        public string GetErrorString() 
        {
            return _process.StandardError.ReadToEnd();
        }

        public bool Start()
        {
            return _process.Start();
        }

        public bool WaitForExit(int milliseconds)
        {
            return _process.WaitForExit(milliseconds);
        }

    }
}