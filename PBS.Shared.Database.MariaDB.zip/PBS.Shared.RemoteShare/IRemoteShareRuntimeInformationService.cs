﻿using System.Runtime.InteropServices;

namespace PBS.Shared.RemoteShare
{
    public interface IRemoteShareRuntimeInformationService
    {
        bool IsOSPlatform(OSPlatform platform);
        
        OSPlatform GetOSPlatform();
    }
}