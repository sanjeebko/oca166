﻿using System;

namespace PBS.Shared.RemoteShare
{
    public class FileShareCredentials : ICloneable
    {
        public FileShareCredentials() { }
        public FileShareCredentials(FileShareCredentials other)
        {
            UserName = other.UserName;
            MountPath = other.MountPath;
            Password = other.Password;
            UserDomain = other.UserDomain;
        }

        public string? UserName { get; set; } = "";
        public string MountPath { get; set; } = "";
        public string? Password { get; set; } = "";
        public string UserDomain { get; set; } = "";

        public object Clone()
        {
            return new FileShareCredentials(this);
        }
    }
}