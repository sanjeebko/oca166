﻿using PBS.Shared.RemoteShare.ProcessHandlers;

namespace PBS.Shared.RemoteShare.Factory
{
    public interface IRemoteProcessFactory
    {
        IRemoteProcess GetProcessForMount(string filename, string args);
    }
}