﻿using PBS.Shared.RemoteShare.ProcessHandlers;
using System.Diagnostics;

namespace PBS.Shared.RemoteShare.Factory
{
    public class MountProcessFactory : IRemoteProcessFactory
    {
        public IRemoteProcess GetProcessForMount(string filename, string args)
        {
            var process = new Process();
            process.StartInfo.FileName = filename;
            process.StartInfo.Arguments = args;
            process.StartInfo.UseShellExecute = false;
            process.StartInfo.RedirectStandardError = true;

            return new RemoteProcess(process);
        }
    }
}
