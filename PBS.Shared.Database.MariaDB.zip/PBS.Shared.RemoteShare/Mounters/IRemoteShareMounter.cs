﻿using System;

namespace PBS.Shared.RemoteShare.Mounters
{
    public interface IRemoteShareMounter : IDisposable
    {
        string MountDrive(FileShareCredentials credentials, string localStoragePath, MountType mountType = MountType.CIFS);
        string RemountDrive();
        string AbsoluteFilePath { get; }
        bool IsMounted { get; }
    }
}
