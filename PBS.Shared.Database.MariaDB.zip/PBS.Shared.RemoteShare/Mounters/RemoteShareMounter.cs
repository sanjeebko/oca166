﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare.Exceptions;
using PBS.Shared.RemoteShare.Extensions;
using PBS.Shared.RemoteShare.Factory;
using PBS.Shared.RemoteShare.ProcessHandlers;
using System;
using System.Runtime.InteropServices;

namespace PBS.Shared.RemoteShare.Mounters
{
    public class RemoteShareMounter : IRemoteShareMounter
    {
        private readonly ILogger _logger;
        private readonly IRemoteProcessFactory _processFactory;
        private readonly IRemoteShareRuntimeInformationService _runtimeInformationService;

        public string AbsoluteFilePath { get; protected set; } = "";
        public bool IsMounted { get; private set; } = false;

        private bool _mountHasBeenAttempted = false;
        private FileShareCredentials? _fileShareCredentials;
        protected IRemoteShareMountingProcessHandler? MountingProcessHandler { get; set; }

        public RemoteShareMounter(ILogger<RemoteShareMounter> logger, IRemoteShareRuntimeInformationService runtimeInformationService, IRemoteProcessFactory processFactory)
        {
            _logger = logger;
            _runtimeInformationService = runtimeInformationService;
            _processFactory = processFactory;
        }

        protected IRemoteShareMountingProcessHandler GetCorrectMountingProcessHandler() => RuntimeInformation.IsOSPlatform(OSPlatform.Windows)
                                                                                     ? new RemoteShareWindowsCIFSMountingProcessHandler(_logger, _processFactory)
                                                                                     : new RemoteShareLinuxCIFSMountingProcessHandler(_logger, _processFactory);

        public string MountDrive(FileShareCredentials credentials, string localStoragePath, MountType mountType = MountType.CIFS)
        {

            if (IsMounted)
                throw new FileMountFailedException("Drive is already mounted, please unmount before try to mount or call remount");

            if (_runtimeInformationService.IsOSPlatform(OSPlatform.OSX) || _runtimeInformationService.IsOSPlatform(OSPlatform.FreeBSD))
                throw new NotImplementedException("Your OS is not currently supported for mounting files and drives.");

            ValidateCredentials(credentials);
            MountingProcessHandler ??= GetCorrectMountingProcessHandler();

            _fileShareCredentials = (FileShareCredentials)credentials.Clone();
            _fileShareCredentials.MountPath = SanitiseNetworkPathForPlatform(_fileShareCredentials.MountPath, _runtimeInformationService.GetOSPlatform());

            localStoragePath = SanitisePathForPlatform(localStoragePath, _runtimeInformationService.GetOSPlatform());

            _mountHasBeenAttempted = true;
            _logger.LogDebug("Attempting to mount drive {CredentialsMountPath}", _fileShareCredentials.MountPath);

            AbsoluteFilePath = MountingProcessHandler.MountDrive(_fileShareCredentials, localStoragePath);

            IsMounted = true;
            return AbsoluteFilePath;
        }

        private void ValidateCredentials(FileShareCredentials credentials)
        {
            if (!credentials.RequiredCredentialsAreNotNullOrEmpty())
            {
                _logger.LogError("Credentials were incomplete.");
                throw new FileShareCredentialsMissingException("Credentials were incomplete.");
            }
        }

        public string RemountDrive()
        {
            if (!_mountHasBeenAttempted || MountingProcessHandler == null || _fileShareCredentials == null)
                throw new FileMountFailedException("Cannot attempt a remount until a mount has been attempted with valid credentials");

            if (IsMounted && !MountingProcessHandler.UnMountDrive(AbsoluteFilePath))
                throw new FileMountFailedException("Unmounting old file share failed");

            AbsoluteFilePath = MountingProcessHandler.MountDrive(_fileShareCredentials, AbsoluteFilePath, true);

            IsMounted = true;
            return AbsoluteFilePath;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private bool _disposed = false;

        protected virtual void Dispose(bool disposing)
        {
            if (_disposed)
                return;

            if (disposing && IsMounted && (MountingProcessHandler != null))
                IsMounted = !MountingProcessHandler.UnMountDrive(AbsoluteFilePath);

            _disposed = true;
        }

        private static string SanitisePathForPlatform(string filePath, OSPlatform platform)
        {
            filePath = filePath.RemoveInvalidMountCharacters();

            if (platform == OSPlatform.Windows)
                return filePath.Replace("/", @"\").TrimEnd('\\');

            return filePath.Replace(@"\", "/").TrimEnd('/');
        }

        private static string SanitiseNetworkPathForPlatform(string networkPath, OSPlatform platform)
        {
            networkPath = SanitisePathForPlatform(networkPath, platform);

            if (platform == OSPlatform.Linux)
                return networkPath.TrimStart('/');

            if (networkPath.StartsWith(@"\\"))
                return networkPath;
            return networkPath.StartsWith(@"\") ? $@"\{networkPath}" : $@"\\{networkPath}";
        }
    }
}
