﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.RemoteShare.Factory;
using PBS.Shared.RemoteShare.Mounters;

namespace PBS.Shared.RemoteShare.Extensions
{
    public static class RemoteShareExtensions
    {
        public static IServiceCollection AddRemoteShare(this IServiceCollection services)
        {
            services.AddTransient<IRemoteShareMounter, RemoteShareMounter>();
            services.AddSingleton<IRemoteProcessFactory, MountProcessFactory>();
            services.AddSingleton<IRemoteShareRuntimeInformationService, RemoteShareRuntimeInformationService>();

            return services;
        }
    }
}
