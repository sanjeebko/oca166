﻿namespace PBS.Shared.RemoteShare.Extensions
{
    public static class StringExtensions
    {
        private static readonly char[] InvalidMountPathCharacters = { '"' };

        public static string RemoveInvalidMountCharacters(this string mountPath)
        {
            return string.Join("", mountPath.Split(InvalidMountPathCharacters));
        }
    }
}
