﻿namespace PBS.Shared.RemoteShare.Extensions
{
    public static class FileShareCredentialsExtensions
    {
        public static bool RequiredCredentialsAreNotNullOrEmpty(this FileShareCredentials? credentials)
        {
            return !(credentials == null || string.IsNullOrEmpty(credentials.MountPath) || string.IsNullOrEmpty(credentials.Password) || string.IsNullOrEmpty(credentials.UserName));
        }
    }
}