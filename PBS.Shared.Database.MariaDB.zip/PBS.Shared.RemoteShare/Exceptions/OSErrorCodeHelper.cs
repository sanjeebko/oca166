﻿using System;
using System.Collections.Generic;
using System.Runtime.InteropServices;

namespace PBS.Shared.RemoteShare.Exceptions
{
    public static class OSErrorCodeHelper
    {
        public const int SuccessErrorCode = 0;

        private static readonly InvalidCredentialsException _invalidCredentialsException = new InvalidCredentialsException("Permission denied");
        private static readonly FileMountFailedException _fileMountingException = new FileMountFailedException("File is currently busy");

        private static Dictionary<int, Exception> linuxErrors = new Dictionary<int, Exception>()
        {
            { 32, _invalidCredentialsException },
            { 16, _fileMountingException },
            { 27, _fileMountingException }
        };

        private static Dictionary<int, Exception> windowsErrors = new Dictionary<int, Exception>()
        {
            { 2, _invalidCredentialsException },
            { 170, _fileMountingException },
            { 223, _fileMountingException }
        };

        public static void GetOSException(int exceptionCode, out Exception? foundException)
        {
            if (IsWindows())
            {
                windowsErrors.TryGetValue(exceptionCode, out foundException);
            }
            else
            {
                linuxErrors.TryGetValue(exceptionCode, out foundException);
            }
        }

        public static int GetPermissionDeniedErrorCode() => IsWindows() ? 2 : 32;
        public static int GetFileBusyPermissionCode() => IsWindows() ? 170 : 16;
        public static int GetFileTooLargeCode() => IsWindows() ? 223 : 27;

        private static bool IsWindows() => RuntimeInformation.IsOSPlatform(OSPlatform.Windows);
    }
}
