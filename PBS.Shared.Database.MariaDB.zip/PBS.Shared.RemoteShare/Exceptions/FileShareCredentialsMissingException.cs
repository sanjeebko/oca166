﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.RemoteShare.Exceptions
{
    [Serializable]
    public class FileShareCredentialsMissingException : Exception
    {
        public FileShareCredentialsMissingException()
        {
        }

        public FileShareCredentialsMissingException(string message) : base(message)
        {
        }

        public FileShareCredentialsMissingException(string message, Exception inner) : base(message, inner)
        {
        }

        protected FileShareCredentialsMissingException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}