﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.RemoteShare.Exceptions
{
    [Serializable]
    public class FileMountFailedException : Exception
    {
        public FileMountFailedException()
        {
        }

        public FileMountFailedException(string message): base(message) 
        {
        }

        public FileMountFailedException(string message, Exception inner): base(message, inner)
        {
        }

        protected FileMountFailedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
