﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.RemoteShare.Exceptions
{
    [Serializable]
    public class NetworkConnectionTimeOutException : Exception
    {
        public NetworkConnectionTimeOutException()
        {
        }

        public NetworkConnectionTimeOutException(string message) : base(message)
        {
        }

        public NetworkConnectionTimeOutException(string message, Exception inner) : base(message, inner)
        {
        }

        protected NetworkConnectionTimeOutException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
