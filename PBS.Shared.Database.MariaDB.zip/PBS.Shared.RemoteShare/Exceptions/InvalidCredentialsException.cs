﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.RemoteShare.Exceptions
{
    [Serializable]
    public class InvalidCredentialsException : Exception
    {
        public InvalidCredentialsException()
        {
        }

        public InvalidCredentialsException(string message) : base(message)
        {
        }

        public InvalidCredentialsException(string message, Exception inner) : base(message, inner)
        {
        }

        protected InvalidCredentialsException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
