﻿namespace PBS.Shared.RemoteShare
{
    public enum MountType
    {
        CIFS,
    }
}
