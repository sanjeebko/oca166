﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public interface ITypeFormats
    {
        IEnumerable<ITypeFormat> GetAll();
        IEnumerable<TFormat> GetAll<TFormat>() where TFormat : class, ITypeFormat;
        ITypeFormat? GetTypeFormat(string? formatType);
        TFormat? GetTypeFormat<TFormat>(string? formatType) where TFormat : class, ITypeFormat;
    }
}