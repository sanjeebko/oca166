﻿namespace PBS.Shared.PropertyTypeFormats
{
    public interface ITypeFormatInstance<out TFormat> where TFormat : class, ITypeFormat
    {
        TFormat Object { get; }
    }
}
