﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace PBS.Shared.PropertyTypeFormats
{
    public class TypeFormats : ITypeFormats
    {
        private static readonly Lazy<ITypeFormats> LazyInstance = new Lazy<ITypeFormats>(() => new TypeFormats(), LazyThreadSafetyMode.ExecutionAndPublication);

        public static ITypeFormats Instance => LazyInstance.Value;

        public ConcurrentDictionary<string, ITypeFormat> Formats { get; }

        public TypeFormats()
        {
            Formats = CreateTypeFormats();
        }

        private static ConcurrentDictionary<string, ITypeFormat> CreateTypeFormats()
        {
            return new ConcurrentDictionary<string, ITypeFormat>(LookupTypeFormats(new[] { typeof(TypeFormats).Assembly, Assembly.GetCallingAssembly(), Assembly.GetEntryAssembly(), Assembly.GetExecutingAssembly() }));
        }

        private static IDictionary<string, ITypeFormat> LookupTypeFormats(IEnumerable<Assembly?> assemblies)
        {
            IEnumerable<Type> types = LookupTypeFormatInstances(assemblies);

            var formats = new Dictionary<string, ITypeFormat>();

            foreach (var type in types)
            {
                object? instance = Activator.CreateInstance(type);
                if (instance == null)
                    continue;

                PropertyInfo? objectPropertyInfo = type.GetProperty(nameof(ITypeFormatInstance<ITypeFormat>.Object));

                object? objectInstance = objectPropertyInfo?.GetValue(instance);

                if (objectInstance is ITypeFormat typeFormat)
                {
                    if (string.IsNullOrWhiteSpace(typeFormat.Name))
                        continue;

                    var formatKey = CreateTypeFormatKey(typeFormat);
                    if (!formats.ContainsKey(formatKey))
                        formats.Add(formatKey, typeFormat);
                }
            }

            return formats;
        }

        private static List<Type> LookupTypeFormatInstances(IEnumerable<Assembly?> assemblies)
        {
            List<Type> types = new List<Type>();

            var lookupType = typeof(ITypeFormatInstance<>);

            foreach (Assembly? assembly in assemblies)
            {
                if (assembly is null)
                    continue;

                var formatTypes = GetAllTypes(assembly, lookupType).ToList();
                if (formatTypes.Any())
                    types.AddRange(formatTypes);
            }

            types = types.Distinct().ToList();
            return types;
        }

        public static IDictionary<string, ITypeFormat> RegisterFormatsFromAssembly(Assembly assembly)
        {
            var typeFormats = LookupTypeFormats(new[] { assembly });
            foreach (var pair in typeFormats)
            {
                ((TypeFormats)Instance).Formats.GetOrAdd(pair.Key, pair.Value);
            }
            return typeFormats;
        }

        public static string CreateTypeFormatKey(ITypeFormat format)
        {
            return format.Name ?? throw new InvalidOperationException("Invalid config object format name");
        }

        public IEnumerable<ITypeFormat> GetAll()
        {
            return Formats.Values;
        }

        public IEnumerable<TFormat> GetAll<TFormat>() where TFormat : class, ITypeFormat
        {
            return Formats.Values.OfType<TFormat>();
        }

        public ITypeFormat? GetTypeFormat(string? formatType)
        {
            if (string.IsNullOrWhiteSpace(formatType))
                return default;
            return Formats.TryGetValue(formatType, out ITypeFormat? configObjectFormat) ? configObjectFormat : default;
        }

        public TFormat? GetTypeFormat<TFormat>(string? formatType) where TFormat : class, ITypeFormat
        {
            if (string.IsNullOrWhiteSpace(formatType))
                return default;
            return Formats.TryGetValue(formatType, out ITypeFormat? configObjectFormat) ? configObjectFormat as TFormat : default;
        }

        private static IEnumerable<Type> GetAllTypes(Assembly assembly, Type genericType)
        {
            return assembly.GetTypes().Where(t => t.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == genericType));
        }
    }
}
