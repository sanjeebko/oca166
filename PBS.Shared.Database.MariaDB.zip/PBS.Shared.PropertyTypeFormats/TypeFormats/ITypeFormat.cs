﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public interface ITypeFormat
    {
        string? Name { get; }
        string? DisplayName { get; }
        IDictionary<string, PropertyFormat> Properties { get; }
        IDictionary<string, object> ObjectValidators { get; }
        bool Deprecated { get; }
        string? Hint { get; }
    }
}
