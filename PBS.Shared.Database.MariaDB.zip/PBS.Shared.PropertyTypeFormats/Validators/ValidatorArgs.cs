﻿namespace PBS.Shared.PropertyTypeFormats
{
    public static class ValidatorArgs
    {
        public const string Default = "";
    }
}
