﻿namespace PBS.Shared.PropertyTypeFormats
{
    public static class ValidatorKeys
    {
        public const string Required = "Required";
        public const string Max = "Max";
        public const string MaxLength = "MaxLength";
        public const string Min = "Min";
        public const string MinLength = "MinLength";
        public const string Pattern = "Pattern";
        public const string SmbConnection = "SmbConnection";
        public const string AmazonS3Connection = "AmazonS3Connection";
        public const string DemoValidator = "DemoValidator";
        public const string Unique = "Unique";
    }
}
