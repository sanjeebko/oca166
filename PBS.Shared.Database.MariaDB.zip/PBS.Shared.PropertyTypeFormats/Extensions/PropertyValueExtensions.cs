﻿using System;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class PropertyValueExtensions
	{
		public static string GetPropertyType(this PropertyValue property) => property.Type ?? throw new ArgumentNullException(nameof(property), "Property Value must never have a null type");
	}
}
