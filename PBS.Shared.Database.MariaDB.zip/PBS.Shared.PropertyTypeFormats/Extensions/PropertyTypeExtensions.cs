﻿using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class PropertyTypeExtensions
    {
        /// <returns>True if the property type does not specify accepted values, or if the property fits the accepted values</returns>
        public static bool AcceptsValue(this PropertyType propertyType, PropertyValue property) => !propertyType.AcceptedValues.Any() || propertyType.AcceptedValues.Contains(property.Value);
    }
}
