﻿using PBS.Shared.Comparers;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class PropertyFormatExtensions
	{
		
		/// <returns>True if any type in the format is required</returns>
		public static bool IsRequired(this PropertyFormat property)
        {
			return property.CollectionValidators.ContainsKey(ValidatorKeys.Required) || 
				   property.Types.Any((propertyType) => propertyType.Validators.ContainsKey(ValidatorKeys.Required));
        }


		/// <returns>True if the type of the given value is marked as required in the format</returns>
		public static bool IsRequired(this PropertyFormat property, PropertyValue value)
        {
			PropertyType? propertyType = property.Types.FirstOrDefault((propertyType) => propertyType.Name == value.Type);
			if(propertyType is null)
            {
				throw new ArgumentException("Type of value is not found in the given Property Format", nameof(value));
            }

			return property.CollectionValidators.ContainsKey(ValidatorKeys.Required) || propertyType.Validators.ContainsKey(ValidatorKeys.Required);
        }

        
        /// <returns>True if the given property format shares at least one type of the same name and accepted values list</returns>
        public static bool AreCompatibleProperties(this PropertyFormat left, PropertyFormat right)
        {
            List<PropertyType> compatibleTypes = GetCompatibleTypes(left.Types, right.Types);
            return compatibleTypes.Any();
        }

        private static List<PropertyType> GetCompatibleTypes(IEnumerable<PropertyType> leftTypes, IEnumerable<PropertyType> rightTypes)
            => leftTypes.Where(leftType =>
                rightTypes.Any(rightType =>
                    leftType.Name == rightType.Name &&
                    AreAcceptedValuesCompatible(leftType.AcceptedValues, rightType.AcceptedValues))).ToList();

        private static bool AreAcceptedValuesCompatible(IEnumerable<object> leftAcceptedValues, IEnumerable<object> rightAcceptedValues)
        {
            return leftAcceptedValues.ContentCompatible(rightAcceptedValues);
        }
    }
}
