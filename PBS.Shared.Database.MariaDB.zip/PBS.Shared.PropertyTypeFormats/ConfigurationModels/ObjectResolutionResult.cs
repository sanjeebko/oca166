﻿using PBS.Shared.PropertyTypeFormats.Resolutions;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.PropertyTypeFormats
{
    public class ObjectResolutionResult : IReferenceObject
    {
        [JsonIgnore]
        public string Id { get; set; } = string.Empty;
        [JsonPropertyName("hasErrors")]
        public bool HasErrors { get; set; }
        [JsonPropertyName("errors")]
        public List<PropertyResolutionErrorDto> Errors { get; set; } = new List<PropertyResolutionErrorDto>();
        [JsonPropertyName("data")]
        public Dictionary<string, PropertyValue> Data { get; set; } = new Dictionary<string, PropertyValue>();
    }
}
