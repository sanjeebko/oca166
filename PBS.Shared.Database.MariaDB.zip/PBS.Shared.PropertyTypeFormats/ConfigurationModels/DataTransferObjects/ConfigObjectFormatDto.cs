﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.PropertyTypeFormats.ConfigurationModels
{
    public class ConfigObjectFormatDto
    {
        public string? Name { get; set; }
        public string? Category { get; set; }
        public string? DisplayName { get; set; }
        public Dictionary<string, PropertyFormatDto> Properties { get; set; } = new Dictionary<string, PropertyFormatDto>();

        [JsonPropertyName("validators")]
        public Dictionary<string, object> ObjectValidators { get; set; } = new Dictionary<string, object>();
        public bool Deprecated { get; set; }
        public string? Hint { get; set; }
    }
}
