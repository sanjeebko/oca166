﻿using PBS.Shared.PropertyTypeFormats.Resolutions;
using System;
using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.ConfigurationModels
{
    public class ConfigObjectDetailsDto : IReferenceObject
    {
        public string Id { get; set; } = string.Empty;
        public string? Name { get; set; }
        public ConfigObjectFormatDto? TypeFormat { get; set; }
        public Dictionary<string, PropertyValueDto> Properties { get; set; } = new Dictionary<string, PropertyValueDto>();
        public DateTimeOffset CreationTime { get; set; }
        public DateTimeOffset LastUpdatedTime { get; set; }
        public string? Creator { get; set; }
    }
}
