﻿namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyResolutionErrorDto
    {
        public string Id { get; set; } = string.Empty;
        public string Error { get; set; } = string.Empty;
    }
}
