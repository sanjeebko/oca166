﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats.ConfigurationModels
{
    public class ConfigObjectDto
    {
        public string? Name { get; set; }
        public string? FormatTypeName { get; set; }
        public Dictionary<string, PropertyValueDto> Properties { get; set; } = new Dictionary<string, PropertyValueDto>();
        public string? Creator { get; set; }
    }
}
