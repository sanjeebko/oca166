﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public record PropertyType
    {
        public string? Name { get; set; }
        public Dictionary<string, object> Validators { get; set; } = new Dictionary<string, object>();
        public IEnumerable<object> AcceptedValues { get; set; } = Enumerable.Empty<object>();
        public object? SuggestedDefault { get; set; }
    }
}