﻿namespace PBS.Shared.PropertyTypeFormats
{
    public enum FormatPropertyMetadata
    {
        Sensitive,
        Password,
        Collection,
        File,
    }
}
