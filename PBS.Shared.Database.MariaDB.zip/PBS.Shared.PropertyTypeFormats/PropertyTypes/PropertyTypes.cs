﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class PropertyTypes
    {
        public const string FormatDelimiter = ".";

        public const string StringValue = "string";
        public const string NumberValue = "number";
        public const string BooleanValue = "boolean";

        public static readonly string[] StandardPropertyTypes = { StringValue, NumberValue, BooleanValue };

        private static Lazy<IEnumerable<string>> _lazyAllowedPropertyTypes = new(GetAllExistingTypesFromFormats, LazyThreadSafetyMode.ExecutionAndPublication);

        public static IEnumerable<string> AllowedPropertyTypes
        {
            get => _lazyAllowedPropertyTypes.Value;
            private set => _lazyAllowedPropertyTypes = new Lazy<IEnumerable<string>>(value);
        }

        private static IEnumerable<string> GetAllExistingTypesFromFormats()
        {
            IEnumerable<ITypeFormat> typeFormats = TypeFormats.Instance.GetAll();

            return GetAllExistingTypesFromTypeFormats(typeFormats);
        }

        private static IEnumerable<string> GetAllExistingTypesFromTypeFormats(IEnumerable<ITypeFormat> typeFormats)
        {
            var properties = typeFormats.SelectMany(format => format.Properties);
            var propertyTypes = properties.SelectMany(property => property.Value.Types);
            var distinctPropertyTypes = propertyTypes.Select(type => type.Name).Distinct();

            var types = RemoveNullValuesFromList(distinctPropertyTypes).ToList();

            foreach (var propertyType in StandardPropertyTypes)
            {
                if (!types.Contains(propertyType))
                    types.Add(propertyType);
            }

            return types;
        }

        private static IEnumerable<string> RemoveNullValuesFromList(IEnumerable<string?> list)
        {
            List<string> values = new();
            foreach (string? value in list)
            {
                if (value is not null)
                    values.Add(value);
            }
            return values;
        }

        /// <summary>
        /// Automatically finds and registers all the Type Formats in the given assembly <param name="assembly"/> 
        /// </summary>
        /// <param name="assembly">The assembly to search for Type Format implementations</param>
        public static void RegisterPropertyTypesFromAssembly(Assembly assembly, string? context = null)
        {
            IDictionary<string, ITypeFormat> typeformats = TypeFormats.RegisterFormatsFromAssembly(assembly);
            IEnumerable<string> allTypes = GetAllExistingTypesFromTypeFormats(TypeFormats.Instance.GetAll());
            allTypes = allTypes.Concat(context == null ? typeformats.Keys : BuildContextStrings(context, typeformats.Keys));
            IEnumerable<string> newTypes = allTypes.Except(AllowedPropertyTypes);

            AllowedPropertyTypes = AllowedPropertyTypes.Concat(newTypes).ToList();
        }

        private static IEnumerable<string> BuildContextStrings(string context, IEnumerable<string> existingKeys)
        {
            foreach (string key in existingKeys)
                yield return BuildFormatTypeCompositeKey(context, key);
        }

        /// <summary>
        /// Builds composite key for format type using <param name="context"/> and <param name="formatType"></param>
        /// </summary>
        /// <param name="context">Context within which the type is unique</param>
        /// <param name="formatType">Raw or Internal type of the format object</param>
        /// <returns>{Domain}.{FormatType}</returns>
        public static string BuildFormatTypeCompositeKey(string context, string formatType)
        {
            if (string.IsNullOrWhiteSpace(context))
                throw new ArgumentNullException(nameof(context));
            ValidateFormatType(formatType);
            return $"{context}{(context.EndsWith(FormatDelimiter) ? string.Empty : FormatDelimiter)}{formatType}";
        }

        /// <summary>
        /// Ensures that <param name="formatType"/> is in the expected structure. Must not be empty, 
        /// and be a single type value with no context. Throws exception if validation fails.
        /// </summary>
        /// <param name="formatType">The format type string to validate</param>
        public static void ValidateFormatType(string formatType)
        {
            if (string.IsNullOrWhiteSpace(formatType))
                throw new ArgumentNullException(nameof(formatType));

            if (formatType.Split(FormatDelimiter, StringSplitOptions.RemoveEmptyEntries).Length != 1)
                throw new InvalidOperationException($"Invalid format type {formatType}");
        }
    }
}