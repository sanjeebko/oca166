﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class DomainObjectReferences
    {
        public const string ReferenceIdentifier = "$";
        public const string ReferenceOpenLimiter = "{";
        public const string ReferenceCloseLimiter = "}";
        public const string ReferenceDelimiter = ";";

        public const int FullReferenceRegexGroup = 0;
        public const int ReferenceContentRegexGroup = 1;
        public const int DomainRegexGroup = 2;
        public const int IdentifierRegexGroup = 3;
        public const int OptionalPropertyRegexGroup = 4;

        private static readonly string EscapedDelimiterList = @$"\{ReferenceIdentifier}\{ReferenceOpenLimiter}\{ReferenceCloseLimiter}\{ReferenceDelimiter}\s";
        public static readonly Regex ReferencePattern = new($@"\{ReferenceIdentifier}\{ReferenceOpenLimiter}(([^{EscapedDelimiterList}]+)\{ReferenceDelimiter}([^{EscapedDelimiterList}]+)(\{ReferenceDelimiter}[^{EscapedDelimiterList}]+)?)\{ReferenceCloseLimiter}", RegexOptions.Compiled);

        /// <summary>
        /// Builds Object Reference string using domain, object identifier and an optional property string
        /// </summary>
        /// <param name="domain">Domain of the object being reference</param>
        /// <param name="id">String that identifies the object within the domain</param>
        /// <param name="property">String that identifies a subproperty of the referenced object</param>
        /// <returns>${[Domain];[Identifier];[Property]}</returns>
        public static string BuildObjectReference(string domain, string id, string? property = null)
        {
            if (string.IsNullOrWhiteSpace(domain))
                throw new ArgumentNullException(nameof(domain));
            if (string.IsNullOrWhiteSpace(id))
                throw new ArgumentNullException(nameof(id));

            string reference = $"{ReferenceIdentifier}{ReferenceOpenLimiter}{domain}{(domain.EndsWith(ReferenceDelimiter) ? string.Empty : ReferenceDelimiter)}{id}"; 
            if(!string.IsNullOrWhiteSpace(property))
            {
                reference += $"{ReferenceDelimiter}{property}";
            }
            reference += $"{ReferenceCloseLimiter}";

            if (!ReferencePattern.IsMatch(reference))
                throw new InvalidOperationException($"Generated reference {reference} is not a valid structure");

            return reference;
        }

        /// <summary>
        /// Resolves Domain Object Reference Identifier using a reference formatted string
        /// Valid reference field for resolving id should be formatted as {Domain};{Identifier};{optional property}
        /// </summary>
        /// Example Configuration;4;Name
        /// Example Configuration;Context.Id
        /// <param name="reference">Reference in the form {Domain};{Identifier}{; optional property}</param>
        /// <returns>The identifier of the referenced object if successful</returns>
        public static string ResolveReferenceId(string? reference)
        {
            if (!IsDomainObjectReference(reference) || string.IsNullOrEmpty(reference))
                throw new ArgumentException("Reference String must be Configuration Reference format");

            return ReferencePattern.Match(reference).Groups[IdentifierRegexGroup].Value;
        }

        /// <returns>True if the property value is a single domain object reference</returns>
        public static bool IsDomainObjectReference(this PropertyValue property) => IsDomainObjectReference(property.Reference?.ToString());
        
        /// <returns>True if the object as a string contains only a single domain object reference</returns>
        public static bool IsDomainObjectReference(this object? value) => IsDomainObjectReference(value?.ToString());

        /// <summary>
        /// Determines if string is a single Domain Object Reference using the ReferencePattern: Format should be Domain;Identifier;{Property} <param name="reference"></param>
        /// </summary>
        /// <returns>True if the string contains only a single domain object reference</returns>
        public static bool IsDomainObjectReference(string? reference)
        {
            return !string.IsNullOrWhiteSpace(reference) &&
                   ReferencePattern.Matches(reference).Count == 1 &&
                   string.IsNullOrWhiteSpace(ReferencePattern.Replace(reference, ""));
        }

        /// <returns>True if the property value contains any domain object references</returns>
        public static bool ContainsReferences(this PropertyValue property) => ContainsReferences(property.Reference?.ToString());
        
        /// <returns>True if the object as a string contains any domain object references</returns>
        public static bool ContainsReferences(object? value) => ContainsReferences(value?.ToString());
        
        /// <summary>
        /// Determines if string contains any Domain Object Reference using the ReferencePattern: Format should be Domain;Identifier;{Property} <param name="reference"></param>
        /// </summary>
        /// <returns>True if the string contains any domain object references</returns>
        public static bool ContainsReferences(string? value) => !string.IsNullOrWhiteSpace(value) && ReferencePattern.IsMatch(value);

        /// <returns>An array of each of the reference formats string found in the given string</returns>
        public static string[] GetReferences(string? value)
        {
            if (value == null)
                return Array.Empty<string>();
            return ReferencePattern.Matches(value).OfType<Match>().Select(match => match.Value).ToArray();
        }

        /// <summary>
        /// Extract reference contents inside <see cref="ReferenceOpenDelimiter"/> and <see cref="ReferenceCloseDelimiter"/>
        /// </summary>
        /// <param name="reference">Reference value</param>
        /// <returns>Content inside default delimiters</returns>
        public static string GetReferenceContent(string reference)
        {
            foreach (Match match in ReferencePattern.Matches(reference))
            {
                if (match.Success && match.Groups.Count > 0)
                    return match.Groups[ReferenceContentRegexGroup].Value;
            }

            return string.Empty;
        }

        /// <summary>
        /// Extracts reference names inside <see cref="ReferenceOpenDelimiter"/> and <see cref="ReferenceCloseDelimiter"/>
        /// In case there are multiple references, it will extract all references
        /// then extracts from each reference content using <see cref="RetrieveReferenceName"/>
        /// </summary>
        /// <param name="value">Value</param>
        /// <param name="fallbackValue">Value to return in case <param name="value"></param> does not contain refence</param>
        /// <returns>An enumerable of the content inside any found references in the given string</returns>
        public static IEnumerable<string> GetReferenceContents(string value, string fallbackValue)
        {
            if (!ContainsReferences(value))
            {
                yield return fallbackValue;
            }

            foreach (Match match in ReferencePattern.Matches(value))
            {
                if (match.Success && match.Groups.Count > 0)
                {
                    yield return match.Groups[ReferenceContentRegexGroup].Value;
                }
            }
        }

        /// <returns>The domain section from a single reference formatted string</returns>
        public static string GetDomainFromReference(string reference)
        {
            if (!IsDomainObjectReference(reference))
                throw new ArgumentException("Parameter must be a single reference formatted string", nameof(reference));

            return ReferencePattern.Match(reference).Groups[DomainRegexGroup].Value;
        }
        
        /// <returns>The identifier section from a single reference formatted string</returns>
        public static string GetIdentifierFromReference(string reference)
        {
            if (!IsDomainObjectReference(reference))
                throw new ArgumentException("Parameter must be a single reference formatted string", nameof(reference));

            return ReferencePattern.Match(reference).Groups[IdentifierRegexGroup].Value;
        }
        
        /// <returns>The property section from a single reference formatted string if available, or empty</returns>
        public static string GetPropertyFromReference(string reference)
        {
            if (!IsDomainObjectReference(reference))
                throw new ArgumentException("Parameter must be a single reference formatted string", nameof(reference));

            string optionalProperty = ReferencePattern.Match(reference).Groups[OptionalPropertyRegexGroup].Value;

            //Because of the regex grouping, if we found a property it comes with an extra delimiter character that we need to remove
            return string.IsNullOrWhiteSpace(optionalProperty) ? optionalProperty : optionalProperty[1..];
        }
    }
}
