﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyValueDto : IEquatable<PropertyValueDto>
    {
        public string? Type { get; set; }
        public object? Value { get; set; }
        public string? Reference { get; set; }
        public virtual bool Equals([AllowNull] PropertyValueDto? other) =>
            other is not null &&
            (Type == other.Type) &&
            ((Value == other.Value) || (Reference == other.Reference));

        public override bool Equals(object? obj) => obj is PropertyValueDto propertyValueDto && Equals(propertyValueDto);

        public override int GetHashCode() => HashCode.Combine(Type, Value, Reference);
    }
}
