﻿namespace PBS.Shared.PropertyTypeFormats
{
    public record PropertyValue
    {
        public string? Type { get; set; }
        public object? Value { get; set; }
        public string? Reference { get; set; }
    }
}
