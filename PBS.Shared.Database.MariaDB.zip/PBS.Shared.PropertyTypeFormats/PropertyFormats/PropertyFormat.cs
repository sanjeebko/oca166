﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public record PropertyFormat
    {
        public string? Name { get; set; }
        public string? DisplayName { get; set; }
        public string? Hint { get; set; }
        public IEnumerable<PropertyType> Types { get; set; } = Enumerable.Empty<PropertyType>();
        public IEnumerable<FormatPropertyMetadata> Flags { get; set; } = Enumerable.Empty<FormatPropertyMetadata>();
        public bool IsCollection { get; set; }
        public Dictionary<string, object> CollectionValidators { get; set; } = new Dictionary<string, object>();
    }
}