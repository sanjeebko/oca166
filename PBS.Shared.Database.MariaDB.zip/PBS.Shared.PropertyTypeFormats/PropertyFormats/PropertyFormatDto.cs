﻿using System.Text.Json.Serialization;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyFormatDto
    {
        public string? Name { get; set; }
        public string? DisplayName { get; set; }
        public string? Hint { get; set; }
        public IEnumerable<PropertyTypeDto> Types { get; set; } = Enumerable.Empty<PropertyTypeDto>();
        public IEnumerable<string> Flags { get; set; } = Enumerable.Empty<string>();
        [JsonIgnore]
        public bool IsCollection { get; set; }
        public Dictionary<string, object>? CollectionValidators { get; set; } = new Dictionary<string, object>();
    }
}
