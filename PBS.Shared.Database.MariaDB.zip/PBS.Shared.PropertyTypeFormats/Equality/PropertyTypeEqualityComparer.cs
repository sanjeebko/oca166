﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyTypeEqualityComparer : EqualityComparer<PropertyType>
    {
        private readonly IPropertyTypeFormatsComparer<PropertyType> _comparer;
        public new static EqualityComparer<PropertyType> Default { get; } = new PropertyTypeEqualityComparer();

        public PropertyTypeEqualityComparer() : this(new PropertyTypeComparer())
        {
        }

        public PropertyTypeEqualityComparer(IPropertyTypeFormatsComparer<PropertyType> comparer)
        {
            _comparer = comparer;
        }

        public override bool Equals(PropertyType? x, PropertyType? y)
        {
            if (x == null && y == null)
                return true;
            if (x == null || y == null)
                return false;
            return _comparer.Compare(x, y);
        }

        public override int GetHashCode(PropertyType obj)
        {
            return _comparer.GetHashCode(obj);
        }
    }
}
