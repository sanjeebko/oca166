﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyValueEqualityComparer : EqualityComparer<PropertyValue>
    {
        private readonly IPropertyTypeFormatsComparer<PropertyValue> _comparer;
        public new static EqualityComparer<PropertyValue> Default { get; } = new PropertyValueEqualityComparer();

        public PropertyValueEqualityComparer() : this(new PropertyValueComparer())
        {
        }

        public PropertyValueEqualityComparer(IPropertyTypeFormatsComparer<PropertyValue> comparer)
        {
            _comparer = comparer;
        }

        public override bool Equals(PropertyValue? x, PropertyValue? y)
        {
            if (x == null && y == null)
                return true;
            if (x == null || y == null)
                return false;
            return _comparer.Compare(x, y);
        }

        public override int GetHashCode(PropertyValue obj)
        {
            return _comparer.GetHashCode(obj);
        }
    }
}