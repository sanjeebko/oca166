﻿using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyFormatEqualityComparer : EqualityComparer<PropertyFormat>
    {
        private readonly IPropertyTypeFormatsComparer<PropertyFormat> _comparer;
        public new static EqualityComparer<PropertyFormat> Default { get; } = new PropertyFormatEqualityComparer();

        public PropertyFormatEqualityComparer() : this(new PropertyFormatComparer())
        {
        }

        public PropertyFormatEqualityComparer(IPropertyTypeFormatsComparer<PropertyFormat> comparer)
        {
            _comparer = comparer;
        }

        public override bool Equals(PropertyFormat? x, PropertyFormat? y)
        {
            if (x == null && y == null)
                return true;
            if (x == null || y == null)
                return false;
            return _comparer.Compare(x, y);
        }

        public override int GetHashCode(PropertyFormat obj)
        {
            return _comparer.GetHashCode(obj);
        }
    }
}
