﻿namespace PBS.Shared.PropertyTypeFormats
{
    public interface IPropertyTypeFormatsComparer<in T>
    {
        bool Compare(T x, T y);

        int GetHashCode(T obj);
    }
}