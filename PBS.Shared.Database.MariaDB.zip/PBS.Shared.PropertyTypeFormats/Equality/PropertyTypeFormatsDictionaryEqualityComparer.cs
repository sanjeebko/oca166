﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyTypeFormatsDictionaryEqualityComparer : EqualityComparer<Dictionary<string, object>>
    {
        public new static readonly EqualityComparer<Dictionary<string, object>> Default = new PropertyTypeFormatsDictionaryEqualityComparer();

        public override bool Equals(Dictionary<string, object>? x, Dictionary<string, object>? y)
        {
            if (x == null && y == null)
                return true;
            if (x == null || y == null)
                return false;
            if (x.Count == 0 && y.Count == 0)
                return true;
            return x.Count == y.Count && y.OrderBy(kvp => kvp.Key).BuildHash() == x.OrderBy(kvp => kvp.Key).BuildHash();
        }

        public override int GetHashCode(Dictionary<string, object> obj)
        {
            return obj.BuildHash();
        }
    }
}
