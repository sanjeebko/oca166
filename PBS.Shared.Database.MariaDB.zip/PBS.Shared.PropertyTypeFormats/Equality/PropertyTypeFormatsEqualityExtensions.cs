﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public static class PropertyTypeFormatsEqualityExtensions
    {
        public static int BuildHash<TKey, TValue>(this IEnumerable<KeyValuePair<TKey, TValue>> dictionary) where TKey : notnull
        {
            int hash = 0;

            foreach (KeyValuePair<TKey, TValue> pair in dictionary)
            {
                hash += HashCode.Combine(pair.Key, pair.Value);
            }

            return hash;
        }

        public static int GetSequenceHashCode<TItem>(this IEnumerable<TItem>? list, IEqualityComparer<TItem>? comparer = null)
        {
            if (list == null) return 0;
            if (!list.Any()) return 0;

            const int seedValue = 0x2D2816FE;
            const int primeNumber = 397;

            Func<TItem, int> hashFunction = comparer is null ? ((item) => item!.GetHashCode()) : ((item) => comparer.GetHashCode(item!));
            return list.Aggregate(seedValue, (current, item) => (current * primeNumber) + (Equals(item, null) ? 0 : hashFunction(item)));
        }
    }
}
