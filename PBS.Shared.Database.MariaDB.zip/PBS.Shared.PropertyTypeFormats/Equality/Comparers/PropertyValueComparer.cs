﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyValueComparer : IPropertyTypeFormatsComparer<PropertyValue>
    {
        public bool Compare(PropertyValue x, PropertyValue y)
        {
            return
                x.Type == y.Type &&
                x.Reference == y.Reference &&
                EqualityComparer<object>.Default.Equals(x.Value, y.Value);
        }

        public int GetHashCode(PropertyValue obj)
        {
            return HashCode.Combine(obj.Type, obj.Reference, obj.Value);
        }
    }
}
