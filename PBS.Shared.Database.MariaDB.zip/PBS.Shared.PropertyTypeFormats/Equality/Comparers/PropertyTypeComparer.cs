﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyTypeComparer : IPropertyTypeFormatsComparer<PropertyType>
    {
        public bool Compare(PropertyType x, PropertyType y)
        {
            return
                x.Name == y.Name &&
                EqualityComparer<object>.Default.Equals(x.SuggestedDefault, y.SuggestedDefault) &&
                x.AcceptedValues.SequenceEqual(y.AcceptedValues, EqualityComparer<object>.Default) &&
                PropertyTypeFormatsDictionaryEqualityComparer.Default.Equals(x.Validators, y.Validators);
        }

        public int GetHashCode(PropertyType obj)
        {
            return HashCode.Combine(
                obj.Name,
                obj.SuggestedDefault,
                obj.AcceptedValues.GetSequenceHashCode(),
                obj.Validators.BuildHash());
        }
    }
}
