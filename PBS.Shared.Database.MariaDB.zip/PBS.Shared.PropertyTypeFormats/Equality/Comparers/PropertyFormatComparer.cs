﻿using System;
using System.Linq;

namespace PBS.Shared.PropertyTypeFormats
{
    public class PropertyFormatComparer : IPropertyTypeFormatsComparer<PropertyFormat>
    {
        public bool Compare(PropertyFormat x, PropertyFormat y)
        {
            return
                x.Name == y.Name &&
                x.DisplayName == y.DisplayName &&
                x.Hint == y.Hint &&
                x.IsCollection == y.IsCollection &&
                x.Flags.SequenceEqual(y.Flags) &&
                x.Types.SequenceEqual(y.Types, PropertyTypeEqualityComparer.Default) &&
                PropertyTypeFormatsDictionaryEqualityComparer.Default.Equals(x.CollectionValidators, y.CollectionValidators);
        }

        public int GetHashCode(PropertyFormat obj)
        {
            return HashCode.Combine(
                obj.Name,
                obj.DisplayName,
                obj.Hint,
                obj.IsCollection,
                obj.CollectionValidators.BuildHash(),
                obj.Flags.GetSequenceHashCode(),
                obj.Types.GetSequenceHashCode(PropertyTypeEqualityComparer.Default));
        }
    }
}
