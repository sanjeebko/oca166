﻿using PBS.Shared.MappingProfiles;

namespace PBS.Shared.PropertyTypeFormats.MappingProfile
{
    public class PropertyTypeMappingProfile : CommonMappingProfile
    {
        public PropertyTypeMappingProfile()
        {
            CreateMap<PropertyFormat, PropertyFormatDto>();
            CreateMap<PropertyFormatDto, PropertyFormat>();
            CreateMap<PropertyType, PropertyTypeDto>();
            CreateMap<PropertyTypeDto, PropertyType>();
            CreateMap<PropertyValue, PropertyValueDto>();
            CreateMap<PropertyValueDto, PropertyValue>();
        }
    }
}
