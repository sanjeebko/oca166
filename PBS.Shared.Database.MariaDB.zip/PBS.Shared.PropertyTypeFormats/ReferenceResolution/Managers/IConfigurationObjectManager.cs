﻿using PBS.Shared.PropertyTypeFormats.Resolutions;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.PropertyTypeFormats.Manager
{
    public interface IConfigurationObjectManager
    {
        Task<T?> GetResolvedObjectAsync<T>(string? reference, CancellationToken cancellationToken = default) where T : class, IReferenceObject;

        Task<T?> GetObjectAsync<T>(string? uid, CancellationToken cancellationToken = default) where T : class, IReferenceObject;

        Task<TResult?> AddObjectAsync<TResult, TRequest>(TRequest configObject, CancellationToken cancellationToken = default) where TRequest : class where TResult : class, IReferenceObject;

        Task<bool> DeleteObjectAsync(string? uid, CancellationToken cancellationToken = default);

        Task<TResult?> UpdateObjectAsync<TResult, TRequest>(TRequest configObject, CancellationToken cancellationToken = default) where TRequest : class, IReferenceObject where TResult : class, IReferenceObject;
    }
}
