﻿using Microsoft.Extensions.Logging;
using PBS.Shared.PropertyTypeFormats.Resolutions;
using PBS.Shared.Logging;
using System.Threading.Tasks;
using System.Threading;
using PBS.Shared.ServicePathResolution;
using System.Net.Http;
using System.Text.Json;
using System;
using PBS.Shared.Json;
using System.Text;
using PBS.Shared.HttpHandlers;
using System.Collections.Generic;
using PBS.Shared.Validation;

namespace PBS.Shared.PropertyTypeFormats.Manager
{
    public class ConfigurationObjectManager : IConfigurationObjectManager
    {
        private const string JsonFormatType = "application/json";
        private const string ConfigObjectEndpoint = "/api/1/configuration/objects/";
        private const string ConfigResolutionEndpoint = "/api/1/configuration/objects/resolve/";

        private Uri? _cachedConfigObjectUri { get; set; }
        private Uri? _cachedConfigResolutionUri { get; set; }
        private JsonSerializerOptions JsonSerializationOptions { get; } = new() { PropertyNameCaseInsensitive = true };

        private readonly ILogger _logger;
        private readonly IConfigObjectReferenceService _referenceService;
        protected readonly IHttpClientHandler _httpHandler;
        protected readonly IServicePathResolver _servicePathResolver;

        public ConfigurationObjectManager(ILogger<ConfigurationObjectManager> logger, IConfigObjectReferenceService referenceService, IHttpClientHandler httpHandler, IServicePathResolver servicePathResolver)
        {
            _logger = logger;
            _referenceService = referenceService;
            _httpHandler = httpHandler;
            _servicePathResolver = servicePathResolver;
        }

        public async Task<T?> GetResolvedObjectAsync<T>(string? reference, CancellationToken cancellationToken = default) where T : class, IReferenceObject
        {
            string uid = DomainObjectReferences.ResolveReferenceId(reference);
            using var _ = _logger.WithProperty("ConfigurationObjectId", uid);
            _logger.LogTrace("Retrieving Configuration Object");

            try
            {
                var serializedReference = new List<string> { uid };
                var postMessage = GetContentForMessage(serializedReference, Encoding.UTF8);
                var response = await _httpHandler.PostAsync(GetConfigResolutionObjectUri(), postMessage, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Status code: {response.StatusCode}, Error: {response.ReasonPhrase}, Message: {error}");
                }

                T? config = JsonSerializationUtilities.Deserialize<T>(await response.Content.ReadAsStringAsync(cancellationToken), JsonSerializationOptions);

                if (config is null)
                {
                    _logger.LogDebug("Failed to recover Configuration Object");
                    return default;
                }

                config.Id = uid;
                _logger.LogTrace("Successfully recovered Configuration Object");
                return _referenceService.AddReference(config);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"An exception occurred during request to the Configuration Service");
                return default;
            }
        }

        public async Task<T?> GetObjectAsync<T>(string? uid, CancellationToken cancellationToken = default) where T : class, IReferenceObject
        {
            Requires.NotNull(uid, nameof(uid), "Uid cannot be null when retrieving object");
            using var _ = _logger.WithProperty("ConfigurationObjectId", uid);
            _logger.LogTrace("Retrieving Configuration Object");

            try
            {
                var requestUri = new Uri(GetConfigObjectUri(), uid);
                var response = await _httpHandler.GetAsync(requestUri, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Status code: {response.StatusCode}, Error: {response.ReasonPhrase}, Message: {error}");
                }

                T? config = JsonSerializationUtilities.Deserialize<T>(await response.Content.ReadAsStringAsync(cancellationToken), JsonSerializationOptions);

                if (config is null)
                {
                    _logger.LogDebug("Failed to recover Configuration Object");
                    return default;
                }

                config.Id = uid;
                _logger.LogTrace("Successfully recovered Configuration Object");
                return _referenceService.AddReference(config);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"An exception occurred during request to the Configuration Service");
                return default;
            }
        }

        public async Task<TResult?> AddObjectAsync<TResult, TRequest>(TRequest configObject, CancellationToken cancellationToken = default) where TRequest : class where TResult : class, IReferenceObject
        {
            _logger.LogTrace("Sending request to the Configuration Service");

            try
            {
                var postMessage = GetContentForMessage(configObject, Encoding.UTF8);
                var response = await _httpHandler.PostAsync(GetConfigObjectUri(), postMessage, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Status code: {response.StatusCode}, Error: {response.ReasonPhrase}, Message: {error}");
                }

                TResult? config = JsonSerializationUtilities.Deserialize<TResult>(await response.Content.ReadAsStringAsync(cancellationToken), JsonSerializationOptions);

                if (config is null)
                {
                    _logger.LogDebug("Failed to add Configuration Object");
                    return default;
                }

                _logger.LogTrace("Successfully added Configuration Object");
                return _referenceService.AddReference(config);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"An exception occurred during request to the Configuration Service");
                return default;
            }
        }

        public async Task<bool> DeleteObjectAsync(string? uid, CancellationToken cancellationToken = default)
        {
            Requires.NotNull(uid, nameof(uid), "Uid cannot be null when retrieving object");
            using var _ = _logger.WithProperty("ConfigurationObjectId", uid);
            _logger.LogTrace("Retrieving Configuration Object");

            try
            {
                var requestUri = new Uri(GetConfigObjectUri(), uid);
                var response = await _httpHandler.DeleteAsync(requestUri, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Status code: {response.StatusCode}, Error: {response.ReasonPhrase}, Message: {error}");
                }

                _logger.LogDebug("Successfully deleted Configuration Object");
                return true;
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"An exception occurred during request to the Configuration Service");
                return false;
            }
        }

        public async Task<TResult?> UpdateObjectAsync<TResult, TRequest>(TRequest configObject, CancellationToken cancellationToken = default) where TRequest : class, IReferenceObject where TResult : class, IReferenceObject
        {
            Requires.NotNull(configObject.Id, nameof(configObject), "Id cannot be null when updating an object");
            _logger.LogTrace("Sending request to the Configuration Service");

            try
            {
                var postMessage = GetContentForMessage(configObject, Encoding.UTF8);
                var requestUri = new Uri(GetConfigObjectUri(), configObject.Id);
                var response = await _httpHandler.PutAsync(requestUri, postMessage, cancellationToken);

                if (!response.IsSuccessStatusCode)
                {
                    var error = await response.Content.ReadAsStringAsync(cancellationToken);
                    throw new InvalidOperationException($"Status code: {response.StatusCode}, Error: {response.ReasonPhrase}, Message: {error}");
                }

                TResult? config = JsonSerializationUtilities.Deserialize<TResult>(await response.Content.ReadAsStringAsync(cancellationToken), JsonSerializationOptions);

                if (config is null)
                {
                    _logger.LogDebug("Failed to add Configuration Object");
                    return default;
                }

                _logger.LogTrace("Successfully added Configuration Object");
                return _referenceService.AddReference(config);
            }
            catch (Exception e)
            {
                _logger.LogError(e, $"An exception occurred during request to the Configuration Service");
                return default;
            }
        }

        private static HttpContent GetContentForMessage<T>(T configObject, Encoding messageEncoding) where T : class
        {
            var serializedContent = JsonSerializationUtilities.Serialize(configObject);
            return new StringContent(serializedContent, messageEncoding, JsonFormatType);
        }

        private Uri GetConfigurationServiceUri(string endpoint)
        {
            string urlService = _servicePathResolver.ResolveServiceOrigin(endpoint);
            string requestUri = $"{urlService}{endpoint}";
            return new UriBuilder(requestUri).Uri;
        }

        private Uri GetConfigObjectUri()
        {
            _cachedConfigObjectUri ??= GetConfigurationServiceUri(ConfigObjectEndpoint);
          return _cachedConfigObjectUri;
        }

        private Uri GetConfigResolutionObjectUri()
        {
            _cachedConfigResolutionUri ??= GetConfigurationServiceUri(ConfigResolutionEndpoint);
          return _cachedConfigResolutionUri;
        }
    }
}
