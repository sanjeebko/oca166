﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PBS.Shared.PropertyTypeFormats.Resolutions
{
    public class ConfigObjectReferenceService : IConfigObjectReferenceService
    {
        private readonly ConcurrentDictionary<string, WeakReference> _configurationObjects = new();
        private readonly ConcurrentDictionary<Type, List<PropertyInfo>> _propertyCache = new();

        public T? AddReference<T>(T configObject) where T : class, IReferenceObject
        {
            string key = BuildReferenceObjectKey(configObject);
            if (_configurationObjects.TryGetValue(key, out WeakReference? weakRef) && !weakRef.IsAlive)
                _configurationObjects.TryRemove(key, out WeakReference? _);
            WeakReference reference = new(configObject);
            return _configurationObjects.AddOrUpdate(key, reference, (id, referenceToUpdate) => UpdateReferenceInCollection(configObject, referenceToUpdate)).Target as T;
        }

        private WeakReference UpdateReferenceInCollection<T>(T configObject, WeakReference reference) where T : class, IReferenceObject
        {
            UpdateReferenceTargetProperties(reference, configObject, GetCachedProperties(typeof(T)));
            return reference;
        }

        private List<PropertyInfo> GetCachedProperties(Type type) => _propertyCache.GetOrAdd(type, type => type.GetProperties().Where(prop => prop.CanRead && prop.CanWrite).ToList());

        private static void UpdateReferenceTargetProperties<T>(WeakReference reference, T configObject, List<PropertyInfo> properties)
        {
            foreach (PropertyInfo property in properties)
                property.SetValue(reference.Target, property.GetValue(configObject));
        }

        private static string BuildReferenceObjectKey<T>(T configObject) where T : class, IReferenceObject => $"{configObject.Id}_{typeof(T).FullName}";
    }
}