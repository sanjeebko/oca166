﻿namespace PBS.Shared.PropertyTypeFormats.Resolutions
{
    public interface IReferenceObject
    {
        string Id { get; set; }
    }
}
