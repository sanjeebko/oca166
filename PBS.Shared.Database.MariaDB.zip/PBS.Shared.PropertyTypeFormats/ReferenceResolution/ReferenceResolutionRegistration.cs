﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.PropertyTypeFormats.Manager;

namespace PBS.Shared.PropertyTypeFormats.Resolutions
{
    public static class ReferenceResolutionRegistration
    {
        public static void AddConfigurationServiceReferenceResolution(this IServiceCollection services)
        {
            services.AddSingleton<IConfigObjectReferenceService, ConfigObjectReferenceService>();
            services.AddSingleton<IConfigurationObjectManager, ConfigurationObjectManager>();
        }
    }
}
