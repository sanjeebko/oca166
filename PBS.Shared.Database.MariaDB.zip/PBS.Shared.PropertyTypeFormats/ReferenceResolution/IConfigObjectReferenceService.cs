﻿namespace PBS.Shared.PropertyTypeFormats.Resolutions
{
    public interface IConfigObjectReferenceService
    {
        T? AddReference<T>(T configObject) where T : class, IReferenceObject;
    }
}
