﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Models;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    public class WorkerConsoleBuilder : IDisposable
    {
        private bool isDisposed;
        private IHost? host;

        /// <summary>
        /// Enables console support, builds and starts the worker host, and waits for Ctrl+C or SIGTERM to shut down.
        /// </summary>
        /// <returns>A <see cref="Task"/> that only completes when the token is triggered or shutdown is triggered.</returns>
        public Task RunConsoleAsync(Action<WorkerConfig> configureWorker, Action<IWorkerTaskMappingBuilder> configureTaskMapping, Action<ILoggingBuilder>? loggingConfigure, CancellationToken cancellationToken = default)
        {
            if (host != null)
                throw new InvalidOperationException("Host already created");

            host = new HostBuilder()
                .ConfigureServices((hostContext, services) =>
                {
                    services.AddLogging(builder =>
                    {
                        loggingConfigure?.Invoke(builder);
                    });

                    services.AddPBSWorker(configureWorker);
                })
                .UseConsoleLifetime()
                .Build();

            host.Services.UsePBSWorker(configureTaskMapping);

            return host.RunAsync(cancellationToken);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (isDisposed)
                return;

            host?.Dispose();

            isDisposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
