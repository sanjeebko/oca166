﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Hosting;
using PBS.Shared.Orchestration.Worker.Clients;
using PBS.Shared.Orchestration.Worker.Clients.SignalR;
using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Paths;
using PBS.Shared.Orchestration.Worker.Restrictions.Validators;
using PBS.Shared.Orchestration.Worker.Services;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Validators;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    /// <summary>
    /// Registers all required services, configuration to enable worker-orchestration workflow
    /// </summary>
    public static partial class WorkerRegistration
    {
        /// <summary>
        /// Adds worker to <see cref="IServiceCollection"/>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configure"></param>
        public static IWorkerBuilder AddPBSWorker(this IServiceCollection services, Action<WorkerConfig>? configure)
        {
            if (services == null)
                throw new WorkerRegistrationArgumentException(nameof(services));

            if (configure == null)
                throw new WorkerRegistrationArgumentException(nameof(configure));

            if (services.Any(x => x.ServiceType == typeof(WorkerMarkerService)))
                throw new WorkerRegistrationException("AddPBSWorker(...) called multiple times");

            var config = new WorkerConfig();
            configure?.Invoke(config);

            return services.AddPBSWorker(config);
        }

        /// <summary>
        /// Adds worker to <see cref="IServiceCollection"/>
        /// </summary>
        /// <param name="services"></param>
        /// <param name="config"></param>
        private static IWorkerBuilder AddPBSWorker(this IServiceCollection services, WorkerConfig config)
        {
            services.AddSingleton<WorkerConfig>(config);
            services.AddSingleton<IWorkerConfigService, WorkerConfigService>();
            services.AddEvents(config);
            services.AddTasks(config);
            services.AddPathResolver(config);
            services.AddClient(config);
            services.AddValidators(config);
            services.RegisterOrReplaceHosted<OrchestrationClientInitializer>(config);
            services.AddSingleton<WorkerMarkerService>();
            return new WorkerBuilder(services);
        }

        private static void AddPathResolver(this IServiceCollection services, WorkerConfig config)
        {
            if (config.ServicePathsConfig?.Enabled == true)
            {
                services.AddTransient<IServicePathResolver, ConfigurableServicePathResolver>();
            }
            else
            {
                services.AddTransient<IServicePathResolver, ServicePathResolver>();
            }
        }

        private static void AddClient(this IServiceCollection services, WorkerConfig config)
        {
            services.RegisterOrReplaceSingleton<IOrchestrationClient, SignalROrchestrationClient>(config);
            services.RegisterOrReplaceSingleton<IOrchestrationClientService, OrchestrationClientService>(config);
            services.RegisterOrReplaceSingleton<IOrchestrationClientMessagingService, OrchestrationClientService>(config);
        }

        private static void AddEvents(this IServiceCollection services, WorkerConfig config)
        {            
            services.RegisterOrReplaceSingleton<IEventManager, EventManager>(config);

            IEnumerable<Assembly?> assemblies = config.ScanAssembly.ConcatAssemblies();

            foreach (Assembly? assemblyEntry in assemblies)
            {
                if (assemblyEntry == null) continue;
                foreach (Type type in assemblyEntry.GetAllTypesImplementing<IEventHandler>())
                {
                    services.AddScoped(type);
                }
            }
        }
  
        private static void AddTasks(this IServiceCollection services, WorkerConfig config)
        {
            IEnumerable<Assembly?> assemblies = config.ScanAssembly.ConcatAssemblies().ToList();

            services.RegisterOrReplaceScoped<ITaskManager, TaskManager>(config);
            services.RegisterOrReplaceScoped<ITaskHandlerFactory, TaskHandlerFactory>(config);
            services.AddSingleton<ITaskMappingDataSource, TaskMappingDataSource>();
            if (assemblies == null) return;
            services.AddSingleton<ITaskTypeCacheService>(new TaskTypeCacheService(assemblies!));

            foreach (Assembly? assemblyEntry in assemblies)
            {
                if (assemblyEntry == null) continue;
                foreach (var type in assemblyEntry.GetAllTypesImplementing<ITask>())
                {
                    services.AddScoped(type).AddScoped(typeof(ITask), type);
                }
            }
        }

        private static void AddValidators(this IServiceCollection services, WorkerConfig config)
        {
            IEnumerable<Assembly?> assemblies = new List<Assembly?>(config.ScanAssembly.ConcatAssemblies()) {typeof(IWorkerValidator).Assembly}.Distinct().ToList();

            Type lookupType = typeof(IWorkerValidator);

            foreach (var assembly in assemblies)
            {
                if (assembly == null) continue;
                foreach (Type implementationType in assembly.GetAllTypesImplementing<IWorkerValidator>())
                {
                    Type[] typeInterfaces = implementationType.GetInterfaces();

                    IEnumerable<Type> lookupTypeServices = typeInterfaces.Where(interfaceType => lookupType != interfaceType && interfaceType != typeof(IDisposable));

                    foreach (Type service in lookupTypeServices)
                    {
                        services.RegisterOrReplaceSingleton(service, implementationType, config);
                    }
                }
            }

            services.RegisterOrReplaceSingleton<IWorkerRestrictionValidatorLookup, WorkerRestrictionValidatorLookup>(config);
            services.RegisterOrReplaceSingleton<IRestrictionValidatorLookup, RestrictionValidatorLookup>(config);

            services.RegisterOrReplaceSingleton<IWorkerRestrictionValidatorFactory, WorkerRestrictionValidatorFactory>(config);
            services.RegisterOrReplaceSingleton<IRestrictionValidatorFactory, RestrictionValidatorFactory>(config);
        }

        private static IEnumerable<Assembly?> ConcatAssemblies(this IEnumerable<Assembly>? assemblies)
        {
            if(assemblies != null)
                return assemblies.Concat(new[] {typeof(WorkerRegistration).Assembly, Assembly.GetEntryAssembly() }).Distinct().ToList();
            return new[] {typeof(WorkerRegistration).Assembly, Assembly.GetEntryAssembly()}.Distinct().ToList();
        }

        private static void RegisterOrReplaceSingleton<TService, TImplementation>(this IServiceCollection services, WorkerConfig config) where TService : class where TImplementation : class, TService
        {
            if (config.ServiceReplacement.TryGetValue(typeof(TService), out Type? replacementType))
            {
                services.AddSingleton(typeof(TService), replacementType);
                return;
            }

            services.AddSingleton<TService, TImplementation>();
        }

        private static void RegisterOrReplaceSingleton(this IServiceCollection services, Type serviceType, Type ImplementationType, WorkerConfig config)
        {
            if (config.ServiceReplacement.TryGetValue(serviceType, out Type? replacementType))
            {
                services.AddSingleton(serviceType, replacementType);
                return;
            }

            services.AddSingleton(serviceType, ImplementationType);
        }

        private static void RegisterOrReplaceScoped<TService, TImplementation>(this IServiceCollection services, WorkerConfig config) where TService : class where TImplementation : class, TService
        {
            if (config.ServiceReplacement.TryGetValue(typeof(TService), out Type? replacementType))
            {
                services.AddScoped(typeof(TService), replacementType);
                return;
            }

            services.AddScoped<TService, TImplementation>();
        }

        private static void RegisterOrReplaceHosted<THostedService>(this IServiceCollection services, WorkerConfig config) where THostedService : class, IHostedService
        {
            if (config.ServiceReplacement.TryGetValue(typeof(THostedService), out Type? replacementType))
            {
                services.TryAddEnumerable(ServiceDescriptor.Singleton(typeof(THostedService), replacementType));
                return;
            }

            services.AddHostedService<THostedService>();
        }
    }
}
