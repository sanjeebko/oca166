﻿namespace PBS.Shared.Orchestration.Worker.Registration
{
    /// <summary>
    /// A marker class used to determine if all the Worker services were added
    /// to the <see cref="IServiceCollection"/> before Worker is configured.
    /// </summary>
    internal class WorkerMarkerService
    {
        private volatile bool marked;

        public void Mark()
        {
            marked = true;
        }

        public bool IsMarked => marked;
    }
}
