﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    internal class WorkerBuilder : IWorkerBuilder
    {
        /// <summary>
        /// Initializes a new <see cref="WorkerBuilder"/> instance.
        /// </summary>
        /// <param name="services">The <see cref="IServiceCollection" /> to add services to.</param>
        public WorkerBuilder(IServiceCollection services)
        {
            Services = services ?? throw new ArgumentNullException(nameof(services));
        }

        public IServiceCollection Services { get; }
    }
}