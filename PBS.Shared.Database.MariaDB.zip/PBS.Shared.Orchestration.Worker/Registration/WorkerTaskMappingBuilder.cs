﻿using System;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    internal class WorkerTaskMappingBuilder : IWorkerTaskMappingBuilder
    {
        public WorkerTaskMappingBuilder(IServiceProvider serviceProvider)
        {
            ServiceProvider = serviceProvider;
        }
        public IServiceProvider ServiceProvider { get; }
    }
}