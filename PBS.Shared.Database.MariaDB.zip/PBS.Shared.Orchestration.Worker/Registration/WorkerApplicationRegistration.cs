﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Tasks;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Restrictions.Validators;
using PBS.Shared.Orchestration.Worker.Validators;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    public static partial class WorkerRegistration
    {
        public static IApplicationBuilder UsePBSWorker(this IApplicationBuilder applicationBuilder, Action<IWorkerTaskMappingBuilder>? configure)
        {
            if (applicationBuilder == null)
                throw new WorkerRegistrationArgumentException(nameof(applicationBuilder));

            applicationBuilder.ApplicationServices.UsePBSWorker(configure);

            return applicationBuilder;
        }

        public static IServiceProvider UsePBSWorker(this IServiceProvider serviceProvider, Action<IWorkerTaskMappingBuilder>? configure)
        {
            if (serviceProvider == null)
                throw new WorkerRegistrationArgumentException(nameof(serviceProvider));

            EnsureRequiredServices(serviceProvider);

            IWorkerRestrictionValidatorLookup workerRestrictionValidatorLookup = serviceProvider.GetRequiredService<IWorkerRestrictionValidatorLookup>();
            IRestrictionValidatorLookup restrictionValidatorLookup = serviceProvider.GetRequiredService<IRestrictionValidatorLookup>();
            IWorkerConfigService workerConfigService = serviceProvider.GetRequiredService<IWorkerConfigService>();

            IEnumerable<Assembly?> assemblies = new List<Assembly?>(workerConfigService.Value.ScanAssembly.ConcatAssemblies()) { typeof(IWorkerValidator).Assembly }.Distinct().ToList();

            workerRestrictionValidatorLookup.AddFromAssembly(assemblies.ToArray());
            restrictionValidatorLookup.AddFromAssembly(assemblies.ToArray());

            try
            {
                workerConfigService.Validate();
            }
            catch (Exception e)
            {
                throw new WorkerConfigValidationException(e.Message, e);
            }

            IEventManager eventManager = serviceProvider.GetRequiredService<IEventManager>();

            // subscribe worker config change
            workerConfigService.OnChange += config => eventManager.PublishAsync(new WorkerConfigChangedEvent(config));

            foreach (Assembly? assembly in assemblies)
            {
                if (assembly == null) continue;
                foreach (Type handlerType in assembly.GetAllTypesImplementing<IEventHandler>())
                {
                    eventManager.Subscribe(handlerType);
                }
            }

            configure?.Invoke(new WorkerTaskMappingBuilder(serviceProvider));

            return serviceProvider;
        }

        /// <summary>
        /// Creates mapping for step template name to Task <see cref="TTask"/> implementation
        /// </summary>
        /// <typeparam name="TTask">Task implementation</typeparam>
        /// <param name="mappings"></param>
        /// <param name="stepTemplateName">Step Template name</param>
        public static void MapTask<TTask>(this IWorkerTaskMappingBuilder mappings, string stepTemplateName) where TTask : ITask
        {
            WorkerConfig config = mappings.ServiceProvider.GetRequiredService<IWorkerConfigService>().Value;

            WorkerStepTemplate? template = config.WorkerAnnouncement?.StepTemplates?.FirstOrDefault(s => s.Name == stepTemplateName);

            if (template == null)
                throw new WorkerTaskMappingException($"Failed to find {nameof(WorkerStepTemplate)} with name {stepTemplateName}");

            ITaskMappingDataSource mappingDataSource = mappings.ServiceProvider.GetRequiredService<ITaskMappingDataSource>();

            mappingDataSource.AddMapping<TTask>(template);
        }

        private static void EnsureRequiredServices(this IServiceProvider serviceProvider)
        {
            var marker = serviceProvider.GetService<WorkerMarkerService>();

            if (marker == null)
                throw new WorkerRegistrationException("AddPBSWorker(...) not called in ConfigureServices(...)");
            if (marker.IsMarked)
                throw new WorkerRegistrationException("AddPBSWorker(...) called multiple times");

            marker.Mark();
        }
    }
}