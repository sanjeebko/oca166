﻿using System;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    public interface IWorkerTaskMappingBuilder
    {
        /// <summary>
        /// Gets the sets the <see cref="IServiceProvider"/> used to resolve services for routes.
        /// </summary>
        IServiceProvider ServiceProvider { get; }
    }
}