﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    [Serializable]
    public class WorkerConfigValidationException : Exception
    {
        public WorkerConfigValidationException(string message, Exception exception) : base(message, exception)
        {
        }

        protected WorkerConfigValidationException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
