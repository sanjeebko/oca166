﻿using Microsoft.Extensions.DependencyInjection;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    public interface IWorkerBuilder
    {
        IServiceCollection Services { get; }
    }
}
