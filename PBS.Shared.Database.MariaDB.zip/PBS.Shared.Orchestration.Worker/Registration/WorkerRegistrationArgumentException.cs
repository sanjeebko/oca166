﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    [Serializable]
    public class WorkerRegistrationArgumentException : ArgumentException
    {
        public WorkerRegistrationArgumentException(string message) : base(message)
        {
        }

        protected WorkerRegistrationArgumentException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}