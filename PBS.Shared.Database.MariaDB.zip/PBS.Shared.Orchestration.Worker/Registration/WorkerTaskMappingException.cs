﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Orchestration.Worker.Registration
{
    [Serializable]
    public class WorkerTaskMappingException : Exception
    {
        public WorkerTaskMappingException(string message) : base(message)
        {
        }

        protected WorkerTaskMappingException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}