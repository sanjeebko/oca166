using System;
using System.Collections.Generic;
using System.Linq;
using PBS.Shared.Orchestration.Worker.Options;

namespace PBS.Shared.Orchestration.Worker.Paths
{
    internal class ConfigurableServicePathResolver : IServicePathResolver
    {
        private readonly IWorkerConfigService _workerConfigService;

        public ConfigurableServicePathResolver(IWorkerConfigService workerConfigService)
        {
            _workerConfigService = workerConfigService;
        }

        public string ResolveServiceOrigin(string uri)
        {
            string baseOriginPath = BuildOriginPath(_workerConfigService.Value.ServicePathsConfig?.Base?.Host, _workerConfigService.Value.ServicePathsConfig?.Base?.Port);

            if (_workerConfigService.Value.ServicePathsConfig?.DevelopmentPaths == null || _workerConfigService.Value.ServicePathsConfig?.DevelopmentPaths?.Count() == 0)
            {
                return baseOriginPath;
            }

            BaseOrigin? baseOrigin = _workerConfigService.Value.ServicePathsConfig?.Base;
            ServicePathConfig? pathConfig = _workerConfigService.Value.ServicePathsConfig?.DevelopmentPaths?.FirstOrDefault((path) => PathsContainPrefixOfURI(path.Paths, uri));
            if (pathConfig != null)
            {
                return BuildOriginPath(pathConfig.Host ?? baseOrigin?.Host, pathConfig.Port ?? baseOrigin?.Port);
            }

            return baseOriginPath;
        }

        private static bool PathsContainPrefixOfURI(IEnumerable<string>? paths, string uri)
        {
            if (paths == null)
            {
                return false;
            }

            return paths.Any((path) => uri.StartsWith(path));
        }

        private static string BuildOriginPath(string? host, int? port)
        {
            if (host == null)
            {
                throw new ArgumentNullException(nameof(host));
            }

            if (port == null)
            {
                throw new ArgumentNullException(nameof(port));
            }

            return $"http://{host}:{port}";
        }
    }
}