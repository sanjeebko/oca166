namespace PBS.Shared.Orchestration.Worker.Paths
{
    internal class ServicePathResolver : IServicePathResolver
    {
        public string ResolveServiceOrigin(string uri) => "http://router.default.svc.cluster.local";
    }
}