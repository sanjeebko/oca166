namespace PBS.Shared.Orchestration.Worker.Paths
{
    internal interface IServicePathResolver
    {
        string ResolveServiceOrigin(string uri);
    }
}