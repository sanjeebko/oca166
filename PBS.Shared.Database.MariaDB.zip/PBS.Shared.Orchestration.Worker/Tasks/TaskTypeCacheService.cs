﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using PBS.Shared.Orchestration.Worker.Extensions;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal class TaskTypeCacheService : ITaskTypeCacheService
    {
        private readonly Dictionary<string, Type> _cache = new Dictionary<string, Type>(StringComparer.OrdinalIgnoreCase);

        public TaskTypeCacheService(IEnumerable<Assembly> assemblies)
        {
            foreach (var assembly in assemblies.Distinct())
            {
                foreach (var type in assembly.GetAllTypesImplementing<ITask>())
                {
                    _cache.Add(type.Name, type);
                }
            }
        }

        public Type? GetTypeOrNull(string taskType)
        {
            return _cache.TryGetValue(taskType, out Type? type) ? type : null;
        }
    }
}
