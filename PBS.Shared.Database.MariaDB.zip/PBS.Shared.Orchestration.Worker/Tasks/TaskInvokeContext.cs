﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public class TaskInvokeContext : ITaskInvokeContext
    {
        public TaskInvokeContext(WorkerStepTemplate stepTemplate, WorkerTaskInvokeRequest request)
        {
            StepTemplate = stepTemplate;
            Request = request;
        }

        public WorkerStepTemplate StepTemplate { get; }
        public WorkerTaskInvokeRequest Request { get; }
    }
}
