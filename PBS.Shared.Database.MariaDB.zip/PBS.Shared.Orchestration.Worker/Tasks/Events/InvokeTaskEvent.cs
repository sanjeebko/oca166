﻿using PBS.Shared.Orchestration.Worker.Events;

namespace PBS.Shared.Orchestration.Worker.Tasks.Events
{
    public class InvokeTaskEvent : EventBase
    {
        public string? Payload { get; set; }
    }
}
