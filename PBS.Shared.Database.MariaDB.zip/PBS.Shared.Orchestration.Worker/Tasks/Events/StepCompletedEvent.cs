﻿using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Tasks.Events
{
    public class StepCompletedEvent : StepTaskEvent
    {
        [JsonPropertyName("result")]
        public WorkerTaskInvokeResult? Result { get; set; }
    }
}
