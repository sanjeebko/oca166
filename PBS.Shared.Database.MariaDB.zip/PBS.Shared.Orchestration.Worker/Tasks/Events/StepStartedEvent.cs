﻿namespace PBS.Shared.Orchestration.Worker.Tasks.Events
{
    public class StepStartedEvent : StepTaskEvent
    {
        public string? Message { get; set; }
    }
}
