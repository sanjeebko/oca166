﻿using System.Text.Json.Serialization;
using PBS.Shared.Orchestration.Worker.Events;

namespace PBS.Shared.Orchestration.Worker.Tasks.Events
{
    /// <summary>
    /// Base event for Step templates
    /// </summary>
    public abstract class StepTaskEvent : EventBase
    {
        [JsonPropertyName("stepTemplateName")]
        public string? StepTemplateName { get; set; }

        [JsonPropertyName("stepInstanceId")]
        public string? StepInstanceId { get; set; }
    }
}
