﻿using PBS.Shared.Orchestration.Worker.Models;
using System;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal interface ITaskMappingDataSource
    {
        void AddMapping<TTask>(WorkerStepTemplate config) where TTask : ITask;

        Type? GetTypeForMappingOrNull(WorkerStepTemplate config);
    }
}