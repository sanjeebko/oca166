﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Logging;
using System;
using System.Linq;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal class TaskHandlerFactory : ITaskHandlerFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ITaskMappingDataSource _taskMappingDataSource;
        private readonly IWorkerConfigService _workerConfigService;
        private readonly ILogger<TaskHandlerFactory> _logger;

        public TaskHandlerFactory(
            ILogger<TaskHandlerFactory> logger,
            IServiceProvider serviceProvider,
            ITaskMappingDataSource taskMappingDataSource,
            IWorkerConfigService workerConfigService)
        {
            _serviceProvider = serviceProvider;
            _taskMappingDataSource = taskMappingDataSource;
            _workerConfigService = workerConfigService;
            _logger = logger;
        }

        public ITaskHandler? GetTaskHandler(string stepTemplateName)
        {
            WorkerStepTemplate? stepTemplate = _workerConfigService.Value.WorkerAnnouncement?.StepTemplates?.FirstOrDefault(s => s.Name == stepTemplateName);

            using var _ = _logger.WithProperty("StepTemplate", stepTemplateName);

            if (stepTemplate == null)
            {
                _logger.LogWarning("Failed to find step template");

                return null;
            }

            Type? taskType = _taskMappingDataSource.GetTypeForMappingOrNull(stepTemplate);

            if (taskType == null)
            {
                _logger.LogWarning("Failed to find task type");

                return null;
            }

            var task = _serviceProvider.GetService(taskType) as ITask;

            if (task == null)
            {
                _logger.LogWarning("Failed to resolve task with type {TaskType}", taskType.FullName);

                return null;
            }

            return new TaskHandler(task, stepTemplate);
        }
    }
}
