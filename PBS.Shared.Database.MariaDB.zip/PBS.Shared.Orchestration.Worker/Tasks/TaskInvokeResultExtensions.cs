﻿using PBS.Shared.PropertyTypeFormats;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public static class TaskInvokeResultExtensions
    {
        public static WorkerTaskInvokeResult ForStatus(WorkerTaskInvokeRequestStatus status, Dictionary<string, PropertyValue>? output, params Exception[] exceptions)
        {
            return new WorkerTaskInvokeResult
            {
                Status = status,
                Output = output ?? new Dictionary<string, PropertyValue>(),
                Errors = exceptions.Select(s => s.Message).ToList(),
                CompletedTimestamp = DateTimeOffset.UtcNow
            };
        }

        public static WorkerTaskInvokeResult Success(Dictionary<string, PropertyValue>? output = null)
        {
            return new WorkerTaskInvokeResult
            {
                Status = WorkerTaskInvokeRequestStatus.Success,
                Output = output ?? new Dictionary<string, PropertyValue>(),
                CompletedTimestamp = DateTimeOffset.UtcNow
            };
        }

        public static WorkerTaskInvokeResult NonFatal()
        {
            return NonFatal(null);
        }

        public static WorkerTaskInvokeResult NonFatal(Dictionary<string, PropertyValue>? output)
        {
            return new WorkerTaskInvokeResult
            {
                Status = WorkerTaskInvokeRequestStatus.NonFatal,
                Output = output ?? new Dictionary<string, PropertyValue>(),
                CompletedTimestamp = DateTimeOffset.UtcNow
            };
        }

        public static WorkerTaskInvokeResult Failed(params Exception[] exceptions)
        {
            return Failed(null, exceptions);
        }

        public static WorkerTaskInvokeResult Failed(Dictionary<string, PropertyValue>? output, params Exception[] exceptions)
        {
            return new WorkerTaskInvokeResult
            {
                Status = WorkerTaskInvokeRequestStatus.Failed,
                Output = output ?? new Dictionary<string, PropertyValue>(),
                Errors = exceptions.Select(s => s.Message).ToList(),
                CompletedTimestamp = DateTimeOffset.UtcNow
            };
        }

        public static WorkerTaskInvokeResult Failed(params string[] errors)
        {
            return Failed(null, errors);
        }

        public static WorkerTaskInvokeResult Failed(Dictionary<string, PropertyValue>? output, params string[] errors)
        {
            return Failed(output, errors.Select(s => new Exception(s)).ToArray());
        }
    }
}
