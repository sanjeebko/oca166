﻿using PBS.Shared.Orchestration.Worker.Models;
using System;
using System.Collections.Concurrent;
using System.Data;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal class TaskMappingDataSource : ITaskMappingDataSource
    {
        private readonly ITaskTypeCacheService _taskTypeCacheService;
        private readonly ConcurrentDictionary<string, Type> _mappings = new ConcurrentDictionary<string, Type>();

        public TaskMappingDataSource(ITaskTypeCacheService taskTypeCacheService)
        {
            _taskTypeCacheService = taskTypeCacheService;
        }

        public void AddMapping<TTask>(WorkerStepTemplate config) where TTask : ITask
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            if (string.IsNullOrEmpty(config.Name))
            {
                throw new ArgumentNullException("config.Name", "config.Name is not defined");
            }

            Type? foundType = _taskTypeCacheService.GetTypeOrNull(typeof(TTask).Name);

            if (foundType == null)
            {
                throw new InvalidOperationException($"Failed to find task with name {typeof(TTask).Name}");
            }

            string name = config.Name!;

            if (_mappings.ContainsKey(name))
            {
                throw new DuplicateNameException($"Duplicate mapping name {name}");
            }

            _mappings.GetOrAdd(name, foundType);
        }

        public Type? GetTypeForMappingOrNull(WorkerStepTemplate config)
        {
            if (config == null)
            {
                throw new ArgumentNullException(nameof(config));
            }

            if (string.IsNullOrEmpty(config.Name))
            {
                throw new ArgumentNullException("config.Name", "config.Name is not defined");
            }

            return _mappings.TryGetValue(config.Name!, out Type? taskType) ? taskType : null;
        }
    }
}
