﻿namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal interface ITaskHandlerFactory
    {
        ITaskHandler? GetTaskHandler(string stepTemplateName);
    }
}