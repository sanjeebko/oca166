﻿using System;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal interface ITaskTypeCacheService
    {
        Type? GetTypeOrNull(string taskType);
    }
}