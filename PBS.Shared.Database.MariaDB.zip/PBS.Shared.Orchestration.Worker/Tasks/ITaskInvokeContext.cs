﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public interface ITaskInvokeContext
    {
        WorkerStepTemplate StepTemplate { get; }
        WorkerTaskInvokeRequest Request { get; }
    }
}