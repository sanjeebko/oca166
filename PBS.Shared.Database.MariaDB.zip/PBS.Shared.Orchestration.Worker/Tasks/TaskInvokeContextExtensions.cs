﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public static class TaskInvokeContextExtensions
    {
        public static ITaskInvokeContext Create(WorkerStepTemplate stepTemplate, WorkerTaskInvokeRequest request)
        {
            return new TaskInvokeContext(stepTemplate, request);
        }
    }
}