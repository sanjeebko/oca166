﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Orchestration.Worker.Services;
using PBS.Shared.Orchestration.Worker.Tasks.Events;
using System;
using System.Text.Json;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tasks.Handlers
{
    internal class StepStartedEventHandler : EventHandlerBase<StepStartedEvent>
    {
        private readonly IOrchestrationClientMessagingService _orchestrationClientService;
        private readonly ILogger<StepStartedEventHandler> _logger;
        private const string InvokeMethodName = "InvokeTaskStarted";

        public StepStartedEventHandler(IOrchestrationClientMessagingService orchestrationClientService, ILogger<StepStartedEventHandler> logger)
        {
            _orchestrationClientService = orchestrationClientService;
            _logger = logger;
        }

        protected override async Task HandleAsync(StepStartedEvent evt)
        {
            try
            {
                var message = JsonSerializer.Serialize(evt);

                _logger.LogInformation("Sending message {StepStartedMessage}", message);

                await _orchestrationClientService.SendMessageAsync(InvokeMethodName, message);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error sending message");
            }
        }
    }
}
