﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Tasks.Events;
using System;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tasks.Handlers
{
    internal class InvokeTaskEventHandler : EventHandlerBase<InvokeTaskEvent>
    {
        private readonly ITaskManager _taskManager;
        private readonly ILogger<InvokeTaskEventHandler> _logger;

        public InvokeTaskEventHandler(ITaskManager taskManager, ILogger<InvokeTaskEventHandler> logger)
        {
            _taskManager = taskManager;
            _logger = logger;
        }

        protected override async Task HandleAsync(InvokeTaskEvent evt)
        {
            _logger.LogDebug("Invoking task with payload {InvokeTaskEventPayload}", evt.Payload);

            try
            {
                ValidatePayload(evt.Payload);

                WorkerTaskInvokeRequest? taskInvokeRequest = WorkerTaskInvokeRequestExtensions.Deserialize(evt.Payload);
                if (taskInvokeRequest is null)
                    throw new InvalidOperationException("Task invoke request message could not be deserialized");
                await _taskManager.InvokeTaskAsync(taskInvokeRequest);
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Error invoking task");
            }
        }

        private static void ValidatePayload(string? payload)
        {
            if (string.IsNullOrEmpty(payload))
                throw new ArgumentNullException(payload);
        }
    }
}
