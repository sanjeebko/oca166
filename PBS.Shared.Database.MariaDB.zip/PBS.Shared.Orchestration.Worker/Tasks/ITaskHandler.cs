﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public interface ITaskHandler
    {
        Task<WorkerTaskInvokeResult> ExecuteAsync(WorkerTaskInvokeRequest invokeRequest);

        Type TaskType { get; }
    }
}