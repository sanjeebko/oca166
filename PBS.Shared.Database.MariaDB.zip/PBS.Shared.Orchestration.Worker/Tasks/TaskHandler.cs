﻿using PBS.Shared.Orchestration.Worker.Models;
using System;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    internal class TaskHandler : ITaskHandler
    {
        private readonly ITask _task;
        private readonly WorkerStepTemplate _stepTemplate;

        public TaskHandler(ITask task, WorkerStepTemplate stepTemplate)
        {
            _task = task;
            _stepTemplate = stepTemplate;
            TaskType = task.GetType();
        }

        public async Task<WorkerTaskInvokeResult> ExecuteAsync(WorkerTaskInvokeRequest invokeRequest)
        {
            return await _task.ExecuteAsync(TaskInvokeContextExtensions.Create(_stepTemplate, invokeRequest));
        }

        public Type TaskType { get; }
    }
}