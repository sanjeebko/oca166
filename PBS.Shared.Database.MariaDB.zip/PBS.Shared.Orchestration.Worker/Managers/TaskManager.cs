﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Tasks.Events;
using PBS.Shared.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Managers
{
    internal class TaskManager : ITaskManager
    {
        private readonly ILogger<TaskManager> _logger;
        private readonly IEventManager _eventManager;
        private readonly ITaskHandlerFactory _taskHandlerFactory;

        public TaskManager(ILogger<TaskManager> logger, IEventManager eventManager, ITaskHandlerFactory taskHandlerFactory)
        {
            _logger = logger;
            _eventManager = eventManager;
            _taskHandlerFactory = taskHandlerFactory;
        }

        public async Task<WorkerTaskInvokeResult?> InvokeTaskAsync(WorkerTaskInvokeRequest invokeRequest)
        {
            ValidateRequest(invokeRequest);

            ITaskHandler? handler = _taskHandlerFactory.GetTaskHandler(invokeRequest.StepTemplateName!);

            using var _ = _logger.WithProperties(new Dictionary<string, object>
            {
                ["TaskType"] = handler?.TaskType.Name ?? string.Empty,
                ["StepTemplateName"] = invokeRequest.StepTemplateName ?? string.Empty,
                ["StepInstanceId"] = invokeRequest.StepInstanceId ?? string.Empty,
            });

            if (handler == null)
            {
                _logger.LogWarning("Failed to find task for step template");
                return null;
            }

            Stopwatch stopwatch = Stopwatch.StartNew();

            _logger.LogInformation("Executing task");

            WorkerTaskInvokeResult? taskResult;

            try
            {
                taskResult = await handler.ExecuteAsync(invokeRequest);
            }
            catch (Exception e)
            {
                taskResult = TaskInvokeResultExtensions.Failed(e);
                _logger.LogError(e, "Error executing task");
            }

            await _eventManager.PublishAsync(new StepCompletedEvent { Result = taskResult, StepTemplateName = invokeRequest.StepTemplateName, StepInstanceId = invokeRequest.StepInstanceId });

            _logger.LogInformation("Executing task completed in {TaskExecutionDuration}", stopwatch.Elapsed.ToString());

            return taskResult;
        }

        private static void ValidateRequest(WorkerTaskInvokeRequest? invokeRequest)
        {
            if (invokeRequest == null)
            {
                throw new ArgumentNullException(nameof(invokeRequest));
            }

            if (string.IsNullOrEmpty(invokeRequest.StepTemplateName))
            {
                throw new ArgumentNullException("invokeRequest.StepTemplateName", "invokeRequest.StepTemplateName is not defined");
            }

            if (string.IsNullOrEmpty(invokeRequest.StepInstanceId))
            {
                throw new ArgumentNullException("invokeRequest.StepInstanceId", "invokeRequest.StepInstanceId is not defined");
            }
        }
    }
}
