﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Managers
{
    internal class EventManager : IEventManager
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly ConcurrentDictionary<Type, List<Type>> _subscribers = new ConcurrentDictionary<Type, List<Type>>();
        private readonly ILogger _logger;

        public EventManager(ILogger<EventManager> logger, IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
            _logger = logger;
        }

        public async Task PublishAsync<TEvent>(TEvent evt) where TEvent : class, IEvent
        {
            Type eventType = typeof(TEvent);

            if (!_subscribers.TryGetValue(eventType, out List<Type>? handlerTypes))
            {
                return;
            }

            List<Type> types = handlerTypes.ToList();

            switch (types.Count)
            {
                case > 1:
                    await Task.WhenAll(types.Select(handlerType => ExecuteEventHandlerAsync(evt, handlerType)));
                    break;
                default:
                    await ExecuteEventHandlerAsync(evt, types[0]);
                    break;
            }
        }

        public async Task SendAsync<TEvent>(TEvent evt) where TEvent : class, IEvent
        {
            Type eventType = typeof(TEvent);

            if (!_subscribers.TryGetValue(eventType, out List<Type>? handlerTypes))
            {
                return;
            }

            foreach (Type handlerType in handlerTypes)
            {
                await ExecuteEventHandlerAsync(evt, handlerType);
            }
        }

        private async Task ExecuteEventHandlerAsync<TEvent>(TEvent evt, Type handlerType) where TEvent : class, IEvent
        {
            using IServiceScope scope = _serviceProvider.CreateScope();
            using var _ = _logger.WithProperties(new Dictionary<string, object>
            {
                ["EventId"] = evt.Id,
                ["EventType"] = evt.GetType().Name,
                ["HandlerType"] = handlerType.Name
            });
            try
            {
                IEventHandler handler = (IEventHandler)scope.ServiceProvider.GetRequiredService(handlerType);

                _logger.LogTrace("Executing event");

                await handler.ExecuteAsync(evt);
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Error on event subscriber: {EventSubscriberErrorMessage}", ex.Message);
            }
        }

        public void Subscribe<TEventHandler>() where TEventHandler : IEventHandler
        {
            Subscribe(typeof(TEventHandler));
        }

        public void Subscribe(Type handlerType)
        {
            Type eventHandlerType = handlerType;

            using var _ = _logger.WithProperty("HandlerType", handlerType.Name);

            Type? eventType = handlerType.BaseType?.GetGenericArguments().FirstOrDefault(s => typeof(IEvent).IsAssignableFrom(s));

            if (eventType == null)
            {
                _logger.LogWarning("Failed to find event type for handler");
                return;
            }

            _subscribers.AddOrUpdate(eventType, _ => new List<Type> { eventHandlerType }, (_, list) =>
            {
                if (!list.Contains(eventHandlerType))
                {
                    list.Add(eventHandlerType);
                }

                return list;
            });
        }
    }
}
