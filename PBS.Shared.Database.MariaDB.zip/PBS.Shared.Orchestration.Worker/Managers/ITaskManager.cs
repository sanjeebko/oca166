﻿using System.Threading.Tasks;
using PBS.Shared.Orchestration.Worker.Tasks;

namespace PBS.Shared.Orchestration.Worker.Managers
{
    public interface ITaskManager
    {
        Task<WorkerTaskInvokeResult?> InvokeTaskAsync(WorkerTaskInvokeRequest invokeRequest);
    }
}
