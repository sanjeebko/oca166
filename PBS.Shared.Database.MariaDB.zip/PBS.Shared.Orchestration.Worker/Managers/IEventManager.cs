﻿using System;
using System.Threading.Tasks;
using PBS.Shared.Orchestration.Worker.Events;

namespace PBS.Shared.Orchestration.Worker.Managers
{
    public interface IEventManager
    {
        /// <summary>
        /// None blocking publish of event <param name="evt"></param> to all subscribed <see cref="IEventHandler"/> for that event type <see cref="TEvent"/>
        /// </summary>
        /// <typeparam name="TEvent">Event type</typeparam>
        /// <param name="evt">Event to publish</param>
        Task PublishAsync<TEvent>(TEvent evt) where TEvent : class, IEvent;

        /// <summary>
        /// Blocking send of event <param name="evt"></param> to all subscribed <see cref="IEventHandler"/> for that event type <see cref="TEvent"/>
        /// </summary>
        /// <typeparam name="TEvent">Event type</typeparam>
        /// <param name="evt">Event to publish</param>
        Task SendAsync<TEvent>(TEvent evt) where TEvent : class, IEvent;

        /// <summary>
        /// Subscribes <see cref="TEventHandler"/>
        /// </summary>
        /// <typeparam name="TEventHandler"></typeparam>
        void Subscribe<TEventHandler>() where TEventHandler : IEventHandler;

        /// <summary>
        /// Subscribes handler <see cref="EventHandlerBase{TEvent}"/> of type <param name="handlerType"></param>
        /// </summary>
        /// <param name="handlerType"></param>
        void Subscribe(Type handlerType);
    }
}
