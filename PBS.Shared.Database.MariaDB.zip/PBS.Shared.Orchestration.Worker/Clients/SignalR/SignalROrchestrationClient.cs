﻿using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Clients.SignalR
{
    internal class SignalROrchestrationClient : IOrchestrationClient
    {
        public event Func<Task>? OnConnected;
        public bool Connected => _connection != null && _connection.State == HubConnectionState.Connected;

        protected HubConnection? _connection;
        private CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        private volatile bool _disposing;
        private readonly ILogger<SignalROrchestrationClient> _logger;
        private readonly ConcurrentDictionary<string, ISignalRHubMethodSubscription> _subscriptions = new ConcurrentDictionary<string, ISignalRHubMethodSubscription>(StringComparer.OrdinalIgnoreCase);

        private const int ConnectionRetryDelayMs = 2000;

        public SignalROrchestrationClient(ILogger<SignalROrchestrationClient> logger)
        {
            _logger = logger;
        }

        public async Task ConnectAsync(string url)
        {
            _logger.LogInformation("Connecting to {SignalRHubAddress}", url);

            if (_connection != null)
                await _connection.DisposeAsync();

            _cancellationTokenSource = new CancellationTokenSource();

            _connection = GenerateConnection(url);

            _connection.Reconnected += message =>
            {
                _logger.LogInformation("Reconnected {ConnectionId}, message {SignalRReconnectedEventMessage}", _connection.ConnectionId, message);

                return OnConnected?.Invoke();
            };

            _connection.Closed += error =>
            {
                _logger.LogError(error, "Connection {ConnectionId} closed, message {SignalRClosedEventErrorMessage}", _connection.ConnectionId, error?.Message);

                if (_disposing)
                    return Task.CompletedTask;

                return ConnectAsync(url);
            };

            _connection.Reconnecting += error =>
            {
                _logger.LogWarning(error, "Reconnecting {ConnectionId}, message {SignalRReconnectingEventErrorMessage}", _connection.ConnectionId, error?.Message);

                return Task.CompletedTask;
            };

            foreach (KeyValuePair<string, ISignalRHubMethodSubscription> subscription in _subscriptions)
            {
                _logger.LogInformation("Creating subscription for {SubscriptionKey}", subscription.Key);

                subscription.Value.Subscribe(_connection);
            }

            await ConnectWithRetryAsync(url);
        }

        protected virtual HubConnection GenerateConnection(string url)
        {
            return new HubConnectionBuilder()
                 .WithUrl(url)
                 .AddJsonProtocol()
                 .WithAutomaticReconnect(new HubConnectionAlwaysRetryPolicy(_cancellationTokenSource.Token))
                 .Build();
        }

        public async Task SendMessage(string method, object message)
        {
            if (_connection?.State == HubConnectionState.Connected)
            {
                await _connection.SendAsync(method, message);
            }
        }

        public void Subscribe<T>(string method, Func<T, Task> function)
        {
            _subscriptions.AddOrUpdate(method, s => new SignalRHubMethodSubscription<T>(method, function), (s, subscription) =>
            {
                subscription.UnSubscribe();
                return new SignalRHubMethodSubscription<T>(method, function);
            });
        }

        public void Subscribe(string method, Func<string, Task> function)
        {
            Subscribe<string>(method, function);
        }

        public void UnSubscribe(string method)
        {
            if (_subscriptions.TryRemove(method, out ISignalRHubMethodSubscription? subscription))
            {
                subscription.UnSubscribe();
            }
        }

        public async Task DisconnectAsync()
        {
            _logger.LogInformation("Disconnecting client");

            _cancellationTokenSource.Cancel(false);

            if (_connection != null && _connection.State == HubConnectionState.Connected)
            {
                await _connection.DisposeAsync();
            }
        }

        public async Task DisposeAsync()
        {
            if (_disposing)
                return;

            _logger.LogInformation("Disposing client");

            _disposing = true;

            await DisconnectAsync();
        }


        private async Task ConnectWithRetryAsync(string url)
        {
            // Keep trying to until we can start or the token is canceled.
            while (!_cancellationTokenSource.IsCancellationRequested)
            {
                try
                {
                    await _connection?.StartAsync(_cancellationTokenSource.Token)!;

                    _logger.LogTrace("Connection state {HubConnectionState}", _connection.State);

                    OnConnected?.Invoke();

                    return;
                }
                catch when (_cancellationTokenSource.Token.IsCancellationRequested)
                {
                    return;
                }
                catch (Exception e)
                {
                    _logger.LogWarning(e, "Failed to connect {SignalRHubAddress}", url);

                    await Task.Delay(ConnectionRetryDelayMs, _cancellationTokenSource.Token);
                }
            }
        }
    }
}