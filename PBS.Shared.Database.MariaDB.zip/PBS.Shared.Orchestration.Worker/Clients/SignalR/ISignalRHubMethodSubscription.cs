﻿using Microsoft.AspNetCore.SignalR.Client;

namespace PBS.Shared.Orchestration.Worker.Clients.SignalR
{
    internal interface ISignalRHubMethodSubscription
    {
        void Subscribe(HubConnection connection);

        void UnSubscribe();
    }
}