﻿using Microsoft.AspNetCore.SignalR.Client;
using System;
using System.Threading;

namespace PBS.Shared.Orchestration.Worker.Clients.SignalR
{
    internal class HubConnectionAlwaysRetryPolicy : IRetryPolicy
    {
        private readonly CancellationToken _token;

        private const int DefaultRetryDelaySeconds = 2;

        public HubConnectionAlwaysRetryPolicy(CancellationToken token)
        {
            _token = token;
        }

        public TimeSpan? NextRetryDelay(RetryContext retryContext)
        {
            if (_token.IsCancellationRequested)
                return null;
            return TimeSpan.FromSeconds(DefaultRetryDelaySeconds);
        }
    }
}