﻿using Microsoft.AspNetCore.SignalR.Client;
using System;

namespace PBS.Shared.Orchestration.Worker.Clients.SignalR
{
    internal class HubConnectionRandomRetryPolicy : IRetryPolicy
    {
        private readonly Random _random = new Random();

        private const int MaxAllowedRetrySeconds = 60;

        public TimeSpan? NextRetryDelay(RetryContext retryContext)
        {
            if (retryContext.ElapsedTime < TimeSpan.FromSeconds(MaxAllowedRetrySeconds))
            {
                return TimeSpan.FromSeconds(_random.NextDouble() * 10);
            }

            return null;
        }
    }
}