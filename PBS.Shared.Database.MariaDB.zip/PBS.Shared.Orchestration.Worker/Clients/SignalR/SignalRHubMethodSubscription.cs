﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR.Client;

namespace PBS.Shared.Orchestration.Worker.Clients.SignalR
{
    internal class SignalRHubMethodSubscription<T> : ISignalRHubMethodSubscription
    {
        public string Method { get; }
        public Func<T, Task> Function { get; }

        private IDisposable? _subscriptionObject;

        public SignalRHubMethodSubscription(string method, Func<T, Task> function)
        {
            Method = method;
            Function = function;
        }

        public void Subscribe(HubConnection connection)
        {
            _subscriptionObject?.Dispose();

            _subscriptionObject = connection.On<T>(Method, Function);
        }

        public void UnSubscribe()
        {
            _subscriptionObject?.Dispose();
        }
    }
}