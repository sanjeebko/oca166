﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Clients
{
    public interface IOrchestrationClient
    {
        event Func<Task> OnConnected;

        bool Connected { get; }

        Task ConnectAsync(string url);

        Task DisconnectAsync();

        Task DisposeAsync();

        Task SendMessage(string method, object message);

        void Subscribe<T>(string method, Func<T, Task> function);

        void Subscribe(string method, Func<string, Task> function);

        void UnSubscribe(string method);
    }
}
