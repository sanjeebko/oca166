﻿using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Events
{
    /// <summary>
    /// Base class for handling event <see cref="TEvent"/>, registered as Scoped
    /// </summary>
    /// <typeparam name="TEvent"></typeparam>
    public abstract class EventHandlerBase<TEvent> : IEventHandler where TEvent : class, IEvent
    {
        public Task ExecuteAsync(IEvent evt)
        {
            return HandleAsync((TEvent)evt);
        }

        protected abstract Task HandleAsync(TEvent evt);
    }
}
