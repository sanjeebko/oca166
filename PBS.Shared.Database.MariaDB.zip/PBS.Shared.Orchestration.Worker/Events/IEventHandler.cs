﻿
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Events
{
    public interface IEventHandler
    {
        Task ExecuteAsync(IEvent evt);
    }
}
