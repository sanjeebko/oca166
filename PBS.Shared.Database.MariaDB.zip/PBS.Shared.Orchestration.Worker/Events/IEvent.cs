﻿using System;

namespace PBS.Shared.Orchestration.Worker.Events
{
    public interface IEvent
    {
        string Id { get; set; }

        DateTimeOffset EventTimeUtc { get; set; }
    }
}