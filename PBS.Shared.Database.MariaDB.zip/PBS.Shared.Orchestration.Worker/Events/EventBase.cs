﻿using System;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Events
{
    public abstract class EventBase : IEvent
    {
        [JsonPropertyName("eventId")]
        public string Id { get; set; } = Guid.NewGuid().ToString("N");

        [JsonPropertyName("eventTimeUtc")]
        public DateTimeOffset EventTimeUtc { get; set; } = DateTimeOffset.UtcNow;
    }
}
