﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Paths;
using PBS.Shared.Orchestration.Worker.Tasks.Events;
using System;
using System.Globalization;
using System.Text.Json;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Services
{
    internal class OrchestrationClientService : IOrchestrationClientService, IOrchestrationClientMessagingService
    {
        private readonly ILogger<OrchestrationClientService> _logger;
        private readonly IWorkerConfigService _workerConfigService;
        private readonly IServicePathResolver _servicePathResolver;
        private readonly IEventManager _eventManager;
        private readonly IOrchestrationClient _orchestrationClient;

        public OrchestrationClientService(ILogger<OrchestrationClientService> logger,
            IWorkerConfigService workerConfigService,
            IOrchestrationClient client,
            IServicePathResolver servicePathResolver,
            IEventManager eventManager)
        {
            _logger = logger;
            _workerConfigService = workerConfigService;
            _servicePathResolver = servicePathResolver;
            _eventManager = eventManager;
            _orchestrationClient = client;
        }

        public async Task StartAsync()
        {
            string serviceOrigin = _servicePathResolver.ResolveServiceOrigin(_workerConfigService.Value.OrchestrationEngineWebSocketEndpoint!);
            string requestUri = OrchestrationClientUrlResolver.ResolveUrl(serviceOrigin, _workerConfigService.Value.OrchestrationEngineWebSocketEndpoint, _workerConfigService.Value.WorkerName);

            _logger.LogInformation("Connecting to {OrchestrationServerAddress}", requestUri);

            _orchestrationClient.OnConnected += OrchestrationClientOnConnectedEventHandler;

            _orchestrationClient.Subscribe(OrchestrationSubscriptionType.Heartbeat.ToString(), Heartbeat);
            _orchestrationClient.Subscribe(OrchestrationSubscriptionType.InvokeTask.ToString(), InvokeTask);
            await _orchestrationClient.ConnectAsync(requestUri);
        }

        public async Task StopAsync()
        {
            await _orchestrationClient.DisposeAsync();
        }

        private async Task OrchestrationClientOnConnectedEventHandler()
        {
            try
            {
                await SendAnnouncementAsync();
            }
            catch (Exception e)
            {
                _logger.LogError(e, "Failed to send announcement message, error:{WorkerAnnouncementSendErrorMessage}", e.Message);
            }
        }

        private async Task InvokeTask(string message)
        {
            _logger.LogTrace("Received {MethodName} from server with {InvokeTaskMessage}", nameof(InvokeTask), message);

            await _eventManager.PublishAsync(new InvokeTaskEvent { Payload = message });
        }

        private async Task Heartbeat(string message)
        {
            _logger.LogTrace("Received {MethodName} from server {HeartbeatMessage}", nameof(Heartbeat), message);

            await SendHeartbeatAsync();
        }

        public async Task SendHeartbeatAsync()
        {
            await SendMessageAsync("Heartbeat", DateTime.Now.ToString(CultureInfo.InvariantCulture));
        }

        public async Task SendAnnouncementAsync()
        {
            string announcementMessage = _workerConfigService.Value.WorkerAnnouncement.Serialize();

            _logger.LogInformation("Sending announcement message, content:{WorkerAnnouncementMessageContent}", announcementMessage);

            await SendMessageAsync("Announcement", announcementMessage);
        }

        public async Task SendMessageAsync(string method, string message)
        {
            await _orchestrationClient.SendMessage(method, message);
        }

        public async Task SendMessageAsync<T>(string method, T message)
        {
            await _orchestrationClient.SendMessage(method, JsonSerializer.Serialize(message));
        }

        public bool Connected => _orchestrationClient.Connected;
    }
}
