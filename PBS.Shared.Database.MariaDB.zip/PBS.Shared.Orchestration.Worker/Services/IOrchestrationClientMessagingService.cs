﻿using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Services
{
    public interface IOrchestrationClientMessagingService
    {
        Task SendMessageAsync(string method, string message);

        Task SendMessageAsync<T>(string method, T message);
    }
}