﻿using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Services
{
    internal interface IOrchestrationClientService
    {
        Task StartAsync();

        Task StopAsync();

        Task SendHeartbeatAsync();

        Task SendAnnouncementAsync();

        bool Connected { get; }
    }
}