﻿using System;
using System.Text.RegularExpressions;

namespace PBS.Shared.Orchestration.Worker.Services
{
    public static class OrchestrationClientUrlResolver
    {
        public const string UnknownWorkerName = "Unknown Worker";

        public static string ResolveUrl(string serviceOrigin, string webSocketEndpoint, string? workerName)
        {
            serviceOrigin = serviceOrigin.RemoveLastCharacter("/");
            webSocketEndpoint = webSocketEndpoint.RemoveLastCharacter("/").EnsureStartsWith("/");

            string escapedWorkerName = EscapeString(string.IsNullOrWhiteSpace(workerName) ? $"{UnknownWorkerName}-{GenerateUid()}" : workerName);
            return $"{serviceOrigin}{webSocketEndpoint}?identifier={escapedWorkerName}";
        }

        private static string GenerateUid()
        {
            return Regex.Replace(Convert.ToBase64String(Guid.NewGuid().ToByteArray()), "[/+=]", "");
        }

        public static string EscapeString(string value)
        {
            return Uri.EscapeDataString(value);
        }

        private static string RemoveLastCharacter(this string source, string character)
        {
            return source.EndsWith(character) ? source.Remove(source.Length - 1, 1) : source;
        }

        private static string EnsureStartsWith(this string source, string character)
        {
            return !source.StartsWith(character) ? character + source : source;
        }
    }
}
