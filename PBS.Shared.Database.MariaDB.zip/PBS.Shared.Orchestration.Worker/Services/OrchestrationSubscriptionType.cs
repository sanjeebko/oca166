﻿namespace PBS.Shared.Orchestration.Worker.Services
{
    public enum OrchestrationSubscriptionType
    {
        Heartbeat,
        InvokeTask
    }
}
