﻿using System;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Options
{
    public interface IWorkerConfigService
    {
        /// <summary>
        /// Worker config
        /// </summary>
        WorkerConfig Value { get; }

        /// <summary>
        /// Event handler triggered when worker config is updated
        /// </summary>
        event Action<WorkerConfig> OnChange;

        /// <summary>
        /// Updates current worker configuration
        /// </summary>
        /// <param name="other"></param>
        void Change(WorkerConfig other);

        /// <summary>
        /// Validates current worker config
        /// </summary>
        void Validate();
    }
}
