﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Hosting;

namespace PBS.Shared.Orchestration.Worker.Services
{
    /// <summary>
    /// Creates connection to Orchestration engine
    /// </summary>
    internal class OrchestrationClientInitializer : BackgroundService
    {
        private readonly IOrchestrationClientService _orchestrationClientService;

        public OrchestrationClientInitializer(IOrchestrationClientService orchestrationClientService)
        {
            _orchestrationClientService = orchestrationClientService;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            await Task.Yield(); // hack, not to block the app startup

            await _orchestrationClientService.StartAsync();
        }

        public override async Task StopAsync(CancellationToken cancellationToken)
        {
            await _orchestrationClientService.StopAsync();

            await base.StopAsync(cancellationToken);
        }
    }
}
