﻿using System;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Validators;

namespace PBS.Shared.Orchestration.Worker.Options
{
    internal class WorkerConfigService : IWorkerConfigService
    {
        private volatile WorkerConfig _current;
        private readonly IWorkerConfigValidator _workerConfigValidator;

        public event Action<WorkerConfig>? OnChange;
        
        public WorkerConfigService(WorkerConfig workerConfig, IWorkerConfigValidator workerConfigValidator)
        {
            _current = workerConfig;
            _workerConfigValidator = workerConfigValidator;
        }

        public WorkerConfig Value => _current;

        public void Change(WorkerConfig other)
        {
            _workerConfigValidator.Validate(other);

            _current = other;

            OnChange?.Invoke(Value);
        }

        public void Validate()
        {
            _workerConfigValidator.Validate(Value);
        }
    }
}