﻿using PBS.Shared.Orchestration.Worker.Events;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Options
{
    public class WorkerConfigChangedEvent : EventBase
    {
        public WorkerConfigChangedEvent(WorkerConfig current)
        {
            Current = current;
        }

        public WorkerConfig Current { get; }
    }
}
