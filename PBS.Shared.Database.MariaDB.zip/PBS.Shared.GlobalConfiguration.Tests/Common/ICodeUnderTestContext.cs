﻿using Moq;

namespace PBS.Shared.GlobalConfiguration.Tests.Common
{
    public interface ICodeUnderTestContext
    {
        /// <summary>
        /// Use GetMock() to retrieve an instance of the mocked TDependency.
        /// </summary>
        /// <typeparam name="TDependency"></typeparam>
        Mock<TDependency> GetMock<TDependency>() where TDependency : class;

        /// <summary>
        /// Use GetDependency() to retrieve any none mock objects
        /// </summary>
        /// <typeparam name="TDependency"></typeparam>
        TDependency GetDependency<TDependency>() where TDependency : class;
    }
}