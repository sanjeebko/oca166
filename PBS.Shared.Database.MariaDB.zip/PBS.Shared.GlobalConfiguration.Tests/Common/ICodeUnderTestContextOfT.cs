﻿namespace PBS.Shared.GlobalConfiguration.Tests.Common
{
    public interface ICodeUnderTestContext<out TCodeUnderTest> : ICodeUnderTestContext where TCodeUnderTest : class
    {
        /// <summary>
        /// Code under test instance
        /// </summary>
        TCodeUnderTest CodeUnderTest { get; }
    }
}
