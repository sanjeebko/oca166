﻿using Microsoft.Extensions.Logging;
using Xunit.Abstractions;

namespace PBS.Shared.GlobalConfiguration.Tests.Common.Logging
{
    public class CategoryMockupLoggerFactory : ILoggerFactory
    {
        private readonly ILoggerProvider _provider;

        public CategoryMockupLoggerFactory(ITestOutputHelper testOutputHelper)
        {
            _provider = new CategoryMockupLoggerProvider(testOutputHelper, null);
        }
        public ILogger CreateLogger(string categoryName)
        {
            return _provider.CreateLogger(categoryName);
        }

        public void AddProvider(ILoggerProvider provider)
        {
            //
        }

        public void Dispose()
        {
            //
        }
    }
}