﻿using System;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Testing;
using Xunit.Abstractions;

namespace PBS.Shared.GlobalConfiguration.Tests.Common
{
    public abstract class CodeUnderTestBaseUnitTest
    {
        protected readonly ITestOutputHelper _outputHelper;

        protected CodeUnderTestBaseUnitTest(ITestOutputHelper outputHelper)
        {
            _outputHelper = outputHelper;
        }

        public virtual ILogger<T> CreateLogger<T>()
        {
            return new MockILogger<T>(_outputHelper);
        }

        public virtual ILogger CreateLogger(object obj)
        {
            MethodInfo createLoggerMethod = GetType().GetMethods().FirstOrDefault(m => m.Name == "CreateLogger" && m.IsGenericMethodDefinition);
            MethodInfo genericCreateLoggerMethod = createLoggerMethod?.MakeGenericMethod(obj is Type objType ? objType : obj.GetType());
            return genericCreateLoggerMethod?.Invoke(this, null) as ILogger;
        }
    }

    public abstract class CodeUnderTestBaseUnitTest<TCodeUnderTest> : CodeUnderTestBaseUnitTest where TCodeUnderTest : class
    {
        protected CodeUnderTestBaseUnitTest(ITestOutputHelper outputHelper) : base(outputHelper)
        {
        }

        public ILogger<TCodeUnderTest> CreateLogger()
        {
            return new MockILogger<TCodeUnderTest>(_outputHelper);
        }

        protected virtual CodeUnderTestContext<TCodeUnderTest> CreateContextForCodeUnderTest()
        {
            return new CodeUnderTestContext<TCodeUnderTest>();
        }
    }
}
