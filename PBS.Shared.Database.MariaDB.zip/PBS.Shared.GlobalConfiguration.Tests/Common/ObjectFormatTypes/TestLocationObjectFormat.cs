﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Tests.Common.ObjectFormatTypes
{
    public class TestLocationObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string DomainPropertyName = "Domain";
        public const string PathPropertyName = "Path";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
        {
            var objectFormat = new ConfigObjectFormat
            {
                Category = "Location",
                DisplayName = "Test location format",
                Name = "TestLocation",
                Hint = "location",
                Deprecated = false,
                Properties = new Dictionary<string, PropertyFormat>
                {
                    { DomainPropertyName, new PropertyFormat
                    {
                        Name = DomainPropertyName,
                        DisplayName = "Domain",
                        Hint = "location",
                        IsCollection = false,
                        Types = new []
                        {
                            new PropertyType
                            {
                                Name = "string",
                                Validators = new Dictionary<string, object>
                                {
                                    { ValidatorKeys.MaxLength, 20 },
                                    { ValidatorKeys.MinLength, 3 },
                                }
                            }
                        },
                    }},
                    { PathPropertyName, new PropertyFormat
                    {
                        Name = PathPropertyName,
                        DisplayName = "Location path",
                        Hint = "path",
                        IsCollection = false,
                        Types = new []
                        {
                            new PropertyType
                            {
                                Name = "string",
                                Validators = new Dictionary<string, object>
                                {
                                    { ValidatorKeys.Required, ValidatorArgs.Default},
                                    { ValidatorKeys.MinLength, 4 }
                                }
                            }
                        },
                    }}
                },
            };

            return objectFormat;
        }

        public ConfigObjectFormat Object => Instance;
    }
}
