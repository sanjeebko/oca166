﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Tests.Common.ObjectFormatTypes
{
    public class TestCredentialObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string UsernamePropertyName = "Username";
        public const string PasswordPropertyName = "Password";
        public const string PinPropertyName = "PIN";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
        {
            var objectFormat = new ConfigObjectFormat
            {
                Category = "Credential",
                Name = "TestCredential",
                DisplayName = "Test Credential Format",
                Hint = "credential",
                Deprecated = false,
                Properties = new Dictionary<string, PropertyFormat>
                {
                    { UsernamePropertyName, new PropertyFormat
                    {
                        Name = UsernamePropertyName,
                        DisplayName = "UserName",
                        Hint = "user",
                        IsCollection = false,
                        Types = new []
                        {
                            new PropertyType
                            {
                                Name = "string",
                                Validators = new Dictionary<string, object>
                                {
                                    { ValidatorKeys.Required, ValidatorArgs.Default},
                                    { ValidatorKeys.MaxLength, 20 },
                                    { ValidatorKeys.MinLength, 3 },
                                    { ValidatorKeys.Pattern, "(.*)"}
                                }
                            }
                        },
                    }},
                    { PasswordPropertyName, new PropertyFormat
                    {
                        Name = PasswordPropertyName,
                        DisplayName = "Password",
                        Hint = "Password",
                        IsCollection = false,
                        Flags = new [] { FormatPropertyMetadata.Sensitive, FormatPropertyMetadata.Password },
                        Types = new []
                        {
                            new PropertyType
                            {
                                Name = "string",
                                Validators = new Dictionary<string, object>
                                {
                                    { ValidatorKeys.Required, ValidatorArgs.Default},
                                    { ValidatorKeys.MinLength, 4 }
                                }
                            }
                        },
                    }},
                    {
                        PinPropertyName, new PropertyFormat
                        {
                            Name = PinPropertyName,
                            DisplayName = "Pin",
                            Hint = "pin",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = "number"
                                }
                            }
                        }
                    }
                },
            };

            return objectFormat;
        }

        public ConfigObjectFormat Object => Instance;
    }
}
