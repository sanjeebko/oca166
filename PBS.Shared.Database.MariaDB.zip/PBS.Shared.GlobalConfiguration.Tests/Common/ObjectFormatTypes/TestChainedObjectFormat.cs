﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Tests.Common.ObjectFormatTypes
{
    public class TestChainedObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string FormatName = "ChainedObject";
        public const string LinkPropertyName = "link";
        public const string MultiLinkPropertyName = "multiLink";
        public const string EditablePropertyName = "editable";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
        {
            var objectFormat = new ConfigObjectFormat
            {
                Category = "Test",
                DisplayName = "Chained Object",
                Name = FormatName,
                Hint = "An object which has 0-N properties referencing other chained objects",
                Deprecated = false,
                Properties = new Dictionary<string, PropertyFormat>
                {
                    { 
                        LinkPropertyName, new PropertyFormat
                        {
                            Name = LinkPropertyName,
                            DisplayName = LinkPropertyName,
                            Hint = "An optional property for a single referenced chained object",
                            IsCollection = false,
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = "Configuration.ChainedObject"
                                }
                            },
                        }
                    },
                    { 
                        MultiLinkPropertyName, new PropertyFormat
                        {
                            Name = MultiLinkPropertyName,
                            DisplayName = MultiLinkPropertyName,
                            Hint = "An optional property for a collection of chained object references",
                            IsCollection = true,
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = "Configuration.ChainedObject"
                                }
                            },
                        }
                    },
                    {
                        EditablePropertyName, new PropertyFormat
                        {
                            Name = EditablePropertyName,
                            DisplayName = EditablePropertyName,
                            Hint = "An optional string property that can be any value",
                            IsCollection = true,
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = "string"
                                }
                            },
                        }
                    }
                },
            };

            return objectFormat;
        }

        public ConfigObjectFormat Object => Instance;
    }
}
