﻿using System;
using System.Collections.Generic;
using Moq;

namespace PBS.Shared.GlobalConfiguration.Tests.Common
{
    public class CodeUnderTestContext : ICodeUnderTestContext
    {
        private readonly Dictionary<Type, object> mockDependencies = new Dictionary<Type, object>();
        private readonly Dictionary<Type, object> otherDependencies = new Dictionary<Type, object>();

        /// <summary>
        /// Use MockFor() to create or retrieve an instance of the mocked TDependency.
        /// </summary>
        /// <typeparam name="TDependency"></typeparam>
        /// <param name="parameters">Mock constructor parameters</param>
        public Mock<TDependency> MockFor<TDependency>(params object[] parameters) where TDependency : class
        {
            if (!ContainsMock<TDependency>())
                AddMock<TDependency>(parameters);
            return GetMockInternal<TDependency>();
        }

        /// <summary>
        /// Use MockFor() to create or retrieve an instance of the mocked TDependency.
        /// </summary>
        /// <typeparam name="TDependency"></typeparam>
        /// <param name="instance">Instance of mock</param>
        public Mock<TDependency> MockFor<TDependency>(Mock<TDependency> instance) where TDependency : class
        {
            if (!ContainsMock<TDependency>())
                AddMock(instance);
            return GetMockInternal<TDependency>();
        }

        public void AddDependencies(params object[] dependencyObjects)
        {
            foreach (var dependency in dependencyObjects)
            {
                otherDependencies.TryAdd(dependency.GetType(), dependency);
            }
        }

        protected virtual void AddMock<TDependency>(params object[] parameters) where TDependency : class
        {
            mockDependencies.Add(typeof(TDependency), new Mock<TDependency>(parameters));
        }

        protected virtual void AddMock<TDependency>(Mock<TDependency> instance) where TDependency : class
        {
            instance ??= new Mock<TDependency>();
            mockDependencies.Add(typeof(TDependency), instance);
        }

        protected virtual bool ContainsMock<TDependency>() where TDependency : class
        {
            return mockDependencies.ContainsKey(typeof(TDependency));
        }

        protected Mock<TDependency> GetMockInternal<TDependency>() where TDependency : class
        {
            if (mockDependencies.TryGetValue(typeof(TDependency), out object mockObject))
            {
                return (Mock<TDependency>)mockObject;
            }
            throw new InvalidOperationException($"Mock for {typeof(TDependency).Name} not created");
        }

        public virtual Mock<TDependency> GetMock<TDependency>() where TDependency : class
        {
            return GetMockInternal<TDependency>();
        }

        public TDependency GetDependency<TDependency>() where TDependency : class
        {
            if (otherDependencies.TryGetValue(typeof(TDependency), out object dependencyObject))
                return (TDependency)dependencyObject;
            return null;
        }
    }
}
