﻿using Moq;

namespace PBS.Shared.GlobalConfiguration.Tests.Common
{
    public class CodeUnderTestContext<TCodeUnderTest> : CodeUnderTestContext, ICodeUnderTestContext<TCodeUnderTest> where TCodeUnderTest : class
    {
        public override Mock<TDependency> GetMock<TDependency>() where TDependency : class
        {
            return GetMockInternal<TDependency>();
        }

        /// <summary>
        /// Builds context using code under test instance
        /// </summary>
        /// <param name="instance"></param>
        public ICodeUnderTestContext<TCodeUnderTest> Build(TCodeUnderTest instance)
        {
            CodeUnderTest = instance;
            return this;
        }

        public TCodeUnderTest CodeUnderTest { get; private set; }
    }
}
   
