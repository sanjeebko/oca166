﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.GlobalConfiguration.Extensions;
using PBS.Shared.PropertyTypeFormats;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.TypeFormatTests
{
    public class TypeFormatsTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void RegisterFormatsInConfigurationLibrary_RegistersExistingObjectFormatsSuccessfully()
        {
            Assert.Empty(TypeFormats.Instance.GetAll());
            IServiceCollection collection = new ServiceCollection();
            collection.RegisterConfigurationFormatsAndPropertyTypes();
            Assert.NotEmpty(TypeFormats.Instance.GetAll());
        }
    }
}
