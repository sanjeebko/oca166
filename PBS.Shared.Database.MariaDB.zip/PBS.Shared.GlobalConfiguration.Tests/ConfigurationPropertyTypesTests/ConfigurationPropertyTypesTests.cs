﻿using System;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests
{
    public class ConfigurationPropertyTypesTests
    {
        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Format1", "Configuration.Format1")]
        [InlineData("Format2", "Configuration.Format2")]
        public void BuildConfigurationFormatTypeCompositeKey_WhenDataIsValid_ReturnsValidCompositeKey(string formatType, string expected)
        {
            Assert.Equal(ConfigurationPropertyTypes.BuildConfigurationFormatTypeCompositeKey(formatType), expected);
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration", "Format1", "Configuration.Format1")]
        [InlineData("Configuration.", "Format1", "Configuration.Format1")]
        [InlineData("Configuration", "Format2", "Configuration.Format2")]
        [InlineData("SomeOtherContext", "Format3", "SomeOtherContext.Format3")]
        [InlineData("SomeOtherContext.", "Format3", "SomeOtherContext.Format3")]
        public void BuildFormatTypeCompositeKey_WhenDataIsValid_ReturnsValidCompositeKey(string context, string formatType, string expected)
        {
            Assert.Equal(ConfigurationPropertyTypes.BuildFormatTypeCompositeKey(context, formatType), expected);
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("")]
        [InlineData("  ")]
        [InlineData("Configuration.Format1")]
        public void BuildConfigurationFormatTypeCompositeKey_WhenFormatTypeIsInvalid_ThrowsException(string formatType)
        {
            Assert.ThrowsAny<Exception>(() => ConfigurationPropertyTypes.BuildConfigurationFormatTypeCompositeKey(formatType));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("", "")]
        [InlineData("", "FormatType")]
        [InlineData("  ", "FormatType")]
        [InlineData("Context", "")]
        [InlineData("Context", " ")]
        [InlineData("Context", "Context.Format1")]
        public void BuildFormatTypeCompositeKey_WhenFormatTypeIsInvalid_ThrowsException(string context, string formatType)
        {
            Assert.ThrowsAny<Exception>(() => ConfigurationPropertyTypes.BuildFormatTypeCompositeKey(context, formatType));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration.Format1")]
        [InlineData("Configuration.Format2")]
        public void IsConfigurationType_WhenTypeIsValid_ReturnsTrue(string type)
        {
            Assert.True(ConfigurationPropertyTypes.IsConfigurationType(type));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration.")]
        [InlineData("Format2")]
        [InlineData("InvalidContext.Format2")]
        [InlineData("InvalidContext;Format2")]
        [InlineData("")]
        [InlineData("Configuration;Format")]
        [InlineData("Configuration;")]
        [InlineData("Configuration+Format2")]
        public void IsConfigurationType_WhenTypeIsInvalid_ReturnsFalse(string type)
        {
            Assert.False(ConfigurationPropertyTypes.IsConfigurationType(type));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration.Format1", "Format1")]
        [InlineData("Configuration.Format2", "Format2")]
        public void ResolveConfigurationFormatType_WhenTypeIsValid_ReturnsExpectedFormat(string type, string expected)
        {
            Assert.Equal(expected, ConfigurationPropertyTypes.ResolveConfigurationFormatType(type));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("SomeOtherContext.Format1")]
        [InlineData("SomeOtherContext;Format1")]
        [InlineData("Format2")]
        [InlineData("")]
        public void ResolveConfigurationFormatType_WhenTypeIsInvalid_ReturnsEmptyString(string type)
        {
            Assert.Equal(string.Empty, ConfigurationPropertyTypes.ResolveConfigurationFormatType(type));
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void ValidateFormatType_WhenFormatTypeIsValid_NoExceptionIsThrown()
        {
            ConfigurationPropertyTypes.ValidateFormatType("FormatA");
            Assert.True(true);
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("")]
        [InlineData(null)]
        public void ValidateFormatType_WhenFormatTypeIsNullOrWhiteSpac_ExceptionIsThrown(string type)
        {
            Assert.Throws<ArgumentNullException>(() => ConfigurationPropertyTypes.ValidateFormatType(type));
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void ValidateFormatType_WhenFormatTypeIsNotFormattedCorrectly_ExceptionIsThrown()
        {
            Assert.ThrowsAny<InvalidOperationException>(() => ConfigurationPropertyTypes.ValidateFormatType("Configuration.FormatA"));
        }
    }
}
