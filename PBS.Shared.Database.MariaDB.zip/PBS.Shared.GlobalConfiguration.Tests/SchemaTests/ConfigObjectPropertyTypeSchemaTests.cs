﻿using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using System.Collections.Generic;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.SchemaTests
{
    public class ConfigObjectPropertyTypeSchemaTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<PropertyType> tester = new SchemaTester<PropertyType>();
            tester.ValidateProperty<string>("Name");
            tester.ValidateProperty<Dictionary<string, object>>("Validators");
            tester.ValidateProperty<IEnumerable<object>>("AcceptedValues");
            tester.ValidateProperty<object>("SuggestedDefault");
            tester.ValidateUncheckedProperties();
        }
    }
}
