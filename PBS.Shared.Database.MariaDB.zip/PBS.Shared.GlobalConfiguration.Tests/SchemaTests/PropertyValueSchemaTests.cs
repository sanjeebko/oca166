﻿using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.SchemaTests
{
    public class PropertyValueSchemaTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<PropertyValue> tester = new SchemaTester<PropertyValue>();
            tester.ValidateProperty<string>("Type");
            tester.ValidateProperty<object>("Value");
            tester.ValidateProperty<string>("Reference");
            tester.ValidateUncheckedProperties();
        }
    }
}
