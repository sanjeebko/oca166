﻿using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using System.Collections.Generic;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.SchemaTests
{
    public class ConfigObjectFormatSchemaTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<ConfigObjectFormat> tester = new SchemaTester<ConfigObjectFormat>();
            tester.ValidateProperty<string>("Name");
            tester.ValidateProperty<string>("Category");
            tester.ValidateProperty<string>("DisplayName");
            tester.ValidateProperty<IDictionary<string, PropertyFormat>>("Properties");
            tester.ValidateProperty<IDictionary<string, object>>("ObjectValidators");
            tester.ValidateProperty<bool>("Deprecated");
            tester.ValidateProperty<string>("Hint");
            tester.ValidateUncheckedProperties();
        }
    }
}
