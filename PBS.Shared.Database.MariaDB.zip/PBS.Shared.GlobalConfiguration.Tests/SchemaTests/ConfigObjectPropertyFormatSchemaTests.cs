﻿using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using System.Collections.Generic;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.SchemaTests
{
    public class ConfigObjectPropertyFormatSchemaTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<PropertyFormat> tester = new SchemaTester<PropertyFormat>();
            tester.ValidateProperty<string>("Name");
            tester.ValidateProperty<string>("DisplayName");
            tester.ValidateProperty<string>("Hint");
            tester.ValidateProperty<IEnumerable<PropertyType>>("Types");
            tester.ValidateProperty<IEnumerable<FormatPropertyMetadata>>("Flags");
            tester.ValidateProperty<bool>("IsCollection");
            tester.ValidateProperty<Dictionary<string, object>>("CollectionValidators");
            tester.ValidateUncheckedProperties();
        }
    }
}
