﻿using PBS.Shared.GlobalConfiguration.Extensions;
using PBS.Shared.PropertyTypeFormats;
using Xunit;

namespace PBS.Shared.GlobalConfiguration.Tests.PropertyValueExtensionsTests
{
    public class PropertyValueExtensionsTests
    {
        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration;Reference")]
        [InlineData("Configuration.")]
        [InlineData(".Type")]
        public void IsConfigurationType_WhenInvalidConfigurationTypeProvided_ReturnsFalse(string type)
        {
            PropertyValue value = new() { Type = type };
            Assert.False(value.IsConfigurationType());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void IsConfigurationType_WhenValidConfigurationTypeProvided_ReturnsTrue()
        {
            PropertyValue value = new() { Type = "Configuration.Type" };
            Assert.True(value.IsConfigurationType());
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Configuration;Reference")]
        [InlineData("Configuration.")]
        [InlineData(".Type")]
        public void ResolveConfigurationFormatType_WhenTypeIsInvalid_ReturnsEmptyString(string type)
        {
            PropertyValue value = new() { Type = type };
            Assert.Equal(string.Empty, value.ResolveConfigurationFormatType());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void ResolveConfigurationFormatType_WhenTypeIsValid_ReturnsFormat()
        {
            PropertyValue value = new() { Type = "Configuration.TestType" };
            Assert.Equal("TestType", value.ResolveConfigurationFormatType());
        }

        [Theory]
        [InlineData("Configuration;Type;1")]
        [InlineData("${Configuration;Type;1")]
        [InlineData("$Configuration;Type;1}")]
        [InlineData("$Configuration;Type;1")]
        [InlineData("${Configuration.Type;1")]
        [InlineData("")]
        [InlineData("${Configuration;Type;1;Extra}")]
        [InlineData("${Configuration;;1}")]
        [Trait("TestType", "UnitTest")]
        public void IsConfigurationReference_WhenIsInvalidReference_ReturnsFalse(string reference)
        {
            PropertyValue value = new() { Reference = reference };
            Assert.False(value.IsConfigurationReference());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void IsConfigurationReference_WhenIsValidReference_ReturnsTrue()
        {
            PropertyValue value = new() { Reference = "${Configuration;4}" };
            Assert.True(value.IsConfigurationReference());
        }
    }
}
