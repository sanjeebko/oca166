﻿namespace PBS.Shared.Storage
{
    public class StorageFileMoveRequest : StorageFileTransferRequest, IStorageFileMoveRequest
    {
    }
}
