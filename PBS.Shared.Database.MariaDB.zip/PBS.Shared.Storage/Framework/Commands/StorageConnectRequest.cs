﻿namespace PBS.Shared.Storage
{
    public class StorageConnectRequest : StorageCommand, IStorageConnectRequest
    {
        public IStorageCredential? Credential { get; set; }
        public StorageType? StorageType { get; set; }
    }
}