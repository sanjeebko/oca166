﻿namespace PBS.Shared.Storage
{
    public class StorageFileGetRequest : StorageCommand, IStorageFileGetRequest
    {
        public string? Path { get; set; }
        public IStorageCredential? Credential { get; set; }
        public StorageType? StorageType { get; set; }
    }
}