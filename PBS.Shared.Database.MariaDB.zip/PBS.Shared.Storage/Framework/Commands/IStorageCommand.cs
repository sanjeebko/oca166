﻿namespace PBS.Shared.Storage
{
    public interface IStorageCommand : IAttributesProvider
    {
    }
}
