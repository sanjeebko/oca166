﻿namespace PBS.Shared.Storage
{
    public class StorageFileDeleteRequest : StorageCommand, IStorageFileDeleteRequest
    {
        public IStorageCredential? Credential { get; set; }
        public string? Path { get; set; }
        public StorageType? StorageType { get; set; }
    }
}