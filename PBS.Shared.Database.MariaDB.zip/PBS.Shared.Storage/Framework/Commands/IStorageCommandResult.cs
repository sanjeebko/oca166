﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public interface IStorageCommandResult
    {
        bool Success { get; }
        TimeSpan Duration { get; }
        IEnumerable<Exception> Errors { get; }
    }
}
