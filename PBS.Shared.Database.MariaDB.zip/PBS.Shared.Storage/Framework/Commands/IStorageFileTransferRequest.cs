﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileTransferRequest : IStorageCommand
    {
        IStorageCredential? SourceCredential { get; }
        string? SourceFilePath { get; }
        StorageType? SourceStorageType { get; }

        IStorageCredential? DestinationCredential { get; }
        string? DestinationFilePath { get; }
        StorageType? DestinationStorageType { get; }

        bool Overwrite { get; }
        bool ValidateHash { get; }
    }
}