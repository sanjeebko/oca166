﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageFileChangeSubscriptionRequest : IStorageFileChangeSubscriptionRequest
    {
        public StorageType? StorageType { get; set; }
        public IStorageCredential? Credential { get; set; }
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}