﻿namespace PBS.Shared.Storage
{
    public interface IStorageGetAllFilesRequest : IStorageCommand, IStorageTypeProvider
    {
        IStorageCredential? Credential { get; }
        IStorageFileFilter? Filter { get; }
    }
}