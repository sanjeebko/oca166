﻿namespace PBS.Shared.Storage
{
    public class StorageGetAllFilesRequest : StorageCommand, IStorageGetAllFilesRequest
    {
        public IStorageCredential? Credential { get; set; }
        public IStorageFileFilter? Filter { get; set; }
        public StorageType? StorageType { get; set; }
    }
}