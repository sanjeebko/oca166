﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileGetHashRequest : IStorageCommand, IStorageTypeProvider
    {
        string? Path { get; }
        IStorageCredential? Credential { get; }
    }
}
