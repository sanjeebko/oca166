﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileDeleteRequest : IStorageCommand, IStorageTypeProvider
    {
        IStorageCredential? Credential { get; }
        string? Path { get; }
    }
}
