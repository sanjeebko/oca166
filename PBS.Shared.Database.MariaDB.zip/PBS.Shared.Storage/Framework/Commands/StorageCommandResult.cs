﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageCommandResult : IStorageCommandResult
    {
        public bool Success { get; set; }
        public TimeSpan Duration { get; set; }
        public IEnumerable<Exception> Errors { get; set; } = new List<Exception>();
    }
}