﻿namespace PBS.Shared.Storage
{
    public interface IStorageConnectRequest : IStorageCommand, IStorageTypeProvider
    {
        IStorageCredential? Credential { get; }
    }
}