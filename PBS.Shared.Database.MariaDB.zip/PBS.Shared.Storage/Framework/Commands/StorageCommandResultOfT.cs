﻿namespace PBS.Shared.Storage
{
    public class StorageCommandResult<T> : StorageCommandResult, IStorageCommandResult<T> where T : class
    {
        public T? Data { get; set; }
    }
}
