﻿namespace PBS.Shared.Storage
{
    public class StorageFileGetHashRequest : StorageCommand, IStorageFileGetHashRequest
    {
        public StorageType? StorageType { get; set; }
        public string? Path { get; set; }
        public IStorageCredential? Credential { get; set; }
    }
}