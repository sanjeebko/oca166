﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileGetRequest : IStorageCommand, IStorageTypeProvider
    {
        string? Path { get; }
        IStorageCredential? Credential { get; }
    }
}
