﻿namespace PBS.Shared.Storage
{
    public class StorageFileTransferRequest : StorageCommand, IStorageFileTransferRequest
    {
        public IStorageCredential? SourceCredential { get; set; }
        public string? SourceFilePath { get; set; }
        public StorageType? SourceStorageType { get; set; }
        public IStorageCredential? DestinationCredential { get; set; }
        public string? DestinationFilePath { get; set; }
        public StorageType? DestinationStorageType { get; set; }
        public bool Overwrite { get; set; }
        public bool ValidateHash { get; set; } = true;
    }
}