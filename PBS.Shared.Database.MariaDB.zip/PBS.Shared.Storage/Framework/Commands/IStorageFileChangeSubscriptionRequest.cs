﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileChangeSubscriptionRequest : IStorageConnectRequest
    {
    }
}
