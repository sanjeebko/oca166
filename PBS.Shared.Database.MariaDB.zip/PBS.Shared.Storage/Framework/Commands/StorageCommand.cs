﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageCommand : IStorageCommand
    {
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}