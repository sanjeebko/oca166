﻿namespace PBS.Shared.Storage
{
    public interface IStorageCommandResult<out T> : IStorageCommandResult where T: class
    {
        T? Data { get; }
    }
}
