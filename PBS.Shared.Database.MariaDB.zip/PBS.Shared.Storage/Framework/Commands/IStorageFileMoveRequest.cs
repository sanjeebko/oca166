﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileMoveRequest : IStorageFileTransferRequest
    {
    }
}
