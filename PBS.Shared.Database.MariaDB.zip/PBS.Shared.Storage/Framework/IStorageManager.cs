﻿using PBS.Shared.Storage.FileMonitoring;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public interface IStorageManager
    {
        ValueTask<IStorageCommandResult> ConnectAsync(IStorageConnectRequest request);

        ValueTask<IStorageCommandResult> DeleteAsync(IStorageFileDeleteRequest request);

        ValueTask<IStorageCommandResult<IStorageFileMetadata>> GetAsync(IStorageFileGetRequest request);

        ValueTask<IStorageCommandResult<IStorageFileHash>> GetHashAsync(IStorageFileGetHashRequest request);

        ValueTask<IStorageCommandResult<IEnumerable<StorageDirectory>>> GetDirectoryTreeAsync(IStorageGetAllFilesRequest request);

        ValueTask<IStorageCommandResult<IEnumerable<IStorageFileMetadata>>> GetAllAsync(IStorageGetAllFilesRequest request);

        ValueTask<IStorageCommandResult> CopyAsync(IStorageFileTransferRequest request);

        ValueTask<IStorageCommandResult> MoveAsync(IStorageFileMoveRequest request);

        ValueTask<IStorageCommandResult<IStorageFileChangeSubscriptionScope>> CreateSubscriptionAsync(IStorageFileChangeSubscriptionRequest request);
    }
}
