﻿using PBS.Shared.Storage.FileMonitoring;

namespace PBS.Shared.Storage
{
    public interface IStorageFileChangeBuilder
    {
        void RegisterFileChangeProvider<TProvider>() where TProvider : IStorageFileChangeProvider;
    }
}
