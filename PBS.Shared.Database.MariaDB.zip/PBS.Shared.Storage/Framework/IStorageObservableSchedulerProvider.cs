﻿using System.Reactive.Concurrency;

namespace PBS.Shared.Storage
{
    public interface IStorageObservableSchedulerProvider
    {
        IScheduler Scheduler { get; }
    }
}
