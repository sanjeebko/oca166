﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public interface IStorageFileHandler : IDisposable
    {
        IStorageFileMetadata GetFile(string fileName);

        ValueTask DeleteFile(string fileName);

        ValueTask<bool> CopyFile(Stream sourceStream, string destinationPath);

        Stream GetStream(string path);

        IEnumerable<StorageDirectory> GetDirectoryTree(DirectoryInfo directory);

        ValueTask<IEnumerable<IStorageFileMetadata>> GetAllFiles(string directoryPath);
    }
}
