﻿namespace PBS.Shared.Storage
{
    public interface IStorageCredential : IAttributesProvider
    {
        string? Name { get; }
    }
}
