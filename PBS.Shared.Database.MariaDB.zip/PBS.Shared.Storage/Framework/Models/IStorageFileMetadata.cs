﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileMetadata : IAttributesProvider
    {
        string? Path { get; }
        bool Exists { get; }
        long Size { get; }
        StorageType? StorageType { get; }
    }
}