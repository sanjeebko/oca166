﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileFilter
    {
        string? Filter { get; }
    }
}
