﻿using System;

namespace PBS.Shared.Storage
{
    public class StorageFileHash : IStorageFileHash
    {
        public string Hash { get; set; } = string.Empty;
        public TimeSpan Duration { get; set; } = TimeSpan.Zero;
        public StorageFileHashProviderType? HashProvider { get; set; }

        public static StorageFileHash Empty { get; } = new StorageFileHash();
    }
}
