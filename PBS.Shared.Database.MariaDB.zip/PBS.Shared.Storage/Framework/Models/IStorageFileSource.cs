﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public interface IStorageFileSource : IAttributesProvider, IDisposable
    {
        IStorageFileMetadata? Metadata { get; }
        StorageLazyFileStream? Stream { get; }
        Func<IStorageFileMetadata, IStorageFileMetadata, ValueTask>? DownloadProvider { get; }

        bool HasStream { get; }
        bool HasDownloadProvider { get; }
    }
}
