﻿using System;

namespace PBS.Shared.Storage
{
    public interface IStorageFileHash
    {
        string Hash { get; }
        TimeSpan Duration { get; }
        StorageFileHashProviderType? HashProvider { get; }
    }
}