﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageDirectory : IAttributesProvider
    {
        public string? Name { get; set; }
        public List<StorageDirectory> Children { get; set; } = new();
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}
