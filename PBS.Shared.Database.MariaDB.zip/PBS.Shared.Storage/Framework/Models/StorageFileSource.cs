﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class StorageFileSource : IStorageFileSource
    {
        public IStorageFileMetadata? Metadata { get; set; }
        public StorageLazyFileStream? Stream { get; set; }
        public Func<IStorageFileMetadata, IStorageFileMetadata, ValueTask>? DownloadProvider { get; set; }
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();

        public bool HasStream => Stream != null;
        public bool HasDownloadProvider => DownloadProvider != null;

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    Stream?.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}