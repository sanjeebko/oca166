﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageCredential : IStorageCredential
    {
        public string? Name { get; set; }
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}