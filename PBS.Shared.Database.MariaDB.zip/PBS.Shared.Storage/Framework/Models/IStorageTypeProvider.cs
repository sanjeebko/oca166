﻿namespace PBS.Shared.Storage
{
    public interface IStorageTypeProvider
    {
        StorageType? StorageType { get; }
    }
}
