﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageFileMetadata : IStorageFileMetadata
    {
        public string? Path { get; set; }
        public bool Exists { get; set; }
        public long Size { get; set; }
        public StorageType? StorageType { get; set; }
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}