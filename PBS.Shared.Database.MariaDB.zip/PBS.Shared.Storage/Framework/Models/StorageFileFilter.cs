﻿namespace PBS.Shared.Storage
{
    public class StorageFileFilter : IStorageFileFilter
    {
        public string? Filter { get; set; }
    }
}