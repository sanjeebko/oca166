﻿namespace PBS.Shared.Storage
{
    public enum StorageType
    {
        SMB,
        AmazonS3,
    }
}
