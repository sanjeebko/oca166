﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class StorageLazyFileStream : AsyncLazy<Stream>, IDisposable
    {
        public StorageLazyFileStream(Func<Stream> factory) : base(factory)
        {
        }

        public StorageLazyFileStream(Func<Task<Stream>> factory) : base(factory)
        {
        }

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing && IsValueCreated)
                {
                    GetValue()?.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
