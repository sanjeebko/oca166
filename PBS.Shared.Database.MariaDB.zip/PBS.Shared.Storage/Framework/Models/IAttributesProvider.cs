﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public interface IAttributesProvider
    {
        IReadOnlyDictionary<string, object?> Attributes { get; }
    }
}
