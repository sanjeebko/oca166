﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Storage.FileMonitoring;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class StorageManager : IStorageManager
    {
        public ILogger<StorageManager> Logger { get; }
        public IServiceProvider ServiceProvider { get; }

        public StorageManager(ILogger<StorageManager> logger, IServiceProvider serviceProvider)
        {
            Logger = logger;
            ServiceProvider = serviceProvider;
        }

        public async ValueTask<IStorageCommandResult> ConnectAsync(IStorageConnectRequest request)
        {
            var commandResult = new StorageCommandResult();
            var stopwatch = Stopwatch.StartNew();

            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);
                commandResult.Success = true;
            }
            catch (Exception e)
            {
                commandResult.Success = false;
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult> DeleteAsync(IStorageFileDeleteRequest request)
        {
            var commandResult = new StorageCommandResult();
            var stopwatch = Stopwatch.StartNew();

            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateEmptyString(() => request.Path, out string path);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);

                var metadata = await adapter.GetAsync(path);
                if (!metadata.Exists)
                    throw new StorageFileNotFoundException($"File '{path}' was not found on storage");

                commandResult.Success = await adapter.DeleteAsync(metadata);
            }
            catch (Exception e)
            {
                commandResult.Success = false;
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult<IStorageFileMetadata>> GetAsync(IStorageFileGetRequest request)
        {
            var commandResult = new StorageCommandResult<IStorageFileMetadata>();
            var stopwatch = Stopwatch.StartNew();

            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateEmptyString(() => request.Path, out string path);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);

                commandResult.Data = await adapter.GetAsync(path);
            }
            catch (Exception e)
            {
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            commandResult.Success = commandResult.Data != null;

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult<IStorageFileHash>> GetHashAsync(IStorageFileGetHashRequest request)
        {
            var commandResult = new StorageCommandResult<IStorageFileHash>();
            var stopwatch = Stopwatch.StartNew();

            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateEmptyString(() => request.Path, out string path);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);

                commandResult.Data = await adapter.GetHashAsync(path);
            }
            catch (Exception e)
            {
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            commandResult.Success = commandResult.Data != null;

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult<IEnumerable<StorageDirectory>>> GetDirectoryTreeAsync(IStorageGetAllFilesRequest request)
        {
            var commandResult = new StorageCommandResult<IEnumerable<StorageDirectory>>();
            var stopwatch = Stopwatch.StartNew();
            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);

                commandResult.Data = await adapter.GetDirectoryTreeAsync();
            }
            catch (Exception e)
            {
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            commandResult.Success = commandResult.Data != null;

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult<IEnumerable<IStorageFileMetadata>>> GetAllAsync(IStorageGetAllFilesRequest request)
        {
            var commandResult = new StorageCommandResult<IEnumerable<IStorageFileMetadata>>();
            var stopwatch = Stopwatch.StartNew();
            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);

                IStorageAdapter adapter = ResolveAdapterOrThrow(factory, storageType);
                await adapter.ConnectAsync(credential);

                commandResult.Data = await adapter.GetAllAsync(request.Filter);
            }
            catch (Exception e)
            {
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            commandResult.Success = commandResult.Data != null;

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult> CopyAsync(IStorageFileTransferRequest request)
        {
            var commandResult = new StorageCommandResult();
            var stopwatch = Stopwatch.StartNew();
            var scope = ServiceProvider.CreateScope();
            var factory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

            try
            {
                ValidateCredential(() => request.SourceCredential, out IStorageCredential sourceCredential);
                ValidateCredential(() => request.DestinationCredential, out IStorageCredential destinationCredential);
                ValidateEmptyString(() => request.SourceFilePath, out string sourcePath);
                ValidateEmptyString(() => request.DestinationFilePath, out string destinationPath);
                ValidateStorageType(() => request.SourceStorageType, out StorageType sourceStorageType);
                ValidateStorageType(() => request.DestinationStorageType, out StorageType destinationStorageType);

                IStorageAdapter sourceAdapter = ResolveAdapterOrThrow(factory, sourceStorageType);
                IStorageAdapter destinationAdapter = ResolveAdapterOrThrow(factory, destinationStorageType);

                await sourceAdapter.ConnectAsync(sourceCredential);
                await destinationAdapter.ConnectAsync(destinationCredential);

                IStorageFileMetadata sourceFileMetadata = await sourceAdapter.GetAsync(sourcePath);

                ValidateMetadata(() => sourceFileMetadata);

                if (!sourceFileMetadata.Exists)
                    throw new StorageFileNotFoundException($"File source '{sourcePath}' from '{sourceStorageType}' does not exists");

                IStorageFileMetadata destinationFileMetadata = await destinationAdapter.GetAsync(destinationPath);

                ValidateMetadata(() => destinationFileMetadata);

                if (destinationFileMetadata.Exists && !request.Overwrite)
                {
                    commandResult.Success = true;
                    return commandResult;
                }

                using (IStorageFileSource? sourceFile = await sourceAdapter.GetStreamAsync(sourceFileMetadata))
                {
                    if (sourceFile == null)
                        throw new StorageFileStreamValidationException($"Failed to get '{sourceStorageType} file source for path '{sourcePath}'");

                    if (!sourceFile.HasDownloadProvider && !sourceFile.HasStream)
                        throw new StorageFileStreamValidationException($"Invalid '{sourceStorageType}' source stream for file '{sourcePath}'");

                    commandResult.Success = await destinationAdapter.CopyAsync(sourceFile, destinationFileMetadata);
                }

                if (commandResult.Success)
                {
                    await ValidateCopyAsync(request, sourceAdapter, destinationAdapter, sourceFileMetadata, destinationFileMetadata);
                }
            }
            catch (Exception e)
            {
                commandResult.Success = false;
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                scope.Dispose();
                commandResult.Duration = stopwatch.Elapsed;
            }

            return commandResult;
        }

        public async ValueTask<IStorageCommandResult> MoveAsync(IStorageFileMoveRequest request)
        {
            var commandResult = new StorageCommandResult();
            var stopwatch = Stopwatch.StartNew();

            try
            {
                IStorageCommandResult copyResponse = await CopyAsync(request);

                if (!copyResponse.Success)
                    throw new AggregateException(copyResponse.Errors);

                StorageFileDeleteRequest deleteRequest = new StorageFileDeleteRequest { Credential = request.SourceCredential, Path = request.SourceFilePath, StorageType = request.SourceStorageType };
                IStorageCommandResult deleteResponse = await DeleteAsync(deleteRequest);

                if (!deleteResponse.Success)
                    throw new AggregateException(deleteResponse.Errors);

                commandResult.Success = true;
            }
            catch (Exception e)
            {
                commandResult.Success = false;
                commandResult.Errors = new List<Exception> { e };
            }
            finally
            {
                commandResult.Duration = stopwatch.Elapsed;
            }

            return commandResult;
        }

        public ValueTask<IStorageCommandResult<IStorageFileChangeSubscriptionScope>> CreateSubscriptionAsync(IStorageFileChangeSubscriptionRequest request)
        {
            var commandResult = new StorageCommandResult<IStorageFileChangeSubscriptionScope>();

            var stopwatch = Stopwatch.StartNew();

            IServiceScope scope = ServiceProvider.CreateScope();

            try
            {
                var adapterFactory = scope.ServiceProvider.GetRequiredService<IStorageAdapterFactory>();

                ValidateCredential(() => request.Credential, out IStorageCredential credential);
                ValidateStorageType(() => request.StorageType, out StorageType storageType);
                ValidateAdapterExists(adapterFactory, storageType);

                IStorageFileChangeProvider provider = scope.ServiceProvider.GetRequiredService<IStorageFileChangeProviderFactory>().ResolveProvider(storageType) ?? throw new StorageFileChangeProviderResolveException($"Failed to resolve file change provider for '{storageType}'");

                commandResult.Data = new StorageFileChangeSubscriptionScope(scope, provider, credential);
                commandResult.Success = true;
            }
            catch (Exception e)
            {
                commandResult.Success = false;
                commandResult.Errors = new List<Exception> { e };
                scope.Dispose();
            }
            finally
            {
                commandResult.Duration = stopwatch.Elapsed;
            }

            return new ValueTask<IStorageCommandResult<IStorageFileChangeSubscriptionScope>>(commandResult);
        }

        private static async Task ValidateCopyAsync(IStorageFileTransferRequest request, IStorageAdapter sourceAdapter, IStorageAdapter destinationAdapter, IStorageFileMetadata sourceFileMetadata, IStorageFileMetadata destinationFileMetadata)
        {
            if (request.ValidateHash)
                await ValidateFilesHash(sourceAdapter, sourceFileMetadata.Path, destinationAdapter, destinationFileMetadata.Path);
            ValidateFileSize(sourceFileMetadata, await destinationAdapter.GetAsync(destinationFileMetadata.Path ?? string.Empty));
        }

        private static void ValidateFileSize(IStorageFileMetadata sourceFileMetadata, IStorageFileMetadata destinationFileMetadata)
        {
            if (sourceFileMetadata.Size != destinationFileMetadata.Size)
            {
                throw new StorageFileSizeValidationException($"Source file '{sourceFileMetadata.Path}' size '{destinationFileMetadata.Size}' is different then destination file '{destinationFileMetadata.Path}' size '{destinationFileMetadata.Size}'");
            }
        }

        private static async ValueTask ValidateFilesHash(IStorageAdapter sourceAdapter, string? sourcePath, IStorageAdapter destinationAdapter, string? destinationPath)
        {
            var supportedSourceHashProviders = sourceAdapter.GetSupportedHashProviders().ToList();
            var supportedDestinationHashProvider = destinationAdapter.GetSupportedHashProviders().ToList();

            StorageFileHashProviderType? commonProvider = supportedSourceHashProviders.Intersect(supportedDestinationHashProvider).OrderByDescending(type => (int)type).OfType<StorageFileHashProviderType?>().FirstOrDefault();

            if (commonProvider is null)
                return;

            IStorageFileHash destinationHash = await destinationAdapter.GetHashAsync(destinationPath, commonProvider);

            if (string.IsNullOrWhiteSpace(destinationHash.Hash))
                return;

            StorageFileHashProviderType sourceHashProvider = destinationHash.HashProvider ?? commonProvider.Value;

            if (supportedSourceHashProviders.All(provider => provider != sourceHashProvider))
                return;

            IStorageFileHash sourceHash = await sourceAdapter.GetHashAsync(sourcePath, sourceHashProvider);

            if (string.IsNullOrWhiteSpace(sourceHash.Hash))
                return;

            if (sourceHash.Hash != destinationHash.Hash)
                throw new StorageFileHashValidationException($"Destination file hash '{destinationHash.Hash}' is not same as source file hash '{sourceHash.Hash}'");
        }

        private static IStorageAdapter ResolveAdapterOrThrow(IStorageAdapterFactory factory, StorageType storageType)
        {
            IStorageAdapter? adapter = factory.ResolveAdapter(storageType);
            if (adapter == null)
                throw new StorageAdapterResolveException($"Failed to resolve adapter for storage type '{storageType}'");
            return adapter;
        }

        private static void ValidateAdapterExists(IStorageAdapterFactory factory, StorageType storageType)
        {
            if (!factory.IsAdapterRegistered(storageType))
                throw new StorageAdapterResolveException($"Adapter for storage type '{storageType}' is not registered");
        }

        private static void ValidateMetadata(Expression<Func<IStorageFileMetadata?>> member)
        {
            IStorageFileMetadata? metadata = member.Compile().Invoke();

            if (metadata == null)
                throw new StorageFileMetadataValidationException((member.Body as MemberExpression)?.Member.Name);
            if (metadata.StorageType == null)
                throw new StorageFileMetadataValidationException($"{(member.Body as MemberExpression)?.Member.Name}.{nameof(metadata.StorageType)}");
            if (string.IsNullOrEmpty(metadata.Path))
                throw new StorageFileMetadataValidationException($"{(member.Body as MemberExpression)?.Member.Name}.{nameof(metadata.Path)}");
        }

        private static void ValidateCredential(Expression<Func<IStorageCredential?>> member, out IStorageCredential credential)
        {
            credential = member.Compile().Invoke() ?? throw new StorageCredentialValidationException((member.Body as MemberExpression)?.Member.Name);
        }

        private static void ValidateStorageType(Expression<Func<StorageType?>> member, out StorageType storageType)
        {
            storageType = member.Compile().Invoke() ?? throw new StorageTypeValidationException((member.Body as MemberExpression)?.Member.Name);
        }

        private static void ValidateEmptyString(Expression<Func<string?>> member, out string value)
        {
            value = member.Compile().Invoke() ?? string.Empty;

            if (string.IsNullOrEmpty(value))
                throw new ArgumentNullException((member.Body as MemberExpression)?.Member.Name);
        }
    }
}