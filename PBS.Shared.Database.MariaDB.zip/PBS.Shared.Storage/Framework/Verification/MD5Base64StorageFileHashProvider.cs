﻿using Amazon.S3.Util;
using System.IO;

namespace PBS.Shared.Storage.Framework.Verification
{
    public class MD5Base64StorageFileHashProvider : IStorageFileHashProvider
    {
        public StorageFileHashProviderConfiguration Configuration { get; }

        public MD5Base64StorageFileHashProvider(StorageFileHashProviderConfiguration configuration)
        {
            Configuration = configuration;
        }

        public string ComputeHashString(Stream stream)
        {
            return AmazonS3Util.GenerateMD5ChecksumForStream(stream);
        }
    }
}
