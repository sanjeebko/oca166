﻿using System;
using System.IO;

namespace PBS.Shared.Storage
{
    public abstract class StorageFileHashProvider : IStorageFileHashProvider
    {
        private readonly StorageFileHashProviderConfiguration _configuration;
        protected const int OneMb = 1024 * 1024;

        protected StorageFileHashProvider(StorageFileHashProviderConfiguration configuration)
        {
            _configuration = configuration;
            _configuration.ChunkSizeBytes = _configuration.ChunkSizeBytes == 0 ? OneMb : _configuration.ChunkSizeBytes;
        }
        /// <summary>
        /// Computes the hash string for the given stream
        /// </summary>
        /// <param name="stream">A stream to compute the tree hash fo</param>
        /// <returns>a computed hash string</returns>
        public string ComputeHashString(Stream stream)
        {
            StreamHelper.ResetStreamPosition(stream);

            if (stream.Length <= _configuration.ChunkSizeBytes)
            {
                using (var memStream = new MemoryStream())
                {
                    stream.CopyTo(memStream);
                    var data = memStream.ToArray();
                    return BitConverter.ToString(CalculateHash(data, data.Length)).Replace("-", "").ToLower();
                }
            }

            return BitConverter.ToString(ComputeTreeHash(stream)).Replace("-", "").ToLower();
        }



        /// <summary>
        /// Computes the tree hash for the given stream
        /// </summary>
        /// <param name="stream">A stream to compute the tree hash for</param>
        /// <returns>a byte[] containing the tree hash</returns>
        protected virtual byte[] ComputeTreeHash(Stream stream)
        {
            byte[][] chunkHashes = GetChunkHashes(stream);
            return ComputeTreeHash(chunkHashes);
        }

        /// <summary>
        /// Computes a checksum for each 1 MB chunk of the stream. This
        /// includes the checksum for the last chunk even if it is smaller than 1 MB.
        /// </summary>
        /// <param name="stream">A stream to compute checksums on</param>
        /// <returns>a byte[][] containing the checksums of each 1MB chunk</returns>
        protected virtual byte[][] GetChunkHashes(Stream stream)
        {
            StreamHelper.ResetStreamPosition(stream);

            long numChunks = stream.Length / _configuration.ChunkSizeBytes;
            if (stream.Length % _configuration.ChunkSizeBytes > 0)
            {
                numChunks++;
            }

            if (numChunks == 0)
            {
                return new[] { CalculateHash(null, 0) };
            }

            byte[][] chunkHashes = new byte[(int)numChunks][];

            try
            {
                byte[] buff = new byte[_configuration.ChunkSizeBytes];

                int bytesRead;
                int idx = 0;

                while ((bytesRead = stream.Read(buff, 0, _configuration.ChunkSizeBytes)) > 0)
                {
                    chunkHashes[idx++] = CalculateHash(buff, bytesRead);
                }
                return chunkHashes;
            }
            finally
            {
                stream.Close();
            }

        }

        /// <summary>
        /// Computes the tree hash for the passed array of 1MB chunk checksums.
        /// This method uses a pair of arrays to iteratively compute the tree hash
        ///  * level by level. Each iteration takes two adjacent elements from the
        ///    * previous level source array, computes the hash on their
        ///    * concatenated value and places the result in the next level's destination
        ///    * array. At the end of an iteration, the destination array becomes the
        ///    * source array for the next level.
        /// </summary>
        /// <param name="chunkHashes">An array of checksums</param>
        /// <returns>A byte[] containing the tree hash for the input chunks</returns>
        private byte[] ComputeTreeHash(byte[][] chunkHashes)
        {
            byte[][] prevLvlHashes = chunkHashes;
            while (prevLvlHashes.GetLength(0) > 1)
            {

                int len = prevLvlHashes.GetLength(0) / 2;
                if (prevLvlHashes.GetLength(0) % 2 != 0)
                {
                    len++;
                }

                byte[][] currLvlHashes = new byte[len][];

                int j = 0;
                for (int i = 0; i < prevLvlHashes.GetLength(0); i = i + 2, j++)
                {

                    // If there are at least two elements remaining
                    if (prevLvlHashes.GetLength(0) - i > 1)
                    {
                        // Calculate a digest of the concatenated nodes
                        byte[] firstPart = prevLvlHashes[i];
                        byte[] secondPart = prevLvlHashes[i + 1];
                        byte[] concatenation = new byte[firstPart.Length + secondPart.Length];
                        Buffer.BlockCopy(firstPart, 0, concatenation, 0, firstPart.Length);
                        Buffer.BlockCopy(secondPart, 0, concatenation, firstPart.Length, secondPart.Length);

                        currLvlHashes[j] = CalculateHash(concatenation, concatenation.Length);

                    }
                    else
                    { // Take care of remaining odd chunk
                        currLvlHashes[j] = prevLvlHashes[i];
                    }
                }

                prevLvlHashes = currLvlHashes;
            }

            return prevLvlHashes[0];
        }


        /// <summary>
        /// Computes hash for given bytes, this method should be implemented in inherited class
        /// </summary>
        /// <param name="inputBytes">An array of bytes</param>
        /// <param name="count">An array length to take for computing hash</param>
        /// <returns>Hashed byte array</returns>
        protected abstract byte[] CalculateHash(byte[]? inputBytes, int count);
    }
}
