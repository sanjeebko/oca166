﻿using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageFileHashProviderConfiguration
    {
        public int ChunkSizeBytes { get; set; } = 1024 * 1024;
        public Dictionary<string, object> Attributes { get; set; } = new Dictionary<string, object>();
    }
}
