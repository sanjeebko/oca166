﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileHashProviderOptions
    {
        StorageFileHashProviderOptionEntry? GetProviderOptionEntry(StorageFileHashProviderType providerType);
    }
}