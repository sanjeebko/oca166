﻿using System;

namespace PBS.Shared.Storage
{
    public class StorageFileHashProviderOptionEntry
    {
        public StorageFileHashProviderOptionEntry(Type providerType, StorageFileHashProviderConfiguration configuration)
        {
            ProviderType = providerType;
            ProviderConfiguration = configuration;
        }

        public Type ProviderType { get; }
        public StorageFileHashProviderConfiguration ProviderConfiguration { get; set; }
    }
}