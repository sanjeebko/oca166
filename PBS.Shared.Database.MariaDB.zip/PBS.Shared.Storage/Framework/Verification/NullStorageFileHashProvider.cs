﻿using System.IO;

namespace PBS.Shared.Storage
{
    public class NullStorageFileHashProvider : IStorageFileHashProvider
    {
        public NullStorageFileHashProvider(StorageFileHashProviderConfiguration configuration)
        {
        }

        public string ComputeHashString(Stream stream)
        {
            return string.Empty;
        }
    }
}
