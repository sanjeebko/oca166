﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileHashProviderFactory
    {
        IStorageFileHashProvider GetProvider(StorageFileHashProviderType providerType);
    }
}