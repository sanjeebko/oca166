﻿using System;
using System.Security.Cryptography;
using System.Threading;

namespace PBS.Shared.Storage
{
    public class MerkleMD5StorageFileHashProvider : StorageFileHashProvider, IDisposable
    {
        private readonly Lazy<MD5> _lazyMD5 = new Lazy<MD5>(MD5.Create, LazyThreadSafetyMode.ExecutionAndPublication);

        public MerkleMD5StorageFileHashProvider(StorageFileHashProviderConfiguration configuration) : base(configuration)
        {
        }

        protected override byte[] CalculateHash(byte[]? inputBytes, int count)
        {
            return _lazyMD5.Value.ComputeHash(inputBytes ?? Array.Empty<byte>(), 0, count);
        }

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing && _lazyMD5.IsValueCreated)
                {
                    _lazyMD5.Value.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}