﻿using System;
using System.Security.Cryptography;
using System.Threading;

namespace PBS.Shared.Storage
{
    public class MerkleSHA256StorageFileHashProvider : StorageFileHashProvider, IDisposable
    {
        private readonly Lazy<SHA256> _lazySHA256 = new Lazy<SHA256>(SHA256.Create, LazyThreadSafetyMode.ExecutionAndPublication);

        public MerkleSHA256StorageFileHashProvider(StorageFileHashProviderConfiguration configuration) : base(configuration)
        {
        }

        protected override byte[] CalculateHash(byte[]? inputBytes, int count)
        {
            return _lazySHA256.Value.ComputeHash(inputBytes ?? Array.Empty<byte>(), 0, count);
        }

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing && _lazySHA256.IsValueCreated)
                {
                    _lazySHA256.Value.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
