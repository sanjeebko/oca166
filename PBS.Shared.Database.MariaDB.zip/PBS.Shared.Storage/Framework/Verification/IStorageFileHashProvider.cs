﻿using System.IO;

namespace PBS.Shared.Storage
{
    public interface IStorageFileHashProvider
    {
        string ComputeHashString(Stream stream);
    }
}