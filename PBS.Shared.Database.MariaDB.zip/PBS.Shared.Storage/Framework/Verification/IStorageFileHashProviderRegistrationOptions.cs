﻿namespace PBS.Shared.Storage
{
    public interface IStorageFileHashProviderRegistrationOptions
    {
        /// <exception cref="T:System.InvalidOperationException">When provider is already added to mapping for <see cref="StorageFileHashProviderType"/></exception>
        void RegisterProvider<T>(StorageFileHashProviderType providerType, StorageFileHashProviderConfiguration configuration) where T : IStorageFileHashProvider;
    }
}