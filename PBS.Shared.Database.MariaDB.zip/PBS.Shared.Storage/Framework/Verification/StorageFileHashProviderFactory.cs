﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Concurrent;

namespace PBS.Shared.Storage
{
    public class StorageFileHashProviderFactory : IStorageFileHashProviderFactory
    {
        private readonly IOptions<IStorageFileHashProviderOptions> _mappings;
        private readonly ConcurrentDictionary<StorageFileHashProviderType, IStorageFileHashProvider> _providers = new ConcurrentDictionary<StorageFileHashProviderType, IStorageFileHashProvider>();

        public StorageFileHashProviderFactory(IOptions<IStorageFileHashProviderOptions> mappings)
        {
            _mappings = mappings;
        }

        public IStorageFileHashProvider GetProvider(StorageFileHashProviderType providerType)
        {
            return _providers.GetOrAdd(providerType, type => CreateProvider(type) ?? throw new InvalidOperationException($"Failed to create provider '{providerType}'"));
        }

        private IStorageFileHashProvider CreateProvider(StorageFileHashProviderType providerType)
        {
            StorageFileHashProviderOptionEntry? mappingEntry = _mappings.Value.GetProviderOptionEntry(providerType);
            if (mappingEntry == null)
                throw new StorageHashProviderRegistrationException($"Provider with type '{providerType}' is not registered");

            try
            {
                if (Activator.CreateInstance(mappingEntry.ProviderType, mappingEntry.ProviderConfiguration) is not IStorageFileHashProvider createdInstance)
                    throw new StorageHashProviderCreationException($"Failed to create instance of '{mappingEntry.ProviderType.Name}'");
                return createdInstance;

            }
            catch (Exception e)
            {
                throw new StorageHashProviderCreationException($"Failed to create instance of file hash provider '{mappingEntry.ProviderType.Name}'", e);
            }
        }
    }
}
