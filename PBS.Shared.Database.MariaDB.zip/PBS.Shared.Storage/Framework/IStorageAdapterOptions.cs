﻿using System;

namespace PBS.Shared.Storage
{
    public interface IStorageAdapterOptions
    {
        Type? GetAdapterType(StorageType storageType);
    }
}