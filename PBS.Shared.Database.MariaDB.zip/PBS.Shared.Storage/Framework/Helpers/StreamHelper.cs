﻿using System.IO;

namespace PBS.Shared.Storage
{
    public static class StreamHelper
    {
        /// <summary>
        /// Resets stream position to 0 if it can
        /// </summary>
        /// <param name="stream">stream</param>
        public static void ResetStreamPosition(this Stream stream)
        {
            if (stream.CanSeek && stream.Position != 0)
                stream.Seek(0, SeekOrigin.Begin);
        }
    }
}
