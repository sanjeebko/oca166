﻿using Microsoft.Extensions.Options;
using System;

namespace PBS.Shared.Storage
{
    public class StorageAdapterFactory : IStorageAdapterFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IOptions<IStorageAdapterOptions> _options;

        public StorageAdapterFactory(IServiceProvider serviceProvider, IOptions<IStorageAdapterOptions> options)
        {
            _serviceProvider = serviceProvider;
            _options = options;
        }

        /// <inheritdoc cref="IStorageAdapterFactory"/>
        public IStorageAdapter? ResolveAdapter(StorageType type)
        {
            Type? adapterType = _options.Value.GetAdapterType(type);
            return adapterType != null ? _serviceProvider.GetService(adapterType) as IStorageAdapter : default;
        }

        /// <inheritdoc cref="IStorageAdapterFactory"/>
        public bool IsAdapterRegistered(StorageType type)
        {
            return _options.Value.GetAdapterType(type) != null;
        }
    }
}