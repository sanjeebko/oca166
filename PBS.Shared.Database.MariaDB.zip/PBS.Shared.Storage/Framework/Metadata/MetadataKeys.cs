﻿namespace PBS.Shared.Storage
{
    public static class MetadataKeys
    {
        public const string PbsMetadataPrefix = "pbs";
        public const string HashCodeMetadataKey = "hash-code";
        public const string HashProviderMetadataKey = "hash-provider";
        public const string AmazonS3MetadataPrefix = "x-amz-meta-";
    }
}
