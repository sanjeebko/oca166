﻿namespace PBS.Shared.Storage
{
    public static class MetadataUtility
    {
        public static string BuildPbsMetadataKey(string key)
        {
            if (key.StartsWith(MetadataKeys.PbsMetadataPrefix))
                return key;
            return $"{MetadataKeys.PbsMetadataPrefix}{(key.StartsWith("-") ? key.ToLower() : $"-{key.ToLower()}")}";
        }
    }
}
