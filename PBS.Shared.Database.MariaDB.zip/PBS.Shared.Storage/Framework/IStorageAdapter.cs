﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public interface IStorageAdapter : IDisposable
    {
        ValueTask ConnectAsync(IStorageCredential credential);

        ValueTask<bool> DeleteAsync(IStorageFileMetadata metadata);

        ValueTask<IStorageFileMetadata> GetAsync(string path);

        ValueTask<IStorageFileSource> GetStreamAsync(IStorageFileMetadata metadata);

        ValueTask<IStorageFileHash> GetHashAsync(string? path, StorageFileHashProviderType? hashProviderType = default);

        ValueTask<IEnumerable<StorageDirectory>> GetDirectoryTreeAsync();

        ValueTask<IEnumerable<IStorageFileMetadata>> GetAllAsync(IStorageFileFilter? filter = default);

        ValueTask<bool> CopyAsync(IStorageFileSource source, IStorageFileMetadata destination, IReadOnlyDictionary<string, object?>? metadata = default);

        ValueTask<bool> PutMetadataAsync(IStorageFileMetadata source, IReadOnlyDictionary<string, object?> metadata);

        IEnumerable<StorageFileHashProviderType> GetSupportedHashProviders();
    }
}