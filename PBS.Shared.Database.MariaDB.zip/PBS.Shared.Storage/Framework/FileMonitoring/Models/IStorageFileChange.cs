﻿using System;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChange : IAttributesProvider
    {
        StorageFileChangeType? ChangeType { get; }
        IStorageFileChangeMetadata? FileMetadata { get; }
        StorageType Storage { get; }
        DateTimeOffset Timestamp { get; }
    }
}
