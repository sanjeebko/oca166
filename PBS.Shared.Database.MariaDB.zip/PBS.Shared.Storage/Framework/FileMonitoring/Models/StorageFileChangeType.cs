﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public enum StorageFileChangeType
    {
        Created,
        Deleted,
        Modified
    }
}
