﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class StorageFileChange : IStorageFileChange
    {
        public StorageFileChangeType? ChangeType { get; set; }
        public IStorageFileChangeMetadata? FileMetadata { get; set; }
        public StorageType Storage { get; set; }
        public DateTimeOffset Timestamp { get; } = DateTimeOffset.UtcNow;
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}