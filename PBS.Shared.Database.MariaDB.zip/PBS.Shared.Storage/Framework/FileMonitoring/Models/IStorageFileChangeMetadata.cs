﻿using System;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeMetadata : IStorageFileMetadata
    {
        string? RelativePath { get; }
        DateTime? LastWriteTimeUtc { get; }
        DateTime? CreationTimeUtc { get; }
    }
}
