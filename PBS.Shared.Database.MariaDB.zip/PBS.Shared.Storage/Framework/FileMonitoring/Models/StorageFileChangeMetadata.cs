﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class StorageFileChangeMetadata : IStorageFileChangeMetadata
    {
        public string? Path { get; set; }
        public string? RelativePath { get; set; }
        public bool Exists { get; set; }
        public long Size { get; set; }
        public StorageType? StorageType { get; set; }
        public DateTime? LastWriteTimeUtc { get; set; }
        public DateTime? CreationTimeUtc { get; set; }
        public IReadOnlyDictionary<string, object?> Attributes { get; set; } = new Dictionary<string, object?>();
    }
}