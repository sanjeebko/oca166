﻿using System;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeProviderOptions
    {
        Type? GetProviderType(StorageType storageType);
    }
}