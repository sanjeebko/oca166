﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeProviderRegistrationOptions
    {
        /// <exception cref="StorageAdapterMappingException">When provider is already added to mapping for <see cref="StorageType"/></exception>
        void RegisterProvider<T>(StorageType storageType) where T : IStorageFileChangeProvider;
    }
}