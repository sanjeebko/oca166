﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class StorageFileChangeProviderOptions : IOptions<IStorageFileChangeProviderOptions>, IStorageFileChangeProviderOptions, IStorageFileChangeProviderRegistrationOptions
    {
        private readonly Dictionary<StorageType, Type> _mappings = new Dictionary<StorageType, Type>();

        /// <exception cref="StorageAdapterMappingException">When provider is already added to mapping for <see cref="StorageType"/></exception>
        public void RegisterProvider<T>(StorageType storageType) where T : IStorageFileChangeProvider
        {
            if (_mappings.ContainsKey(storageType))
                throw new StorageAdapterMappingException($"Provider for {storageType} already added");
            _mappings.Add(storageType, typeof(T));
        }

        public Type? GetProviderType(StorageType storageType)
        {
            return _mappings.TryGetValue(storageType, out Type? providerType) ? providerType : default;
        }

        public IReadOnlyDictionary<StorageType, Type> Mappings => _mappings;

        public IStorageFileChangeProviderOptions Value => this;
    }
}
