﻿using PBS.Shared.Dependency;
using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Runtime.CompilerServices;
using System.Threading;
using System.Threading.Tasks;

[assembly: InternalsVisibleTo("PBS.Shared.Tests")]

namespace PBS.Shared.Storage.FileMonitoring
{
    internal class StorageFileChangeSubscriptionScope : Disposable, IStorageFileChangeSubscriptionScope, IStorageFileChangeSubscriptionScopeAccessor
    {
        private readonly CancellationTokenSource _cts = new CancellationTokenSource();
        private readonly IDisposable _scope;
        private readonly IStorageCredential _credential;
        private readonly IStorageFileChangeProvider _provider;
        private event EventHandler Unsubscribe = delegate { };

        private long _providerState;
        private const int ProviderInitialized = 1;

        public StorageFileChangeSubscriptionScope(IDisposable ownedScope, IStorageFileChangeProvider provider, IStorageCredential credential)
        {
            _scope = ownedScope;
            _credential = credential;
            _provider = provider;
        }

        public async ValueTask<IStorageFileChangeSubscriptionScopeAccessor> InitializeAsync(CancellationToken cancellationToken = default)
        {
            if (Interlocked.CompareExchange(ref _providerState, ProviderInitialized, 0) == ProviderInitialized)
                return this;
            using var linkedToken = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken, _cts.Token);
            await _provider.StartAsync(_credential, linkedToken.Token);
            return this;
        }

        public async ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default)
        {
            return await _provider.GetAllAsync(filter);
        }

        public IObservable<IStorageFileChange> FileChanges =>
            Observable.Create<IStorageFileChange>(subscriber =>
                {
                    IDisposable subscription = _provider.FileChanges.Subscribe(subscriber);
                    return () => { subscription.Dispose(); };
                })
                .Publish()
                .RefCount()
                .TakeUntil(Observable.FromEventPattern(h => Unsubscribe += h, h => Unsubscribe -= h));

        public IObservable<Exception> Errors =>
            Observable.Create<Exception>(subscriber =>
                {
                    IDisposable subscription = _provider.Errors.Subscribe(subscriber);
                    return () => { subscription.Dispose(); };
                })
                .Publish()
                .RefCount()
                .TakeUntil(Observable.FromEventPattern(h => Unsubscribe += h, h => Unsubscribe -= h));

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Unsubscribe.Invoke(this, EventArgs.Empty);
                _cts.Cancel();
                _scope.Dispose();
            }

            base.Dispose(disposing);
        }

        public ValueTask<bool> TestConnectionAsync() => _provider.CheckConnectionAsync();
    }
}