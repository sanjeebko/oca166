﻿using System;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeSubscriptionScope : IDisposable
    {
        ValueTask<IStorageFileChangeSubscriptionScopeAccessor> InitializeAsync(CancellationToken cancellationToken = default);
    }
}
