﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeSubscriptionScopeAccessor
    {
        IObservable<IStorageFileChange> FileChanges { get; }
        IObservable<Exception> Errors { get; }
        ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default);
        ValueTask<bool> TestConnectionAsync();
    }
}