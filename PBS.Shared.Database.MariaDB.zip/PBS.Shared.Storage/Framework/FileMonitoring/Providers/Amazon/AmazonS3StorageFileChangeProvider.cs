﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonS3StorageFileChangeProvider : StorageFileChangeProvider
    {
        protected AmazonS3StorageAdapter AmazonS3StorageAdapter { get; }

        public AmazonS3StorageFileChangeProvider(ILogger<AmazonS3StorageFileChangeProvider> logger, AmazonS3StorageAdapter amazonS3StorageAdapter) : base(logger)
        {
            AmazonS3StorageAdapter = amazonS3StorageAdapter;
        }

        public override async ValueTask StartAsync(IStorageCredential credential, CancellationToken cancellationToken)
        {
            if (Status is StorageFileChangeProviderStatus.Available)
                throw new InvalidOperationException("Provider already started");

            await AmazonS3StorageAdapter.ConnectAsync(credential);

            Status = StorageFileChangeProviderStatus.Available;
        }

        public override ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default)
        {
            ValidateStatus();

            return ValueTask.FromResult(Enumerable.Empty<IStorageFileChangeMetadata>());
        }

        public override ValueTask<bool> CheckConnectionAsync() => throw new NotImplementedException("");
    }
}
