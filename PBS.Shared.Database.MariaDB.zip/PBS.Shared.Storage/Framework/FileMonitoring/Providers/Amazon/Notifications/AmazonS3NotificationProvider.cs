﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public abstract class AmazonS3NotificationProvider : IAmazonS3NotificationProvider
    {
        public abstract ValueTask<string> EnableNotificationsForBucketAsync(AmazonEnableNotificationsRequest enableNotificationsRequest);
        public abstract ValueTask DisableNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest);
        public abstract ValueTask RemoveNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest);

        protected static async Task EnableNotificationOnBucketAsync(IAmazonS3 client, string configurationId, string bucketName, string queueArn, AmazonS3NotificationProviderType notificationProviderType, IEnumerable<NotificationConfiguration> existingConfigurations, IEnumerable<EventType> eventTypes)
        {
            var request = new PutBucketNotificationRequest { BucketName = bucketName };

            AddNotificationConfigurations(ref request, notificationProviderType, existingConfigurations, configurationId, queueArn, eventTypes);

            PutBucketNotificationResponse response = await client.PutBucketNotificationAsync(request);

            response.ValidateAmazonServiceResponse<AmazonS3RequestException>($"Failed to enable queue {queueArn} notifications for bucket {bucketName}");
        }

        protected static async Task DisableNotificationOnBucketAsync(IAmazonS3 client, string bucketName, AmazonS3NotificationProviderType notificationProviderType, IEnumerable<NotificationConfiguration> currentConfigurations, NotificationConfiguration configurationToRemove)
        {
            var request = new PutBucketNotificationRequest
            {
                BucketName = bucketName,
            };

            RemoveNotificationConfigurations(ref request, notificationProviderType, currentConfigurations, configurationToRemove);

            PutBucketNotificationResponse response = await client.PutBucketNotificationAsync(request);

            response.ValidateAmazonServiceResponse<AmazonS3RequestException>($"Failed to disable notifications for bucket {bucketName}");
        }

        /// <summary>
        /// Validates if there are any overlapped events in bucket notification configuration by comparing it with provided event types <param name="eventTypes"></param>
        /// </summary>
        /// <param name="bucketNotification">Bucket notification response</param>
        /// <param name="eventTypes">Event types to validate</param>
        protected static void ValidateBucketNotification(GetBucketNotificationResponse bucketNotification, IReadOnlyList<EventType> eventTypes)
        {
            IReadOnlyList<EventType> eventTypesFromRequest = ReplaceRootEventTypes(eventTypes).Distinct().ToList();

            ValidateBucketNotificationConfiguration(bucketNotification.QueueConfigurations, eventTypesFromRequest);
            ValidateBucketNotificationConfiguration(bucketNotification.TopicConfigurations, eventTypesFromRequest);
            ValidateBucketNotificationConfiguration(bucketNotification.LambdaFunctionConfigurations, eventTypesFromRequest);
        }

        private static void ValidateBucketNotificationConfiguration(IEnumerable<NotificationConfiguration> configurations, IReadOnlyList<EventType> eventTypes)
        {
            foreach (NotificationConfiguration configuration in configurations)
            {
                IReadOnlyList<EventType> eventTypesFromConfiguration = ReplaceRootEventTypes(configuration.Events).Distinct().ToList();

                List<EventType> overlappedEventTypes = eventTypesFromConfiguration.Intersect(eventTypes).ToList();

                if (!overlappedEventTypes.Any())
                    continue;
                throw new BucketNotificationValidationException($"Configurations on the same bucket cannot share a common event type. Following types are overlapped: {string.Join(", ", overlappedEventTypes)}) with {configuration.GetType().Name}");
            }
        }

        /// <summary>
        /// To simplify validation, we are replacing any root event type that ends with 'All' with it's sub/child events
        /// </summary>
        /// <remarks>
        /// If provided event types contains root event like ObjectCreatedAll, it will be replaces with collection of its sub events like
        /// ObjectCreatedPut, ObjectCreatedPost, ObjectCreatedCopy ....
        /// </remarks>
        private static IEnumerable<EventType> ReplaceRootEventTypes(IEnumerable<EventType> eventTypes)
        {
            foreach (EventType eventType in eventTypes)
            {
                if (AmazonS3EventTypes.RootedEventTypes.TryGetValue(eventType, out IReadOnlyList<EventType>? childEvents))
                {
                    foreach (EventType childEvent in childEvents)
                    {
                        yield return childEvent;
                    }
                }
                else
                {
                    yield return eventType;
                }
            }
        }

        protected static async ValueTask<GetBucketNotificationResponse> GetBucketNotificationSettings(IAmazonS3 client, string bucketName)
        {
            GetBucketNotificationResponse existingBucketNotification = await client.GetBucketNotificationAsync(bucketName);
            if (existingBucketNotification.HttpStatusCode != HttpStatusCode.OK)
                throw new AmazonS3RequestException($"Failed to get bucket '{bucketName}' notification settings", existingBucketNotification.HttpStatusCode);
            return existingBucketNotification;
        }

        private static void AddNotificationConfigurations(ref PutBucketNotificationRequest request, AmazonS3NotificationProviderType notificationProviderType, IEnumerable<NotificationConfiguration> existingConfigurations, string configurationId, string destinationArn, IEnumerable<EventType> eventTypes)
        {
            switch (notificationProviderType)
            {
                case AmazonS3NotificationProviderType.SQS:
                    request.QueueConfigurations = existingConfigurations.OfType<QueueConfiguration>().Concat(new[]
                            { new QueueConfiguration { Id = configurationId, Queue = destinationArn, Events = eventTypes.ToList() } })
                        .ToList();
                    break;
                case AmazonS3NotificationProviderType.SNS:
                    request.TopicConfigurations = existingConfigurations.OfType<TopicConfiguration>().Concat(new[]
                            { new TopicConfiguration { Id = configurationId, Topic = destinationArn, Events = eventTypes.ToList() } })
                        .ToList();
                    break;
                default: throw new ArgumentOutOfRangeException(nameof(notificationProviderType), notificationProviderType, null);
            }
        }

        private static void RemoveNotificationConfigurations(ref PutBucketNotificationRequest request, AmazonS3NotificationProviderType notificationProviderType, IEnumerable<NotificationConfiguration> currentConfigurations, NotificationConfiguration configurationToRemove)
        {
            switch (notificationProviderType)
            {
                case AmazonS3NotificationProviderType.SQS:
                    request.QueueConfigurations = currentConfigurations.OfType<QueueConfiguration>().Where(c => c.Queue != ((QueueConfiguration)configurationToRemove).Queue).ToList();
                    break;
                case AmazonS3NotificationProviderType.SNS:
                    request.TopicConfigurations = currentConfigurations.OfType<TopicConfiguration>().Where(c => c.Topic != ((TopicConfiguration)configurationToRemove).Topic).ToList();
                    break;
                default:
                    throw new ArgumentOutOfRangeException(nameof(notificationProviderType), notificationProviderType, null);
            }
        }

        protected static string GetResourceNameFromArnString(string arn) => Arn.Parse(arn).Resource;
    }
}
