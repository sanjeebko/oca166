﻿using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IAmazonS3NotificationProvider
    {
        /// <summary>
        /// Creates Queue if it doesn't exists and connects it to bucket if connection does not exists
        /// </summary>
        /// <returns>Url of Queue</returns>
        ValueTask<string> EnableNotificationsForBucketAsync(AmazonEnableNotificationsRequest enableNotificationsRequest);

        /// <summary>
        /// Disconnects queue from bucket
        /// </summary>
        ValueTask DisableNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest);

        /// <summary>
        /// Disconnects queue from bucket and removes queue
        /// </summary>
        ValueTask RemoveNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest);
    }
}