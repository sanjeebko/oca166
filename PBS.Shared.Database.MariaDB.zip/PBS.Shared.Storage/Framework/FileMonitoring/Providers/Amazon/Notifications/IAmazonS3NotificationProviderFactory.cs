﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IAmazonS3NotificationProviderFactory
    {
        IAmazonS3NotificationProvider GetProvider(AmazonS3NotificationProviderType notificationProviderType);
    }
}
