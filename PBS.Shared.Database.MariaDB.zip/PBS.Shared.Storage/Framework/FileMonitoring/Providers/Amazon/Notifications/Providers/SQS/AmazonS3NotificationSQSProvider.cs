﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.SQS;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonS3NotificationSQSProvider : AmazonS3NotificationProvider
    {
        private readonly IAmazonS3ClientFactory _s3ClientFactory;
        private readonly IAmazonSQSQueueManager _queueManager;

        private static readonly List<EventType> DefaultListeningEvents = new List<EventType> { EventType.ObjectCreatedAll, EventType.ObjectRemovedAll, EventType.ObjectRestoreAll };

        public AmazonS3NotificationSQSProvider(IAmazonS3ClientFactory s3ClientFactory, IAmazonSQSQueueManager queueManager)
        {
            _s3ClientFactory = s3ClientFactory;
            _queueManager = queueManager;
        }

        /// <summary>
        /// Creates SQS Queue if it doesn't exists and connects it to bucket if Queue Configuration for same does not exists
        /// </summary>
        /// <returns>Url of Queue</returns>
        /// <remarks>
        /// Execution steps
        /// 1.Get existing bucket notification settings for queue
        /// 2.If configuration already exists, try to retrieve queue url from existing queue configuration
        /// 3.Validate if there are any events that are overlapped with event types provided in request <param name="enableNotificationsRequest"></param>
        /// 4.Ensure that queue exists if number 2 did not pass by creating SQS queue with defined name in <param name="enableNotificationsRequest"></param>
        /// 5.Apply authorization policy on created queue for it to access s3 bucket defined in <param name="enableNotificationsRequest"></param>
        /// 6.Post new bucket notification queue configuration for defined queue and defined event types
        /// </remarks>
        /// <exception cref="AmazonS3RequestException">Throws when notification configuration update has failed or getting bucket notification settings has failed</exception>
        /// <exception cref="ArgumentNullException">Throws when <see cref="enableNotificationsRequest"/> is invalid</exception>
        /// <exception cref="InvalidOperationException">Throws when creation of sqs queue failed</exception>
        public override async ValueTask<string> EnableNotificationsForBucketAsync(AmazonEnableNotificationsRequest enableNotificationsRequest)
        {
            Requires.NotNull(enableNotificationsRequest, nameof(enableNotificationsRequest));
            Requires.NotNull(enableNotificationsRequest.Credential, nameof(enableNotificationsRequest.Credential));
            Requires.NotNull(enableNotificationsRequest.BucketName, nameof(enableNotificationsRequest.BucketName));
            Requires.NotNull(enableNotificationsRequest.QueueName, nameof(enableNotificationsRequest.QueueName));

            List<EventType> eventTypesList = enableNotificationsRequest.EventTypes.Any() ? enableNotificationsRequest.EventTypes.Distinct().ToList() : DefaultListeningEvents;

            using IAmazonS3 client = await _s3ClientFactory.CreateClient(enableNotificationsRequest.Credential);

            AmazonSQSCredential sqsCredentials = ConvertToSQSCredentials(enableNotificationsRequest.Credential);

            GetBucketNotificationResponse existingBucketNotification = await GetBucketNotificationSettings(client, enableNotificationsRequest.BucketName);

            QueueConfiguration? existingQueueConfiguration =
                existingBucketNotification.QueueConfigurations.FirstOrDefault(p =>
                    Arn.Parse(p.Queue).Resource == enableNotificationsRequest.QueueName);

            string? queueUrl = null;

            // if we have existing configuration, we will remove it from queue configuration list so we can do validation of overlapped event types
            // also new configuration will be created each time, so we don't have to deal with comparing existing queue configuration with new one
            if (existingQueueConfiguration != null)
            {
                existingBucketNotification.QueueConfigurations.RemoveAll(c => c.Queue == existingQueueConfiguration.Queue);
                // if we have existing configuration, try to get sqs queue url for same, if queue was deleted using some other amazon cli tool or through amazon 
                // management ui, it will not reflect queue configuration, so we will get valid queue arn and we need to double check if it actually exists.
                queueUrl = await _queueManager.GetQueueUrlAsync(sqsCredentials, enableNotificationsRequest.QueueName);
            }

            // Do validation of overlapped event types before creating actual sqs queue, amazon s3 does not allow same event types to be defined in multiple
            // destinations, to avoid creating queue and then adding new invalid queue configuration to bucket we are doing validation before hand to avoid creating queue for invalid configuration.
            // We will check Queue, Topic and Lamba configurations
            ValidateBucketNotification(existingBucketNotification, eventTypesList);

            queueUrl ??= await EnsureQueueExistsAsync(sqsCredentials, enableNotificationsRequest.QueueName, enableNotificationsRequest.Attributes);

            if (string.IsNullOrEmpty(queueUrl))
                throw new InvalidOperationException($"Failed to create queue {enableNotificationsRequest.QueueName}");

            // we need to ensure proper authorization policy is added on queue for it to access defined bucket, if policy already exists it will be ignored.
            string queueArn = await _queueManager.AuthorizeS3ToSendMessageAsync(sqsCredentials, queueUrl, enableNotificationsRequest.BucketName);

            // generate configuration id, without specifying id, amazon will create new id each time, so we are avoiding this by generating our own id
            string queueConfigurationId = AmazonS3NameGenerator.Generate(enableNotificationsRequest.BucketName, AmazonS3NotificationProviderType.SQS.ToString(), enableNotificationsRequest.QueueName);

            await EnableNotificationOnBucketAsync(client, queueConfigurationId, enableNotificationsRequest.BucketName, queueArn, AmazonS3NotificationProviderType.SQS, existingBucketNotification.QueueConfigurations, eventTypesList);

            return queueUrl;
        }

        /// <summary>
        /// Removes queue configuration if any for a queue defined in <param name="notificationsRequest"></param> from defined bucket
        /// </summary>
        /// <exception cref="AmazonS3RequestException">Throws when notification configuration update has failed or getting bucket notification settings has failed</exception>
        /// <exception cref="ArgumentNullException">Throws when <see cref="notificationsRequest"/> is invalid</exception>
        public override async ValueTask DisableNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest)
        {
            Requires.NotNull(notificationsRequest, nameof(notificationsRequest));
            Requires.NotNull(notificationsRequest.Credential, nameof(notificationsRequest.Credential));
            Requires.NotNull(notificationsRequest.BucketName, nameof(notificationsRequest.BucketName));
            Requires.NotNull(notificationsRequest.QueueName, nameof(notificationsRequest.QueueName));

            using IAmazonS3 client = await _s3ClientFactory.CreateClient(notificationsRequest.Credential);

            GetBucketNotificationResponse existingBucketNotification = await GetBucketNotificationSettings(client, notificationsRequest.BucketName);

            // find queue configuration where queue name from existing queue configuration arn is equal to queue name defined in request
            foreach (QueueConfiguration queueConfiguration in existingBucketNotification.QueueConfigurations.Where(queueConfiguration => GetQueueName(queueConfiguration) == notificationsRequest.QueueName))
            {
                await DisableNotificationOnBucketAsync(client, notificationsRequest.BucketName, AmazonS3NotificationProviderType.SQS, existingBucketNotification.QueueConfigurations, queueConfiguration);
            }
        }

        /// <summary>
        /// Removes queue configuration if any for a queue defined in <param name="notificationsRequest"></param> from defined bucket
        /// then deletes SQS queue if it exists.
        /// </summary>
        /// <exception cref="AmazonS3RequestException">Throws when notification configuration update has failed or getting bucket notification settings has failed</exception>
        /// <exception cref="ArgumentNullException">Throws when <see cref="notificationsRequest"/> is invalid</exception>
        /// <exception cref="AggregateException">Throws when delete queue failed</exception>
        public override async ValueTask RemoveNotificationsForBucketAsync(AmazonNotificationsRequest notificationsRequest)
        {
            await DisableNotificationsForBucketAsync(notificationsRequest);

            AmazonQueueResponse response = await _queueManager.DeleteQueueAsync(ConvertToSQSCredentials(notificationsRequest.Credential!), notificationsRequest.QueueName!);
            if (!response.Success)
                throw new AggregateException(response.Errors);
        }

        private static AmazonSQSCredential ConvertToSQSCredentials(AmazonS3Credential credential)
        {
            return new AmazonSQSCredential
            {
                AccessKey = credential.AccessKey,
                SecretAccessKey = credential.SecretAccessKey,
                Config = credential.Config != null ? new AmazonSQSConfig { RegionEndpoint = credential.Config.RegionEndpoint } : null
            };
        }

        private async Task<string?> EnsureQueueExistsAsync(AmazonSQSCredential credential, string queueName, IReadOnlyDictionary<string, string> attributes)
        {
            if (!await _queueManager.IsQueueAvailableAsync(credential, queueName))
            {
                AmazonCreateQueueResponse createCreateQueueResponse = await _queueManager.CreateQueueAsync(credential, new AmazonCreateQueueRequest { QueueName = queueName, Attributes = attributes });
                if (!createCreateQueueResponse.Success)
                    throw new InvalidOperationException($"Failed to create queue {queueName}", new AggregateException(createCreateQueueResponse.Errors));
                return createCreateQueueResponse.QueueUrl;
            }

            return await _queueManager.GetQueueUrlAsync(credential, queueName);
        }

        private static string GetQueueName(QueueConfiguration queueConfiguration) => GetResourceNameFromArnString(queueConfiguration.Queue);
    }
}