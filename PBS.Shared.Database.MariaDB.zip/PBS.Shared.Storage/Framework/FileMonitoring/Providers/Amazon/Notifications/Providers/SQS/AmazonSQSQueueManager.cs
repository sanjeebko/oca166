﻿using Amazon;
using Amazon.Runtime;
using Amazon.SQS;
using Amazon.SQS.Model;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonSQSQueueManager : IAmazonSQSQueueManager
    {
        private readonly IAmazonSQSClientFactory _clientFactory;

        private static readonly List<string> QueueArnAttributes = new List<string> { QueueAttributeName.QueueArn };

        public AmazonSQSQueueManager(IAmazonSQSClientFactory clientFactory)
        {
            _clientFactory = clientFactory;
        }

        public async ValueTask<AmazonCreateQueueResponse> CreateQueueAsync(AmazonSQSCredential credential, AmazonCreateQueueRequest request)
        {
            var response = new AmazonCreateQueueResponse();

            try
            {
                Requires.NotNull(credential, nameof(credential));
                Requires.NotNull(request, nameof(request));
                Requires.NotNull(request.QueueName, nameof(request.QueueName));

                using IAmazonSQS client = await _clientFactory.CreateClient(credential);

                var createQueueRequest = new CreateQueueRequest { QueueName = request.QueueName };

                if (request.Attributes.Any())
                    createQueueRequest.Attributes = new Dictionary<string, string>(request.Attributes);

                CreateQueueResponse createQueueResponse = await client.CreateQueueAsync(createQueueRequest);

                ValidateResponse(createQueueResponse, $"Failed to create queue {request.QueueName}");

                Requires.NotNull(createQueueResponse.QueueUrl, nameof(createQueueResponse.QueueUrl), $"Created queue url for queue {request.QueueName} is invalid");

                response.QueueUrl = createQueueResponse.QueueUrl;
            }
            catch (Exception e)
            {
                response.Errors = new[] { e };
            }

            response.Success = !string.IsNullOrEmpty(response.QueueUrl);
            return response;
        }

        public async ValueTask<AmazonQueueResponse> DeleteQueueAsync(AmazonSQSCredential credential, string queueName)
        {
            var response = new AmazonQueueResponse();

            try
            {
                Requires.NotNull(credential, nameof(credential));
                Requires.NotNull(queueName, nameof(queueName));

                using IAmazonSQS client = await _clientFactory.CreateClient(credential);

                string? queueUrl = await GetQueueUrlAsync(client, queueName);

                if (!string.IsNullOrEmpty(queueUrl))
                {
                    DeleteQueueResponse deleteResponse = await client.DeleteQueueAsync(queueUrl);
                    ValidateResponse(deleteResponse, $"Failed to delete queue {queueName}");
                }

                response.Success = true;
            }
            catch (Exception e)
            {
                response.Errors = new[] { e };
            }

            return response;
        }


        public async ValueTask<string?> GetQueueUrlAsync(AmazonSQSCredential credential, string queueName)
        {
            Requires.NotNull(credential, nameof(credential));
            Requires.NotNull(queueName, nameof(queueName));

            using IAmazonSQS client = await _clientFactory.CreateClient(credential);

            return await GetQueueUrlAsync(client, queueName);
        }

        public async ValueTask<bool> IsQueueAvailableAsync(AmazonSQSCredential credential, string queueName)
        {
            Requires.NotNull(credential, nameof(credential));
            Requires.NotNull(queueName, nameof(queueName));

            using IAmazonSQS client = await _clientFactory.CreateClient(credential);

            ListQueuesResponse responseList = await client.ListQueuesAsync("");

            ValidateResponse(responseList, "Failed to list queues");

            foreach (string queueUrl in responseList.QueueUrls)
            {
                GetQueueAttributesResponse responseGetAtt = await client.GetQueueAttributesAsync(queueUrl, QueueArnAttributes);

                if (responseGetAtt.HttpStatusCode != HttpStatusCode.OK)
                    continue;

                Arn arn = Arn.Parse(responseGetAtt.QueueARN);
                if (queueName == arn.Resource)
                    return true;
            }
            return false;
        }

        public async ValueTask<string> AuthorizeS3ToSendMessageAsync(AmazonSQSCredential credential, string queueUrl, string bucketName)
        {
            Requires.NotNull(credential, nameof(credential));
            Requires.NotNull(queueUrl, nameof(queueUrl));
            Requires.NotNull(bucketName, nameof(bucketName));

            using IAmazonSQS client = await _clientFactory.CreateClient(credential);
            return await client.AuthorizeS3ToSendMessageAsync(queueUrl, bucketName);
        }

        private static async ValueTask<string?> GetQueueUrlAsync(IAmazonSQS client, string queueName)
        {
            try
            {
                GetQueueUrlResponse response = await client.GetQueueUrlAsync(new GetQueueUrlRequest(queueName));
                ValidateResponse(response, $"Failed to get queue {queueName} url");
                return response.QueueUrl;
            }
            catch (QueueDoesNotExistException)
            {
                return default;
            }
        }

        private static void ValidateResponse(AmazonWebServiceResponse response, string message)
        {
            response.ValidateAmazonServiceResponse<AmazonQueueRequestException>(message);
        }
    }
}