﻿using Amazon.SQS;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonSQSCredential : AmazonCredential<AmazonSQSConfig>
    {
    }
}
