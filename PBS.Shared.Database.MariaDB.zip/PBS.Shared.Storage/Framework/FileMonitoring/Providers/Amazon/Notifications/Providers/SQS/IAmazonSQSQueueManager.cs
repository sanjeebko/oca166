﻿using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    /// <summary>
    /// SQS queue manager interface
    /// </summary>
    public interface IAmazonSQSQueueManager : IAmazonQueueManager<AmazonSQSCredential>
    {
        /// <summary>
        /// Creates SQS Queue
        /// </summary>
        /// <param name="credential">SQS Credentials</param>
        /// <param name="request">Create request</param>
        /// <returns>A Task containing create queue response containing Queue Url if created successfully</returns>
        /// <remarks>
        /// * In case that queue exists, response will contain <see cref="Amazon.SQS.Model.QueueNameExistsException"/>
        /// * In case that queue was deleted recently, less then 60s, response errors could contain <see cref="Amazon.SQS.Model.QueueDeletedRecentlyException"/>
        /// * In case that create queue status code was not OK, response errors should contain <see cref="AmazonQueueRequestException"/>
        /// </remarks>
        new ValueTask<AmazonCreateQueueResponse> CreateQueueAsync(AmazonSQSCredential credential, AmazonCreateQueueRequest request);

        /// <summary>
        /// Deletes SQS queue
        /// </summary>
        /// <param name="credential">SQS Credentials</param>
        /// <param name="queueName">Queue name</param>
        /// <returns>A Task containing SQS response</returns>
        /// <remarks>
        /// * In case that queue with defined name does not exists, response will be success
        /// * In case that delete of queue fails, response errors should contain <see cref="AmazonQueueRequestException"/>
        /// * In case that queue has dead letter queue configured, dead letter queue should be deleted
        /// </remarks>
        new ValueTask<AmazonQueueResponse> DeleteQueueAsync(AmazonSQSCredential credential, string queueName);
    }
}
