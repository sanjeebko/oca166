﻿using Amazon.SQS;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IAmazonSQSClientFactory
    {
        ValueTask<IAmazonSQS> CreateClient(AmazonSQSCredential credential);
    }
}
