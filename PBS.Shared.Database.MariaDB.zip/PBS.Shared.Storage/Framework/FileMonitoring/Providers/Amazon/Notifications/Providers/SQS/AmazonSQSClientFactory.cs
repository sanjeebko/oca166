﻿using Amazon.SQS;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonSQSClientFactory : IAmazonSQSClientFactory
    {
        public ValueTask<IAmazonSQS> CreateClient(AmazonSQSCredential credential)
        {
            bool hasCredentials = !string.IsNullOrEmpty(credential.AccessKey) && !string.IsNullOrEmpty(credential.SecretAccessKey);

            if (hasCredentials)
            {
                return ValueTask.FromResult<IAmazonSQS>(new AmazonSQSClient(credential.AccessKey, credential.SecretAccessKey, credential.Config));
            }

            return ValueTask.FromResult<IAmazonSQS>(new AmazonSQSClient(credential.Config));
        }
    }
}