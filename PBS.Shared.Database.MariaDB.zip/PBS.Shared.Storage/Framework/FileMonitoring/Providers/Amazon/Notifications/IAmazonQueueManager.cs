﻿using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IAmazonQueueManager<in TCredential> where TCredential : AmazonCredential
    {
        /// <summary>
        /// Creates queue
        /// </summary>
        /// <param name="credential">Credentials</param>
        /// <param name="request">Create request</param>
        /// <returns>A Task containing create queue response containing Queue Url if created successfully</returns>
        ValueTask<AmazonCreateQueueResponse> CreateQueueAsync(TCredential credential, AmazonCreateQueueRequest request);

        /// <summary>
        /// Deletes queue
        /// </summary>
        /// <param name="credential">Credentials</param>
        /// <param name="queueName">Queue name</param>
        /// <returns>A Task containing  response</returns>
        ValueTask<AmazonQueueResponse> DeleteQueueAsync(TCredential credential, string queueName);

        /// <summary>
        /// Get's queue url
        /// </summary>
        /// <param name="credential"> Credentials</param>
        /// <param name="queueName">Queue name</param>
        /// <returns>A Task containing queue url if found, or null if not found</returns>
        ValueTask<string?> GetQueueUrlAsync(TCredential credential, string queueName);

        /// <summary>
        /// Check's if queue is available
        /// </summary>
        /// <param name="credential"> Credentials</param>
        /// <param name="queueName">Queue name</param>
        /// <returns>A Task containing true if it is found, or false if not</returns>
        ValueTask<bool> IsQueueAvailableAsync(TCredential credential, string queueName);

        /// <summary>
        /// This is a utility method which asynchronously updates the policy of a queue to allow the
        /// S3 bucket to publish events to it.
        /// </summary>
        /// <param name="credential"> Credentials</param>
        /// <param name="queueUrl">The queue that will have its policy updated.</param>
        /// <param name="bucketName">The bucket that will be given access to send messages from.</param>
        /// <returns>A Task containing the ARN for the  queue. This can be used when setting up the S3 bucket notification.</returns>
        ValueTask<string> AuthorizeS3ToSendMessageAsync(TCredential credential, string queueUrl, string bucketName);
    }
}
