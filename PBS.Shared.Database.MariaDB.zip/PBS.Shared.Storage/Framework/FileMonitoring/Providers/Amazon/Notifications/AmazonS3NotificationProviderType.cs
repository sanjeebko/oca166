﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public enum AmazonS3NotificationProviderType
    {
        SQS,
        SNS
    }
}
