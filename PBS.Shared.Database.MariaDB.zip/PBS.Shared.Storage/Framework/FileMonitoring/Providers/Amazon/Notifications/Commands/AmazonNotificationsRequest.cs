﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonNotificationsRequest
    {
        public AmazonS3Credential? Credential { get; init; }
        public string? BucketName { get; init; }
        public string? QueueName { get; init; }
    }
}
