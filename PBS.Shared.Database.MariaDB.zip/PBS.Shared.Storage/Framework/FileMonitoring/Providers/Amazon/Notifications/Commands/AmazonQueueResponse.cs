﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonQueueResponse
    {
        public bool Success { get; set; }
        public IEnumerable<Exception> Errors { get; set; } = new List<Exception>();
    }
}