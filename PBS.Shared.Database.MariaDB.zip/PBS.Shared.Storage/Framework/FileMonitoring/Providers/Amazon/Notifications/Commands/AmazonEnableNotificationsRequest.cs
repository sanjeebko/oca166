﻿using Amazon.S3;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonEnableNotificationsRequest : AmazonNotificationsRequest
    {
        public IEnumerable<EventType> EventTypes { get; set; } = Enumerable.Empty<EventType>();
        public IReadOnlyDictionary<string, string> Attributes { get; set; } = new Dictionary<string, string>();
    }
}
