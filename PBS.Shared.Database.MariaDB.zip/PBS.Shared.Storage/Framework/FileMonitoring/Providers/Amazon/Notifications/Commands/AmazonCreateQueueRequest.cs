﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonCreateQueueRequest : AmazonQueueRequest
    {
    }
}