﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonCreateQueueResponse : AmazonQueueResponse
    {
        public string QueueUrl { get; set; } = string.Empty;
    }
}