﻿using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonQueueRequest
    {
        public string QueueName { get; set; } = string.Empty;
        public IReadOnlyDictionary<string, string> Attributes { get; set; } = new Dictionary<string, string>();
    }
}