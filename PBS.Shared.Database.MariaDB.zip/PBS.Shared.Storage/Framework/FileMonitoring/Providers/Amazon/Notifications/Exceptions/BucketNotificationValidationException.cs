﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage.FileMonitoring
{
    [Serializable]
    public class BucketNotificationValidationException : InvalidOperationException
    {
        public BucketNotificationValidationException(string? message) : base(message) { }
        public BucketNotificationValidationException(string? message, Exception? innerException) : base(message, innerException) { }
        protected BucketNotificationValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
