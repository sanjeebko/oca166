﻿using System;
using System.Net;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage.FileMonitoring
{
    [Serializable]
    public class AmazonQueueRequestException : AmazonHttpException
    {
        public AmazonQueueRequestException(string? message, HttpStatusCode? statusCode) : base(message, statusCode) { }
        public AmazonQueueRequestException(string? message, HttpStatusCode? statusCode, Exception? innerException) : base(message, statusCode, innerException) { }
        protected AmazonQueueRequestException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
