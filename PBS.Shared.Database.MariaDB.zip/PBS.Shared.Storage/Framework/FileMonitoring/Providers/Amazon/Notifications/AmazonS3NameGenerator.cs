﻿using System.Text;

namespace PBS.Shared.Storage.FileMonitoring
{
    public static class AmazonS3NameGenerator
    {
        public const string DefaultPrefix = "Pebble";
        public const char DefaultDelimiter = '_';

        public static string Generate(params string[] arguments)
        {
            return Generate(DefaultPrefix, DefaultDelimiter, arguments);
        }

        public static string Generate(string prefix, char delimiter, params string[] arguments)
        {
            var builder = new StringBuilder();
            builder.Append(prefix + delimiter);
            foreach (string argument in arguments)
                builder.Append(argument + delimiter);
            return builder.ToString(0, builder.Length - 1);
        }
    }
}