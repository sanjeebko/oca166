﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class AmazonS3NotificationProviderFactory : IAmazonS3NotificationProviderFactory
    {
        private readonly IServiceProvider _serviceProvider;

        public AmazonS3NotificationProviderFactory(IServiceProvider serviceProvider)
        {
            _serviceProvider = serviceProvider;
        }

        public IAmazonS3NotificationProvider GetProvider(AmazonS3NotificationProviderType notificationProviderType)
        {
            return notificationProviderType switch
            {
                AmazonS3NotificationProviderType.SQS => _serviceProvider.GetRequiredService<AmazonS3NotificationSQSProvider>(),
                AmazonS3NotificationProviderType.SNS => throw new NotSupportedException($"Provider {notificationProviderType} is not supported"),
                _ => throw new ArgumentOutOfRangeException(nameof(notificationProviderType), notificationProviderType, null)
            };
        }
    }
}