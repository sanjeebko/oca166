﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeProvider : IDisposable
    {
        IObservable<IStorageFileChange> FileChanges { get; }
        IObservable<Exception> Errors { get; }

        StorageFileChangeProviderStatus Status { get; }

        ValueTask StartAsync(IStorageCredential credential, CancellationToken cancellationToken);
        ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default);
        ValueTask<bool> CheckConnectionAsync();
    }
}
