﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public interface IStorageFileChangeProviderFactory
    {
        public IStorageFileChangeProvider? ResolveProvider(StorageType type);
    }
}
