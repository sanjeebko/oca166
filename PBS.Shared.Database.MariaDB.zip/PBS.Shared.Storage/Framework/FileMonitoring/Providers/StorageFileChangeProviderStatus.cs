﻿namespace PBS.Shared.Storage.FileMonitoring
{
    public enum StorageFileChangeProviderStatus
    {
        Available,
        Unavailable
    }
}
