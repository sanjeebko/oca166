﻿using Microsoft.Extensions.Options;
using System;

namespace PBS.Shared.Storage.FileMonitoring
{
    public class StorageFileChangeProviderFactory : IStorageFileChangeProviderFactory
    {
        private readonly IServiceProvider _serviceProvider;
        private readonly IOptions<IStorageFileChangeProviderOptions> _options;

        public StorageFileChangeProviderFactory(IServiceProvider serviceProvider, IOptions<IStorageFileChangeProviderOptions> options)
        {
            _serviceProvider = serviceProvider;
            _options = options;
        }

        public IStorageFileChangeProvider? ResolveProvider(StorageType type)
        {
            Type? providerType = _options.Value.GetProviderType(type);
            return providerType != null ? _serviceProvider.GetService(providerType) as IStorageFileChangeProvider : default;
        }
    }
}