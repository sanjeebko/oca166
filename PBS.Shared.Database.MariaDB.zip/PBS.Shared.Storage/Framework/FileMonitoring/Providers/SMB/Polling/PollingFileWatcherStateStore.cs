﻿using PBS.Shared.Validation;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class PollingFileWatcherStateStore : IPollingFileWatcherStateStore
    {
        private readonly ConcurrentDictionary<string, FileInfoState> _state;

        public PollingFileWatcherStateStore(IReadOnlyDictionary<string, FileInfoState>? states)
        {
            _state = states != null ? new ConcurrentDictionary<string, FileInfoState>(states) : new ConcurrentDictionary<string, FileInfoState>();
        }

        public PollingFileWatcherStateStore()
        {
            _state = new ConcurrentDictionary<string, FileInfoState>();
        }

        public bool Add(string key, FileInfoState fileInfoState)
        {
            Requires.NotNull(key, nameof(key));
            Requires.NotNull(fileInfoState, nameof(fileInfoState));

            _state.AddOrUpdate(key, fileInfoState, (_, _) => fileInfoState);
            return true;
        }

        public void Update(string key, FileInfoState fileInfoState)
        {
            Requires.NotNull(key, nameof(key));
            Requires.NotNull(fileInfoState, nameof(fileInfoState));

            ValidateKeyExists(key);

            if (!ReferenceEquals(fileInfoState, _state[key])) // check if it's new object
            {
                _state.AddOrUpdate(key, fileInfoState, (_, _) => fileInfoState);
            }
        }

        public bool Remove(string key)
        {
            Requires.NotNull(key, nameof(key));

            return _state.TryRemove(key, out _);
        }

        public bool TryGetValue(string key, out FileInfoState? fileInfoState)
        {
            Requires.NotNull(key, nameof(key));

            return _state.TryGetValue(key, out fileInfoState);
        }

        private void ValidateKeyExists(string key)
        {
            if (!_state.ContainsKey(key))
                throw new KeyNotFoundException($"Key {key} is not found");
        }

        public IReadOnlyDictionary<string, FileInfoState> GetState()
        {
            return _state;
        }
    }
}