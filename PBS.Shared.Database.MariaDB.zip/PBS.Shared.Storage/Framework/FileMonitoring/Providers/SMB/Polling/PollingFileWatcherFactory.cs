﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class PollingFileWatcherFactory : IPollingFileWatcherFactory
    {
        private readonly IPollingFileWatcherStateStore _stateStore;

        public PollingFileWatcherFactory(IPollingFileWatcherStateStore stateStore)
        {
            _stateStore = stateStore;
        }

        public IPollingFileWatcher Create(string watchedDirectory, TimeSpan interval, PollingFileWatcherType type = PollingFileWatcherType.Sync)
        {
            return type switch
            {
                PollingFileWatcherType.Sync => new PollingFileWatcher(watchedDirectory, interval, _stateStore),
                _ => throw new ArgumentException($"Polling file watcher with type {type} is not supported")
            };
        }
    }
}