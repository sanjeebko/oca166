﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public readonly struct FileInfo
    {
        public readonly string Path;
        public readonly string RelativePath;
        public readonly long Length;
        public readonly DateTimeOffset LastWriteTimeUtc;
        public readonly DateTimeOffset CreationTimeUtc;

        public FileInfo(
            string path,
            string relativePath,
            long length,
            DateTimeOffset creationTimeUtc,
            DateTimeOffset lastWriteTimeUtc)
        {
            Path = path;
            RelativePath = relativePath;
            LastWriteTimeUtc = lastWriteTimeUtc;
            CreationTimeUtc = creationTimeUtc;
            Length = length;
        }
    }
}