﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public interface IPollingFileWatcherFactory
    {
        IPollingFileWatcher Create(string watchedDirectory, TimeSpan interval, PollingFileWatcherType type = PollingFileWatcherType.Sync);
    }
}
