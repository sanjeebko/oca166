﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class PollingFileWatcherEventArgs : EventArgs
    {
        public PollingFileWatcherEventArgs(params FileChange[] changes)
        {
            Changes = changes;
        }

        public FileChange[] Changes { get; }
    }
}
