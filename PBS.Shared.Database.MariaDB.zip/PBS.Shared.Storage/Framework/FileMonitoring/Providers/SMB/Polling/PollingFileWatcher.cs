﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class PollingFileWatcher : PollingFileWatcherBase
    {
        public PollingFileWatcher(
            string watchedDirectory,
            TimeSpan interval,
            IPollingFileWatcherStateStore? store = null)
            : base(watchedDirectory, interval, store ?? new PollingFileWatcherStateStore())
        {
        }

        protected override ValueTask CreateSnapshotInternalAsync()
        {
            ForeachFileInDirectory(HandleStateAdded);
            return ValueTask.CompletedTask;
        }

        protected override ValueTask CheckForChangesInternalAsync()
        {
            ForeachFileInDirectory(HandleStateUpdate);
            return ValueTask.CompletedTask;
        }

        public override ValueTask<IEnumerable<FileInfo>> GetSnapshotAsync()
        {
            var snapshot = new List<FileInfo>();
            ForeachFileInDirectory((directory, fileName, length, creationTimeUtc, lastWriteTimeUtc) =>
            {
                string path = JoinPaths(directory, fileName);
                string relativePath = GetNormalizedRelativePath(path);
                snapshot.Add(new FileInfo(path, relativePath, length, creationTimeUtc, lastWriteTimeUtc));
            });
            return ValueTask.FromResult<IEnumerable<FileInfo>>(snapshot);
        }

        protected virtual void HandleStateAdded(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, long length, DateTimeOffset creationTimeUtc, DateTimeOffset lastWriteTimeUtc)
        {
            var path = JoinPaths(directory, fileName);
            var relativePath = GetNormalizedRelativePath(path);
            var fileState = new FileInfoState(path, relativePath, length, creationTimeUtc, lastWriteTimeUtc, Version);
            Store.Add(fileState.Path, fileState);
        }

        protected virtual void HandleStateUpdate(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, long length, DateTimeOffset creationTimeUtc, DateTimeOffset lastWriteTimeUtc)
        {
            string path = JoinPaths(directory, fileName);
            if (!Store.TryGetValue(path, out FileInfoState? fileState))
            {
                // New file
                fileState = new FileInfoState(path, GetNormalizedRelativePath(path), length, creationTimeUtc, lastWriteTimeUtc, Version);

                NotifyChange(fileState, WatcherChangeTypes.Created);

                Store.Add(path, fileState);

                return;
            }

            if (fileState is null)
                throw new ArgumentNullException(path, "File state is null");

            try
            {
                fileState.Version = Version;

                if (!IsEntryChange(ref fileState, length, lastWriteTimeUtc))
                {
                    Store.Update(path, fileState);
                    return;
                }

                fileState.Size = length;
                fileState.LastWriteTimeUtc = lastWriteTimeUtc;

                NotifyChange(fileState, WatcherChangeTypes.Changed);

                Store.Update(path, fileState);
            }
            catch (FileNotFoundException)
            {
                fileState.Version = 0;
                Store.Update(path, fileState);
            }
        }

        protected virtual void ForeachFileInDirectory(FileSystemEntryDelegate fileSystemEntryDelegate)
        {
            using var enumerator = new PollingFileSystemEntryEnumerator(
                WatchedDirectory,
                ShouldIncludeEntry,
                ShouldRecurseInto,
                fileSystemEntryDelegate,
                GetEnumerationOptions());

            while (enumerator.MoveNext())
            {
                if (CancellationToken.IsCancellationRequested)
                    return;
            }
        }

        private static bool IsEntryChange(ref FileInfoState fileInfoState, long size, DateTimeOffset lastWriteTimeUtc) =>
            fileInfoState.Size != size || fileInfoState.LastWriteTimeUtc != lastWriteTimeUtc;

        public override FileDirectoryInfo? GetDirectoryInfoFromWatchedDirectory() => Directory.Exists(WatchedDirectory) ? new FileDirectoryInfo(WatchedDirectory) : null;
    }
}
