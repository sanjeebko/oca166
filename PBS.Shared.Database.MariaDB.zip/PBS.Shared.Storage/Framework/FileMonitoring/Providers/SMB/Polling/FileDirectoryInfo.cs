﻿using System.IO;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public struct FileDirectoryInfo
    {
        public string? Path { get;  }
        public FileDirectoryInfo(DirectoryInfo directoryInfo)
        {
            Path = directoryInfo.FullName;
        }

        public FileDirectoryInfo(string? path)
        {
            Path = path;
        }
    }
}
