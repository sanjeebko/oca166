﻿using System;
using System.IO;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public readonly struct FileChange
    {
        public FileChange(FileInfoState fileInfoState, WatcherChangeTypes changeType)
            : this(
                fileInfoState.Path,
                fileInfoState.RelativePath,
                fileInfoState.Size,
                fileInfoState.CreationTimeUtc,
                fileInfoState.LastWriteTimeUtc,
                changeType)
        {
        }

        public FileChange(
            string path,
            string relativePath,
            long size,
            DateTimeOffset creationTimeUtc,
            DateTimeOffset lastWriteTimeUtc,
            WatcherChangeTypes changeType)
        {
            Path = path;
            RelativePath = relativePath;
            Size = size;
            LastWriteTimeUtc = lastWriteTimeUtc;
            CreationTimeUtc = creationTimeUtc;
            ChangeType = changeType;
        }

        public string Path { get; }
        public string RelativePath { get; }
        public long Size { get; }
        public DateTimeOffset LastWriteTimeUtc { get; }
        public DateTimeOffset CreationTimeUtc { get; }
        public WatcherChangeTypes ChangeType { get; }

        public override string ToString()
        {
            return Path;
        }
    }
}
