﻿using PBS.Shared.Dependency;
using PBS.Shared.Extensions;
using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Enumeration;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public abstract class PollingFileWatcherBase : Disposable, IPollingFileWatcher
    {
        private readonly CancellationTokenSource _cancellationTokenSource = new();
        private readonly bool _ignoreCase;
        private readonly StringComparison _comparison;
        private readonly IEqualityComparer<string> _equalityComparer;
        private Task? _pollingTask;

        protected long Version;
        protected long State;
        protected const long StateIdle = 0;
        protected const long StateRunning = 1;

        protected string WatchedDirectory { get; }
        protected TimeSpan MinRunInternal { get; }
        protected IPollingFileWatcherStateStore Store { get; }
        protected CancellationToken CancellationToken => _cancellationTokenSource.Token;
        protected EnumerationOptions? EnumerationOptions { get; set; }

        public event PollingFileWatcherEventHandler? Changed;
        public event ErrorEventHandler? Error;

        public string[]? FolderFilters { get; set; }
        public string[]? FileFilters { get; set; }
        public bool EnableRaisingEvents { get; set; }
        public bool WatchSubfolders { get; set; } = true;

        protected PollingFileWatcherBase(
            string watchedDirectory,
            TimeSpan interval,
            IPollingFileWatcherStateStore store)
        {
            _cancellationTokenSource.Token.Register(() => _cancellationTokenSource.Cancel());
            _ignoreCase = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX);
            _comparison = _ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal;
            _equalityComparer = _ignoreCase ? StringComparer.OrdinalIgnoreCase : StringComparer.Ordinal;

            Store = store;
            WatchedDirectory = watchedDirectory;
            MinRunInternal = interval.TotalMilliseconds > 0 ? interval : TimeSpan.FromMinutes(2);
        }

        public virtual async ValueTask StartAsync()
        {
            if (_pollingTask is not null)
                throw new InvalidOperationException("Watcher already started");

            await CreateSnapshotAsync();

            _pollingTask = PollingLoop();
        }

        protected virtual async Task? PollingLoop()
        {
            while (!CancellationToken.IsCancellationRequested)
            {
                try
                {
                    if (EnableRaisingEvents)
                    {
                        await CheckForChangesAsync();
                    }
                }
                catch (Exception e)
                {
                    Error?.Invoke(this, new ErrorEventArgs(e));
                }

                await Task.Delay(MinRunInternal, CancellationToken).SwallowCancellation();
            }
        }

        protected async ValueTask CreateSnapshotAsync()
        {
            Interlocked.Increment(ref Version);

            await CreateSnapshotInternalAsync();
        }

        public async ValueTask CheckForChangesAsync()
        {
            if (Interlocked.CompareExchange(ref State, StateRunning, StateIdle) == StateIdle)
            {
                Interlocked.Increment(ref Version);

                try
                {
                    await CheckForChangesInternalAsync();

                    HandleStateRemoved();
                }
                finally
                {
                    Interlocked.Exchange(ref State, StateIdle);
                }
            }
        }

        protected virtual void HandleStateRemoved()
        {
            foreach ((string key, FileInfoState fileState) in Store.GetState())
            {
                if (CancellationToken.IsCancellationRequested)
                    break;

                if (fileState.Version == Version)
                    continue;

                NotifyChange(fileState, WatcherChangeTypes.Deleted);

                Store.Remove(key);
            }
        }

        protected abstract ValueTask CreateSnapshotInternalAsync();
        protected abstract ValueTask CheckForChangesInternalAsync();
        public abstract ValueTask<IEnumerable<FileInfo>> GetSnapshotAsync();

        protected virtual bool ShouldIncludeEntry(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, bool isDirectory)
        {
            bool shouldIncludeEntry = !isDirectory && MatchesFileFilter(fileName, _ignoreCase, FileFilters);

            // if we have folder filters we need to check if file belongs to defined folders
            if (shouldIncludeEntry)
            {
                shouldIncludeEntry = MatchesFolderFilter(directory, fileName, isDirectory, _comparison, FolderFilters);
            }

            return shouldIncludeEntry;
        }

        protected virtual bool ShouldRecurseInto(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, bool isDirectory)
            => isDirectory && MatchesFolderFilter(directory, fileName, isDirectory, _comparison, FolderFilters);

        private static bool MatchesFileFilter(ReadOnlySpan<char> fileName, bool ignoreCase, string[]? filters)
        {
            if (filters is null) return true;
            if (filters.Length == 0) return true;

            foreach (string filter in filters)
            {
                if (FileSystemName.MatchesSimpleExpression(filter, fileName, ignoreCase))
                    return true;
            }
            return false;
        }

        private bool MatchesFolderFilter(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, bool isDirectory, StringComparison comparison, string[]? filters)
        {
            if (filters is null) return true;
            if (filters.Length == 0) return true;

            string normalizedPath = GetNormalizedRelativePath(directory, fileName, isDirectory);

            return filters.Any(filter =>
                isDirectory ?
                    filter.StartsWith(normalizedPath, comparison) :
                    filter.Equals(normalizedPath, comparison));
        }

        protected virtual string GetNormalizedRelativePath(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, bool isDirectory)
            => GetNormalizedRelativePath(isDirectory ? JoinPaths(directory, fileName) : directory.ToString());

        protected virtual string GetNormalizedRelativePath(string path)
            => StoragePath.GetNormalizedRelativePath(WatchedDirectory, path, comparer: _equalityComparer);

        protected virtual string JoinPaths(ReadOnlySpan<char> path1, ReadOnlySpan<char> path2) => Path.Join(path1, path2);

        protected EnumerationOptions GetEnumerationOptions()
        {
            EnumerationOptions ??= new EnumerationOptions
            {
                IgnoreInaccessible = true,
                RecurseSubdirectories = WatchSubfolders,
                BufferSize = 16 * 1000
            };

            return EnumerationOptions;
        }

        protected virtual void NotifyChange(FileInfoState fileInfoState, WatcherChangeTypes change)
        {
            if (CancellationToken.IsCancellationRequested)
                return;

            if (fileInfoState.Path.Equals(WatchedDirectory, _comparison))
                return;

            Changed?.Invoke(this, new PollingFileWatcherEventArgs(
                new FileChange(
                fileInfoState.Path,
                fileInfoState.RelativePath,
                fileInfoState.Size,
                fileInfoState.CreationTimeUtc,
                fileInfoState.LastWriteTimeUtc,
                change)));
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _cancellationTokenSource.Cancel();
                _pollingTask?.Wait();
            }

            base.Dispose(disposing);
        }

        public abstract FileDirectoryInfo? GetDirectoryInfoFromWatchedDirectory();
    }
}
