﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class FileInfoState : ICloneable
    {
        public string Path { get; init; }
        public string RelativePath { get; init; }
        public long Size { get; set; }
        public DateTimeOffset LastWriteTimeUtc { get; set; }
        public DateTimeOffset CreationTimeUtc { get; set; }
        public long Version { get; set; }

        public FileInfoState(FileInfoState other) :
            this(
                other.Path,
                other.RelativePath,
                other.Size,
                other.LastWriteTimeUtc,
                other.CreationTimeUtc,
                other.Version)
        { }

        public FileInfoState(string path, string relativePath, long size, DateTimeOffset creationTimeUtc, DateTimeOffset lastWriteTimeUtc, long version)
        {
            Path = path;
            RelativePath = relativePath;
            Size = size;
            LastWriteTimeUtc = lastWriteTimeUtc;
            CreationTimeUtc = creationTimeUtc;
            Version = version;
        }

        public override string ToString()
        {
            return Path;
        }

        public object Clone()
        {
            return new FileInfoState(this);
        }
    }
}
