﻿using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public interface IPollingFileWatcherStateStore
    {
        bool Add(string key, FileInfoState fileInfoState);
        void Update(string key, FileInfoState fileInfoState);
        bool Remove(string key);
        bool TryGetValue(string key, out FileInfoState? fileInfoState);
        IReadOnlyDictionary<string, FileInfoState> GetState();
    }
}
