﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public interface IPollingFileWatcher : IDisposable
    {
        event PollingFileWatcherEventHandler Changed;

        event ErrorEventHandler? Error;

        bool EnableRaisingEvents { get; set; }

        bool WatchSubfolders { get; set; }

        string[]? FileFilters { get; set; }

        string[]? FolderFilters { get; set; }

        ValueTask CheckForChangesAsync();

        ValueTask<IEnumerable<FileInfo>> GetSnapshotAsync();

        FileDirectoryInfo? GetDirectoryInfoFromWatchedDirectory();

        ValueTask StartAsync();
    }
}