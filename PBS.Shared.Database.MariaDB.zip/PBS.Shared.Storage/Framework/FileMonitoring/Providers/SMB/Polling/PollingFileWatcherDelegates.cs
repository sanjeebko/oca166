﻿using System;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public delegate void FileSystemEntryDelegate(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, long length, DateTimeOffset creationTimeUtc, DateTimeOffset lastWriteTimeUtc);
    public delegate bool FileSystemEntryFindPredicate(ReadOnlySpan<char> directory, ReadOnlySpan<char> fileName, bool isDirectory);
    public delegate void PollingFileWatcherEventHandler(object sender, PollingFileWatcherEventArgs e);
}
