﻿namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public enum PollingFileWatcherType
    {
        Sync
    }
}
