﻿using System.IO;
using System.IO.Enumeration;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public class PollingFileSystemEntryEnumerator : FileSystemEnumerator<string>
    {
        private readonly FileSystemEntryFindPredicate? _shouldIncludePredicate;
        private readonly FileSystemEntryFindPredicate? _shouldRecursePredicate;
        private readonly FileSystemEntryDelegate _fileSystemEntryDelegate;
        private readonly EnumerationOptions? _options;

        public PollingFileSystemEntryEnumerator(
            string directory,
            FileSystemEntryFindPredicate? shouldIncludePredicate,
            FileSystemEntryFindPredicate? shouldRecursePredicate,
            FileSystemEntryDelegate fileSystemEntryDelegate,
            EnumerationOptions? options)
            : base(directory, options)
        {
            _shouldIncludePredicate = shouldIncludePredicate;
            _shouldRecursePredicate = shouldRecursePredicate;
            _fileSystemEntryDelegate = fileSystemEntryDelegate;
            _options = options;
        }

        protected override string TransformEntry(ref FileSystemEntry entry)
        {
            if (!entry.IsDirectory)
                _fileSystemEntryDelegate.Invoke(entry.Directory, entry.FileName, entry.Length, entry.CreationTimeUtc, entry.LastWriteTimeUtc);
            return string.Empty;
        }

        protected override bool ShouldRecurseIntoEntry(ref FileSystemEntry entry)
            => _shouldRecursePredicate?.Invoke(entry.Directory, entry.FileName, entry.IsDirectory) ?? (_options?.RecurseSubdirectories ?? true);

        protected override bool ShouldIncludeEntry(ref FileSystemEntry entry)
            => _shouldIncludePredicate?.Invoke(entry.Directory, entry.FileName, entry.IsDirectory) ?? true;
    }
}