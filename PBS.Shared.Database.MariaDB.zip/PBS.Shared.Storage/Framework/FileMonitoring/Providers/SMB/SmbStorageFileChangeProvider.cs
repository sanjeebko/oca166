﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Validation;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reactive.Disposables;
using System.Reactive.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public partial class SmbStorageFileChangeProvider : StorageFileChangeProvider
    {
        private readonly IPollingFileWatcherFactory _watcherFactory;
        private readonly IStorageObservableSchedulerProvider _schedulerProvider;
        private readonly SmbStorageAdapter _smbStorageAdapter;
        private IPollingFileWatcher? _watcher;
        private CompositeDisposable? _subscription;
        private string? _mountedPath;

        public SmbStorageFileChangeProvider(
            ILogger<SmbStorageFileChangeProvider> logger,
            IPollingFileWatcherFactory watcherFactory,
            IStorageObservableSchedulerProvider schedulerProvider,
            SmbStorageAdapter smbStorageAdapter)
            : base(logger)
        {
            _watcherFactory = watcherFactory;
            _schedulerProvider = schedulerProvider;
            _smbStorageAdapter = smbStorageAdapter;
        }

        public override async ValueTask StartAsync(IStorageCredential credential, CancellationToken cancellationToken)
        {
            if (_watcher != null)
                throw new InvalidOperationException("Provider already started");

            await _smbStorageAdapter.ConnectAsync(credential);

            Requires.NotNull(_smbStorageAdapter.MountedFilePath, nameof(_smbStorageAdapter.MountedFilePath));

            // mounting library does not return full absolute path, where DirectoryInfo does
            _mountedPath = new DirectoryInfo(_smbStorageAdapter.MountedFilePath).FullName;

            Logger.LogDebug("Using paths, Mounted path: {MountPath}, Target path:{TargetPath}", _mountedPath, _smbStorageAdapter.CredentialsObject?.MountPath);

            _watcher = _watcherFactory.Create(_mountedPath, GetIntervalOrDefault(credential), GetWatcherTypeOrDefault(credential));
            _watcher.WatchSubfolders = GetWatchSubfoldersOrDefault(credential);
            _watcher.FileFilters = GetFileFiltersOrNull(credential);
            _watcher.FolderFilters = GetNormalizedFolderFiltersOrNull(credential);

            _subscription = new CompositeDisposable();
            _subscription.Add(Observable
                .FromEventPattern<PollingFileWatcherEventHandler, PollingFileWatcherEventArgs>(action => _watcher.Changed += action, action => _watcher.Changed -= action)
                .SubscribeOn(_schedulerProvider.Scheduler)
                .Select(pattern => pattern.EventArgs)
                .Subscribe(args =>
                {
                    foreach (FileChange change in args.Changes)
                    {
                        FileChangesSubject.OnNext(new StorageFileChange
                        {
                            Storage = StorageType.SMB,
                            ChangeType = GetChangeType(change),
                            FileMetadata = CreateFileChangeMetadata(change)
                        });
                    }
                }));

            _subscription.Add(Observable
                .FromEventPattern<ErrorEventHandler, ErrorEventArgs>(action => _watcher.Error += action, action => _watcher.Error -= action)
                .SubscribeOn(_schedulerProvider.Scheduler)
                .Select(pattern => pattern.EventArgs)
                .Subscribe(args =>
                {
                    Exception exception = args.GetException();
                    ErrorsSubject.OnNext(new StorageFileChangeProviderException(exception.Message, exception));
                }));

            await _watcher.StartAsync();

            Status = StorageFileChangeProviderStatus.Available;

            Logger.LogDebug("Polling watcher started");
        }

        public override async ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default)
        {
            ValidateStatus();

            // using watcher to retrieve list of files rather then smb adapter because of watch subfolders option, filtering etc..
            return _watcher is null ? Enumerable.Empty<IStorageFileChangeMetadata>() : (await _watcher.GetSnapshotAsync()).Select(CreateFileChangeMetadata);
        }

        public override ValueTask<bool> CheckConnectionAsync() => ValueTask.FromResult(_watcher?.GetDirectoryInfoFromWatchedDirectory() != null);

        protected override void OnSubscriberConnected(int subscriberCount)
        {
            if (_watcher is null)
                return;

            if (subscriberCount > 0 && !_watcher.EnableRaisingEvents)
            {
                Logger.LogDebug("Subscriber connected, enabling watcher raising events");
                _watcher.EnableRaisingEvents = true;
            }
        }

        protected override void OnSubscriberDisconnected(int subscriberCount)
        {
            if (_watcher is null || subscriberCount > 0)
                return;
            Logger.LogDebug("All subscribers are disconnected, disabling watcher raising events");
            _watcher.EnableRaisingEvents = false;
        }

        private static IStorageFileChangeMetadata CreateFileChangeMetadata(FileChange change) =>
            CreateFileChangeMetadata(change.Path, change.RelativePath, change.CreationTimeUtc, change.LastWriteTimeUtc, change.Size);

        private static IStorageFileChangeMetadata CreateFileChangeMetadata(FileInfo fileInfo) =>
            CreateFileChangeMetadata(fileInfo.Path, fileInfo.RelativePath, fileInfo.CreationTimeUtc, fileInfo.LastWriteTimeUtc, fileInfo.Length);

        private static IStorageFileChangeMetadata CreateFileChangeMetadata(
            string path,
            string relativePath,
            DateTimeOffset creationTimeUtc,
            DateTimeOffset lastWriteTimeUtc,
            long size) =>
            new StorageFileChangeMetadata
            {
                StorageType = StorageType.SMB,
                Path = path,
                RelativePath = relativePath,
                CreationTimeUtc = creationTimeUtc.UtcDateTime,
                LastWriteTimeUtc = lastWriteTimeUtc.UtcDateTime,
                Size = size,
                Exists = true
            };

        private static StorageFileChangeType? GetChangeType(FileChange change) =>
            change.ChangeType switch
            {
                WatcherChangeTypes.Created => StorageFileChangeType.Created,
                WatcherChangeTypes.Deleted => StorageFileChangeType.Deleted,
                WatcherChangeTypes.Changed => StorageFileChangeType.Modified,
                _ => null
            };


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                _subscription?.Dispose();
                _watcher?.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
