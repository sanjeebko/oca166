﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.FileMonitoring.SMB
{
    public partial class SmbStorageFileChangeProvider
    {
        private static readonly TimeSpan DefaultInterval = TimeSpan.FromMinutes(2);
        private const PollingFileWatcherType DefaultWatcherType = PollingFileWatcherType.Sync;

        public const string IntervalSecondsAttributeName = "Interval";
        public const string PollingFileWatcherTypeAttributeName = "WatcherType";
        public const string WatchSubfoldersAttributeName = "WatchSubfolders";
        public const string FileFiltersAttributeName = "FileFilters";
        public const string FolderFiltersAttributeName = "FolderFilters";

        public static PollingFileWatcherType GetWatcherTypeOrDefault(IAttributesProvider attributesProvider)
            => attributesProvider.Attributes.TryGetValue(PollingFileWatcherTypeAttributeName, out object? value) && Enum.TryParse(value?.ToString(), out PollingFileWatcherType watcherType) ? watcherType : DefaultWatcherType;

        public static bool GetWatchSubfoldersOrDefault(IAttributesProvider attributesProvider)
            => !attributesProvider.Attributes.TryGetValue(WatchSubfoldersAttributeName, out object? value) || !bool.TryParse(value?.ToString(), out bool valueBool) || valueBool;

        public static string[]? GetFolderFiltersOrNull(IAttributesProvider attributesProvider)
            => attributesProvider.Attributes.TryGetValue(FolderFiltersAttributeName, out object? value) && value is string[] array ? array : null;

        public static string[]? GetNormalizedFolderFiltersOrNull(IAttributesProvider attributesProvider)
        {
            string[]? filters = attributesProvider.Attributes.TryGetValue(FolderFiltersAttributeName, out object? value) && value is string[] array ? array : null;
            if (filters == null || filters.Length <= 0)
                return filters;
            
            List<string> normalizedFilters = new();
            foreach (string filter in filters)
            {
                string folderFilter = filter.Replace(StoragePath.WindowsPathSeparator, StoragePath.UniversalPathSeparator);
                string normalizedFolderFilter = folderFilter.StartsWith(StoragePath.UniversalPathSeparator) ? folderFilter.Substring(1) : folderFilter;
                normalizedFilters.Add(normalizedFolderFilter);
            }

            return normalizedFilters.ToArray();   
        }

        public static string[]? GetFileFiltersOrNull(IAttributesProvider attributesProvider)
            => attributesProvider.Attributes.TryGetValue(FileFiltersAttributeName, out object? value) && value is string[] array ? array : null;

        public static TimeSpan GetIntervalOrDefault(IAttributesProvider attributesProvider)
            => attributesProvider.Attributes.TryGetValue(IntervalSecondsAttributeName, out object? intervalSeconds) && int.TryParse(intervalSeconds?.ToString(), out int seconds) ? TimeSpan.FromSeconds(seconds) : DefaultInterval;
    }
}