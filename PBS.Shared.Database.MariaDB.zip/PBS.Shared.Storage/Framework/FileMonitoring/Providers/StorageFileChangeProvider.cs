﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Dependency;
using System;
using System.Collections.Generic;
using System.Reactive.Linq;
using System.Reactive.Subjects;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage.FileMonitoring
{
    public abstract class StorageFileChangeProvider : Disposable, IStorageFileChangeProvider
    {
        protected Subject<IStorageFileChange> FileChangesSubject { get; } = new Subject<IStorageFileChange>();
        protected Subject<Exception> ErrorsSubject { get; } = new Subject<Exception>();
        protected event EventHandler Unsubscribe = delegate { };
        protected int SubscriptionCount;
        protected ILogger Logger { get; }

        protected StorageFileChangeProvider(ILogger logger)
        {
            Logger = logger;
        }

        public abstract ValueTask StartAsync(IStorageCredential credential, CancellationToken cancellationToken);
        public abstract ValueTask<IEnumerable<IStorageFileChangeMetadata>> GetAllAsync(IStorageFileFilter? filter = default);
        public abstract ValueTask<bool> CheckConnectionAsync();

        public StorageFileChangeProviderStatus Status { get; protected set; } = StorageFileChangeProviderStatus.Unavailable;
        public IObservable<IStorageFileChange> FileChanges => CreateFileChangesObservable();
        public IObservable<Exception> Errors => CreateErrorsObservable();

        protected virtual void PublishProviderError(string message, Exception? exception = null, IStorageFileChangeMetadata? fileMetadata = null, StorageFileChangeType? changeType = null)
            => ErrorsSubject.OnNext(new StorageFileChangeProviderException(message, fileMetadata, changeType, exception));

        protected virtual void ValidateStatus()
        {
            if (Status == StorageFileChangeProviderStatus.Unavailable)
                throw new InvalidOperationException("Provider is not available");
        }

        protected virtual IObservable<IStorageFileChange> CreateFileChangesObservable() =>
            Observable.Create<IStorageFileChange>(subscriber =>
                {
                    IDisposable subscription = FileChangesSubject.Subscribe(subscriber);
                    OnSubscriberConnected(Interlocked.Increment(ref SubscriptionCount));

                    return () =>
                    {
                        subscription.Dispose();
                        OnSubscriberDisconnected(Interlocked.Decrement(ref SubscriptionCount));
                    };
                })
                .Publish()
                .RefCount()
                .TakeUntil(Observable.FromEventPattern(h => Unsubscribe += h, h => Unsubscribe -= h));

        protected virtual IObservable<Exception> CreateErrorsObservable() =>
            Observable.Create<Exception>(subscriber =>
                {
                    IDisposable subscription = ErrorsSubject.Subscribe(subscriber);
                    return () => { subscription.Dispose(); };
                })
                .Publish()
                .RefCount()
                .TakeUntil(Observable.FromEventPattern(h => Unsubscribe += h, h => Unsubscribe -= h));

        protected virtual void OnSubscriberConnected(int subscriberCount) { }
        protected virtual void OnSubscriberDisconnected(int subscriberCount) { }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Unsubscribe(this, EventArgs.Empty);

                FileChangesSubject.OnCompleted();
                ErrorsSubject.OnCompleted();

                FileChangesSubject.Dispose();
                ErrorsSubject.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}
