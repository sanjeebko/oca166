﻿using System.Reactive.Concurrency;

namespace PBS.Shared.Storage
{
    public class StorageObservableSchedulerProvider : IStorageObservableSchedulerProvider
    {
        public IScheduler Scheduler => TaskPoolScheduler.Default;
    }
}