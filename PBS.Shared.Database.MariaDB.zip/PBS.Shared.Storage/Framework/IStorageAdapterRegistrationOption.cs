﻿namespace PBS.Shared.Storage
{
    public interface IStorageAdapterRegistrationOption
    {
        /// <exception cref="T:System.InvalidOperationException">When adapter is already added to mapping for <see cref="StorageType"/></exception>
        void RegisterAdapter<T>(StorageType storageType) where T : IStorageAdapter;
    }
}