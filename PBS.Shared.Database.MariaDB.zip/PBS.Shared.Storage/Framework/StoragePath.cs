﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.Storage
{
    public static class StoragePath
    {
        public const char UniversalPathSeparator = '/';
        public const char WindowsDrivePathSeparator = ':';
        public const char WindowsPathSeparator = '\\';

        private static readonly string[] EmptyArray = Enumerable.Empty<string>().ToArray();

        /// <summary>
        /// Create a relative path from one path to another. Paths will be resolved before calculating the difference.
        /// Does not depending on platform specific path separators.
        /// </summary>
        /// <param name="root">The source path the output should be relative to. This path is always considered to be a directory.</param>
        /// <param name="path">The destination path.</param>
        /// <param name="pathJoinCharacter">Normalize separator that will be used to make final relative path</param>
        /// <param name="comparer">String comparer</param>
        /// <returns>The relative path or <paramref name="path"/> if the paths don't share the same root.</returns>
        public static string GetNormalizedRelativePath(string? root, string path, char pathJoinCharacter = UniversalPathSeparator, IEqualityComparer<string>? comparer = null)
        {
            if (string.IsNullOrEmpty(path)) return path;

            string splitCharLookupPath = string.IsNullOrWhiteSpace(root) ? path : root;
            char splitChar = splitCharLookupPath.IndexOfAny(new[] { WindowsDrivePathSeparator, WindowsPathSeparator }) >= 0 ? WindowsPathSeparator : UniversalPathSeparator;

            // we can handle case when root is empty but file path is based on windows mount / drive letter, so we can use path to retrieve root.
            // for unc we would have to guest what is root folder, which could be false positive.
            if (splitCharLookupPath.Contains(WindowsDrivePathSeparator) && string.IsNullOrWhiteSpace(root))
            {
                root = path.Substring(0, path.IndexOf(WindowsPathSeparator));
            }

            var rootParts = root?.Split(splitChar, StringSplitOptions.RemoveEmptyEntries) ?? EmptyArray;
            var pathParts = path.Split(splitChar, StringSplitOptions.RemoveEmptyEntries);

            // case for if the path don't share the same root, no point in normalizing
            if (rootParts.Any() && rootParts.Any(rootPart => !pathParts.Contains(rootPart, comparer ?? StringComparer.Ordinal)))
                return path;

            return string.Join(pathJoinCharacter, pathParts.Except(rootParts));
        }

        /// <summary>
        /// Checking if normalized relative path is subdirectory
        /// </summary>
        public static bool IsNormalizedPathSubDirectory(string normalizedRelativePath) => normalizedRelativePath.Contains(UniversalPathSeparator);

        /// <summary>
        /// Get's directory name
        /// </summary>
        public static string GetDirectoryName(string normalizedRelativePath)
        {
            string[] segments = normalizedRelativePath.Split(UniversalPathSeparator, StringSplitOptions.RemoveEmptyEntries);
            string fileName = GetFileName(segments);
            return string.Join(UniversalPathSeparator, string.IsNullOrEmpty(fileName) ? segments : segments.Except(new[] { fileName }));
        }

        /// <summary>
        /// Get's file name
        /// </summary>
        public static string GetFileName(string normalizedRelativePath) => GetFileName(normalizedRelativePath.Split(UniversalPathSeparator, StringSplitOptions.RemoveEmptyEntries));

        private static string GetFileName(IEnumerable<string> segments)
        {
            string fileName = segments.LastOrDefault() ?? string.Empty;
            return fileName.Contains('.') ? fileName : string.Empty;
        }
    }
}
