﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare;
using PBS.Shared.RemoteShare.Mounters;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class SmbStorageAdapter : StorageAdapter
    {
        public const string UsernameAttributeName = "Username";
        public const string PasswordAttributeName = "Password";
        public const string TargetPathAttributeName = "TargetPath";
        public const string UserDomainAttributeName = "Domain";

        public static readonly string[] AttributesToValidate =
        {
            UsernameAttributeName,
            PasswordAttributeName,
            TargetPathAttributeName,
        };

        private static StorageFileHashProviderType[] SupportedHashProviderTypes => new[] { StorageFileHashProviderType.MD5_BASE64, StorageFileHashProviderType.MERKLE_TREE };

        public string? MountedFilePath { get; set; }

        public FileShareCredentials? CredentialsObject { get; set; }

        private IStorageCredential? Credential { get; set; }
        private readonly IRemoteShareMounter _remoteShareMounter;
        private readonly IStorageFileHandler _smbFileHandler;
        private readonly IStorageFileHashProviderFactory _hashProviderFactory;

        public SmbStorageAdapter(
            ILogger<SmbStorageAdapter> logger,
            IRemoteShareMounter remoteShareMounter,
            IStorageFileHandler fileHandler,
            IStorageFileHashProviderFactory hashProviderFactory) : base(logger)
        {
            _remoteShareMounter = remoteShareMounter;
            _smbFileHandler = fileHandler;
            _hashProviderFactory = hashProviderFactory;
        }

        public override ValueTask ConnectAsync(IStorageCredential credential)
        {
            Logger.LogDebug("[{SMBCredentialName}] Connecting", credential.Name);
            ValidateCredential(credential);
            Credential = credential;
            CredentialsObject = ResolveCredentials(Credential);

            MountedFilePath = _remoteShareMounter.MountDrive(CredentialsObject, "SmbAdapter");

            return default;
        }

        public override async ValueTask<bool> DeleteAsync(IStorageFileMetadata metadata)
        {
            Logger.LogDebug("[{SMBCredentialName}] Deleting file {Path}", Credential?.Name, metadata.Path);

            string path = RetrieveMetaDataPath(metadata);

            await _smbFileHandler.DeleteFile(path);

            var fileMetadata = await GetAsync(path);

            return !fileMetadata.Exists;
        }

        public override ValueTask<IStorageFileMetadata> GetAsync(string path)
        {
            Logger.LogDebug("[{SMBCredentialName}] Getting file {file}", Credential?.Name, path);

            if (MountedFilePath == null)
                throw new ArgumentException("File Path is not mounted");

            string fullPath = Path.Combine(MountedFilePath, path);

            return new ValueTask<IStorageFileMetadata>(_smbFileHandler.GetFile(fullPath));
        }

        public override async ValueTask<IStorageFileHash> GetHashAsync(string? path, StorageFileHashProviderType? hashProviderType = default)
        {
            Logger.LogDebug("[{SMBCredentialName}] Getting hash for file {SourceFile}", Credential?.Name, path);

            if (string.IsNullOrWhiteSpace(path))
                return StorageFileHash.Empty;

            var orderedHashProviderTypes = GetSupportedHashProviders().OrderByDescending(type => (int)type).ToList();

            if (!orderedHashProviderTypes.Any())
                return StorageFileHash.Empty;

            hashProviderType ??= orderedHashProviderTypes.First();

            ValidateHashProviderType(hashProviderType);

            using (IStorageFileSource source = await GetStreamAsync(await GetAsync(path)))
            {
                if (source.Stream == null)
                    return StorageFileHash.Empty;

                Stream? stream = await source.Stream.GetValueAsync();

                if (stream == null)
                {
                    Logger.LogWarning("[{SMBCredentialName}] Failed to get stream for file {SourceFile}", Credential?.Name, path);
                    return StorageFileHash.Empty;
                }

                Stopwatch durationStopwatch = Stopwatch.StartNew();

                var hashString = _hashProviderFactory.GetProvider(hashProviderType.Value).ComputeHashString(stream);

                return new StorageFileHash
                {
                    Hash = hashString,
                    Duration = durationStopwatch.Elapsed,
                    HashProvider = hashProviderType
                };
            }
        }

        public override ValueTask<IStorageFileSource> GetStreamAsync(IStorageFileMetadata metadata)
        {
            Logger.LogDebug("[{SMBCredentialName}] Getting stream for file {Path}", Credential?.Name, metadata.Path);

            if (metadata.Path == null)
                throw new ArgumentNullException(nameof(metadata), "Can't find stream of null file path.");

            return new ValueTask<IStorageFileSource>(new StorageFileSource
            {
                Metadata = new StorageFileMetadata
                {
                    Path = metadata.Path,
                    StorageType = StorageType.SMB,
                    Size = metadata.Size
                },
                Stream = new StorageLazyFileStream(() => _smbFileHandler.GetStream(metadata.Path))
            });
        }

        public override ValueTask<IEnumerable<StorageDirectory>> GetDirectoryTreeAsync()
        {
            Logger.LogDebug("[{SMBCredentialName}] Getting all directories", Credential?.Name);

            if (MountedFilePath == null)
                throw new ArgumentException("Directory path is not mounted.");
            DirectoryInfo directory = new(MountedFilePath);

            return ValueTask.FromResult(_smbFileHandler.GetDirectoryTree(directory));
        }

        public override ValueTask<IEnumerable<IStorageFileMetadata>> GetAllAsync(IStorageFileFilter? filter = null)
        {
            Logger.LogDebug("[{SMBCredentialName}] Getting all files", Credential?.Name);

            if (MountedFilePath == null)
                throw new ArgumentException("File path is not mounted.");

            return _smbFileHandler.GetAllFiles(MountedFilePath);
        }

        public override async ValueTask<bool> CopyAsync(IStorageFileSource source, IStorageFileMetadata destination, IReadOnlyDictionary<string, object?>? metadata = default)
        {
            Logger.LogDebug("[{SMBCredentialName}] Copying source {SourceFile} from {SourceStorage} to {DestinationFile}", Credential?.Name, source.Metadata?.Path, source.Metadata?.StorageType, destination.Path);

            if (source.Metadata == null)
                return false;

            if (source.DownloadProvider != null)
            {
                await source.DownloadProvider.Invoke(source.Metadata, destination);
                return true;
            }

            if (destination.Path == null)
                throw new ArgumentNullException("destination.Path", "destination.Path is not defined");

            if (source.Stream == null)
                throw new ArgumentNullException("source.Stream", "source.Stream is not defined");

            var sourceStream = await source.Stream.GetValueAsync();
            if (sourceStream == null)
                throw new ArgumentNullException("source.Stream", "source.Stream is not defined");

            return await _smbFileHandler.CopyFile(sourceStream, destination.Path);
        }

        public override IEnumerable<StorageFileHashProviderType> GetSupportedHashProviders()
        {
            return SupportedHashProviderTypes;
        }

        protected override void Cleanup()
        {
            Logger.LogDebug("[{SMBCredentialName}] Disposing", Credential?.Name);
            _remoteShareMounter.Dispose();
        }

        protected void ValidateCredential(IStorageCredential? credential)
        {
            Logger.LogDebug("[{SMBCredentialName}] Validating credentials", credential?.Name);

            if (credential == null)
                throw new ArgumentNullException(nameof(credential));

            ValidateAttributes(credential, AttributesToValidate);
        }

        private static void ValidateHashProviderType(StorageFileHashProviderType? hashProviderType)
        {
            if (hashProviderType is not null && !SupportedHashProviderTypes.Contains(hashProviderType.Value))
                throw new StorageHashProviderTypeValidationException($"Provided hash provider type '{hashProviderType}' is not supported");
        }

        private static FileShareCredentials ResolveCredentials(IStorageCredential credential)
        {
            return new FileShareCredentials
            {
                UserName = ResolveAttribute(credential, UsernameAttributeName, ""),
                Password = ResolveAttribute(credential, PasswordAttributeName, ""),
                UserDomain = ResolveAttribute(credential, UserDomainAttributeName, "") ?? "",
                MountPath = ResolveAttribute(credential, TargetPathAttributeName, "") ?? ""
            };
        }

        private static string RetrieveMetaDataPath(IStorageFileMetadata metadata)
        {
            if (metadata.Path == null)
                throw new ArgumentException("Delete path cannot be null");

            return metadata.Path;
        }
    }
}
