﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class SmbFileHandler : IStorageFileHandler
    {
        private readonly CancellationTokenSource _tokenSource = new CancellationTokenSource();

        public ValueTask DeleteFile(string fileName)
        {
            File.Delete(fileName);
            return default;
        }

        public IStorageFileMetadata GetFile(string fileName) => BuildFileMetadataFromFileName(fileName);

        public Stream GetStream(string path) => new FileStream(path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

        public IEnumerable<StorageDirectory> GetDirectoryTree(DirectoryInfo directory)
        {
            List<StorageDirectory> directoryTree = new();

            foreach (DirectoryInfo subDirectory in directory.EnumerateDirectories("*", new EnumerationOptions { IgnoreInaccessible = true }))
            {
                directoryTree.Add(new StorageDirectory
                {
                    Name = subDirectory.Name,
                    Children = GetDirectoryTree(subDirectory).ToList(),
                });
            }
            return directoryTree;
        }

        public ValueTask<IEnumerable<IStorageFileMetadata>> GetAllFiles(string directoryPath)
        {
            List<IStorageFileMetadata> metadatas = new List<IStorageFileMetadata>();

            DirectoryInfo directory = new DirectoryInfo(directoryPath);

            using var enumerator = directory.EnumerateFiles().GetEnumerator();
            while (enumerator.MoveNext())
            {
                if (_tokenSource.IsCancellationRequested)
                    break;
                metadatas.Add(BuildFileMetaDataFromFileInfo(enumerator.Current));
            }
            return ValueTask.FromResult<IEnumerable<IStorageFileMetadata>>(metadatas);
        }

        public async ValueTask<bool> CopyFile(Stream sourceStream, string destinationPath)
        {
            ValidateStream(sourceStream);

            var directory = Path.GetDirectoryName(destinationPath);
            if (!string.IsNullOrEmpty(directory))
                Directory.CreateDirectory(directory);

            await using (var destinationStream = new FileStream(destinationPath, FileMode.OpenOrCreate, FileAccess.Write, FileShare.ReadWrite))
            {
                StreamHelper.ResetStreamPosition(sourceStream);

                destinationStream.SetLength(sourceStream.Length);

                await sourceStream.CopyToAsync(destinationStream, _tokenSource.Token);
                await destinationStream.FlushAsync(_tokenSource.Token);
            }

            return GetFile(destinationPath).Exists;
        }

        private static IStorageFileMetadata BuildFileMetaDataFromFileInfo(FileInfo info)
        {
            return new StorageFileMetadata
            {
                Path = info.FullName,
                Exists = info.Exists,
                Size = info.Exists ? info.Length : -1,
                StorageType = StorageType.SMB,
            };
        }

        private static IStorageFileMetadata BuildFileMetadataFromFileName(string path)
        {
            FileInfo info = new FileInfo(path);
            return BuildFileMetaDataFromFileInfo(info);
        }

        private static void ValidateStream(Stream stream)
        {
            if (stream == null)
                throw new ArgumentNullException(nameof(stream));
        }

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    _tokenSource.Cancel();
                    _tokenSource.Dispose();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

    }
}
