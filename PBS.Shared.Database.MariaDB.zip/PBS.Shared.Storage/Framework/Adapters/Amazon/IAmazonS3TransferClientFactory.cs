﻿using Amazon.S3;

namespace PBS.Shared.Storage
{
    public interface IAmazonS3TransferClientFactory
    {
        IAmazonS3TransferClient CreateTransferClient(IAmazonS3 client);
    }
}