﻿using System.Threading;
using System.Threading.Tasks;
using Amazon.S3.Transfer;

namespace PBS.Shared.Storage
{
    public interface IAmazonS3TransferClient
    {
        Task UploadAsync(TransferUtilityUploadRequest request, CancellationToken cancellationToken = default);
        Task DownloadAsync(TransferUtilityDownloadRequest request, CancellationToken cancellationToken = default);
    }
}