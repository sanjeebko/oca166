﻿using Amazon.S3;

namespace PBS.Shared.Storage
{
    public class AmazonS3TransferClientFactory : IAmazonS3TransferClientFactory
    {
        public IAmazonS3TransferClient CreateTransferClient(IAmazonS3 client)
        {
            return new AmazonS3TransferClient(client);
        }
    }
}