﻿using Amazon;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Microsoft.Extensions.Logging;
using PBS.Shared.Storage.Framework.Adapters.Amazon;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class AmazonS3StorageAdapter : StorageAdapter
    {
        public const string AccessKeyAttributeName = "AccessKey";
        public const string SecretAccessKeyAttributeName = "SecretKey";
        public const string RegionAttributeName = "Region";
        public const string BucketAttributeName = "Bucket";
        public const string InvalidAccessKeyErrorCode = "InvalidAccessKeyId";
        public const string InvalidSecretAccessKeyErrorCode = "SignatureDoesNotMatch";
        public const string InvalidBucketNameErrorCode = "InvalidBucketName";

        private static StorageFileHashProviderType[] SupportedHashProviderTypes => new[] { StorageFileHashProviderType.MD5_BASE64 };

        private IAmazonS3 Client
        {
            get => _client ?? throw new InvalidOperationException("Client not created");
            set => _client = value;
        }

        private string? BucketName { get; set; }
        private string? AccessKey { get; set; }
        private string? SecretAccessKey { get; set; }
        private RegionEndpoint? RegionEndPoint { get; set; }
        private IStorageCredential? Credential { get; set; }

        private readonly IAmazonS3ClientFactory _clientFactory;
        private readonly IAmazonS3TransferClientFactory _transferClientFactory;
        private readonly IStorageFileHashProviderFactory _hashProviderFactory;
        private readonly CancellationTokenSource _cancellationTokenSource = new CancellationTokenSource();
        private IAmazonS3? _client;

        public AmazonS3StorageAdapter(
            ILogger<AmazonS3StorageAdapter> logger,
            IAmazonS3ClientFactory clientFactory,
            IAmazonS3TransferClientFactory transferClientFactory,
            IStorageFileHashProviderFactory hashProviderFactory) : base(logger)
        {
            _clientFactory = clientFactory;
            _transferClientFactory = transferClientFactory;
            _hashProviderFactory = hashProviderFactory;
        }

        #region StorageAdapterImp

        public override async ValueTask ConnectAsync(IStorageCredential credential)
        {
            Logger.LogDebug("[{S3CredentialName}] Connecting", credential.Name);

            ResolveCredential(() => credential);

            Client = await _clientFactory.CreateClient(new AmazonS3Credential
            {
                AccessKey = AccessKey,
                SecretAccessKey = SecretAccessKey,
                Config = new AmazonS3Config
                {
                    RegionEndpoint = RegionEndPoint,
                }
            }) ?? throw new InvalidOperationException("Failed to create client");

            await VerifyConnectionAsync();

            Credential = credential;
        }

        public override async ValueTask<bool> DeleteAsync(IStorageFileMetadata metadata)
        {
            Logger.LogDebug("[{S3CredentialName}] Deleting file {Path}", Credential?.Name, metadata.Path);

            ValidateMetadataPath(() => metadata);

            try
            {
                await Client.DeleteObjectAsync(new DeleteObjectRequest { BucketName = BucketName, Key = metadata.Path }, _cancellationTokenSource.Token);

                var fileMetadata = await GetAsync(metadata.Path!);
                return !fileMetadata.Exists;
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
        }

        public override async ValueTask<IStorageFileMetadata> GetAsync(string path)
        {
            Logger.LogDebug("[{S3CredentialName}] Getting file {file}", Credential?.Name, path);

            (GetObjectMetadataResponse? response, HttpStatusCode statusCode) = await GetObjectMetadata(path);

            Dictionary<string, object?> metadata = AmazonS3Utility.CloneMetadata(response?.Metadata);

            metadata.TryAdd(BucketAttributeName, BucketName);

            return new StorageFileMetadata
            {
                Path = path,
                Exists = statusCode == HttpStatusCode.OK,
                StorageType = StorageType.AmazonS3,
                Size = response?.ContentLength ?? -1,
                Attributes = metadata
            };
        }

        public override ValueTask<IStorageFileSource> GetStreamAsync(IStorageFileMetadata metadata)
        {
            Logger.LogDebug("[{S3CredentialName}] Getting stream for file {Path}", Credential?.Name, metadata.Path);

            if (string.IsNullOrWhiteSpace(metadata.Path))
                throw new ArgumentNullException("metadata.Path", "metadata.Path is not defined");
            if (!metadata.Exists)
                throw new FileNotFoundException($"File {metadata.Path} does not exists");

            var request = new GetObjectRequest
            {
                BucketName = BucketName,
                Key = metadata.Path
            };

            return ValueTask.FromResult<IStorageFileSource>(new StorageFileSource
            {
                Stream = new StorageLazyFileStream(async () =>
                {
                    GetObjectResponse response = await GetObjectAsync(request);
                    return response.ResponseStream;
                }),

                Metadata = metadata,
                DownloadProvider = DownloadProvider
            });
        }

        public override async ValueTask<IStorageFileHash> GetHashAsync(string? path, StorageFileHashProviderType? hashProviderType = default)
        {
            Logger.LogDebug("[{S3CredentialName}] Getting hash for file {file}", Credential?.Name, path);

            if (string.IsNullOrWhiteSpace(path))
                return StorageFileHash.Empty;

            IStorageFileMetadata fileMetadata = await GetAsync(path);

            fileMetadata.Attributes.TryGetValue(MetadataUtility.BuildPbsMetadataKey(MetadataKeys.HashCodeMetadataKey), out object? hash);

            ValidateHashProviderType(hashProviderType);
            ValidateHashProviderTypeFromFileMetadata(fileMetadata, out StorageFileHashProviderType? hashProviderFromMetadata);
            ValidateHashProviderTypeMismatch(hashProviderFromMetadata, hashProviderType);

            return new StorageFileHash
            {
                Hash = hash?.ToString() ?? string.Empty,
                HashProvider = hashProviderFromMetadata ?? hashProviderType
            };
        }

        public override async ValueTask<IEnumerable<StorageDirectory>> GetDirectoryTreeAsync()
        {
            Logger.LogDebug("[{S3CredentialName}] Getting all directories", Credential?.Name);

            const char AwsDirectorySeparator = '/';
            var request = new ListObjectsV2Request { BucketName = BucketName };
            var folderKeys = new List<string>();
            try
            {
                ListObjectsV2Response listResponse;
                do
                {
                    listResponse = await Client.ListObjectsV2Async(request, _cancellationTokenSource.Token);
                    IEnumerable<S3Object> folders = listResponse.S3Objects.Where(x => x.Key.EndsWith(AwsDirectorySeparator) && x.Size == 0);
                    folderKeys.AddRange(folders.Select(folder => folder.Key));
                    request.ContinuationToken = listResponse.NextContinuationToken;
                } while (listResponse.IsTruncated);
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
            var rootNode = new StorageDirectoryNode();
            foreach (var folder in folderKeys.OrderBy(k => k).ToList())
            {
                rootNode.AddPath(folder, AwsDirectorySeparator);
            }

            return BuildDirectoryTree(new StorageDirectory(), rootNode).Children;
        }

        private static StorageDirectory BuildDirectoryTree(StorageDirectory root, StorageDirectoryNode node)
        {
            foreach (StorageDirectoryNode childNode in node.Children.Values)
            {
                var storageDirectory = new StorageDirectory { Name = childNode.Name };
                if (childNode.Children.Any())
                {
                    BuildDirectoryTree(storageDirectory, childNode);
                }
                root.Children.Add(storageDirectory);
            }
            return root;
        }
        
        public override async ValueTask<IEnumerable<IStorageFileMetadata>> GetAllAsync(IStorageFileFilter? filter = default)
        {
            Logger.LogDebug("[{S3CredentialName}] Getting all files", Credential?.Name);

            List<IStorageFileMetadata> files = new List<IStorageFileMetadata>();

            var request = new ListObjectsV2Request { BucketName = BucketName, Prefix = filter?.Filter };

            try
            {
                ListObjectsV2Response listResponse;
                do
                {
                    listResponse = await Client.ListObjectsV2Async(request, _cancellationTokenSource.Token);
                    foreach (S3Object obj in listResponse.S3Objects)
                    {
                        if (AmazonS3Utility.IsObjectFile(obj)) // ignore folder keys
                        {
                            var metadata = new StorageFileMetadata
                            {
                                Path = obj.Key,
                                Exists = true,
                                StorageType = StorageType.AmazonS3,
                                Attributes = new Dictionary<string, object?>()
                                {
                                    {nameof(obj.Size), obj.Size },
                                    {nameof(obj.LastModified), obj.LastModified }
                                }
                            };

                            files.Add(metadata);
                        }
                        else
                        {
                            Logger.LogTrace("Object is not file {Key}", obj.Key);
                        }
                    }

                    request.ContinuationToken = listResponse.NextContinuationToken;
                } while (listResponse.IsTruncated);
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
            return files;
        }

        public override async ValueTask<bool> CopyAsync(IStorageFileSource source, IStorageFileMetadata destination, IReadOnlyDictionary<string, object?>? metadata = default)
        {
            Logger.LogDebug("[{S3CredentialName}] Copying source {SourceFile} from {SourceStorage} to {DestinationFile}", Credential?.Name, source.Metadata?.Path, source.Metadata?.StorageType, destination.Path);

            ValidateCopyAsync(source, destination);

            if (source.Metadata!.StorageType == StorageType.AmazonS3)
            {
                S3MetadataDirective directive = metadata.IsNullOrEmpty() ? S3MetadataDirective.COPY : S3MetadataDirective.REPLACE;
                return await CopyObjectAsync(source.Metadata, destination, directive, metadata);
            }

            await UploadFileAsync(source, destination, metadata);

            return true;
        }

        public override async ValueTask<bool> PutMetadataAsync(IStorageFileMetadata source, IReadOnlyDictionary<string, object?> metadata)
        {
            Logger.LogDebug("[{S3CredentialName}] Updating file {SourceFile} metadata", Credential?.Name, source.Path);

            if (metadata.IsNullOrEmpty())
                return true;

            ValidatePutMetadataSourceFile(source);

            (GetObjectMetadataResponse? response, HttpStatusCode statusCode) = await GetObjectMetadata(source.Path!);

            if (statusCode != HttpStatusCode.OK)
                throw new InvalidOperationException($"Failed to get file metadata, StatusCode:'{statusCode}'");

            var sourceMetadata = AmazonS3Utility.CloneMetadata(response?.Metadata);

            foreach (var pair in metadata)
            {
                sourceMetadata.AddOrUpdate(MetadataUtility.BuildPbsMetadataKey(pair.Key), _ => pair.Value);
            }

            return await CopyObjectAsync(source, source, S3MetadataDirective.REPLACE, metadata);
        }

        public override IEnumerable<StorageFileHashProviderType> GetSupportedHashProviders()
        {
            return SupportedHashProviderTypes;
        }

        #endregion


        private async ValueTask UploadFileAsync(IStorageFileSource source, IStorageFileMetadata destination, IReadOnlyDictionary<string, object?>? metadata)
        {
            Stream stream = await GetSourceStream(source);

            var uploadRequest = new TransferUtilityUploadRequest
            {
                BucketName = BucketName,
                Key = destination.Path,
                InputStream = stream,
            };

            var hashString = _hashProviderFactory.GetProvider(StorageFileHashProviderType.MD5_BASE64).ComputeHashString(stream);

            metadata ??= new Dictionary<string, object?>();

            var userMetadata = new Dictionary<string, object?>(metadata)
            {
                {MetadataKeys.HashCodeMetadataKey, hashString},
                {MetadataKeys.HashProviderMetadataKey, StorageFileHashProviderType.MD5_BASE64}
            };

            foreach (var pair in AmazonS3Utility.CreateMetadata(userMetadata))
            {
                uploadRequest.Metadata.Add(pair.Key, pair.Value);
            }

            uploadRequest.Headers.ContentMD5 = hashString;

            try
            {
                await _transferClientFactory.CreateTransferClient(Client).UploadAsync(uploadRequest, _cancellationTokenSource.Token);
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
        }

        private async ValueTask<bool> CopyObjectAsync(IStorageFileMetadata source, IStorageFileMetadata destination, S3MetadataDirective directive, IReadOnlyDictionary<string, object?>? metadata)
        {
            ValidateMetadataPath(() => source);

            var copyRequest = new CopyObjectRequest
            {
                SourceBucket = ResolveBucketName(() => source),
                SourceKey = source.Path,
                DestinationBucket = BucketName,
                DestinationKey = destination.Path,
                MetadataDirective = directive
            };

            foreach (var pair in AmazonS3Utility.CreateMetadata(metadata))
            {
                copyRequest.Metadata.Add(pair.Key, pair.Value);
            }

            try
            {
                CopyObjectResponse copyResponse = await Client.CopyObjectAsync(copyRequest, _cancellationTokenSource.Token);
                return copyResponse.HttpStatusCode == HttpStatusCode.OK;
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
        }


        protected override void Cleanup()
        {
            _cancellationTokenSource.Cancel();
            _client?.Dispose();
        }

        private async ValueTask DownloadProvider(IStorageFileMetadata source, IStorageFileMetadata destination)
        {
            await _transferClientFactory.CreateTransferClient(Client).DownloadAsync(new TransferUtilityDownloadRequest
            {
                BucketName = BucketName,
                Key = source.Path,
                FilePath = destination.Path,
            }, _cancellationTokenSource.Token);
        }

        private static async ValueTask<Stream> GetSourceStream(IStorageFileSource source)
        {
            ValidateFileSourceStream(() => source);

            Stream? stream = await source.Stream!.GetValueAsync();

            if (stream == null)
                throw new InvalidOperationException("Failed to get stream");

            return stream!;
        }

        private async ValueTask<GetObjectResponse> GetObjectAsync(GetObjectRequest request)
        {
            try
            {
                return await Client.GetObjectAsync(request, _cancellationTokenSource.Token);
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                throw;
            }
        }

        private static void ValidatePutMetadataSourceFile(IStorageFileMetadata source)
        {
            if (source.StorageType != StorageType.AmazonS3)
                throw new InvalidOperationException("Invalid storage type provided in metadata");
            if (string.IsNullOrEmpty(source.Path))
                throw new ArgumentNullException(nameof(source), $"Invalid {nameof(source.Path)}");
        }

        private async ValueTask<(GetObjectMetadataResponse?, HttpStatusCode)> GetObjectMetadata(string key)
        {
            GetObjectMetadataResponse? metadata = null;
            var statusCode = HttpStatusCode.NotFound;

            try
            {
                metadata = await Client.GetObjectMetadataAsync(new GetObjectMetadataRequest
                {
                    Key = key,
                    BucketName = BucketName,
                }, _cancellationTokenSource.Token);

                statusCode = metadata != null ? HttpStatusCode.OK : HttpStatusCode.NotFound;
            }
            catch (Exception ex)
            {
                HandleS3Exception(ex);
                if (ex is AmazonS3Exception amazonS3Exception)
                    statusCode = amazonS3Exception.StatusCode;
                Logger.LogTrace(ex, "File {Key} on bucket {Bucket} does not exist", key, BucketName);
            }

            return (metadata, statusCode);
        }

        private async ValueTask VerifyConnectionAsync()
        {
            try
            {
                if (!await DoesBucketExistAsync(Client, BucketName!, _cancellationTokenSource.Token))
                {
                    throw new StorageConnectionException($"Bucket with name {BucketName} is not available");
                }
            }
            catch (Exception e)
            {
                HandleS3Exception(e);
                if (e is AmazonS3Exception { StatusCode: HttpStatusCode.BadRequest, ErrorCode: InvalidBucketNameErrorCode })
                    throw new StorageConnectionException($"Bucket with name {BucketName} is not available", e);
                throw;
            }
        }

        private static void HandleS3Exception(Exception exception)
        {
            switch (exception)
            {
                case AmazonS3Exception { StatusCode: HttpStatusCode.Forbidden, ErrorCode: InvalidAccessKeyErrorCode }:
                    throw new StorageCredentialException("Invalid access key provided in storage credentials", exception);
                case AmazonS3Exception { StatusCode: HttpStatusCode.Forbidden, ErrorCode: InvalidSecretAccessKeyErrorCode }:
                    throw new StorageCredentialException("Invalid secret key provided in storage credentials", exception);
                case AmazonServiceException { StatusCode: HttpStatusCode.Forbidden } amazonServiceException:
                    throw new StorageUnauthorizedAccessException("Given account does not have permission to access requested service", amazonServiceException);
            }
        }

        private static async Task<bool> DoesBucketExistAsync(IAmazonS3 s3Client, string bucketName, CancellationToken cancellationToken = default)
        {
            try
            {
                await s3Client.GetACLAsync(bucketName, cancellationToken).ConfigureAwait(false);
            }
            catch (AmazonS3Exception ex)
            {
                switch (ex.ErrorCode)
                {
                    case "AccessDenied":
                    case "PermanentRedirect":
                        return true;
                    case "NoSuchBucket":
                        return false;
                    default:
                        throw;
                }
            }
            return true;
        }

        private static void ValidateCopyAsync(IStorageFileSource source, IStorageFileMetadata destination)
        {
            if (source.Metadata is null)
                throw new ArgumentNullException("source.Metadata", "source.Metadata is not defined");
            if (source.Metadata.StorageType is null)
                throw new ArgumentNullException("source.Metadata.StorageType", "source.Metadata.StorageType is not defined");

            ValidateMetadataPath(() => destination);
        }

        private static void ValidateMetadataPath(Expression<Func<IStorageFileMetadata>> member)
        {
            var memberName = (member.Body as MemberExpression)?.Member.Name;
            var metadata = member.Compile().Invoke();

            if (string.IsNullOrWhiteSpace(metadata.Path))
                throw new ArgumentNullException($"{memberName}.{nameof(metadata.Path)}");
        }

        private static void ValidateFileSourceStream(Expression<Func<IStorageFileSource>> member)
        {
            var memberName = (member.Body as MemberExpression)?.Member.Name;
            var fileSource = member.Compile().Invoke();

            if (fileSource.Stream is null)
                throw new ArgumentNullException($"{memberName}.{nameof(fileSource.Stream)}");
        }

        private static void ValidateHashProviderType(StorageFileHashProviderType? hashProviderType)
        {
            if (hashProviderType is not null && !SupportedHashProviderTypes.Contains(hashProviderType.Value))
                throw new StorageHashProviderTypeValidationException($"Provided hash provider type '{hashProviderType}' is not supported");
        }

        private static void ValidateHashProviderTypeFromFileMetadata(IStorageFileMetadata fileMetadata, out StorageFileHashProviderType? hashProviderFromMetadata)
        {
            fileMetadata.Attributes.TryGetValue(MetadataUtility.BuildPbsMetadataKey(MetadataKeys.HashProviderMetadataKey), out object? hashProviderTypeMetadataValue);

            if (!StorageEnumExtensions.TryParse(hashProviderTypeMetadataValue?.ToString() ?? string.Empty, out hashProviderFromMetadata))
                return;

            if (hashProviderFromMetadata is not null && !SupportedHashProviderTypes.Contains(hashProviderFromMetadata.Value))
                throw new StorageHashProviderTypeValidationException($"Hash provider type '{hashProviderFromMetadata}' defined in '{nameof(S3Object)}' metadata is not supported");
        }

        private static void ValidateHashProviderTypeMismatch(StorageFileHashProviderType? hashProviderFromMetadata, StorageFileHashProviderType? requestedHashProviderType)
        {
            if (hashProviderFromMetadata.HasValue && requestedHashProviderType.HasValue && hashProviderFromMetadata.Value != requestedHashProviderType.Value)
                throw new StorageHashProviderTypeValidationException($"Provided hash provider '{requestedHashProviderType}' does not match with provider '{hashProviderFromMetadata}' used for initial hash generation");
        }

        private void ResolveCredential(Expression<Func<IStorageCredential>> member)
        {
            var memberName = (member.Body as MemberExpression)?.Member.Name;
            var credential = member.Compile().Invoke();

            var region = ResolveAttribute(credential, RegionAttributeName, string.Empty);
            if (string.IsNullOrWhiteSpace(region))
                throw new ArgumentNullException($"{memberName}.{nameof(credential.Attributes)}.{RegionAttributeName}");
            RegionEndPoint = RegionEndpoint.GetBySystemName(region);

            BucketName = ResolveAttribute(credential, BucketAttributeName, string.Empty);
            if (string.IsNullOrWhiteSpace(BucketName))
                throw new ArgumentNullException($"{memberName}.{nameof(credential.Attributes)}.{BucketAttributeName}");

            AccessKey = ResolveAttribute(credential, AccessKeyAttributeName, string.Empty);
            SecretAccessKey = ResolveAttribute(credential, SecretAccessKeyAttributeName, string.Empty);

            if (string.IsNullOrWhiteSpace(AccessKey) && !string.IsNullOrWhiteSpace(SecretAccessKey))
                throw new ArgumentNullException($"{memberName}.{nameof(credential.Attributes)}.{AccessKeyAttributeName}");

            if (!string.IsNullOrWhiteSpace(AccessKey) && string.IsNullOrWhiteSpace(SecretAccessKey))
                throw new ArgumentNullException($"{memberName}.{nameof(credential.Attributes)}.{SecretAccessKeyAttributeName}");
        }

        private static string ResolveBucketName(Expression<Func<IStorageFileMetadata>> member)
        {
            var memberName = (member.Body as MemberExpression)?.Member.Name;
            var metadata = member.Compile().Invoke();

            var bucketName = ResolveAttribute(metadata, BucketAttributeName, string.Empty);
            if (string.IsNullOrEmpty(bucketName))
                throw new ArgumentNullException($"{memberName}.{nameof(metadata.Attributes)}.{BucketAttributeName}");
            return bucketName;
        }
    }
}
