﻿using Amazon.S3;
using Amazon.S3.Transfer;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class AmazonS3TransferClient : IAmazonS3TransferClient
    {
        private readonly IAmazonS3 _client;

        public AmazonS3TransferClient(IAmazonS3 client)
        {
            _client = client;
        }

        public async Task UploadAsync(TransferUtilityUploadRequest request, CancellationToken cancellationToken = default)
        {
            await new TransferUtility(_client).UploadAsync(request, cancellationToken);
        }

        public async Task DownloadAsync(TransferUtilityDownloadRequest request, CancellationToken cancellationToken = default)
        {
            await new TransferUtility(_client).DownloadAsync(request, cancellationToken);
        }
    }
}
