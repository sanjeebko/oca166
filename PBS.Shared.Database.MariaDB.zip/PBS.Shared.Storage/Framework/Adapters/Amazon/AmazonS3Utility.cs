﻿using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;

namespace PBS.Shared.Storage
{
    public static class AmazonS3Utility
    {
        public static bool IsObjectFile(S3Object s3Object)
        {
            bool isFile = !string.IsNullOrWhiteSpace(Path.GetExtension(s3Object.Key));
            if (!isFile)
                isFile = s3Object.Size > 0;
            return isFile;
        }

        public static string BuildAmazonS3MetadataKey(string key)
        {
            return $"{MetadataKeys.AmazonS3MetadataPrefix}{key}";
        }

        public static string RemoveAmazonS3MetadataKeyPrefix(string key)
        {
            return key.Replace($"{MetadataKeys.AmazonS3MetadataPrefix}", "");
        }

        public static Dictionary<string, object?> CloneMetadata(MetadataCollection? metadataCollection)
        {
            if (metadataCollection == null)
                return new Dictionary<string, object?>();

            Dictionary<string, object?> metadata = new Dictionary<string, object?>();

            foreach (var key in metadataCollection.Keys)
            {
                metadata.TryAdd(RemoveAmazonS3MetadataKeyPrefix(key), metadataCollection[key]);
            }

            return metadata;
        }

        public static Dictionary<string, string> CreateMetadata(IReadOnlyDictionary<string, object?>? metadata)
        {
            var s3Metadata = new Dictionary<string, string>();

            if (metadata == null)
                return s3Metadata;

            foreach (var attribute in metadata)
            {
                string metadataKey = attribute.Key.Contains(MetadataKeys.PbsMetadataPrefix, StringComparison.OrdinalIgnoreCase) ? attribute.Key : MetadataUtility.BuildPbsMetadataKey(attribute.Key);
                s3Metadata.Add(metadataKey, attribute.Value?.ToString() ?? string.Empty);
            }

            return s3Metadata;
        }
    }
}
