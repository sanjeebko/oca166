﻿using Amazon.S3;

namespace PBS.Shared.Storage
{
    public class AmazonS3Credential : AmazonCredential<AmazonS3Config>
    {
    }
}
