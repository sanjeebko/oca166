﻿using Amazon.S3;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public class AmazonS3ClientFactory : IAmazonS3ClientFactory
    {
        public ValueTask<IAmazonS3> CreateClient(AmazonS3Credential credential)
        {
            bool hasCredentials = !string.IsNullOrEmpty(credential.AccessKey) && !string.IsNullOrEmpty(credential.SecretAccessKey);

            if (hasCredentials)
            {
                return ValueTask.FromResult<IAmazonS3>(new AmazonS3Client(credential.AccessKey, credential.SecretAccessKey, credential.Config));
            }

            return ValueTask.FromResult<IAmazonS3>(new AmazonS3Client(credential.Config));
        }
    }
}
