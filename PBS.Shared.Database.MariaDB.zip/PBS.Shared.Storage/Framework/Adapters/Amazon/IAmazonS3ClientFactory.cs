﻿using System.Threading.Tasks;
using Amazon.S3;

namespace PBS.Shared.Storage
{
    public interface IAmazonS3ClientFactory
    {
        ValueTask<IAmazonS3> CreateClient(AmazonS3Credential credential);
    }
}