﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage.Framework.Adapters.Amazon
{
    class StorageDirectoryNode
    {
        public IDictionary<string, StorageDirectoryNode> Children { get; set; } = new Dictionary<string, StorageDirectoryNode>();

        public string Name { get; set; } = string.Empty;

        public void AddPath(string path, char separator)
        {
            string[] parts = path.Split(separator, StringSplitOptions.RemoveEmptyEntries);

            StorageDirectoryNode current = this;

            foreach (string part in parts)
            {
                if (!current.Children.TryGetValue(part, out StorageDirectoryNode? child))
                {
                    child = new StorageDirectoryNode { Name = part };
                    current.Children[part] = child;
                }
                current = child;
            }
        }
    }
}
