﻿using System;

namespace PBS.Shared.Storage
{
    public interface IStorageHashBuilder
    {
        /// <summary>
        /// Registers file hash provider
        /// </summary>
        /// <typeparam name="T">Provider type</typeparam>
        /// <param name="providerType"></param>
        /// <param name="configure">Hash provider options configure callback</param>
        void RegisterHashProvider<T>(StorageFileHashProviderType providerType, Action<StorageFileHashProviderConfiguration>? configure = null) where T : IStorageFileHashProvider;
    }
}