﻿using PBS.Shared.Storage.FileMonitoring;

namespace PBS.Shared.Storage
{
    public class StorageFileChangeBuilder : IStorageFileChangeBuilder
    {
        private readonly StorageType _storageType;
        private readonly IStorageFileChangeProviderRegistrationOptions _options;

        public StorageFileChangeBuilder(StorageType storageType, IStorageFileChangeProviderRegistrationOptions options)
        {
            _storageType = storageType;
            _options = options;
        }

        public void RegisterFileChangeProvider<TProvider>() where TProvider : IStorageFileChangeProvider
        {
            _options.RegisterProvider<TProvider>(_storageType);
        }
    }
}