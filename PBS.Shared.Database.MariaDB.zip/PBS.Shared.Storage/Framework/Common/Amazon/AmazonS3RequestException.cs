﻿using System;
using System.Net;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class AmazonS3RequestException : AmazonHttpException
    {
        public AmazonS3RequestException() { }
        public AmazonS3RequestException(string? message, HttpStatusCode? statusCode) : base(message, statusCode) { }
        public AmazonS3RequestException(string? message, HttpStatusCode? statusCode, Exception? innerException) : base(message, statusCode, innerException) { }
        protected AmazonS3RequestException(SerializationInfo info, StreamingContext context) : base(info, context) { }
    }
}
