﻿using Amazon.Runtime;
using System;
using System.Net;

namespace PBS.Shared.Storage
{
    public static class AmazonResponseValidation
    {
        public static void ValidateAmazonServiceResponse<TException>(this AmazonWebServiceResponse response, string message) where TException : AmazonHttpException
        {
            if (response.HttpStatusCode == HttpStatusCode.OK)
                return;
            if (Activator.CreateInstance(typeof(TException), message, response.HttpStatusCode) is AmazonHttpException exception)
                throw exception;
        }
    }
}
