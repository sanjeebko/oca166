﻿using Amazon.Runtime;

namespace PBS.Shared.Storage
{
    public class AmazonCredential<TConfig> : AmazonCredential where TConfig : ClientConfig
    {
        public TConfig? Config { get; set; }
    }

    public class AmazonCredential
    {
        public string? AccessKey { get; set; }
        public string? SecretAccessKey { get; set; }
    }
}
