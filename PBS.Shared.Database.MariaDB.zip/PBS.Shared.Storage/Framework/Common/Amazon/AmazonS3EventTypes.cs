﻿using Amazon.S3;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PBS.Shared.Storage
{
    public static class AmazonS3EventTypes
    {
        private static IReadOnlyDictionary<string, EventType>? _eventTypes;
        private static IReadOnlyDictionary<EventType, IReadOnlyList<EventType>>? _rootedEventTypes;

        /// <summary>
        /// All supported Amazon s3 event types.
        /// </summary>
        /// <returns>Key:EventTypeFieldName, Value:EventType</returns>
        public static IReadOnlyDictionary<string, EventType> EventTypes
        {
            get
            {
                return _eventTypes ??= typeof(EventType)
                    .GetFields(BindingFlags.Public | BindingFlags.Static)
                    .Where(f => f.FieldType == typeof(EventType))
                    .ToDictionary(f => f.Name, f => (EventType)f.GetValue(null)!);
            }
        }

        /// <summary>
        /// Returns map of event types which name ends with All as a key, and all it's sub events
        /// </summary>
        /// <remarks>
        /// Amazon s3 event types have definition of event type which includes all sub events in that category
        /// Example : ObjectCreatedAll event type will include all events under ObjectCreated, like ObjectCreatedPut, ObjectCreatedPost etc..
        /// So we are building and returning map of event types which ends with All as a key, and all it's sub events
        /// </remarks>
        public static IReadOnlyDictionary<EventType, IReadOnlyList<EventType>> RootedEventTypes => _rootedEventTypes ??= BuildRootEventTypes();

        private static IReadOnlyDictionary<EventType, IReadOnlyList<EventType>> BuildRootEventTypes()
        {
            List<EventType> rootEventTypes = EventTypes.Where(pair => pair.Key.EndsWith("All")).Select(pair => pair.Value).ToList();
            return rootEventTypes.ToDictionary(rootEventType => rootEventType, rootEventType => (IReadOnlyList<EventType>)GetChildEventTypes(rootEventType).ToList());
        }

        private static IEnumerable<EventType> GetChildEventTypes(EventType rootEventType)
        {
            string lookup = rootEventType.Value.Remove(rootEventType.Value.LastIndexOf("*", StringComparison.Ordinal), 1);

            foreach (EventType eventType in EventTypes.Values.Except(new[] { rootEventType }))
            {
                if (eventType.Value.StartsWith(lookup))
                    yield return eventType;
            }
        }
    }
}
