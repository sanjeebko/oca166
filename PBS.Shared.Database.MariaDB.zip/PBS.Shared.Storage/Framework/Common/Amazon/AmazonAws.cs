﻿using Amazon;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.Storage
{
    public static class AmazonAws
    {
        public static IEnumerable<string> GetAllRegionNames => RegionEndpoint.EnumerableAllRegions.Select(regionEndpoint => regionEndpoint.SystemName);
    }
}
