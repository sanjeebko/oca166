﻿using System;
using System.Net;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class AmazonHttpException : Exception
    {
        public AmazonHttpException() { }

        protected AmazonHttpException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        public AmazonHttpException(string? message, HttpStatusCode? statusCode) : base(message)
        {
            StatusCode = statusCode;
        }

        public AmazonHttpException(string? message, HttpStatusCode? statusCode, Exception? innerException) : base(message, innerException)
        {
            StatusCode = statusCode;
        }

        public HttpStatusCode? StatusCode { get; }

        public override void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            info.AddValue(nameof(StatusCode), StatusCode);

            base.GetObjectData(info, context);
        }
    }
}
