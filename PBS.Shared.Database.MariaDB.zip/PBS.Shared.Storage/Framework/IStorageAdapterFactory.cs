﻿namespace PBS.Shared.Storage
{
    /// <summary>
    /// Storage adapter factory which uses di service provider to resolve adapter which is mapped in <see cref="StorageAdapterOptions"/>
    /// </summary>
    public interface IStorageAdapterFactory
    {
        /// <summary>
        /// Resolves storage adapter implementation by storage type
        /// </summary>
        /// <param name="type">Storage type</param>
        /// <returns>Return found storage adapter or null if not found</returns>
        IStorageAdapter? ResolveAdapter(StorageType type);

        /// <summary>
        /// Check's if adapter is registered for provided storage type
        /// </summary>
        /// <param name="type">StorageType</param>
        /// <returns>true if it is registered, or false if it is not</returns>
        bool IsAdapterRegistered(StorageType type);
    }
}
