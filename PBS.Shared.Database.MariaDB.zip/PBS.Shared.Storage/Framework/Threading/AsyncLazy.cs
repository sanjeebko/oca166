﻿using System;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    /// <summary> Provides lazy instantiation, uses semaphore so resource is only instantiated once. </summary>
    public class AsyncLazy<T> where T : class
    {
        private Func<T>? _factory;
        private Func<Task<T>>? _asyncFactory;
        private T? _value;
        private bool _isValueCreated;
        private readonly AsyncLock _lock = new AsyncLock();

        /// <summary>
        /// Create with regular factory.
        /// </summary>
        public AsyncLazy(Func<T> factory)
        {
            _factory = factory ?? throw new ArgumentNullException(nameof(factory));
        }

        /// <summary>
        /// Create lazy with async factory, call GetValueAsync to get value in a non blocking way! You can still use the Value property for sync.
        /// </summary>
        public AsyncLazy(Func<Task<T>> factory)
        {
            _asyncFactory = factory ?? throw new ArgumentNullException(nameof(factory));
        }

        /// <summary>
        /// Get value synchronously, if factory is async then factory is run in a background task. 
        /// </summary>
        /// <exception cref="T:System.Exception">A delegate callback throws an exception.</exception>
        public T? Value => GetValue();

        /// <summary>
        /// Get value synchronously, if factory is async then factory is run in a background task. 
        /// </summary>
        /// <exception cref="T:System.Exception">A delegate callback throws an exception.</exception>
        public T? GetValue()
        {
            if (_isValueCreated)
                return _value;

            _lock.Run(() =>
            {
                if (_isValueCreated)
                    return;

                if (_factory != null)
                {
                    _value = _factory();
                    _factory = null;
                }

                if (_asyncFactory != null)
                {
                    _value = _asyncFactory().Result;
                    _asyncFactory = null;
                }
                _isValueCreated = true;
            });
            return _value;
        }

        /// <summary>
        /// Get value asynchronously, if factory is not async then this will still be synchronous.
        /// </summary>
        /// <exception cref="T:System.Exception">A delegate callback throws an exception.</exception>
        public async Task<T?> GetValueAsync()
        {
            if (_isValueCreated)
                return _value;
            await _lock.RunAsync(async () =>
            {
                if (_isValueCreated)
                    return;
                if (_factory != null)
                {
                    _value = _factory();
                    _factory = null;
                }
                if (_asyncFactory != null)
                {
                    _value = await _asyncFactory();
                    _asyncFactory = null;
                }
                _isValueCreated = true;
            });
            return _value;
        }

        /// <summary> 
        /// Set if the factory has been called, if set the factory is never called again. 
        /// </summary>
        public bool IsValueCreated => _isValueCreated;
    }
}
