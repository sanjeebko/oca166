﻿using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;

namespace PBS.Shared.Storage
{
    public class StorageAdapterOptions : IOptions<IStorageAdapterOptions>, IStorageAdapterRegistrationOption, IStorageAdapterOptions
    {
        private readonly Dictionary<StorageType, Type> _mappings = new Dictionary<StorageType, Type>();

        /// <exception cref="T:System.InvalidOperationException">When adapter is already added to mapping for <see cref="StorageType"/></exception>
        public void RegisterAdapter<T>(StorageType storageType) where T : IStorageAdapter
        {
            if (_mappings.ContainsKey(storageType))
                throw new StorageAdapterMappingException($"Adapter for {storageType} already added");
            _mappings.Add(storageType, typeof(T));
        }

        public Type? GetAdapterType(StorageType storageType)
        {
            return _mappings.TryGetValue(storageType, out Type? adapterType) ? adapterType : default;
        }

        public IReadOnlyDictionary<StorageType, Type> Mappings => _mappings;

        public IStorageAdapterOptions Value => this;
    }
}
