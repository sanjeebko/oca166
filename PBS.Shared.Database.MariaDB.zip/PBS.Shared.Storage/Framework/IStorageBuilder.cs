﻿namespace PBS.Shared.Storage
{
    /// <summary>
    /// Extension to storage registration <see cref="StorageRegistration"/> for registering adapter implementation for <see cref="StorageType"/>
    /// </summary>
    public interface IStorageBuilder : IStorageHashBuilder
    {
        /// <summary>
        /// Adds adapter implementation to <see cref="StorageAdapterOptions"/>
        /// </summary>
        /// <typeparam name="T">Storage adapter implementation</typeparam>
        /// <param name="storageType">Storage type</param>
        IStorageFileChangeBuilder RegisterAdapter<T>(StorageType storageType) where T : IStorageAdapter;
    }
}