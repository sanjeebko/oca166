﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace PBS.Shared.Storage
{
    public abstract class StorageAdapter : IStorageAdapter
    {
        protected ILogger Logger { get; }


        protected StorageAdapter(ILogger logger)
        {
            Logger = logger;
        }

        public abstract ValueTask ConnectAsync(IStorageCredential credential);
        public abstract ValueTask<bool> DeleteAsync(IStorageFileMetadata metadata);
        public abstract ValueTask<IStorageFileMetadata> GetAsync(string path);
        public abstract ValueTask<IStorageFileSource> GetStreamAsync(IStorageFileMetadata metadata);
        public virtual ValueTask<IStorageFileHash> GetHashAsync(string? path, StorageFileHashProviderType? hashProviderType = default)
        {
            return ValueTask.FromResult<IStorageFileHash>(StorageFileHash.Empty);
        }
        public abstract ValueTask<IEnumerable<StorageDirectory>> GetDirectoryTreeAsync();
        public abstract ValueTask<IEnumerable<IStorageFileMetadata>> GetAllAsync(IStorageFileFilter? filter = default);
        public abstract ValueTask<bool> CopyAsync(IStorageFileSource source, IStorageFileMetadata destination, IReadOnlyDictionary<string, object?>? metadata = default);
        public virtual ValueTask<bool> PutMetadataAsync(IStorageFileMetadata source, IReadOnlyDictionary<string, object?> metadata)
        {
            return ValueTask.FromResult(true);
        }
        public abstract IEnumerable<StorageFileHashProviderType> GetSupportedHashProviders();

        protected abstract void Cleanup();

        /// <exception cref="T:System.AggregateException">Will throw aggregate exceptions if any attributes are missing</exception>
        protected static void ValidateAttributes(IAttributesProvider attributesProvider, params string[] keys)
        {
            List<Exception> exceptions = new List<Exception>();
            foreach (var key in keys)
                if (!attributesProvider.Attributes.TryGetValue(key, out object? keyValue) || string.IsNullOrEmpty(keyValue?.ToString()))
                    exceptions.Add(new ArgumentException($"Missing or invalid {key} in credential attributes"));
            if (exceptions.Any())
                throw new AggregateException(exceptions);
        }

        /// <exception cref="T:System.InvalidCastException">This conversion is not supported.</exception>
        protected static T? ResolveAttribute<T>(IAttributesProvider attributesProvider, string key, T fallbackValue) where T : class
        {
            if (attributesProvider.Attributes.TryGetValue(key, out object? keyVal))
            {
                if (keyVal is null)
                    return fallbackValue;
                if (keyVal is T val)
                    return val;
                TypeConverter converter = TypeDescriptor.GetConverter(typeof(T));
                if (converter.CanConvertFrom(keyVal.GetType()))
                    return converter.ConvertFrom(keyVal) as T;
                if (converter.CanConvertFrom(typeof(string)))
                    return converter.ConvertFromString(keyVal.ToString()) as T;
                return Convert.ChangeType(keyVal, typeof(T)) as T;
            }
            return fallbackValue;
        }

        private bool disposed;
        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    Cleanup();
                }
                disposed = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
