﻿using System;

namespace PBS.Shared.Storage
{
    public static class StorageEnumExtensions
    {
        public static bool TryParse<T>(string value, out T? result) where T : struct, IConvertible
        {
            if (!typeof(T).IsEnum)
                throw new InvalidOperationException("This method is only for Enums");

            if (Enum.TryParse(value, out T tempResult))
            {
                result = tempResult;
                return true;
            }

            result = null;
            return false;
        }
    }
}
