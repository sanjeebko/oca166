﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageCredentialException : Exception
    {
        public StorageCredentialException() { }
        protected StorageCredentialException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageCredentialException(string message) : base(message) { }
        public StorageCredentialException(string message, Exception innerException) : base(message, innerException) { }
    }
}