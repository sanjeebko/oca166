﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageHashProviderCreationException : InvalidOperationException
    {
        public StorageHashProviderCreationException() { }
        protected StorageHashProviderCreationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageHashProviderCreationException(string message) : base(message) { }
        public StorageHashProviderCreationException(string message, Exception innerException) : base(message, innerException) { }
    }
}