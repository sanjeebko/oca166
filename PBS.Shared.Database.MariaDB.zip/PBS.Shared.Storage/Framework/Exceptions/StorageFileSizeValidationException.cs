﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileSizeValidationException : Exception
    {
        public StorageFileSizeValidationException() { }
        protected StorageFileSizeValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileSizeValidationException(string message) : base(message) { }
        public StorageFileSizeValidationException(string message, Exception innerException) : base(message, innerException) { }
    }
}
