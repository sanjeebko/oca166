﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileStreamValidationException : Exception
    {
        public StorageFileStreamValidationException() { }
        protected StorageFileStreamValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileStreamValidationException(string message) : base(message) { }
        public StorageFileStreamValidationException(string message, Exception innerException) : base(message, innerException) { }
    }
}
