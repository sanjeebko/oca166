﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileNotFoundException : Exception
    {
        public StorageFileNotFoundException() { }
        protected StorageFileNotFoundException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileNotFoundException(string message) : base(message) { }
        public StorageFileNotFoundException(string message, Exception innerException) : base(message, innerException) { }
    }
}
