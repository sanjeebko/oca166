﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileHashValidationException : Exception
    {
        public StorageFileHashValidationException() { }
        protected StorageFileHashValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileHashValidationException(string message) : base(message) { }
        public StorageFileHashValidationException(string message, Exception innerException) : base(message, innerException) { }
    }
}
