﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageHashProviderMappingException : InvalidOperationException
    {
        public StorageHashProviderMappingException() { }
        protected StorageHashProviderMappingException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageHashProviderMappingException(string message) : base(message) { }
        public StorageHashProviderMappingException(string message, Exception innerException) : base(message, innerException) { }
    }
}