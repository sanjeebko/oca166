﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageConnectionException : Exception
    {
        public StorageConnectionException() { }
        protected StorageConnectionException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageConnectionException(string message) : base(message) { }
        public StorageConnectionException(string message, Exception innerException) : base(message, innerException) { }
    }
}
