﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageHashProviderTypeValidationException : InvalidOperationException
    {
        public StorageHashProviderTypeValidationException() { }
        protected StorageHashProviderTypeValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageHashProviderTypeValidationException(string message) : base(message) { }
        public StorageHashProviderTypeValidationException(string message, Exception innerException) : base(message, innerException) { }
    }
}
