﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileMetadataValidationException : ArgumentNullException
    {
        public StorageFileMetadataValidationException() { }
        protected StorageFileMetadataValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileMetadataValidationException(string? message) : base(message) { }
        public StorageFileMetadataValidationException(string? message, Exception? innerException) : base(message, innerException) { }
    }
}
