﻿using PBS.Shared.Storage.FileMonitoring;
using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileChangeProviderException : Exception
    {
        public IStorageFileChangeMetadata? FileMetadata { get; }
        public StorageFileChangeType? ChangeType { get; }

        public StorageFileChangeProviderException() { }
        protected StorageFileChangeProviderException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileChangeProviderException(string message) : base(message) { }

        public StorageFileChangeProviderException(string message, Exception? innerException) : base(message, innerException) { }

        public StorageFileChangeProviderException(string message, IStorageFileChangeMetadata? fileMetadata, StorageFileChangeType? changeType, Exception? innerException) : base(message, innerException)
        {
            FileMetadata = fileMetadata;
            ChangeType = changeType;
        }
    }
}