﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageAdapterMappingException : InvalidOperationException
    {
        public StorageAdapterMappingException() { }
        protected StorageAdapterMappingException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageAdapterMappingException(string message) : base(message) { }
        public StorageAdapterMappingException(string message, Exception innerException) : base(message, innerException) { }
    }
}