﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageCredentialValidationException : ArgumentNullException
    {
        public StorageCredentialValidationException() { }
        protected StorageCredentialValidationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageCredentialValidationException(string? message) : base(message) { }
        public StorageCredentialValidationException(string? message, Exception? innerException) : base(message, innerException) { }
    }
}
