﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageFileChangeProviderResolveException : Exception
    {
        public StorageFileChangeProviderResolveException() { }
        protected StorageFileChangeProviderResolveException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageFileChangeProviderResolveException(string message) : base(message) { }
        public StorageFileChangeProviderResolveException(string message, Exception innerException) : base(message, innerException) { }
    }
}
