﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageHashProviderRegistrationException : InvalidOperationException
    {
        public StorageHashProviderRegistrationException() { }
        protected StorageHashProviderRegistrationException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageHashProviderRegistrationException(string message) : base(message) { }
        public StorageHashProviderRegistrationException(string message, Exception innerException) : base(message, innerException) { }
    }
}