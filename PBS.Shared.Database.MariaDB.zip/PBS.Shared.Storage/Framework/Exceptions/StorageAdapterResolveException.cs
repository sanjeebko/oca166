﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageAdapterResolveException : Exception
    {
        public StorageAdapterResolveException() { }
        protected StorageAdapterResolveException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageAdapterResolveException(string message) : base(message) { }
        public StorageAdapterResolveException(string message, Exception innerException) : base(message, innerException) { }
    }
}
