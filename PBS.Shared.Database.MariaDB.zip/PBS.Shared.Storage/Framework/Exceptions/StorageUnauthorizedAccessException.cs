﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.Storage
{
    [Serializable]
    public class StorageUnauthorizedAccessException : Exception
    {
        public StorageUnauthorizedAccessException() { }
        protected StorageUnauthorizedAccessException(SerializationInfo info, StreamingContext context) : base(info, context) { }

        public StorageUnauthorizedAccessException(string message) : base(message) { }
        public StorageUnauthorizedAccessException(string message, Exception innerException) : base(message, innerException) { }
    }
}
