﻿using PBS.Shared.Storage.FileMonitoring;
using System;

namespace PBS.Shared.Storage
{
    public class StorageBuilder : IStorageBuilder
    {
        private readonly IStorageAdapterRegistrationOption _adapterOptions;
        private readonly IStorageFileHashProviderRegistrationOptions _hashProviderOptions;
        private readonly IStorageFileChangeProviderRegistrationOptions _fileChangeProviderOptions;

        public StorageBuilder(
            IStorageAdapterRegistrationOption adapterOptions,
            IStorageFileHashProviderRegistrationOptions hashProviderOptions,
            IStorageFileChangeProviderRegistrationOptions fileChangeProviderOptions)
        {
            _adapterOptions = adapterOptions;
            _hashProviderOptions = hashProviderOptions;
            _fileChangeProviderOptions = fileChangeProviderOptions;
        }

        /// <inheritdoc cref="IStorageBuilder"/>
        public IStorageFileChangeBuilder RegisterAdapter<T>(StorageType storageType) where T : IStorageAdapter
        {
            _adapterOptions.RegisterAdapter<T>(storageType);
            return new StorageFileChangeBuilder(storageType, _fileChangeProviderOptions);
        }

        internal bool TryRegisterAdapter<T>(StorageType storageType) where T : IStorageAdapter
        {
            try
            {
                RegisterAdapter<T>(storageType);
                return true;
            }
            catch (StorageAdapterMappingException)
            {
                return false;
            }
        }

        /// <inheritdoc cref="IStorageBuilder"/>
        public void RegisterHashProvider<T>(StorageFileHashProviderType providerType, Action<StorageFileHashProviderConfiguration>? configure = null) where T : IStorageFileHashProvider
        {
            var configuration = new StorageFileHashProviderConfiguration();

            configure?.Invoke(configuration);

            _hashProviderOptions.RegisterProvider<T>(providerType, configuration);
        }

        /// <inheritdoc cref="IStorageBuilder"/>
        internal bool TryRegisterHashProvider<T>(StorageFileHashProviderType providerType, Action<StorageFileHashProviderConfiguration>? configure = null) where T : IStorageFileHashProvider
        {
            try
            {
                RegisterHashProvider<T>(providerType, configure);
                return true;
            }
            catch (StorageHashProviderMappingException)
            {
                return false;
            }
        }
    }
}
