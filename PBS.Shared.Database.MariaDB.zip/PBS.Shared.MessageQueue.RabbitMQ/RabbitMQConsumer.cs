﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Configuration;
using PBS.Shared.Logging;
using PBS.Shared.MessageQueue.RabbitMQ.Factory;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using RabbitMQ.Client.Exceptions;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.MessageQueue.RabbitMQ
{
    public class RabbitMQConsumer : IMQConsumer
    {
        public event EventHandler<MessageReceivedEventArgs> OnMessageReceived = delegate { };
        private bool _isDisposed { get; set; } = false;
        private bool _isConnected { get; set; } = false;

        private readonly IMonitoredConfiguration<MQConfig> _configuration;
        private readonly IRabbitMQFactory _factory;
        private readonly ILogger _logger;

        private MQConfig? _currentConfiguration;
        private IConnection? _connection;
        private IModel? _channel;
        private CancellationTokenSource connectCancellationSource = new CancellationTokenSource();

        public RabbitMQConsumer(IMonitoredConfiguration<MQConfig> configuration, ILogger<RabbitMQConsumer> logger, IRabbitMQFactory factory)
        {
            _factory = factory;
            _logger = logger;

            _configuration = configuration ?? throw new ArgumentNullException(nameof(configuration), "Message Queue configuration could not be loaded");
            _currentConfiguration = configuration.Value;
            configuration.ValueChange += ConfigChangedEvent;
        }

        public async Task Connect(CancellationToken cancellationToken)
        {
            connectCancellationSource = new CancellationTokenSource();

            using var _ = cancellationToken.Register(() => connectCancellationSource.Cancel());

            await DoConnect(connectCancellationSource.Token);
        }

        private async Task DoConnect(CancellationToken cancellationToken)
        {
            try
            {
                _logger.LogTrace("Attempting Connection to RabbitMQ Service.");
                var generatedQueueName = await CreateConnection(cancellationToken);

                if (generatedQueueName == null) {
                    _logger.LogWarning("RabbitMQ connection details have not been specified. Cannot connect to RabbitMQ.");
                    DoDisconnect();
                    return;
                }

                cancellationToken.ThrowIfCancellationRequested();
                CreateConsumer(generatedQueueName);

                _isConnected = true;
                _logger.LogTrace("Succcessfully connected to RabbitMQ Service.");
            }
            catch (TaskCanceledException)
            {
                _logger.LogTrace("Connection to RabbitMQ Service failed.");
                DoDisconnect();
                throw;
            }
        }

        private async Task Reconnect() {
            if (!_isConnected) return;

            DoDisconnect();
            connectCancellationSource = new CancellationTokenSource();
            await DoConnect(connectCancellationSource.Token);
        }

        private void ConfigChangedEvent(object? sender, MQConfig? config) {
            if (_currentConfiguration == null && config == null) return;
            if (_currentConfiguration != null && _currentConfiguration.Equals(config)) return;

            _currentConfiguration = config;

            _ = Reconnect();
        }

        private async Task<string?> CreateConnection(CancellationToken cancellationToken)
        {
            if (_currentConfiguration == null) {
                return null;
            }

            cancellationToken.ThrowIfCancellationRequested();

            var generatedQueueName = await Task.Run(() =>
            {
                try
                {
                    // create connection  
                    _connection = _factory.CreateConnection(_currentConfiguration);

                    // create channel  
                    _channel = _connection.CreateModel();

                    if (_currentConfiguration.Exchange is null)
                        throw new ArgumentException($"{nameof(_currentConfiguration.Exchange)} is null");

                    _channel.ExchangeDeclare(_currentConfiguration.Exchange.Name,
                        _currentConfiguration.Exchange.Type,
                        _currentConfiguration.Exchange.Durable,
                        _currentConfiguration.Exchange.AutoDelete);

                    if (_currentConfiguration.Queue is null)
                        throw new ArgumentException($"{nameof(_currentConfiguration.Queue)} is null");


                    var generatedQueueName = _currentConfiguration.Queue.Name.Replace("__guid__", Guid.NewGuid().ToString());

                    _channel.QueueDeclare(generatedQueueName,
                        _currentConfiguration.Queue.Durable,
                        _currentConfiguration.Queue.Exclusive,
                        _currentConfiguration.Queue.AutoDelete,
                        null);

                    _channel.QueueBind(generatedQueueName, _currentConfiguration.Exchange.Name, "", null);
                    _channel.BasicQos(0, 1, false);

                    _connection.ConnectionShutdown += RabbitMQ_ConnectionShutdown;

                    return generatedQueueName;
                }
                catch (BrokerUnreachableException)
                {
                    return null;
                }
            });

            if (generatedQueueName == null)
            {
                _logger.LogError("RabbitMQ Service unreachable");
                // Retry
                await Task.Delay(5000, cancellationToken);
                return await CreateConnection(cancellationToken);
            }

            return generatedQueueName;
        }

        private void CreateConsumer(string generatedQueueName)
        {
            var consumer = new EventingBasicConsumer(_channel);

            consumer.Received += HandleMessage;
            consumer.Shutdown += OnConsumerShutdown;
            consumer.Registered += OnConsumerRegistered;
            consumer.Unregistered += OnConsumerUnregistered;
            consumer.ConsumerCancelled += OnConsumerConsumerCancelled;

            _channel.BasicConsume(generatedQueueName, false, consumer);
        }

        private void HandleMessage(object? _, BasicDeliverEventArgs e)
        {
            if (_channel == null) return;

            var content = System.Text.Encoding.UTF8.GetString(e.Body.Span);

            var notificationReceivedEventArgs = new MessageReceivedEventArgs(content);
            OnMessageReceived(this, notificationReceivedEventArgs);

            _channel.BasicAck(e.DeliveryTag, false);
        }

        private void OnConsumerConsumerCancelled(object? _, ConsumerEventArgs args)
        {
            using (_logger.WithProperty("ConsumerTag", args.ConsumerTags))
                _logger.LogTrace("Consumer has been cancelled unexpectedly");
        }

        private void OnConsumerUnregistered(object? _, ConsumerEventArgs args)
        {
            using (_logger.WithProperty("ConsumerTag", args.ConsumerTags))
                _logger.LogTrace("Consumer unregistered successfully");
        }

        private void OnConsumerRegistered(object? _, ConsumerEventArgs args)
        {
            using (_logger.WithProperty("ConsumerTag", args.ConsumerTags))
                _logger.LogTrace("Consumer registered successfully");
        }

        private void OnConsumerShutdown(object? _, ShutdownEventArgs args)
        {
            using (_logger.WithProperty("ShutdownCause", args.Cause))
                _logger.LogTrace("Connection with consumer is closed");
        }

        private void RabbitMQ_ConnectionShutdown(object? _, ShutdownEventArgs args)
        {
            using (_logger.WithProperty("ShutdownCause", args.Cause))
                _logger.LogTrace("Connection with RabbitMQ is closed");
        }

        public void Disconnect()
        {
            DoDisconnect();
            _isConnected = false;
        }

        private void DoDisconnect()
        {
            _logger.LogTrace("Disconnecting RabbitMQConsumer");

            if (_channel != null)
            {
                if (_channel.IsOpen)
                {
                    _channel.Close();
                    _logger.LogTrace("RabbitMQConsumer channel closed");
                }

                _channel = null;
            }

            if (_connection != null)
            {
                if (_connection.IsOpen)
                {
                    _connection.Close();
                    _logger.LogTrace("RabbitMQConsumer connection closed");
                }

                _connection = null;
            }

            connectCancellationSource.Cancel();
        }

        protected virtual void Dispose(bool disposing)
        {
            if (_isDisposed) return;

            if (disposing)
            {
                Disconnect();
                _configuration.Dispose();
            }
            _isDisposed = true;
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
    }
}
