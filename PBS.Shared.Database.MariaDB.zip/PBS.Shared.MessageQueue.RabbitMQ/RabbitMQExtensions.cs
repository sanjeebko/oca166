﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Audit;
using PBS.Shared.Configuration;
using PBS.Shared.MessageQueue.RabbitMQ.Factory;

namespace PBS.Shared.MessageQueue.RabbitMQ
{
    public static class RabbitMQExtensions
    {
        public static IServiceCollection AddRabbitMQ(this IServiceCollection services)
        {
            services.AddPBSConfigurationValue<MQConfig>("mqservice");
            services.AddTransient<IMQConsumer, RabbitMQConsumer>();
            services.AddTransient<IMQPublisher, RabbitMQPublisher>();
            services.AddTransient<IRabbitMQFactory, RabbitMQFactory>();

            return services;
        }
        
        public static IServiceCollection AddRabbitMQAudit<T>(this IServiceCollection services, string configKey = "database") where T : AuditDataLayer
        {
            services.AddAudit<T>(configKey);
            services.AddRabbitMQ();

            return services;
        }
    }
}
