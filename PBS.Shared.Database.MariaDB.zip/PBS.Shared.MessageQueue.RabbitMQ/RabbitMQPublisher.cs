﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Configuration;
using PBS.Shared.MessageQueue.RabbitMQ.Factory;
using RabbitMQ.Client;
using System;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.MessageQueue.RabbitMQ
{
    public class RabbitMQPublisher : IMQPublisher
    {
        private readonly MQConfig _configuration;
        private readonly MQExchangeConfig _exchangeConfiguration;
        private readonly IRabbitMQFactory _factory;
        private readonly ILogger _logger;
        
        private IConnection? _connection;
        private IModel? _channel;

        public bool Connected { get => _channel?.IsOpen ?? false; }

        public RabbitMQPublisher(IMonitoredConfiguration<MQConfig> configuration, ILogger<RabbitMQPublisher> logger, IRabbitMQFactory connectionFactory)
        {
            if (configuration.Value == null)
            {
                throw new ArgumentNullException(nameof(configuration), "Message Queue configuration has not been specified");
            }
            else if (configuration.Value.Exchange == null)
            {
                throw new ArgumentNullException("configuration.Exchange", "Exchange configuration is not defined");
            }

            _logger = logger;
            _configuration = configuration.Value;
            _exchangeConfiguration = configuration.Value.Exchange;
            _factory = connectionFactory;
        }

        public async Task Connect(CancellationToken cancellationToken)
        {
            if (!Connected)
            {
                try
                {
                    await CreateConnection(cancellationToken);
                    cancellationToken.ThrowIfCancellationRequested();
                }
                catch (OperationCanceledException)
                {
                    Disconnect();
                    throw;
                }
            }
        }

        private async Task CreateConnection(CancellationToken cancellationToken)
        {
            cancellationToken.ThrowIfCancellationRequested();

            var connected = await Task.Run(() =>
            {
                try
                {
                    // create connection  
                    _connection = _factory.CreateConnection(_configuration);

                    // create channel  
                    _channel = _connection.CreateModel();

                    _channel.ExchangeDeclare(_exchangeConfiguration.Name,
                                             _exchangeConfiguration.Type,
                                             _exchangeConfiguration.Durable,
                                             _exchangeConfiguration.AutoDelete);

                    _connection.ConnectionShutdown += RabbitMQ_ConnectionShutdown;
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }, cancellationToken);

            if (!connected)
            {
                cancellationToken.ThrowIfCancellationRequested();
                _logger.LogError("RabbitMQ Service unreachable");

                // Retry
                await Task.Delay(5000, cancellationToken);
                await CreateConnection(cancellationToken);
            }
        }

        private void RabbitMQ_ConnectionShutdown(object? _, ShutdownEventArgs __)
        {
            _logger.LogTrace("Connection with RabbitMQ is closed");
        }

        public void Disconnect()
        {
            _logger.LogTrace("Disconnecting RabbitMQPublisher");

            if (_channel != null)
            {
                if (_channel.IsOpen)
                {
                    _channel.Close();
                    _logger.LogTrace("RabbitMQPublisher channel closed");
                }

                _channel = null;
            }

            if (_connection != null)
            {
                if (_connection.IsOpen)
                {
                    _connection.Close();
                    _logger.LogTrace("RabbitMQPublisher connection closed");
                }

                _connection = null;
            }
        }

        public bool SendToQueue(string message)
        {
            if (!Connected)
            {
                return false;
            }

            var body = Encoding.UTF8.GetBytes(message);
            _channel?.BasicPublish(_exchangeConfiguration.Name, "", body: body);
            return true;
        }

        #region IDisposable Support
        private bool disposedValue = false; // To detect redundant calls

        protected virtual void Dispose(bool disposing)
        {
            if (disposedValue)
            {
                return;
            }

            Disconnect();

            disposedValue = true;
        }

        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
