using RabbitMQ.Client;

namespace PBS.Shared.MessageQueue.RabbitMQ.Factory
{
    public class RabbitMQFactory : IRabbitMQFactory
    {
        public IConnection CreateConnection(MQConfig config, bool AutomaticRecoveryEnabled = true) {
            var factory = new ConnectionFactory
            {
                HostName = config.HostName,
                UserName = config.UserName,
                Password = config.Password,
                Port = config.Port,
                AutomaticRecoveryEnabled = AutomaticRecoveryEnabled,
            };

            return factory.CreateConnection();
        }
    }
}