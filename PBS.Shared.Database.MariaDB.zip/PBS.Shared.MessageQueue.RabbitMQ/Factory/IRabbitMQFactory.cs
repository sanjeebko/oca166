using RabbitMQ.Client;

namespace PBS.Shared.MessageQueue.RabbitMQ.Factory
{
    public interface IRabbitMQFactory
    {
        IConnection CreateConnection(MQConfig config, bool AutomaticRecoveryEnabled = true);
    }
}