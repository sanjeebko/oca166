﻿using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class TemplateWorkerRestriction : WorkerRestriction
    {
        public TemplateWorkerRestriction()
        {
            Type = WorkerRestrictionType.Template;
        }

        [JsonPropertyName("templateName")]
        public string? TemplateName { get; set; }
    }
}
