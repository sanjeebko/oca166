﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class WorkerStepTemplate
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("version")]
        public int Version { get; set; }

        [JsonPropertyName("type")]
        public string? Type { get; set; }

        [JsonPropertyName("category")]
        public string? Category { get; set; }

        [JsonPropertyName("inputs")]
        public List<PropertyFormat> Inputs { get; set; } = new List<PropertyFormat>();

        [JsonPropertyName("outputs")]
        public List<PropertyFormat> Outputs { get; set; } = new List<PropertyFormat>();
    }
}
