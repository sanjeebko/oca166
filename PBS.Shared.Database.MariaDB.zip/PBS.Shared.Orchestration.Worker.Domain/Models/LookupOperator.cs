﻿namespace PBS.Shared.Orchestration.Worker.Models
{
    public enum LookupOperator
    {
        StartsWith,
        EndsWith,
        Contains,
        Equal,
        Like,
        NotEqual,
        GreaterThan,
        GreaterThanOrEqual,
        LessThan,
        LessThanOrEqual,
        RegEx
    }
}
