﻿using System.Text.Json.Serialization;
using PBS.Shared.Json;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class Lookup
    {
        [JsonPropertyName("operator")]
        [JsonConverter(typeof(StringNullableEnumConverter<LookupOperator?>))]
        public LookupOperator? Operator { get; set; }
        [JsonPropertyName("operand")]
        public object? Operand { get; set; }
    }
}