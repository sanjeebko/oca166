﻿using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class WorkerAnnouncement
    {
        [JsonPropertyName("workflowStepTemplates")]
        public IEnumerable<WorkerStepTemplate>? StepTemplates { get; set; }

        [JsonPropertyName("workerCapabilities")]
        public WorkerCapabilities? WorkerCapabilities { get; set; }
    }
}
