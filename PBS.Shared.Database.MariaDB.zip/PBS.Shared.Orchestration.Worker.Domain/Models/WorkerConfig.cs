﻿using PBS.Shared.Orchestration.Worker.Paths;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class WorkerConfig
    {
        private readonly Dictionary<Type, Type> _serviceReplacement = new Dictionary<Type, Type>();

        /// <summary>
        /// Worker name
        /// </summary>
        public string? WorkerName { get; set; }

        /// <summary>
        /// Worker announcement configuration <see cref="WorkerStepTemplate"/> sent to Orchestration Engine
        /// </summary>
        public WorkerAnnouncement WorkerAnnouncement { get; set; } = new WorkerAnnouncement();

        /// <summary>
        /// Worker service path configuration
        /// </summary>
        public ServicePathsConfig? ServicePathsConfig { get; set; }

        /// <summary>
        /// Assemblies where to lookup for tasks and event handler implementations
        /// </summary>
        public IEnumerable<Assembly> ScanAssembly { get; set; } = new List<Assembly>();

        /// <summary>
        /// Orchestration Engine endpoint, defaults to /ws/1/orchestration
        /// </summary>
        public string OrchestrationEngineWebSocketEndpoint { get; set; } = "/ws/1/orchestration";

        /// <summary>
        /// Custom service implementations
        /// </summary>
        public IReadOnlyDictionary<Type, Type> ServiceReplacement => _serviceReplacement;

        /// <summary>
        /// Replaces default/existing services by custom implementations
        /// </summary>
        /// <typeparam name="TService">Service to replace</typeparam>
        /// <typeparam name="TImplementation">New service implementation</typeparam>
        public void ReplaceService<TService, TImplementation>() where TService : class where TImplementation : class, TService
        {
            _serviceReplacement.Add(typeof(TService), typeof(TImplementation));
        }
    }
}
