﻿namespace PBS.Shared.Orchestration.Worker.Models
{
    public static class WorkerStepTemplateCategory
    {
        public const string Demo = "Demo";
        public const string File = "File";
    }
}
