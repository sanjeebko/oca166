﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using PBS.Shared.Orchestration.Worker.Restrictions;
using PBS.Shared.Json;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class Restriction : IRestrictionTypeProvider
    {
        [JsonPropertyName("type")]
        [JsonConverter(typeof(StringNullableEnumConverter<RestrictionType?>))]
        public RestrictionType? Type { get; set; }

        [JsonPropertyName("properties")]
        public Dictionary<string, object>? Properties { get; set; }

        public string? GetRestrictionType()
        {
            return Type?.ToString();
        }
    }
}