﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using PBS.Shared.Orchestration.Worker.Restrictions;
using PBS.Shared.Json;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class WorkerRestriction : IWorkerRestrictionTypeProvider
    {
        [JsonPropertyName("type")]
        [JsonConverter(typeof(StringNullableEnumConverter<WorkerRestrictionType?>))]
        public WorkerRestrictionType? Type { get; set; }

        [JsonPropertyName("properties")]
        public Dictionary<string, object>? Properties { get; set; }

        [JsonPropertyName("restrictions")]
        [JsonConverter(typeof(RestrictionCollectionJsonConverter))]
        public List<Restriction> Restrictions { get; set; } = new List<Restriction>();

        public string? GetRestrictionType()
        {
            return Type?.ToString();
        }
    }
}