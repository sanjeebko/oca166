﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using PBS.Shared.Orchestration.Worker.Restrictions;

namespace PBS.Shared.Orchestration.Worker.Models
{
    public class WorkerCapabilities
    {
        [JsonPropertyName("workerProperties")]
        public Dictionary<string, object>? WorkerProperties { get; set; }

        [JsonPropertyName("workerRestrictions")]
        [JsonConverter(typeof(WorkerRestrictionCollectionJsonConverter))]
        public List<WorkerRestriction>? WorkerRestrictions { get; set; } = new List<WorkerRestriction>();
    }
}
