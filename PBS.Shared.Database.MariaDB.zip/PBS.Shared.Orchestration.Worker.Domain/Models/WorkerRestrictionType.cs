﻿namespace PBS.Shared.Orchestration.Worker.Models
{
    public enum WorkerRestrictionType
    {
        Template
    }
}
