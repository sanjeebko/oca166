﻿namespace PBS.Shared.Orchestration.Worker.Models
{
    public static class WorkerStepTemplateType
    {
        public const string Action = "Action";
        public const string Logical = "Logical";
    }
}
