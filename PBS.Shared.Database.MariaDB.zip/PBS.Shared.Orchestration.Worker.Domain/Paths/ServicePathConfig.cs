﻿using System.Collections.Generic;

namespace PBS.Shared.Orchestration.Worker.Paths
{
    public class ServicePathConfig
    {
        public IEnumerable<string>? Paths { get; set; }
        public string? Host { get; set; }
        public int? Port { get; set; }
    }
}