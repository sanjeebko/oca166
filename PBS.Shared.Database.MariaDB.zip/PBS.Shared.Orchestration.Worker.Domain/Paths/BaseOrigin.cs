﻿namespace PBS.Shared.Orchestration.Worker.Paths
{
    public class BaseOrigin
    {
        public string? Host { get; set; }
        public int? Port { get; set; }
    }
}