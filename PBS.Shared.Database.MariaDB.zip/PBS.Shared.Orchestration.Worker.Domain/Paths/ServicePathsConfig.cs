﻿using System.Collections.Generic;

namespace PBS.Shared.Orchestration.Worker.Paths
{
    public class ServicePathsConfig
    {
        public bool Enabled { get; set; }
        public BaseOrigin? Base { get; set; }
        public IEnumerable<ServicePathConfig>? DevelopmentPaths { get; set; } = new List<ServicePathConfig>();
    }
}