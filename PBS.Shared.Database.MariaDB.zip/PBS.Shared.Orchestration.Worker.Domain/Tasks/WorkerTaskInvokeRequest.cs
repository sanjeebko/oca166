﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public class WorkerTaskInvokeRequest
    {
        [JsonPropertyName("stepTemplateName")]
        public string? StepTemplateName { get; set; }

        [JsonPropertyName("stepInstanceId")]
        public string? StepInstanceId { get; set; }

        [JsonPropertyName("inputs")]
        public Dictionary<string, PropertyValue> Inputs { get; set; } = new Dictionary<string, PropertyValue>();
    }
}
