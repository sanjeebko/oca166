﻿using PBS.Shared.PropertyTypeFormats;
using System;
using System.Collections.Generic;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public class WorkerTaskInvokeResult
    {
        [JsonPropertyName("status")]
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public WorkerTaskInvokeRequestStatus Status { get; set; }

        [JsonPropertyName("errors")]
        public List<string> Errors { get; set; } = new List<string>();

        [JsonPropertyName("output")]
        public Dictionary<string, PropertyValue> Output { get; set; } = new Dictionary<string, PropertyValue>();

        [JsonPropertyName("startedTimestamp")]
        public DateTimeOffset StartedTimestamp { get; set; } = DateTimeOffset.UtcNow;

        [JsonPropertyName("completedTimestamp")]
        public DateTimeOffset? CompletedTimestamp { get; set; }
    }
}
