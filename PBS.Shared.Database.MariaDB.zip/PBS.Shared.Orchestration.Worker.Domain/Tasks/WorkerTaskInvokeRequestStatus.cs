﻿namespace PBS.Shared.Orchestration.Worker.Tasks
{
    public enum WorkerTaskInvokeRequestStatus
    {
        Success,
        NonFatal,
        Failed        
    }
}
