﻿using System.Collections.Generic;
using System.Text.Json.Serialization;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions
{
    public class InputLookupRestriction : Restriction
    {
        public InputLookupRestriction()
        {
            Type = RestrictionType.InputLookup;
        }

        [JsonPropertyName("inputName")]
        public string? InputName { get; set; }

        [JsonPropertyName("lookups")]
        public List<Lookup> Lookups { get; set; } = new List<Lookup>();
    }
}
