﻿using PBS.Shared.Orchestration.Worker.Extensions;
using System;
using System.Collections.Concurrent;
using System.Reflection;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class RestrictionValidatorLookup : IRestrictionValidatorLookup
    {
        private readonly ConcurrentDictionary<string, IRestrictionValidator> _cache = new ConcurrentDictionary<string, IRestrictionValidator>();

        public void AddFromAssembly(params Assembly?[] assemblies)
        {
            foreach (Assembly? assembly in assemblies)
            {
                if (assembly == null) continue;
                foreach (Type implementationType in assembly.GetAllTypesImplementing<IRestrictionValidator>())
                {
                    var validator = (IRestrictionValidator?)Activator.CreateInstance(implementationType);
                    if (validator == null)
                        continue;

                    if (!_cache.ContainsKey(validator.GetSupportedType()))
                    {
                        _cache.GetOrAdd(validator.GetSupportedType(), validator);
                    }
                }
            }
        }

        public void Add<T>(string type) where T : IRestrictionValidator
        {
            AddInternal(typeof(T), type);
        }

        public void Replace<T>(string type) where T : IRestrictionValidator
        {
            ReplaceInternal(typeof(T), type);
        }

        public IRestrictionValidator? Get(string? type)
        {
            if (string.IsNullOrEmpty(type))
                return null;

            return _cache.TryGetValue(type, out IRestrictionValidator? validator) ? validator : null;
        }

        private void AddInternal(Type restrictionType, string type)
        {
            if (!_cache.ContainsKey(type))
            {
                _cache.GetOrAdd(type, CreateAndValidateValidator(restrictionType, type));
            }
        }

        private void ReplaceInternal(Type restrictionType, string type)
        {
            if (_cache.ContainsKey(type) && _cache[type].GetType() != restrictionType)
            {
                _cache[type] = CreateAndValidateValidator(restrictionType, type);
            }
        }

        private static IRestrictionValidator CreateAndValidateValidator(Type restrictionType, string type)
        {
            var validator = (IRestrictionValidator?)Activator.CreateInstance(restrictionType);

            if (validator?.GetSupportedType() != type)
                throw new InvalidOperationException($"{restrictionType.FullName} supported restriction type {validator?.GetSupportedType()} is different from passed type {type}");

            return validator;
        }
    }
}