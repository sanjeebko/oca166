﻿using System;
using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class InputLookupRestrictionValidator : RestrictionValidator
    {
        public override void Validate(Restriction restriction)
        {
            if (restriction is InputLookupRestriction inputLookupRestriction)
            {
                if (string.IsNullOrEmpty(inputLookupRestriction.InputName))
                {
                    throw new ArgumentNullException("restriction.InputName", "restriction.InputName is not defined");
                }

                foreach (Lookup lookup in inputLookupRestriction.Lookups)
                {
                    if (lookup.Operand == null || string.IsNullOrWhiteSpace(lookup.Operand?.ToString()))
                        throw new ArgumentException("lookup must have an Operand");
                    if (lookup.Operator == null)
                        throw new ArgumentException("lookup must have an Operator");
                }

                base.Validate(restriction);
            }
            else
            {
                throw new NotSupportedException($"Validation not supported for {restriction.GetType().Name}");
            }
        }

        protected override void ValidateRestrictionProperties(Dictionary<string, object>? restrictionProperties)
        {
        }

        public override string GetSupportedType()
        {
            return RestrictionType.InputLookup.ToString();
        }
    }
}