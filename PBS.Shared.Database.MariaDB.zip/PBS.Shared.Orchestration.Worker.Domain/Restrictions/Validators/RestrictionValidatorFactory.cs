﻿using System;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class RestrictionValidatorFactory : IRestrictionValidatorFactory
    {
        private readonly IRestrictionValidatorLookup _restrictionValidatorLookup;

        public RestrictionValidatorFactory(IRestrictionValidatorLookup restrictionValidatorLookup)
        {
            _restrictionValidatorLookup = restrictionValidatorLookup;
        }

        public IRestrictionValidator GetValidatorFor(IRestrictionTypeProvider restrictionTypeProvider)
        {
            string? restrictionType = restrictionTypeProvider.GetRestrictionType();

            if (string.IsNullOrEmpty(restrictionType))
                throw new ArgumentException("Type");

            IRestrictionValidator? validator = _restrictionValidatorLookup.Get(restrictionType);

            if(validator == null)
                throw new NotImplementedException(restrictionType);

            return validator;
        }
    }
}