﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IWorkerRestrictionValidator
    {
        void Validate(WorkerRestriction workerRestriction);

        string GetSupportedType();
    }
}