﻿namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IRestrictionValidatorFactory
    {
        IRestrictionValidator GetValidatorFor(IRestrictionTypeProvider restrictionTypeProvider);
    }
}