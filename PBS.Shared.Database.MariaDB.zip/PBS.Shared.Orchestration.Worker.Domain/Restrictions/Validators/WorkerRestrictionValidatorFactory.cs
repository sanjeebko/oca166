﻿using System;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class WorkerRestrictionValidatorFactory : IWorkerRestrictionValidatorFactory
    {
        private readonly IWorkerRestrictionValidatorLookup _workerRestrictionValidatorLookup;

        public WorkerRestrictionValidatorFactory(IWorkerRestrictionValidatorLookup workerRestrictionValidatorLookup)
        {
            _workerRestrictionValidatorLookup = workerRestrictionValidatorLookup;
        }

        public IWorkerRestrictionValidator GetValidatorFor(IWorkerRestrictionTypeProvider workerRestrictionTypeProvider)
        {
            if(string.IsNullOrEmpty(workerRestrictionTypeProvider.GetRestrictionType()))
                throw new ArgumentException("Type");

            IWorkerRestrictionValidator? validatorInstance = _workerRestrictionValidatorLookup.Get(workerRestrictionTypeProvider.GetRestrictionType());

            if(validatorInstance == null)
                throw new NotImplementedException(workerRestrictionTypeProvider.GetRestrictionType());

            return validatorInstance;
        }
    }
}