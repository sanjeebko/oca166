﻿using System;
using System.Collections.Concurrent;
using System.Reflection;
using PBS.Shared.Orchestration.Worker.Extensions;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class WorkerRestrictionValidatorLookup : IWorkerRestrictionValidatorLookup
    {
        private readonly IRestrictionValidatorFactory _restrictionValidatorFactory;
        private readonly ConcurrentDictionary<string, IWorkerRestrictionValidator> _cache;

        public WorkerRestrictionValidatorLookup(IRestrictionValidatorFactory restrictionValidatorFactory)
        {
            _restrictionValidatorFactory = restrictionValidatorFactory;
            _cache = new ConcurrentDictionary<string, IWorkerRestrictionValidator>();
        }

        public void AddFromAssembly(params Assembly?[] assemblies)
        {
            foreach (Assembly? assembly in assemblies)
            {
                if (assembly == null) continue;
                foreach (Type implementationType in assembly.GetAllTypesImplementing<IWorkerRestrictionValidator>())
                {
                    IWorkerRestrictionValidator? validator = (IWorkerRestrictionValidator?)Activator.CreateInstance(implementationType, _restrictionValidatorFactory);
                    if (validator == null) continue;
                    if (!_cache.ContainsKey(validator.GetSupportedType()))
                    {
                        _cache.GetOrAdd(validator.GetSupportedType(), validator);
                    }
                }
            }
        }

        public void Add<T>(string type) where T: IWorkerRestrictionValidator
        {
            AddInternal(typeof(T), type);
        }

        public void Replace<T>(string type) where T : IWorkerRestrictionValidator
        {
            ReplaceInternal(typeof(T), type);
        }

        public IWorkerRestrictionValidator? Get(string? type)
        {
            if (string.IsNullOrEmpty(type))
                return null;

            return _cache.TryGetValue(type, out IWorkerRestrictionValidator? validator) ? validator : null;
        }

        private void AddInternal(Type workerRestrictionType, string type)
        {
            if (!_cache.ContainsKey(type))
            {
                _cache.GetOrAdd(type, CreateAndValidateValidator(workerRestrictionType, type));
            }
        }

        private void ReplaceInternal(Type workerRestrictionType, string type)
        {
            if (_cache.ContainsKey(type) && _cache[type].GetType() != workerRestrictionType)
            {
                _cache[type] = CreateAndValidateValidator(workerRestrictionType, type);
            }
        }

        private IWorkerRestrictionValidator CreateAndValidateValidator(Type workerRestrictionType, string type) 
        {
            IWorkerRestrictionValidator? validator = (IWorkerRestrictionValidator?) Activator.CreateInstance(workerRestrictionType, _restrictionValidatorFactory);

            if (validator?.GetSupportedType() != type)
                throw new InvalidOperationException($"{workerRestrictionType.FullName} supported restriction type {validator?.GetSupportedType()} is different from passed type {type}");

            return validator;
        }
    }
}
