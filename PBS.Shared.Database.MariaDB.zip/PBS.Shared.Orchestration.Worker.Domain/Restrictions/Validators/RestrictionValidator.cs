﻿using System;
using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public abstract class RestrictionValidator : IRestrictionValidator
    {
        public virtual void Validate(Restriction restriction)
        {
            if (restriction.Type == null)
                throw new ArgumentNullException("restriction.Type", "restriction.Type is not defined");

            ValidateRestrictionProperties(restriction.Properties);
        }

        protected abstract void ValidateRestrictionProperties(Dictionary<string, object>? restrictionProperties);

        public abstract string GetSupportedType();
    }
}