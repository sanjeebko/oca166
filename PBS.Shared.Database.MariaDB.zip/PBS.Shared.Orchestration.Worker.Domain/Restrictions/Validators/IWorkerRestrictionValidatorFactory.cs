﻿namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IWorkerRestrictionValidatorFactory
    {
        IWorkerRestrictionValidator GetValidatorFor(IWorkerRestrictionTypeProvider workerRestrictionTypeProvider);
    }
}
