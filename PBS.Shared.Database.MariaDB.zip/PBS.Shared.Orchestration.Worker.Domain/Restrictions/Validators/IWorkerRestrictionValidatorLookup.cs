﻿using System.Reflection;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IWorkerRestrictionValidatorLookup
    {
        void AddFromAssembly(params Assembly?[] assemblies);
        void Add<T>(string type) where T: IWorkerRestrictionValidator;
        void Replace<T>(string type) where T : IWorkerRestrictionValidator;
        IWorkerRestrictionValidator? Get(string? type);
    }
}