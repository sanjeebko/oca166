﻿using System.Reflection;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IRestrictionValidatorLookup
    {
        void AddFromAssembly(params Assembly?[] assemblies);

        void Add<T>(string type) where T : IRestrictionValidator;

        void Replace<T>(string type) where T : IRestrictionValidator;

        IRestrictionValidator? Get(string? type);
    }
}