﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public interface IRestrictionValidator
    {
        void Validate(Restriction restriction);

        string GetSupportedType();
    }
}
