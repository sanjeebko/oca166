﻿using System;
using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public abstract class WorkerRestrictionValidator : IWorkerRestrictionValidator
    {
        private readonly IRestrictionValidatorFactory _restrictionValidatorFactory;

        protected WorkerRestrictionValidator(IRestrictionValidatorFactory restrictionValidatorFactory)
        {
            _restrictionValidatorFactory = restrictionValidatorFactory;
        }

        public virtual void Validate(WorkerRestriction workerRestriction)
        {
            ValidateProperties(workerRestriction.Properties);

            foreach (Restriction restriction in workerRestriction.Restrictions)
            {
                if (restriction.Type == null)
                    throw new ArgumentException("Restriction must have a Type");

                _restrictionValidatorFactory.GetValidatorFor(restriction)?.Validate(restriction);
            }
        }

        protected abstract void ValidateProperties(Dictionary<string, object>? workerRestrictionProperties);

        public abstract string GetSupportedType();
    }
}