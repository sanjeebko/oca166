﻿using System;
using System.Collections.Generic;
using System.Text.Json;
using PBS.Shared.Orchestration.Worker.Extensions;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public static class ValidatorExtensions
    {
        public static void ValidateNotFoundOrNull(string propertyName, Dictionary<string, object> properties)
        {
            if(!properties.TryGetValue(propertyName, out object? value))
                throw new KeyNotFoundException($"Missing property {propertyName}");
            if (value == null)
                throw new ArgumentException($"Property {propertyName} value is empty");
        }

        public static T? GetObject<T>(string propertyName, Dictionary<string, object> properties) where T : class
        {
            if (properties.TryGetValue(propertyName, out object? value))
            {
                if (value is T obj)
                {
                    return obj;
                }

                if (value is JsonElement jsonElement)
                {
                    return jsonElement.ToObject<T>();
                }

                throw new ArgumentException($"{propertyName} value is empty");
            }

            throw new KeyNotFoundException($"Missing property {propertyName}");
        }
    }
}
