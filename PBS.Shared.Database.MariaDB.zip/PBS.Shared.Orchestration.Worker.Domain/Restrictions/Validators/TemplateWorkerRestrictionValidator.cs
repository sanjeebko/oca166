﻿using System;
using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Restrictions.Validators
{
    public class TemplateWorkerRestrictionValidator : WorkerRestrictionValidator
    {
        public TemplateWorkerRestrictionValidator(IRestrictionValidatorFactory restrictionValidatorFactory):base(restrictionValidatorFactory)
        {
        }

        public override void Validate(WorkerRestriction workerRestriction)
        {
            if (workerRestriction is TemplateWorkerRestriction templateWorkerRestriction)
            {
                if(string.IsNullOrEmpty(templateWorkerRestriction.TemplateName))
                    throw new ArgumentNullException("workerRestriction.TemplateName", "workerRestriction.TemplateName is not defined");
                base.Validate(workerRestriction);
            }
            else
            {
                throw new NotSupportedException($"Validation not supported for {workerRestriction.GetType().Name}");
            }

        }

        protected override void ValidateProperties(Dictionary<string, object>? workerRestrictionProperties)
        {
        }

        public override string GetSupportedType()
        {
            return WorkerRestrictionType.Template.ToString();
        }
    }
}