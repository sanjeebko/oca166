﻿namespace PBS.Shared.Orchestration.Worker.Restrictions
{
    public interface IRestrictionTypeProvider
    {
        string? GetRestrictionType();
    }
}