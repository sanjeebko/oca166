﻿namespace PBS.Shared.Orchestration.Worker.Restrictions
{
    public interface IWorkerRestrictionTypeProvider
    {
        public string? GetRestrictionType();
    }
}