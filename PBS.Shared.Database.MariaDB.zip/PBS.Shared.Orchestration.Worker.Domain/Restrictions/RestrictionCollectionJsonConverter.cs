﻿using System;
using System.Text.Json;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Json;

namespace PBS.Shared.Orchestration.Worker.Restrictions
{
    public class RestrictionCollectionJsonConverter : PolymorphicCollectionJsonConverter<Restriction>
    {
        static readonly JsonSerializerOptions objectConverterOptions = new JsonSerializerOptions
        {
            IgnoreNullValues = true,
            WriteIndented = false
        };

        static RestrictionCollectionJsonConverter()
        {
            objectConverterOptions.Converters.Add(new JsonObjectConverter());
        }

        protected override Restriction? Read(ref Utf8JsonReader reader, JsonSerializerOptions? options = null)
        {
            using JsonDocument doc = JsonDocument.ParseValue(ref reader);

            string rawText = doc.RootElement.GetRawText();

            if (doc.RootElement.TryGetProperty(@"type", out JsonElement typeVal))
            {
                string? type = typeVal.GetString();

                if (!string.IsNullOrEmpty(type) && Enum.TryParse(type, out RestrictionType restrictionType))
                {
                    switch (restrictionType)
                    {
                        case RestrictionType.InputLookup:
                            return JsonSerializer.Deserialize<InputLookupRestriction>(rawText, options);
                    }
                }
            }

            return JsonSerializer.Deserialize<Restriction>(rawText, options);
        }

        protected override JsonSerializerOptions GetReadWriteJsonOptions()
        {
            return objectConverterOptions;
        }
    }
}
