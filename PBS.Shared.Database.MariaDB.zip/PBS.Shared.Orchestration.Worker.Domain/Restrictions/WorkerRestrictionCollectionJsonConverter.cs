﻿using System;
using System.Text.Json;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Json;

namespace PBS.Shared.Orchestration.Worker.Restrictions
{
    public class WorkerRestrictionCollectionJsonConverter : PolymorphicCollectionJsonConverter<WorkerRestriction>
    {
        static readonly JsonSerializerOptions objectConverterOptions = new JsonSerializerOptions
        {
            IgnoreNullValues = true,
            WriteIndented = false
        };

        static WorkerRestrictionCollectionJsonConverter()
        {
            objectConverterOptions.Converters.Add(new JsonObjectConverter());
        }

        protected override WorkerRestriction? Read(ref Utf8JsonReader reader, JsonSerializerOptions? options = null)
        {
            using JsonDocument doc = JsonDocument.ParseValue(ref reader);

            string rawText = doc.RootElement.GetRawText();

            if (doc.RootElement.TryGetProperty(@"type", out JsonElement typeVal))
            {
                string? type = typeVal.GetString();

                if (!string.IsNullOrEmpty(type) && Enum.TryParse(type, out WorkerRestrictionType restrictionType))
                {
                    switch (restrictionType)
                    {
                        case WorkerRestrictionType.Template:
                            return JsonSerializer.Deserialize<TemplateWorkerRestriction>(rawText, options);
                    }
                }
            }

            return JsonSerializer.Deserialize<WorkerRestriction>(rawText, options);
        }

        protected override JsonSerializerOptions GetReadWriteJsonOptions()
        {
            return objectConverterOptions;
        }
    }
}
