﻿using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.PropertyTypeFormats;
using System;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public class WorkerStepTemplatesValidator : IWorkerStepTemplatesValidator
    {
        public void Validate(WorkerStepTemplate workerStepTemplate)
        {
            if (string.IsNullOrEmpty(workerStepTemplate.Name))
                throw new ArgumentNullException("workerStepTemplate.Name", "workerStepTemplate.Name is not defined");
            if (string.IsNullOrEmpty(workerStepTemplate.Type))
                throw new ArgumentNullException("workerStepTemplate.Type", "workerStepTemplate.Type is not defined");
            if (string.IsNullOrEmpty(workerStepTemplate.Category))
                throw new ArgumentNullException("workerStepTemplate.Category", "workerStepTemplate.Category is not defined");
            if (workerStepTemplate.Version == 0)
                throw new ArgumentException($"{workerStepTemplate.Name} - {nameof(workerStepTemplate.Version)} cannot be zero");

            foreach (PropertyFormat propertyFormat in workerStepTemplate.Inputs)
                ValidatePropertyFormat(workerStepTemplate.Name, propertyFormat);

            foreach (PropertyFormat propertyFormat in workerStepTemplate.Outputs)
                ValidatePropertyFormat(workerStepTemplate.Name, propertyFormat);
        }

        private static void ValidatePropertyFormat(string stepTemplateName, PropertyFormat propertyFormat)
        {
            if (string.IsNullOrEmpty(propertyFormat.Name))
                throw new ArgumentException($"{stepTemplateName} - missing {nameof(propertyFormat.Name)} property");
            if (propertyFormat.Types.IsNullOrEmpty())
                throw new ArgumentException($"{stepTemplateName} - missing {nameof(propertyFormat.Types)} property");
        }
    }
}
