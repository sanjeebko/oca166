﻿using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Restrictions.Validators;
using System;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public class WorkerCapabilitiesValidator : IWorkerCapabilitiesValidator
    {
        private readonly IWorkerRestrictionValidatorFactory _workerRestrictionValidatorFactory;

        public WorkerCapabilitiesValidator(IWorkerRestrictionValidatorFactory workerRestrictionValidatorFactory)
        {
            _workerRestrictionValidatorFactory = workerRestrictionValidatorFactory;
        }

        public void Validate(WorkerCapabilities workerCapabilities)
        {
            if (workerCapabilities.WorkerRestrictions != null)
            {
                foreach (WorkerRestriction workerRestriction in workerCapabilities.WorkerRestrictions)
                {
                    if (workerRestriction.Type == null)
                        throw new ArgumentException("WorkerRestriction must have a Type");

                    _workerRestrictionValidatorFactory.GetValidatorFor(workerRestriction)?.Validate(workerRestriction);
                }
            }
        }
    }
}
