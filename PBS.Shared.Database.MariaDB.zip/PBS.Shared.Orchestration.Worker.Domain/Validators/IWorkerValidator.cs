﻿namespace PBS.Shared.Orchestration.Worker.Validators
{
    public interface IWorkerValidator
    {
    }
}
