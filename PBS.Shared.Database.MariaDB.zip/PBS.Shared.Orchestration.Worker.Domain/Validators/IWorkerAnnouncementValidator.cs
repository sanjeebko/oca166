﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public interface IWorkerAnnouncementValidator : IWorkerValidator
    {
        void Validate(WorkerAnnouncement workerAnnouncement);
    }
}