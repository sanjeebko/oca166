﻿using System;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public class WorkerConfigValidator : IWorkerConfigValidator
    {
        private readonly IWorkerAnnouncementValidator _workerAnnouncementValidator;

        public WorkerConfigValidator(IWorkerAnnouncementValidator workerAnnouncementValidator)
        {
            _workerAnnouncementValidator = workerAnnouncementValidator;
        }

        public void Validate(WorkerConfig config)
        {
            if (string.IsNullOrEmpty(config.WorkerName))
                throw new ArgumentNullException("config.WorkerName", "config.WorkerName is not defined");

            if (string.IsNullOrEmpty(config.OrchestrationEngineWebSocketEndpoint))
                throw new ArgumentNullException("config.OrchestrationEngineWebSocketEndpoint", "config.OrchestrationEngineWebSocketEndpoint is not defined");

            if (config.ScanAssembly == null)
                throw new ArgumentNullException("config.ScanAssembly", "config.ScanAssembly is not defined");

            if (config.WorkerAnnouncement == null)
                throw new ArgumentNullException("config.WorkerAnnouncement", "config.WorkerAnnouncement is not defined");

            _workerAnnouncementValidator.Validate(config.WorkerAnnouncement);
        }
    }
}
