﻿using System;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public class WorkerAnnouncementValidator : IWorkerAnnouncementValidator
    {
        private readonly IWorkerStepTemplatesValidator _workerStepTemplatesValidator;
        private readonly IWorkerCapabilitiesValidator _workerCapabilitiesValidator;

        public WorkerAnnouncementValidator(IWorkerStepTemplatesValidator workerStepTemplatesValidator, IWorkerCapabilitiesValidator workerCapabilitiesValidator)
        {
            _workerStepTemplatesValidator = workerStepTemplatesValidator;
            _workerCapabilitiesValidator = workerCapabilitiesValidator;
        }

        public void Validate(WorkerAnnouncement workerAnnouncement)
        {
            if (workerAnnouncement.StepTemplates.IsNullOrEmpty())
                throw new ArgumentNullException("workerAnnouncement.StepTemplates", "workerAnnouncement.StepTemplates is not defined");
            
            foreach (var stepTemplate in workerAnnouncement.StepTemplates!)
                _workerStepTemplatesValidator.Validate(stepTemplate);
            
            if(workerAnnouncement.WorkerCapabilities != null)
                _workerCapabilitiesValidator.Validate(workerAnnouncement.WorkerCapabilities);
        }
    }
}
