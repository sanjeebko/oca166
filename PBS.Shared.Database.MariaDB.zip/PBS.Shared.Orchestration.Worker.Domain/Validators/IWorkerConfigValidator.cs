﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Validators
{
    public interface IWorkerConfigValidator : IWorkerValidator
    {
        void Validate(WorkerConfig config);
    }
}