﻿using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerEnumerableExtensions
    {
        public static bool IsNullOrEmpty<T>(this IEnumerable<T>? collection)
        {
            if (collection == null)
                return true;
            return !collection.Any();
        }
    }
}
