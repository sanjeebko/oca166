﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using System.Text.Json;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerPropertyValuesJsonResolver
    {
        public static void Resolve(Dictionary<string, PropertyValue>? values)
        {
            if (values is null)
                return;
            foreach (string key in values.Keys)
                ResolvePropertyValueJsonElements(values[key]);
        }

        private static void ResolvePropertyValueJsonElements(PropertyValue? propertyValue)
        {
            if (propertyValue?.Value is not JsonElement { ValueKind: JsonValueKind.Object } jsonElement)
                return;

            var inputs = jsonElement.ToObject<Dictionary<string, PropertyValue>>();
            propertyValue.Value = inputs;

            if (inputs is null)
                return;

            foreach (string inputName in inputs.Keys)
                ResolvePropertyValueJsonElements(inputs[inputName]);
        }
    }
}
