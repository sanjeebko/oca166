﻿using PBS.Shared.Orchestration.Worker.Tasks;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerTaskInvokeRequestExtensions
    {
        public static WorkerTaskInvokeRequest? Deserialize(string? value)
        {
            var request = WorkerJsonExtensions.Deserialize<WorkerTaskInvokeRequest>(value);
            WorkerPropertyValuesJsonResolver.Resolve(request?.Inputs);
            return request;
        }

        public static string Serialize(this WorkerTaskInvokeRequest request)
        {
            return WorkerJsonExtensions.Serialize(request);
        }
    }
}
