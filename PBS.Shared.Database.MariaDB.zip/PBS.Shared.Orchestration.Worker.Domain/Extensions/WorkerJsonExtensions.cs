﻿using PBS.Shared.Json;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerJsonExtensions
    {
        public static readonly JsonSerializerOptions DefaultJsonSerializerOptions = new JsonSerializerOptions
        {
            IgnoreNullValues = true,
            WriteIndented = false
        };

        static WorkerJsonExtensions()
        {
            DefaultJsonSerializerOptions.Converters.Add(new SystemObjectNewtonsoftCompatibleConverter());
            DefaultJsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
        }

        public static T? ToObject<T>(this JsonElement element, JsonSerializerOptions? options = null)
        {
            return Deserialize<T>(element.GetRawText(), options);
        }

        public static T? ToObject<T>(this JsonDocument document, JsonSerializerOptions? options = null)
        {
            return Deserialize<T>(document.RootElement.GetRawText(), options);
        }

        public static string Serialize<T>(T value, JsonSerializerOptions? options = null)
        {
            return JsonSerializer.Serialize(value, options ?? DefaultJsonSerializerOptions);
        }

        public static T? Deserialize<T>(string? value, JsonSerializerOptions? options = null)
        {
            return string.IsNullOrEmpty(value) ? default : JsonSerializer.Deserialize<T>(value, options ?? DefaultJsonSerializerOptions);
        }
    }
}
