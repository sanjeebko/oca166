﻿using PBS.Shared.Orchestration.Worker.Models;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerAnnounceExtensions
    {
        public static string Serialize(this WorkerAnnouncement announcement)
        {
            return WorkerJsonExtensions.Serialize(announcement);
        }

        public static WorkerAnnouncement? Deserialize(string value)
        {
            return WorkerJsonExtensions.Deserialize<WorkerAnnouncement>(value);
        }
    }
}
