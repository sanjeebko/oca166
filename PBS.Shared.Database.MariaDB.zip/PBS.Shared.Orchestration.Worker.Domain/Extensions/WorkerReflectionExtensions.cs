﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace PBS.Shared.Orchestration.Worker.Extensions
{
    public static class WorkerReflectionExtensions
    {
        public static IEnumerable<Type> GetAllTypesImplementing<T>(this Assembly assembly)
        {
            return assembly.GetTypes().Where(s => !s.IsAbstract && !s.IsInterface && typeof(T).IsAssignableFrom(s));
        }

        public static IEnumerable<Type> GetAllTypesImplementing<T>()
        {
            return Assembly.GetExecutingAssembly().GetAllTypesImplementing<T>();
        }
    }
}
