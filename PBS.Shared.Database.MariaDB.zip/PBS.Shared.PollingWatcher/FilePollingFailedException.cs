﻿using System;
using System.Runtime.Serialization;

namespace PBS.Shared.PollingWatcher
{
    public enum RemotePollingFailState
    {
        NetworkAttemptingRecovery,
        NetworkFatal,
        UnknownFatal
    }

    [Serializable]
    public class FilePollingFailedException : Exception
    {
        public RemotePollingFailState FailState { get; private set; }
        public FilePollingFailedException()
        {
        }

        public FilePollingFailedException(RemotePollingFailState failState , string message) : base(message)
        {
            FailState = failState;
        }

        public FilePollingFailedException(RemotePollingFailState failState, string message, Exception inner) : base(message, inner)
        {
            FailState = failState;
        }

        protected FilePollingFailedException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
