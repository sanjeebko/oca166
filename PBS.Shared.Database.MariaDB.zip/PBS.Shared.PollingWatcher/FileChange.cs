﻿using System;

namespace PBS.Shared.PollingWatcher
{

    public enum PollingWatcherChangeTypes
    {
        Created,
        Deleted,
        Updated,
        UpdatedAndIsWriteable
    }

    public struct FileChange
    {
        public FileChange(string directory, string path, PollingWatcherChangeTypes type, DateTimeOffset dateTimeOffset, long size, string networkPath = "")
        {
            Directory = directory;
            Name = path;
            ChangeType = type;
            NetworkPath = networkPath;
            LastWriteTimeUtc = dateTimeOffset;
            Size = size;
        }

        public string Directory { get; }
        public string Name { get; }
        public string NetworkPath { get;}
        public PollingWatcherChangeTypes ChangeType { get; }
        public DateTimeOffset LastWriteTimeUtc { get; }
        public long Size { get; }

    }
}    
