﻿using System;

namespace PBS.Shared.PollingWatcher
{
    public class RemoteSharePollingErrorEventArgs : EventArgs
    {
        public RemoteSharePollingErrorEventArgs(Exception e, RemotePollingFailState failState)
        {
            RootException = e;
            FailState = failState;
        }

        public Exception RootException { get; private set; }
        public RemotePollingFailState FailState { get; private set; }
    }
}
