﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.RemoteShare.Extensions;

namespace PBS.Shared.PollingWatcher
{
    public static class PollingWatcherExtensions
    {
        public static IServiceCollection AddPollingWatcher(this IServiceCollection services)
        {
            services.AddRemoteShare();
            services.AddTransient<IPollingFileSystemWatcher, PollingFileSystemWatcher>();
            services.AddTransient<IPollingFileSystemRemoteShareWatcher, PollingFileSystemRemoteWatcher>();
            return services;
        }
    }
}
