﻿using System;
using System.IO;
namespace PBS.Shared.PollingWatcher
{
    public interface IPollingFileSystemWatcher : IDisposable
    {
        EnumerationOptions EnumerationOptions { get; set; }
        
        public string Filter { get; set; }
        
        public string Path { get; set; }
        
        int PollingInterval { get; set; }

        void Start(string path, string filter = "*", bool useSubdirectories = false, int pollingInterval = 30000, string networkPath = "");

        void Restart();

        event PollingFileSystemEventHandler Changes;

        event ErrorEventHandler Error;
    }
}