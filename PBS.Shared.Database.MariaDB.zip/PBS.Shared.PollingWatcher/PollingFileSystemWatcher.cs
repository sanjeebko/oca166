﻿// Licensed to the .NET Foundation under one or more agreements.
// The .NET Foundation licenses this file to you under the MIT license.
// See the LICENSE file in the project root for more information.

using System.IO.Enumeration;
using System.Threading;
using System.Threading.Tasks;
using System;
using System.IO;
using Microsoft.Extensions.Logging;
using System.Diagnostics;

namespace PBS.Shared.PollingWatcher
{
    [Serializable]
    public class PollingFileSystemWatcher : IPollingFileSystemWatcher
    {
        private readonly ILogger<PollingFileSystemWatcher> _logger;
        private Timer? _timer;
        private PathToFileStateHashtable _state = new PathToFileStateHashtable(); // stores state of the directory
        private long _version; // this is used to keep track of removals.
        private bool _started = false;
        private bool _disposed = false;
        private int _pollingInterval = 30000;
        private int retrycount;
        private string _networkPath = "";

        public PollingFileSystemWatcher(ILogger<PollingFileSystemWatcher> logger)
        {
            _logger = logger;
        }

        public EnumerationOptions EnumerationOptions { get; set; } = new EnumerationOptions();
        public string Filter { get; set; } = "*";
        public string Path { get; set; } = "";

        public event PollingFileSystemEventHandler? Changes;

        public event ErrorEventHandler? Error;

        public int PollingInterval
        {
            get { return _pollingInterval; }
            set
            {
                _pollingInterval = value;
                if (_started) _timer?.Change(PollingInterval, Timeout.Infinite);
            }
        }

        protected virtual bool CheckNetworkPathExists(String path)
        {
            if (path == null)
            {
                throw new ArgumentNullException(nameof(path));
            }

            if (!Directory.Exists(path))
            {
                throw new ArgumentException("Path not found.", nameof(path));
            }

            return true;
        }

        public void Start(string path, string filter = "*", bool useSubdirectories = false, int pollingInterval = 30000, string networkPath = "")
        {
            CheckNetworkPathExists(path);

            _state = new PathToFileStateHashtable();
            Path = path;
            Filter = filter ?? throw new ArgumentNullException(nameof(filter));
            _networkPath = networkPath;
            _pollingInterval = pollingInterval;

            EnumerationOptions = new EnumerationOptions();
            if (useSubdirectories)
            {
                EnumerationOptions.RecurseSubdirectories = true;
            }

            _timer = new Timer(new TimerCallback(TimerHandler));

            if (_disposed) throw new ObjectDisposedException(nameof(PollingFileSystemWatcher));
            if (_started) return;

            _started = true;
            _timer.Change(PollingInterval, Timeout.Infinite);
        }

        public void Restart()
        {
            if (_disposed) throw new ObjectDisposedException(nameof(PollingFileSystemWatcher));
            if (_started) return;

            _started = true;
            _timer?.Change(PollingInterval, Timeout.Infinite);
        }

        private async Task<ChangeStatePair> ComputeChangesAndUpdateState(CancellationToken cancellationToken)
        {
            _version++;
            var taskSource = new TaskCompletionSource<ChangeStatePair>();

            var changeThread = new Thread((_) =>
            {
                try
                {
                    var enumerator = new FileSystemChangeEnumerator(_state, Path , _networkPath, Filter, _version, EnumerationOptions);
                    while (enumerator.MoveNext())
                    {
                        // Going through this iterator triggers the internal logic to make the changes list and new state.
                    }
                    taskSource.TrySetResult(enumerator.GetChangeStatePair);
                }
                catch(Exception e)
                {
                    taskSource.TrySetException(e);
                }
            });

            ChangeStatePair changeStatePair;
            using (cancellationToken.Register(() =>
            {
                taskSource.TrySetCanceled(cancellationToken);
            }))
            {
                changeThread.Start();
                changeStatePair = await taskSource.Task;
            }

            foreach (FileState value in changeStatePair.stateHashtable)
            {
                if (value._version != _version)
                {
                    if((value.Directory is null) || (value.Path is null))
                    {
                        Debug.Assert(false, "Directory and Path Should never be null for a value that was in the previous state");
                        throw new ArgumentException("Directory and Path Should never be null for a value that was in the previous state");
                    }
                    changeStatePair.changeList.AddRemoved(value.Directory, value.Path, value.LastWriteTimeUtc, value.Length, _networkPath);
                    changeStatePair.stateHashtable.Remove(value.Directory, value.Path);
                }
            }
            return changeStatePair;
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!_disposed)
            {
                if (disposing)
                {
                     _timer?.Dispose();
                }
                _disposed = true;
            }
        }

        // This code was added to correctly implement the disposable pattern.
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        private void TimerHandler(object? __)
        {
            _ = TimerHandler();
        }

        virtual protected async Task TimerHandler()
        {
            try
            {
                FileChangeList changes;
                PathToFileStateHashtable current = _state;
                CancellationTokenSource cancellationTokenSource = new CancellationTokenSource(PollingInterval * 10);

                try
                {
                    var changeStatePair = await ComputeChangesAndUpdateState(cancellationTokenSource.Token);
                    changes = changeStatePair.changeList;
                    _state = changeStatePair.stateHashtable;
                    retrycount = 0;
                }
                catch
                {
                    // Clean up ComputeChangesAndUpdateState.
                    _logger.LogDebug("We have not finished polling the directory {PollingWatcherWatchPath} on time", Path);
                    _version--;
                    _state = current;
                    changes = new FileChangeList();
                    retrycount++;
                    if(retrycount == 3)
                    {
                        //here we throw an error event
                        Error?.Invoke(this, new ErrorEventArgs(new Exception($"Polling the path {Path} has failed 3 times in a row")));
                        retrycount = 0;
                        _started = false;
                        return;
                    }
                }

                if (!changes.IsEmpty)
                {
                    Changes?.Invoke(this, new PollingFileSystemEventArgs(changes.ToArray()));
                }
            }
            catch (Exception e)
            {
                Error?.Invoke(this, new ErrorEventArgs(e));
            }

            if (!_disposed)
                _timer?.Change(PollingInterval, Timeout.Infinite);
        }

        /// These functions are only here to allow us to invoked mocked events from a superclass for testing, never call them outside a unit test.
        protected virtual void InvokeError(ErrorEventArgs e)
        {
            // Safely raise the event for all subscribers
            Error?.Invoke(this, e);
        }

        protected virtual void InvokeChanges(PollingFileSystemEventArgs e)
        {
            // Safely raise the event for all subscribers
            Changes?.Invoke(this, e);
        }

    }


}
