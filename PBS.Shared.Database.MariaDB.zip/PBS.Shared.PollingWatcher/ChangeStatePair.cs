﻿
namespace PBS.Shared.PollingWatcher
{
    internal struct ChangeStatePair
    {
        public PathToFileStateHashtable stateHashtable;
        public FileChangeList changeList;
    }
}
