﻿using System;
using System.Collections.Generic;

namespace PBS.Shared.PollingWatcher
{
    public struct FileChangeList
    {
        const int DefaultListSize = 4;

        FileChange[] _changes;
        int _count;

        public bool IsEmpty { get { return _changes == null || _count == 0; } }

        internal void AddAdded(string directory, string path, DateTimeOffset dateTimeOffset, long size, string networkPath)
        {
            EnsureCapacity();
            _changes[_count++] = new FileChange(directory, path, PollingWatcherChangeTypes.Created, dateTimeOffset, size, networkPath);
        }

        internal void AddChanged(string directory, string path, DateTimeOffset dateTimeOffset, long size, string networkPath)
        {
            EnsureCapacity();
            _changes[_count++] = new FileChange(directory, path, PollingWatcherChangeTypes.Updated, dateTimeOffset, size, networkPath);
        }

        internal void AddRemoved(string directory, string path, DateTimeOffset dateTimeOffset, long size, string networkPath)
        {
            EnsureCapacity();
            _changes[_count++] = new FileChange(directory, path, PollingWatcherChangeTypes.Deleted, dateTimeOffset, size, networkPath);
        }

        internal void AddUpdatedAndIsWriteable(string directory, string path, DateTimeOffset dateTimeOffset, long size, string networkPath)
        {
            EnsureCapacity();
            _changes[_count++] = new FileChange(directory, path, PollingWatcherChangeTypes.UpdatedAndIsWriteable, dateTimeOffset, size, networkPath);
        }

        void EnsureCapacity()
        {
            if (_changes == null)
            {
                _changes = new FileChange[DefaultListSize];
            }
            if (_count >= _changes.Length)
            {
                var larger = new FileChange[_changes.Length * 2];
                _changes.CopyTo(larger, 0);
                _changes = larger;
            }
        }

        void Sort()
        {
            Array.Sort(_changes, 0, _count, Comparer.Default);
        }

        public override string ToString()
        {
            return _count.ToString();
        }

        public FileChange[] ToArray()
        {
            Sort();
            var result = new FileChange[_count];
            Array.Copy(_changes, result, _count);
            return result;
        }

        class Comparer : IComparer<FileChange>
        {
            public readonly static IComparer<FileChange> Default = new Comparer();

            public int Compare(FileChange x, FileChange y)
            {
                var nameOrder = String.CompareOrdinal(x.Name, y.Name);
                if (nameOrder != 0) return nameOrder;

                return x.ChangeType.CompareTo(y.ChangeType);
            }
        }
    }
}
