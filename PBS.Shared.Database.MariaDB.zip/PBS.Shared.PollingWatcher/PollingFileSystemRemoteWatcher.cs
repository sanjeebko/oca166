﻿using Microsoft.Extensions.Logging;
using PBS.Shared.RemoteShare;
using PBS.Shared.RemoteShare.Mounters;
using System;
using System.IO;
using System.Threading;

namespace PBS.Shared.PollingWatcher
{
    public class PollingFileSystemRemoteWatcher : IPollingFileSystemRemoteShareWatcher 
    {
        private readonly IRemoteShareMounter _remoteShareMounter;

        private readonly IPollingFileSystemWatcher _watcher;

        private int _restartCount = 0;

        private readonly ILogger _logger;

        private readonly Timer _restartTimer;

        private readonly int _retryTime = 30000;

        private readonly int _remountAttemptLimit = 3;

        public string AbsoluteFilePath { get; private set; } = "";

        public string NetworkBasePath { get; private set; } = "";

        public event PollingFileSystemEventHandler? FileChanges;

        public event RemotePollingErrorHandler? Error;

        public PollingFileSystemRemoteWatcher(ILogger<PollingFileSystemRemoteWatcher> logger, IRemoteShareMounter remoteShareMounter, IPollingFileSystemWatcher pollingFileSystemWatcher)
        {
            _logger = logger;
            _remoteShareMounter = remoteShareMounter;
            _watcher = pollingFileSystemWatcher;
            _restartTimer = new Timer(new TimerCallback(TimedRemountHandler));
        }

        public void Start(FileShareCredentials fileShareCredentials, MountType mountType, string TargetPath, int PollingInterval = 30000, bool useSubdirectories = false, string wildCard = "*")
        {
            AbsoluteFilePath = _remoteShareMounter.MountDrive(fileShareCredentials, TargetPath, mountType);
            NetworkBasePath = fileShareCredentials.MountPath;
            _watcher.Changes += OnChangesDetailed;
            _watcher.Error += OnError;
            _watcher.Start(AbsoluteFilePath, wildCard, useSubdirectories, PollingInterval, NetworkBasePath);
        }

        public void Restart()
        {
            _remoteShareMounter.RemountDrive();
            _watcher.Restart();
        }

        private void OnChangesDetailed(object source, PollingFileSystemEventArgs e)
        {
            FileChanges?.Invoke(source, e);
        }

        private void OnError(object source, ErrorEventArgs e)
        {
            if (_restartCount < _remountAttemptLimit)
            {
                _restartCount++;
                _restartTimer.Change(_retryTime, Timeout.Infinite);
                _logger.LogError("The polling of remote share {PollingWatcherNetworkBasePath} has failed, we are attempting to remount and restart it.", NetworkBasePath);
                Error?.Invoke(this, new RemoteSharePollingErrorEventArgs(e.GetException(), RemotePollingFailState.NetworkAttemptingRecovery));
            }
        }

        private void TimedRemountHandler(object? _)
        {
            try
            {
                _remoteShareMounter.RemountDrive();
                _watcher.Restart();
                _restartCount = 0;
                _logger.LogDebug("");
            }
            catch(Exception e)
            {
                if (_restartCount < _remountAttemptLimit)
                {
                    _restartCount++;
                    Error?.Invoke(this, new RemoteSharePollingErrorEventArgs(e, RemotePollingFailState.NetworkAttemptingRecovery));
                    if (!disposedValue)
                    {
                        _restartTimer.Change(_retryTime, Timeout.Infinite);
                    }
                }
                else
                { 
                    // here we give up and pass a fatal error back to the user
                    _restartCount = 0;
                    _logger.LogError("Polling watcher has tried to reconnect to {PollingWatcherNetworkBasePath} 3 times, giving up attempting to reconnect.", NetworkBasePath);
                    Error?.Invoke(this, new RemoteSharePollingErrorEventArgs(e, RemotePollingFailState.NetworkFatal));
                }
            }

        }

        #region IDisposable Support
        private bool disposedValue = false;

        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    _watcher.Dispose();
                    _remoteShareMounter.Dispose();
                    _restartTimer.Dispose();
                }
                disposedValue = true;
            }
        }

        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }
        #endregion
    }
}
