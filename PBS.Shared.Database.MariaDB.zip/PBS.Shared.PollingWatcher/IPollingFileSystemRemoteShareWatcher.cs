﻿using PBS.Shared.RemoteShare;
using System;

namespace PBS.Shared.PollingWatcher
{
    public interface IPollingFileSystemRemoteShareWatcher : IDisposable
    {
        public string AbsoluteFilePath { get; }

        public string NetworkBasePath { get; }

        public void Start(FileShareCredentials fileShareCredentials, MountType mountType, string TargetPath, int PollingInterval = 30000, bool useSubdirectories = false, string wildCard = "*");

        public void Restart();

        public event PollingFileSystemEventHandler FileChanges;

        public event RemotePollingErrorHandler Error;

    }
}