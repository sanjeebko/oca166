﻿using System;

namespace PBS.Shared.PollingWatcher
{
    [Serializable]
    internal struct FileState
    {
        internal long _version;
        public string? Path;
        public string? Directory;
        public DateTimeOffset LastWriteTimeUtc;
        public long Length;

        public FileState(string directory, string path) : this()
        {
            Directory = directory;
            Path = path;
        }

        public override string? ToString()
        {
            return Path;
        }
    }
}
