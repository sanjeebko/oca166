﻿using System;
using System.Diagnostics;
using System.IO;
using System.IO.Enumeration;
using System.Runtime.InteropServices;
namespace PBS.Shared.PollingWatcher
{
    /// <summary>
    /// This class is based on a design proposal for a polling filewatcher in the CoreFxLab github repository(https://github.com/dotnet/corefxlab/tree/master/src/System.IO.FileSystem.Watcher.Polling) and is licensed under the MIT license for that repository.
    /// </summary>
    internal class FileSystemChangeEnumerator : FileSystemEnumerator<string?>
    {
        private FileChangeList _changes = new FileChangeList();
        private string? _currentDirectory;
        private readonly string _filter; 
        private readonly string _networkPath;
        readonly PathToFileStateHashtable _state;
        readonly long _version;

        internal FileSystemChangeEnumerator(PathToFileStateHashtable state, string directory, string networkPath, string filter, long version, EnumerationOptions? options = null)
            : base(directory, options)
        {
            _state = state;
            _networkPath = networkPath;
            _filter = filter;
            _version = version;
        }

        public ChangeStatePair GetChangeStatePair => new ChangeStatePair { changeList = _changes, stateHashtable = _state };

        protected override void OnDirectoryFinished(ReadOnlySpan<char> directory)
        {
            _currentDirectory = null;
        }

        protected override string? TransformEntry(ref FileSystemEntry entry)
        {
            UpdateState(_currentDirectory, ref _changes, ref entry);
            return null;
        }

        protected override bool ShouldIncludeEntry(ref FileSystemEntry entry)
        {
            if (_currentDirectory == null)
                _currentDirectory = entry.Directory.ToString();

            if (entry.IsDirectory) return false;
            if (_filter == null) return true;

            bool ignoreCase = RuntimeInformation.IsOSPlatform(OSPlatform.Windows) || RuntimeInformation.IsOSPlatform(OSPlatform.OSX);
            if (FileSystemName.MatchesSimpleExpression(_filter, entry.FileName, ignoreCase: ignoreCase))
                return true;

            return false;
        }

        protected override bool ShouldRecurseIntoEntry(ref FileSystemEntry entry) => true;

        internal void UpdateState(string? directory, ref FileChangeList changes, ref FileSystemEntry file)
        {

            if (directory is null)
            {
                Debug.Assert(false, "Directory should never be null if it has returned a usable index");
                throw new ArgumentException("Directory should never be null if it has returned a usable index");
            }

            int index = _state.IndexOf(directory, file.FileName);
            if (index == -1) // file added
            {
                string path = file.FileName.ToString();

                var newFileState = new FileState(directory, path)
                {
                    LastWriteTimeUtc = file.LastWriteTimeUtc,
                    Length = file.Length,
                    _version = _version
                };
                changes.AddAdded(directory, path.ToString(), file.LastWriteTimeUtc, file.Length, _networkPath);
                _state.Add(directory, path, newFileState);
                return;
            }

            _state.Values[index]._version = _version;

            FileState previousState = _state.Values[index];

            if (previousState.Path is null)
            {
                Debug.Assert(false, "Path should never be null if it has returned a usable index");
                throw new ArgumentException("Path should never be null if it has returned a usable index");
            }

            if (file.LastWriteTimeUtc != previousState.LastWriteTimeUtc || file.Length != previousState.Length)
            {

                changes.AddChanged(directory, previousState.Path, file.LastWriteTimeUtc, file.Length, _networkPath);
                _state.Values[index].LastWriteTimeUtc = file.LastWriteTimeUtc;
                _state.Values[index].Length = file.Length;
                _state.HaveBeenMarkedAsReady.Remove(file.ToFullPath());
            }
            else if ((!_state.HaveBeenMarkedAsReady.Contains(file.ToFullPath())) && CanGetLock(file.ToFullPath()))
            {
                _state.HaveBeenMarkedAsReady.Add(file.ToFullPath());
                changes.AddUpdatedAndIsWriteable(directory, previousState.Path, file.LastWriteTimeUtc, file.Length, _networkPath);
            }
        }

        private static bool CanGetLock(string path)
        {
            try
            {
                FileInfo f = new FileInfo(path);
                using FileStream stream = f.Open(FileMode.Open, FileAccess.Write, FileShare.None);
                stream.Close();
            }
            catch (IOException)
            {
                return false;
            }
            return true;
        }
    }
}
