﻿namespace PBS.Shared.PollingWatcher
{
    public delegate void RemotePollingErrorHandler(object sender, RemoteSharePollingErrorEventArgs e);
}
