﻿using System;

namespace PBS.Shared.Database.MariaDB
{
    public class MariaDBOptionsBuilderFactory : ISqlOptionsBuilderFactory
    {
        public const string CONST_CONFIG_TYPE = "MariaDB";

        public ISqlOptionsBuilder CreateOptionsBuilder(DatabaseConnectionConfiguration connectionOptions)
            => new MariaDBOptionsBuilder(connectionOptions);

        public bool SupportsType(string dbConfigType)
            => dbConfigType.Equals(CONST_CONFIG_TYPE, StringComparison.OrdinalIgnoreCase);
    }
}
