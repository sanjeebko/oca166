﻿using Microsoft.Extensions.DependencyInjection;

namespace PBS.Shared.Database.MariaDB
{
    public static class MariaDBOptionsBuilderExtensions
    {
        public static IServiceCollection AddMariaDB(this IServiceCollection services)
            => services.AddTransient<ISqlOptionsBuilderFactory, MariaDBOptionsBuilderFactory>();
    }
}
