﻿using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;
using System;
using System.Text;

namespace PBS.Shared.Database.MariaDB
{
    public class MariaDBOptionsBuilder : ISqlOptionsBuilder
    {
        private readonly Version DEFAULT_MARIA_SERVER_VERSION = new Version(10, 4, 12);
        private readonly DatabaseConnectionConfiguration _connectionOptions;

        public MariaDBOptionsBuilder(DatabaseConnectionConfiguration connectionOptions)
        {
            _connectionOptions = connectionOptions;
        }

        public void Build(DbContextOptionsBuilder opts)
        {
            StringBuilder connectionString = new StringBuilder();
            connectionString.Append("Server=");
            connectionString.Append(_connectionOptions.Server);
            connectionString.Append(";");

            if (_connectionOptions.Port > 0)
            {
                connectionString.Append("Port=");
                connectionString.Append(_connectionOptions.Port);
                connectionString.Append(";");
            }
            
            connectionString.Append("Database=");
            connectionString.Append(_connectionOptions.Name);
            connectionString.Append(";");

            if (!string.IsNullOrWhiteSpace(_connectionOptions.User))
            {
                connectionString.Append("User=");
                connectionString.Append(_connectionOptions.User);
                connectionString.Append(";");
            }

            if (!string.IsNullOrWhiteSpace(_connectionOptions.Password))
            {
                connectionString.Append("Password=");
                connectionString.Append(_connectionOptions.Password);
                connectionString.Append(";");
            }

            opts.UseMySql(connectionString.ToString(), optsBuilder =>
            {
                Version dbServerVersion = Version.TryParse(_connectionOptions.ServerVersion ?? "", out Version? configuredVersion)
                                          ? configuredVersion
                                          : DEFAULT_MARIA_SERVER_VERSION;

                optsBuilder.ServerVersion(dbServerVersion, ServerType.MariaDb);

                if (_connectionOptions.RetryCount > 0 && _connectionOptions.RetryInterval > 0)
                {
                    optsBuilder.EnableRetryOnFailure(_connectionOptions.RetryCount, TimeSpan.FromSeconds(_connectionOptions.RetryInterval), null);
                }
                else if (_connectionOptions.RetryCount > 0)
                {
                    optsBuilder.EnableRetryOnFailure(_connectionOptions.RetryCount);
                }
            });
        }
    }
}
