﻿using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;

namespace PBS.Shared.Database.SQLite
{
    public class SQLiteOptionsBuilder : ISqlOptionsBuilder
    {
        private readonly SqliteConnection _connection;
 
        public SQLiteOptionsBuilder(SqliteConnection connection)
        {
            _connection = connection;
        }

        public void Build(DbContextOptionsBuilder opts)
        {
            opts.UseSqlite(_connection);
        }
    }
}
