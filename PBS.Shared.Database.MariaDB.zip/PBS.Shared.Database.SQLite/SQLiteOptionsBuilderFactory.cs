﻿using Microsoft.Data.Sqlite;
using System;

namespace PBS.Shared.Database.SQLite
{
    public class SQLiteOptionsBuilderFactory : ISqlOptionsBuilderFactory
    {
        public const string CONST_CONFIG_TYPE = "SQLite";
        private readonly SqliteConnection _connection;

        public SQLiteOptionsBuilderFactory(SqliteConnection connection)
        {
            _connection = connection;
        }

        public ISqlOptionsBuilder CreateOptionsBuilder(DatabaseConnectionConfiguration connectionOptions)
            => new SQLiteOptionsBuilder(_connection);

        public bool SupportsType(string dbConfigType)
            => dbConfigType.Equals(CONST_CONFIG_TYPE, StringComparison.OrdinalIgnoreCase);
    }
}
