﻿using Microsoft.Data.Sqlite;
using Microsoft.Extensions.DependencyInjection;

namespace PBS.Shared.Database.SQLite
{
    public static class SQLiteOptionsBuilderExtensions
    {
        public static IServiceCollection AddSQLite(this IServiceCollection services, SqliteConnection connection)
            => services.AddTransient<ISqlOptionsBuilderFactory>(_ => new SQLiteOptionsBuilderFactory(connection));
    }
}
