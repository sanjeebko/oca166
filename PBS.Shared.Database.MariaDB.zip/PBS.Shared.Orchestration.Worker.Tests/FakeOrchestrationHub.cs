﻿using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.SignalR;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    public class FakeOrchestrationHub : Hub
    {
        public async Task Heartbeat(string message)
        {
            await Clients.All.SendAsync("Heartbeat", message);
        }

        public async Task InvokeTask(string message)
        {
            await Clients.All.SendAsync("InvokeTask", message);
        }

        public override async Task OnConnectedAsync()
        {
            await base.OnConnectedAsync();
        }

        public override async Task OnDisconnectedAsync(Exception? exception)
        {
            await base.OnDisconnectedAsync(exception);
        }
    }
}