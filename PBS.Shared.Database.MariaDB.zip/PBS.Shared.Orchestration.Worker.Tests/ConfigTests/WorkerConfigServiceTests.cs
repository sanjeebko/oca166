﻿using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Restrictions;
using PBS.Shared.Orchestration.Worker.Restrictions.Validators;
using PBS.Shared.Orchestration.Worker.Validators;
using PBS.Shared.PropertyTypeFormats;
using System;
using System.Collections.Generic;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.ConfigTests
{
    public class WorkerConfigServiceTests
    {
        private readonly ITestOutputHelper _outputHelper;
        private IWorkerConfigValidator? _workerConfigValidator;

        public WorkerConfigServiceTests(ITestOutputHelper outputHelper)
        {
            _outputHelper = outputHelper;
        }

        public IWorkerConfigValidator CreateValidator()
        {
            if (_workerConfigValidator != null)
                return _workerConfigValidator;

            IRestrictionValidatorLookup restrictionValidatorLookup = new RestrictionValidatorLookup();
            IRestrictionValidatorFactory restrictionValidatorFactory = new RestrictionValidatorFactory(restrictionValidatorLookup);
            IWorkerRestrictionValidatorLookup workerRestrictionValidatorLookup = new WorkerRestrictionValidatorLookup(restrictionValidatorFactory);
            IWorkerRestrictionValidatorFactory workerRestrictionValidatorFactory = new WorkerRestrictionValidatorFactory(workerRestrictionValidatorLookup);
            IWorkerCapabilitiesValidator workerCapabilitiesValidator = new WorkerCapabilitiesValidator(workerRestrictionValidatorFactory);
            IWorkerStepTemplatesValidator workerStepTemplatesValidator = new WorkerStepTemplatesValidator();
            IWorkerAnnouncementValidator workerAnnouncementValidator = new WorkerAnnouncementValidator(workerStepTemplatesValidator, workerCapabilitiesValidator);
            IWorkerConfigValidator workerConfigValidator = new WorkerConfigValidator(workerAnnouncementValidator);

            // register default validators
            restrictionValidatorLookup.AddFromAssembly(typeof(IWorkerRestrictionValidator).Assembly);
            workerRestrictionValidatorLookup.AddFromAssembly(typeof(IWorkerRestrictionValidator).Assembly);

            _workerConfigValidator = workerConfigValidator;
            return _workerConfigValidator;
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingEmptyWorkerConfig_ThrowsException()
        {
            Assert.ThrowsAny<Exception>(() =>
            {
                var configService = new WorkerConfigService(null!, CreateValidator());
                configService.Validate();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyWorkerName_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = null,
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "DummyStep",
                            Category = "Demo",
                            Type = "Action",
                            Version = 1
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithNullAnnounce_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = null!,
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithNullAnnounceStepTemplates_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement { StepTemplates = null! },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyAnnounceStepTemplates_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement { StepTemplates = new List<WorkerStepTemplate>() },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithNullScanAssemblyList_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = null!,
                WorkerAnnouncement = new WorkerAnnouncement { StepTemplates = new List<WorkerStepTemplate>() },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyStepTemplateName_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = null!,
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>()
                    {
                        new WorkerStepTemplate
                        {
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    }
                },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyStepTemplateType_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = null!,
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>()
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Category = "Demo",
                            Version = 1,
                        }
                    }
                },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyStepTemplateCategory_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = null!,
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>()
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Version = 1,
                        }
                    }
                },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyStepTemplateVersion_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = null!,
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>()
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                        }
                    }
                },
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithEmptyStepTemplateInput_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                            Inputs = new List<PropertyFormat>
                            {
                                new PropertyFormat()
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithStepTemplateInputWithoutInputName_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                            Inputs = new List<PropertyFormat>
                            {
                                new PropertyFormat
                                {
                                    Types = new List<PropertyType>(){new PropertyType(){Name = "string"}}
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithStepTemplateInputWithInputNameButWithoutTypes_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                            Inputs = new List<PropertyFormat>
                            {
                                new PropertyFormat
                                {
                                    Name = "SomeSource",
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWithoutSettingTypeOfWorkerRestriction_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new WorkerRestriction
                            {
                                Type = null,
                                Properties = new Dictionary<string, object>
                                {
                                    {"TemplateName", "TestStep"}
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWithTemplateRestrictionConfigWithoutSettingTemplateName_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction()
                            {
                                TemplateName = null,
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        InputName = "SomeInput",
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operator = LookupOperator.StartsWith,
                                                Operand = "C:\\test"
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWith_TemplateRestrictionConfig_AndWith_InputLookupRestrictionConfig_Without_InputLookupRestrictionConfig_Type_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction
                            {
                                TemplateName = "TestStep",
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        Type = null,
                                        InputName = "SomeInput",
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operator = LookupOperator.StartsWith,
                                                Operand = "C:\\test"
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWith_TemplateRestrictionConfig_AndWith_InputLookupRestrictionConfig_Without_InputLookupRestrictionConfig_InputName_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction
                            {
                                TemplateName = "TestStep",
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operator = LookupOperator.StartsWith,
                                                Operand = "C:\\test"
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWith_TemplateRestrictionConfig_AndWithoutUsing_TemplateWorkerRestriction_Class_ThrowsException()
        {
            Assert.ThrowsAny<NotSupportedException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new WorkerRestriction
                            {
                                Type = WorkerRestrictionType.Template,
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        InputName = "SomeInput",
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operator = LookupOperator.StartsWith,
                                                Operand = "C:\\test"
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWith_TemplateRestrictionConfig_WithoutUsingCorrectRestrictionClassType_ThrowsException()
        {
            Assert.ThrowsAny<NotSupportedException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction
                            {
                                TemplateName = "SomeTemplate",
                                Restrictions = new List<Restriction>
                                {
                                    new Restriction
                                    {
                                        Type = RestrictionType.InputLookup,
                                        Properties = new Dictionary<string, object>()
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingWorkerConfigWithWorkerCapabilitiesWith_TemplateRestrictionConfig_AndWith_InputLookupRestrictionConfig_WithInvalid_InputLookupRestrictionConfig_Lookup_ThrowsException()
        {
            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction
                            {
                                TemplateName = "TestStep",
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operator = LookupOperator.StartsWith,
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());

            Assert.ThrowsAny<ArgumentException>(() => new WorkerConfigService(new WorkerConfig
            {
                WorkerName = "DemoWorker",
                ScanAssembly = new[] { GetType().Assembly },
                WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                        }
                    },
                    WorkerCapabilities = new WorkerCapabilities
                    {
                        WorkerRestrictions = new List<WorkerRestriction>
                        {
                            new TemplateWorkerRestriction
                            {
                                TemplateName = "TestStep",
                                Restrictions = new List<Restriction>
                                {
                                    new InputLookupRestriction
                                    {
                                        Lookups = new List<Lookup>
                                        {
                                            new Lookup
                                            {
                                                Operand = "some value"
                                            }
                                        },
                                    }
                                }
                            }
                        }
                    }
                }
            }, CreateValidator()).Validate());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerConfigService_WhenCreatingValidWorkerConfig_DoesNotThrowException()
        {
            bool valid = true;

            try
            {
                var service = new WorkerConfigService(new WorkerConfig
                {
                    WorkerName = "DemoWorker",
                    ScanAssembly = new[] { GetType().Assembly },
                    WorkerAnnouncement = new WorkerAnnouncement
                    {
                        StepTemplates = new List<WorkerStepTemplate>
                        {
                            new WorkerStepTemplate
                            {
                                Name = "TestStep",
                                Type = "Action",
                                Category = "Demo",
                                Version = 1,
                                Inputs = new List<PropertyFormat>
                                {
                                    new PropertyFormat
                                    {
                                        Name = "SomeSource",
                                        Types = new List<PropertyType>()
                                        {
                                            new PropertyType(){Name = "string"}
                                        }
                                    }
                                }
                            }
                        },
                        WorkerCapabilities = new WorkerCapabilities
                        {
                            WorkerRestrictions = new List<WorkerRestriction>
                            {
                                new TemplateWorkerRestriction
                                {
                                    TemplateName = "TestStep",
                                    Restrictions = new List<Restriction>
                                    {
                                        new InputLookupRestriction
                                        {
                                            InputName = "SomeInput",
                                            Lookups = new List<Lookup>
                                            {
                                                new Lookup
                                                {
                                                    Operator = LookupOperator.StartsWith,
                                                    Operand = "C:\\test"
                                                }
                                            },
                                        }
                                    }
                                }
                            }
                        }
                    },
                }, CreateValidator());

                service.Validate();
            }
            catch (Exception e)
            {
                _outputHelper.WriteLine(e.ToString());
                valid = false;
            }

            Assert.True(valid);
        }
    }
}
