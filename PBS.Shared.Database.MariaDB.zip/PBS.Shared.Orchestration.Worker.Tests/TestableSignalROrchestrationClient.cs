﻿using Microsoft.AspNetCore.SignalR.Client;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients.SignalR;
using System.Net.Http;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    internal class TestableSignalROrchestrationClient : SignalROrchestrationClient
    {
        private readonly HttpMessageHandler _handler;

        public TestableSignalROrchestrationClient(ILogger<SignalROrchestrationClient> logger, HttpMessageHandler handler) : base(logger)
        {
            _handler = handler;
        }

        protected override HubConnection GenerateConnection(string url)
        {
            return new HubConnectionBuilder()
                .WithUrl(url, options =>
                {
                    options.HttpMessageHandlerFactory = _ => _handler;
                })
                .AddJsonProtocol()
                .WithAutomaticReconnect(new HubConnectionRandomRetryPolicy())
                .Build();
        }

        public HubConnection? Connection => _connection;
    }
}
