﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.FactoryTests
{
    public class TaskHandlerFactoryTests : WorkerTestBase
    {
        public TaskHandlerFactoryTests(ITestOutputHelper outputHelper) : base(outputHelper)
        {
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void TaskHandlerFactory_WhenTaskTypeIsNotMappedToStepTemplateNameInWorkerConfig_ReturnsNull()
        {
            using var webFactory = CreateWorkerWebFactoryForTask<DummyTask>(workerName: "DemoWorker", templateName: "TestStep", scanAssemblies: GetType().Assembly);

            ITaskHandler? handler = webFactory.Services.GetRequiredService<ITaskHandlerFactory>().GetTaskHandler("NotMappedTemplateName");

            Assert.Null(handler);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void TaskHandlerFactory_WhenTaskTypeIsMappedToStepTemplateNameInWorkerConfig_ReturnsHandler()
        {
            using var webFactory = CreateWorkerWebFactoryForTask<DummyTask>(workerName: "DemoWorker", templateName: "TestStep", scanAssemblies: GetType().Assembly);
            
            ITaskHandler? handler = webFactory.Services.GetRequiredService<ITaskHandlerFactory>().GetTaskHandler("TestStep");

            Assert.NotNull(handler);
            Assert.Equal(typeof(DummyTask), handler?.TaskType);
        }
    }
}
