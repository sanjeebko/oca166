﻿using Newtonsoft.Json.Linq;
using PBS.Shared.Orchestration.Worker.Extensions;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Restrictions;
using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests.SerializerTests
{
    public class WorkerAnnounceSerializationTests
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerAnnounceConfig_ValidateStepTemplatesJsonSerializationOutput()
        {
            var workerAnnouncement = new WorkerAnnouncement
            {
                StepTemplates = new List<WorkerStepTemplate>
                {
                    new WorkerStepTemplate
                    {
                        Name = "TestStep",
                        Type = "Action",
                        Category = "Demo",
                        Version = 1,
                        Inputs = new List<PropertyFormat>
                        {
                            new PropertyFormat
                            {
                                Name = "SomeInput",
                                DisplayName = "Display name",
                                Hint = "some hint",
                                Flags = new[] {FormatPropertyMetadata.Collection},
                                CollectionValidators = new Dictionary<string, object>(){ {"Validator", "CollectionValidator"}},
                                Types = new List<PropertyType>
                                {
                                    new PropertyType
                                    {
                                        Name = "string",
                                        AcceptedValues = new List<object> {"one", "two"},
                                        SuggestedDefault = "one",
                                        Validators = new Dictionary<string, object> { {"Required", "RequiredValidator"}}
                                    }
                                }
                            }
                        },
                        Outputs = new List<PropertyFormat>
                        {
                            new PropertyFormat
                            {
                                Name = "SomeOutput",
                                Types = new List<PropertyType>()
                                {
                                    new PropertyType()
                                    {
                                        Name = "string"
                                    }
                                }
                            }
                        },
                    }
                },
            };

            string json = workerAnnouncement.Serialize();

            Assert.NotEmpty(json);

            var doc = JObject.Parse(json);

            Assert.Equal("TestStep", doc.SelectToken("workflowStepTemplates[0].name").Value<string>());
            Assert.Equal("Action", doc.SelectToken("workflowStepTemplates[0].type").Value<string>());
            Assert.Equal("Demo", doc.SelectToken("workflowStepTemplates[0].category").Value<string>());
            Assert.Equal("1", doc.SelectToken("workflowStepTemplates[0].version").Value<string>());
            Assert.Equal("SomeInput", doc.SelectToken("workflowStepTemplates[0].inputs[0].Name").Value<string>());
            Assert.Equal("string", doc.SelectToken("workflowStepTemplates[0].inputs[0].Types[0].Name").Value<string>());
            Assert.Equal("one", doc.SelectToken("workflowStepTemplates[0].inputs[0].Types[0].SuggestedDefault").Value<string>());
            Assert.Equal("one", doc.SelectToken("workflowStepTemplates[0].inputs[0].Types[0].AcceptedValues[0]").Value<string>());
            Assert.Equal("RequiredValidator", doc.SelectToken("workflowStepTemplates[0].inputs[0].Types[0].Validators.Required").Value<string>());
            Assert.Equal("Display name", doc.SelectToken("workflowStepTemplates[0].inputs[0].DisplayName").Value<string>());
            Assert.Equal("some hint", doc.SelectToken("workflowStepTemplates[0].inputs[0].Hint").Value<string>());
            Assert.Equal("CollectionValidator", doc.SelectToken("workflowStepTemplates[0].inputs[0].CollectionValidators.Validator").Value<string>());
            Assert.Equal(FormatPropertyMetadata.Collection.ToString(), doc.SelectToken("workflowStepTemplates[0].inputs[0].Flags[0]").Value<string>());

            Assert.Equal("SomeOutput", doc.SelectToken("workflowStepTemplates[0].outputs[0].Name").Value<string>());
            Assert.Equal("string", doc.SelectToken("workflowStepTemplates[0].outputs[0].Types[0].Name").Value<string>());
            var deserializedWorkerAnnouncement = WorkerAnnounceExtensions.Deserialize(json);

            Assert.NotNull(deserializedWorkerAnnouncement);
            Assert.NotEmpty(deserializedWorkerAnnouncement?.StepTemplates);
            
            Assert.Single(deserializedWorkerAnnouncement?.StepTemplates);
            Assert.Single(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs);
            Assert.Single(deserializedWorkerAnnouncement?.StepTemplates?.First().Outputs);
            Assert.Single(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].Types);
            Assert.NotEmpty(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].Flags);
            Assert.NotEmpty(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].CollectionValidators);
            Assert.NotEmpty(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].Types.First().Validators);
            Assert.NotEmpty(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].Types.First().AcceptedValues);
            Assert.NotNull(deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs[0].Types.First().SuggestedDefault);
            Assert.Single(deserializedWorkerAnnouncement?.StepTemplates?.First().Outputs[0].Types);


            Assert.Equal("TestStep", deserializedWorkerAnnouncement?.StepTemplates?.First().Name);
            Assert.Equal("Action", deserializedWorkerAnnouncement?.StepTemplates?.First().Type);
            Assert.Equal("Demo", deserializedWorkerAnnouncement?.StepTemplates?.First().Category);
            Assert.Equal(1, deserializedWorkerAnnouncement?.StepTemplates?.First().Version);
            Assert.Equal("SomeInput", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Name);
            Assert.Equal("Display name", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().DisplayName);
            Assert.Equal("some hint", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Hint);
            Assert.Equal("CollectionValidator", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().CollectionValidators["Validator"]);
            Assert.Equal(FormatPropertyMetadata.Collection, deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Flags.First());

            Assert.Equal("string", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Types.First().Name);
            Assert.Equal("one", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Types.First().SuggestedDefault);
            Assert.Equal("one", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Types.First().AcceptedValues.First());
            Assert.Equal("RequiredValidator", deserializedWorkerAnnouncement?.StepTemplates?.First().Inputs.First().Types.First().Validators["Required"]);

        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerAnnounceConfig_ValidateWorkerCapabilitiesJsonSerializationOutput()
        {
            var workerAnnouncement = new WorkerAnnouncement
            {
                WorkerCapabilities = new WorkerCapabilities
                {
                    WorkerRestrictions = new List<WorkerRestriction>
                    {
                        new TemplateWorkerRestriction
                        {
                            TemplateName = "TestStep",
                            Restrictions = new List<Restriction>
                            {
                                new InputLookupRestriction
                                {
                                    InputName = "SomeSource",
                                    Lookups = new List<Lookup>
                                    {
                                        new Lookup
                                        {
                                            Operator = LookupOperator.StartsWith,
                                            Operand = "C:\\test"
                                        }
                                    },
                                },
                                new Restriction
                                {
                                    Properties = new Dictionary<string, object>
                                    {
                                        {"SomeProp", 33234},
                                    }
                                }
                            }
                        }
                    }
                }
            };

            string json = workerAnnouncement.Serialize();

            Assert.NotEmpty(json);

            var doc = JObject.Parse(json);

            Assert.Equal(WorkerRestrictionType.Template.ToString(), doc.SelectToken("workerCapabilities.workerRestrictions[0].type").Value<string>());
            Assert.Equal("TestStep", doc.SelectToken("workerCapabilities.workerRestrictions[0].templateName").Value<string>());
            Assert.Equal(RestrictionType.InputLookup.ToString(), doc.SelectToken("workerCapabilities.workerRestrictions[0].restrictions[0].type").Value<string>());
            Assert.Equal("SomeSource", doc.SelectToken("workerCapabilities.workerRestrictions[0].restrictions[0].inputName").Value<string>());
            Assert.Equal("StartsWith", doc.SelectToken("workerCapabilities.workerRestrictions[0].restrictions[0].lookups[0].operator").Value<string>());
            Assert.Equal("C:\\test", doc.SelectToken("workerCapabilities.workerRestrictions[0].restrictions[0].lookups[0].operand").Value<string>());


            var deserializedWorkerAnnouncement = WorkerAnnounceExtensions.Deserialize(json);

            Assert.Null(deserializedWorkerAnnouncement?.StepTemplates);
            Assert.NotNull(deserializedWorkerAnnouncement?.WorkerCapabilities);
            Assert.Single(deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions);
            Assert.True(deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions.Count == 2);
            Assert.Equal(WorkerRestrictionType.Template, deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Type);
            Assert.IsType<TemplateWorkerRestriction>(deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0]);
            Assert.Equal("TestStep", ((TemplateWorkerRestriction?)deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0])?.TemplateName);
            Assert.Equal(RestrictionType.InputLookup, deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions[0].Type);
            Assert.IsType<InputLookupRestriction>(deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions[0]);
            Assert.IsType<Restriction>(deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions[1]);
            Assert.Equal("SomeSource", ((InputLookupRestriction?)deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions[0])?.InputName);

            List<Lookup>? lookups = deserializedWorkerAnnouncement?.WorkerCapabilities?.WorkerRestrictions?[0].Restrictions?.OfType<InputLookupRestriction>().Single().Lookups;
            Assert.Single(lookups);
            Assert.Equal(LookupOperator.StartsWith, lookups?[0].Operator);
            Assert.Equal("C:\\test", lookups?[0].Operand);
        }
    }
}
