﻿using PBS.Shared.Orchestration.Worker.Services;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    public class OrchestrationClientUrlResolverTests
    {
        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("Worker - file-system-worker-service--filesystemworkerservice-84f756gknmh")]
        [InlineData("Worker -  --84f756gknmh")]
        public void ResolveUrl_GivenWorkerName_EscapesWorkerName(string workerName)
        {
            string resolvedUrl = OrchestrationClientUrlResolver.ResolveUrl("http://router.default.svc.cluster.local", "/ws/1/orchestration", workerName);
            Assert.Contains("%20", resolvedUrl);
            Assert.DoesNotContain(" ", resolvedUrl);
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("http://someurl.local", "/ws/1/orchestration", "worker", "http://someurl.local/ws/1/orchestration?identifier=worker")]
        [InlineData("http://someurl.local/", "/ws/1/orchestration", "worker", "http://someurl.local/ws/1/orchestration?identifier=worker")]
        [InlineData("http://someurl.local", "ws/1/orchestration", "worker", "http://someurl.local/ws/1/orchestration?identifier=worker")]
        [InlineData("http://someurl.local/", "ws/1/orchestration/", "worker", "http://someurl.local/ws/1/orchestration?identifier=worker")]
        [InlineData("http://someurl.local/", "ws/1/orchestration/", "worker machine", "http://someurl.local/ws/1/orchestration?identifier=worker%20machine")]
        public void ResolveUrl_GivenRequiredParameters_EscapesWorkerName(string origin, string endpoint, string workerName, string expectedUrl)
        {
            Assert.Equal(expectedUrl, OrchestrationClientUrlResolver.ResolveUrl(origin, endpoint, workerName));
        }

        [Theory]
        [Trait("TestType", "UnitTest")]
        [InlineData("")]
        [InlineData(null)]
        [InlineData("   ")]
        public void ResolveUrl_WhenWorkerNameIsNotProvided_ReturnsDefaultWorkerName(string? workerName)
        {
            string escapedUnknownWorkerName = OrchestrationClientUrlResolver.EscapeString(OrchestrationClientUrlResolver.UnknownWorkerName);

            string resolvedUrl = OrchestrationClientUrlResolver.ResolveUrl("http://someurl.local", "/ws/1/orchestration", workerName);
            Assert.Contains(escapedUnknownWorkerName, resolvedUrl);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void ResolveUrl_WhenWorkerNameIsNotProvided_ReturnsUniqueWorkerName()
        {
            List<string?> workerNames = new List<string?>() { "", null, "  " };

            List<string> resolvedUrls = new List<string>(workerNames.Count);

            foreach (var workerName in workerNames)
            {
                string resolvedUrl = OrchestrationClientUrlResolver.ResolveUrl("http://someurl.local", "/ws/1/orchestration", workerName);
                resolvedUrls.Add(resolvedUrl);
            }

            Assert.True(resolvedUrls.Distinct().Count() == resolvedUrls.Count);
        }
    }
}
