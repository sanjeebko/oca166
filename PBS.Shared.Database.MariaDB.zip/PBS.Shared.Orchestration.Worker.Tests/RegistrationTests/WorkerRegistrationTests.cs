﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Registration;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Logging;
using PBS.Shared.Orchestration.Worker.Tests.Common.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.RegistrationTests
{
    public class WorkerRegistrationTests : WorkerTestBase
    {
        public WorkerRegistrationTests(ITestOutputHelper outputHelper) : base(outputHelper)
        {
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_WhenRegisteringWithoutConfiguringWorker_ThrowsException()
        {
            Assert.ThrowsAny<WorkerRegistrationArgumentException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                    collection.AddPBSWorker(null);
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_WhenRegisteringWithEmptyWorkerName_ThrowsException()
        {
            Assert.ThrowsAny<WorkerConfigValidationException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                    collection.AddPBSWorker(config =>
                    {
                        config.WorkerName = "";
                        config.WorkerAnnouncement = new WorkerAnnouncement()
                        {
                            StepTemplates = new List<WorkerStepTemplate>()
                            {
                                new WorkerStepTemplate
                                {
                                    Name = "TestStep",
                                    Category = "Demo",
                                    Type = "Action",
                                    Version = 1
                                }
                            }
                        };
                    });
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_WhenRegisteringWithoutWorkerAnnouncement_ThrowsException()
        {
            Assert.ThrowsAny<WorkerConfigValidationException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                    collection.AddPBSWorker(config =>
                    {
                        config.WorkerName = "DemoWorker";
                    });
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_CallingUsePBSWorkerMultipleTimes_ThrowsException()
        {
            Assert.ThrowsAny<WorkerRegistrationException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                    collection.AddPBSWorker(config =>
                    {
                        config.WorkerName = "DemoWorker";
                        config.WorkerAnnouncement = new WorkerAnnouncement
                        {
                            StepTemplates = new List<WorkerStepTemplate>
                            {
                                new WorkerStepTemplate
                                {
                                    Name = "TestStep",
                                    Category = "Demo",
                                    Type = "Action",
                                    Version = 1
                                }
                            }
                        };
                    });
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_CallingAddPBSWorkerMultipleTimes_ThrowsException()
        {
            Assert.ThrowsAny<WorkerRegistrationException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                    collection.AddPBSWorker(config =>
                    {
                        config.WorkerName = "DemoWorker";
                        config.WorkerAnnouncement = new WorkerAnnouncement()
                        {
                            StepTemplates = new List<WorkerStepTemplate>
                            {
                                new WorkerStepTemplate
                                {
                                    Name = "TestStep",
                                    Category = "Demo",
                                    Type = "Action",
                                    Version = 1
                                }
                            }
                        };
                    });

                    collection.AddPBSWorker(config =>
                    {
                        config.WorkerName = "DemoWorker";
                        config.WorkerAnnouncement = new WorkerAnnouncement()
                        {
                            StepTemplates = new List<WorkerStepTemplate>
                            {
                                new WorkerStepTemplate
                                {
                                    Name = "TestStep",
                                    Category = "Demo",
                                    Type = "Action",
                                    Version = 1
                                }
                            }
                        };
                    });
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void WorkerRegistration_WhenRegisteringWithoutCallingAddPBSWorker_ThrowsException()
        {
            Assert.ThrowsAny<WorkerRegistrationException>(() =>
            {
                using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
                {
                }, applicationConfigure: builder =>
                {
                    builder.UsePBSWorker(null);
                }, loggingBuilder =>
                {
                    loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                });

                factory.Services.GetRequiredService<WorkerMarkerService>();
            });
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task WorkerRegistration_WhenRegisteringWithValidWorkerConfigInvokingTask_ReturnsSuccess()
        {
           using ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
            {
                collection.AddPBSWorker(config =>
                {
                    config.WorkerName = "DemoWorker";
                    config.ScanAssembly = new[] {GetType().Assembly};
                    config.WorkerAnnouncement = new WorkerAnnouncement
                    {
                        StepTemplates = new List<WorkerStepTemplate>
                        {
                            new WorkerStepTemplate
                            {
                                Name = "TestStep",
                                Category = "Demo",
                                Type = "Action",
                                Version = 1
                            }
                        }
                    };
                    config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
                });
            }, applicationConfigure: builder =>
            {
                builder.UsePBSWorker(mappingBuilder =>
                {
                    mappingBuilder.MapTask<SuccessDummyTask>("TestStep");
                });
            }, loggingBuilder =>
            {
                loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
            });

            Assert.NotNull(factory.Services.GetService<WorkerMarkerService>());

            ITaskManager taskManager = factory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(new WorkerTaskInvokeRequest() {StepInstanceId = "1", StepTemplateName = "TestStep"});

            Assert.NotNull(invokeResult);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Success, invokeResult!.Status);
            Assert.Empty(invokeResult?.Errors);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task WorkerRegistration_WhenRegisteringWithoutAspNetCoreWithValidWorkerConfigInvokingTask_ReturnsSuccess()
        {
            IServiceCollection serviceCollection = new ServiceCollection();

            serviceCollection.AddLogging(loggingBuilder =>
            {
                loggingBuilder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
            });

            serviceCollection.AddPBSWorker(config =>
            {
                config.WorkerName = "DemoWorker";
                config.ScanAssembly = new[] { GetType().Assembly };
                config.WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "TestStep",
                            Category = "Demo",
                            Type = "Action",
                            Version = 1
                        }
                    }
                };
                config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
            });

            IServiceProvider serviceProvider = serviceCollection.BuildServiceProvider();

            serviceProvider.UsePBSWorker(mappingBuilder =>
            {
                mappingBuilder.MapTask<SuccessDummyTask>("TestStep");
            });

            Assert.NotNull(serviceProvider.GetService<WorkerMarkerService>());

            ITaskManager taskManager = serviceProvider.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(new WorkerTaskInvokeRequest() { StepInstanceId = "1", StepTemplateName = "TestStep" });

            Assert.NotNull(invokeResult);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Success, invokeResult!.Status);
            Assert.Empty(invokeResult?.Errors);
        }
    }
}
