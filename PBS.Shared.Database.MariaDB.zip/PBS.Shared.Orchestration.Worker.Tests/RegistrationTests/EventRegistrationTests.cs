﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Tasks.Handlers;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Handlers;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.RegistrationTests
{
    public class EventRegistrationTests : WorkerTestBase
    {
        public EventRegistrationTests(ITestOutputHelper outputHelper):base(outputHelper)
        {
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void EventRegistration_WhenRegisteringWithThisAssemblyShouldResolveEventHandlersInLibraryAndThisAssembly_ReturnsEventHandler()
        {
            using var webFactory = CreateWorkerWebFactory(workerName: "DemoWorker", scanAssemblies: GetType().Assembly);

            Assert.NotNull(webFactory.Services.GetService<IEventManager>());
            // handlers from this assembly
            Assert.NotNull(webFactory.Services.GetService<FirstDummyEventHandler>());
            Assert.NotNull(webFactory.Services.GetService<SecondDummyEventHandler>());
            // handlers from library assembly
            Assert.NotNull(webFactory.Services.GetService<InvokeTaskEventHandler>());
            Assert.NotNull(webFactory.Services.GetService<StepCompletedEventHandler>());
            Assert.NotNull(webFactory.Services.GetService<StepStartedEventHandler>());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void EventRegistration_WhenRegisteringWithLibraryAssemblyShouldNotResolveEventHandlersInThisAssembly_ReturnsNull()
        {
            using var webFactory = CreateWorkerWebFactory(workerName: "DemoWorker");

            Assert.NotNull(webFactory.Services.GetService<IEventManager>());
            // handlers from this assembly
            Assert.Null(webFactory.Services.GetService<FirstDummyEventHandler>());
            Assert.Null(webFactory.Services.GetService<SecondDummyEventHandler>());
            // handlers from library assembly
            Assert.NotNull(webFactory.Services.GetService<InvokeTaskEventHandler>());
            Assert.NotNull(webFactory.Services.GetService<StepCompletedEventHandler>());
            Assert.NotNull(webFactory.Services.GetService<StepStartedEventHandler>());
        }
    }
}
