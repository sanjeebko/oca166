﻿using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.RegistrationTests
{
    public class TaskRegistrationTests : WorkerTestBase
    {
        public TaskRegistrationTests(ITestOutputHelper outputHelper):base(outputHelper)
        {
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void TaskRegistration_WhenRegisteringWithThisAssemblyShouldResolveTaskInThisAssembly_ReturnsTask()
        {
            using var webFactory = CreateWorkerWebFactory(workerName: "DemoWorker", scanAssemblies: GetType().Assembly);

            Assert.NotNull(webFactory.Services.GetService<DummyTask>());
            Assert.NotNull(webFactory.Services.GetService<SuccessDummyTask>());
            Assert.NotNull(webFactory.Services.GetService<FailedDummyTask>());
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public void TaskRegistration_WhenRegisteringWithLibraryAssemblyShouldNotResolveTaskInThisAssembly_ReturnsNull()
        {
            using var webFactory = CreateWorkerWebFactory(workerName: "DemoWorker");

            Assert.Null(webFactory.Services.GetService<DummyTask>());
            Assert.Null(webFactory.Services.GetService<SuccessDummyTask>());
            Assert.Null(webFactory.Services.GetService<FailedDummyTask>());
        }
    }
}
