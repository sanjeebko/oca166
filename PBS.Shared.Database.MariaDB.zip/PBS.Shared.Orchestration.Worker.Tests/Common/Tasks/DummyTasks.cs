﻿using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.PropertyTypeFormats;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tests.Common.Tasks
{
    public class DummyTask : ITask
    {
        public Task<WorkerTaskInvokeResult> ExecuteAsync(ITaskInvokeContext context)
        {
            return Task.FromResult(TaskInvokeResultExtensions.Success());
        }
    }

    public class SuccessDummyTask : ITask
    {
        public Task<WorkerTaskInvokeResult> ExecuteAsync(ITaskInvokeContext context)
        {
            return Task.FromResult(TaskInvokeResultExtensions.Success());
        }
    }

    public class FailedDummyTask : ITask
    {
        public Task<WorkerTaskInvokeResult> ExecuteAsync(ITaskInvokeContext context)
        {
            return Task.FromResult(TaskInvokeResultExtensions.Failed(new Exception("This task is failed")));
        }
    }

    public class DecisionByInputDummyTask : ITask
    {
        public Task<WorkerTaskInvokeResult> ExecuteAsync(ITaskInvokeContext context)
        {
            bool shouldSuccess = (bool)(context.Request.Inputs["ShouldSucceed"].Value ?? throw new InvalidOperationException("Missing property value ShouldSucceed"));
            bool shouldError = (bool)(context.Request.Inputs["ShouldError"].Value ?? throw new InvalidOperationException("Missing property value ShouldError"));

            if (shouldSuccess)
            {
                return Task.FromResult(TaskInvokeResultExtensions.Success(new Dictionary<string, PropertyValue> { { "WasSuccessful", new PropertyValue() { Type = "boolean", Value = shouldSuccess } } }));
            }

            if (shouldError)
            {
                return Task.FromResult(TaskInvokeResultExtensions.Failed(new Exception("This task is failed")));
            }

            return Task.FromResult<WorkerTaskInvokeResult>(null!);
        }
    }
}
