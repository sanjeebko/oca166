﻿using System;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace PBS.Shared.Orchestration.Worker.Tests.Common
{
    public class TestStartup
    {
        public TestStartup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddRouting();

            services.AddSignalR(options => { options.KeepAliveInterval = TimeSpan.FromSeconds(10); }).AddJsonProtocol();
        }

        public void Configure(IApplicationBuilder app)
        {
            app.UseWebSockets();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHub<FakeOrchestrationHub>("/ws/1/orchestration", options =>
                {
                    options.WebSockets.SubProtocolSelector = requestedProtocols => requestedProtocols.Count > 0 ? requestedProtocols[0] : null!;
                });
            });
        }
    }
}