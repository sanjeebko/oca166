﻿using System;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;

namespace PBS.Shared.Orchestration.Worker.Tests.Common
{
    public class ConfigurableTestWebFactory : IDisposable
    {
        public ConfigurableTestWebFactory(
            Action<IServiceCollection> serviceConfigure,
            Action<IServiceProvider> applicationConfigure,
            Action<ILoggingBuilder>? loggingConfigure)
        {
            IServiceCollection serviceCollection = new ServiceCollection();
            serviceConfigure?.Invoke(serviceCollection);
            serviceCollection.AddLogging(builder =>
            {
                loggingConfigure?.Invoke(builder);
            });

            Services = serviceCollection.BuildServiceProvider();
            applicationConfigure?.Invoke(Services);

        }

        public IServiceProvider Services { get; }

        public void Dispose()
        {
            ((ServiceProvider)Services).Dispose();
        }
    }
}