﻿using System.Threading;
using PBS.Shared.Orchestration.Worker.Events;

namespace PBS.Shared.Orchestration.Worker.Tests.Common.Handlers
{
    public class FirstDummyEvent : EventBase
    {
        public int Count { get; set; }
        public AutoResetEvent EventProcessedAutoReceiveEvent { get; set; } = new AutoResetEvent(false);
    }

    public class SecondDummyEvent : EventBase
    {
        public int Count { get; set; }
        public AutoResetEvent EventProcessedAutoReceiveEvent { get; set; } = new AutoResetEvent(false);
    }
}
