﻿using System.Threading.Tasks;
using PBS.Shared.Orchestration.Worker.Events;

namespace PBS.Shared.Orchestration.Worker.Tests.Common.Handlers
{
    public class FirstDummyEventHandler : EventHandlerBase<FirstDummyEvent>
    {
        protected override Task HandleAsync(FirstDummyEvent evt)
        {
            evt.Count++;

            evt.EventProcessedAutoReceiveEvent.Set();

            return Task.CompletedTask;
        }
    }

    public class SecondDummyEventHandler : EventHandlerBase<SecondDummyEvent>
    {
        protected override Task HandleAsync(SecondDummyEvent evt)
        {
            evt.Count++;

            evt.EventProcessedAutoReceiveEvent.Set();

            return Task.CompletedTask;
        }
    }
}
