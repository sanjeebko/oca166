﻿using System;
using Microsoft.Extensions.Logging;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.Common.Logging
{
    public class CategoryMockupLoggerProvider : ILoggerProvider
    {
        private readonly ITestOutputHelper _outputHelper;
        private readonly Func<string, string> _categoryFormatter;

        public CategoryMockupLoggerProvider(ITestOutputHelper outputHelper, Func<string, string> categoryFormatter)
        {
            _outputHelper = outputHelper;
            _categoryFormatter = categoryFormatter;
        }

        public ILogger CreateLogger(string categoryName)
        {
           return new CategoryMockupLogger(_outputHelper, _categoryFormatter != null ? _categoryFormatter(categoryName) : categoryName);
        }

        public void Dispose()
        {
            // do nothing
        }
    }
}
