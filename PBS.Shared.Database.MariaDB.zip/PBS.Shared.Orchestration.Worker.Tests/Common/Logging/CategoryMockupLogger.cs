﻿using Microsoft.Extensions.Logging;
using System;
using System.Diagnostics;
using System.Reactive.Disposables;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.Common.Logging
{
    public class CategoryMockupLogger<T> : CategoryMockupLogger, ILogger<T>
    {
        public CategoryMockupLogger(ITestOutputHelper output) : base(output, typeof(T).FullName!)
        {
        }
    }

    public class CategoryMockupLogger : ILogger
    {
        private readonly ITestOutputHelper _output;
        private readonly string _category;

        public CategoryMockupLogger(ITestOutputHelper output, string category)
        {
            _output = output;
            _category = category;
        }

        public IDisposable BeginScope<TState>(TState state)
        {
            return Disposable.Empty;
        }

        public bool IsEnabled(LogLevel logLevel)
        {
            return true;
        }

        public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception exception, Func<TState, Exception, string> formatter)
        {
            string str = DateTime.UtcNow.ToString("u");
            try
            {
                _output.WriteLine($"{_category} | {str} | {logLevel} | {formatter(state, exception)}");
                if (exception == null)
                    return;
                _output.WriteLine("Exception: " + exception);
            }
            catch (InvalidOperationException ex)
            {
                Trace.WriteLine(ex.ToString());
            }
        }
    }
}