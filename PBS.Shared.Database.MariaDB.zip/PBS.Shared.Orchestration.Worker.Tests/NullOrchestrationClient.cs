﻿using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients;
using System;
using System.Threading.Tasks;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    public class NullOrchestrationClient : IOrchestrationClient
    {
        private readonly ILogger<NullOrchestrationClient> _logger;

        public event Func<Task>? OnConnected;

        public bool Connected { get; } = true;

        public NullOrchestrationClient(ILogger<NullOrchestrationClient> logger)
        {
            _logger = logger;
        }

        public Task ConnectAsync(string url)
        {
            _logger.LogInformation($"Connecting to {url}");
            OnConnected?.Invoke();

            return Task.CompletedTask;
        }

        public Task DisconnectAsync()
        {
            _logger.LogInformation("Disconnecting");

            return Task.CompletedTask;
        }

        public Task DisposeAsync()
        {
            _logger.LogInformation("Disposing");

            return Task.CompletedTask;
        }

        public Task SendMessage(string method, object message)
        {
            _logger.LogInformation($"Sending message:{message} for method:{message}");

            return Task.CompletedTask;
        }

        public void Subscribe<T>(string method, Func<T, Task> function)
        {
            _logger.LogInformation($"Subscribe for method {method}");
        }

        public void Subscribe(string method, Func<string, Task> function)
        {
            _logger.LogInformation($"Subscribe for method {method}");
        }

        public void UnSubscribe(string method)
        {
            _logger.LogInformation($"UnSubscribe for method {method}");
        }
    }
}
