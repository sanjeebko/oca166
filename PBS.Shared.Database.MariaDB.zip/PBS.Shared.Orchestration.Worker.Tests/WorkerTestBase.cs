﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Options;
using PBS.Shared.Orchestration.Worker.Registration;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Logging;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    public abstract class WorkerTestBase
    {
        protected ITestOutputHelper OutputHelper { get; }

        protected WorkerTestBase(ITestOutputHelper outputHelper)
        {
            OutputHelper = outputHelper;
        }

        protected ConfigurableTestWebFactory CreateWorkerWebFactory(Action<WorkerConfig> configureWorker, Action<IWorkerTaskMappingBuilder>? configureTaskMapping = null)
        {
            ConfigurableTestWebFactory factory = new ConfigurableTestWebFactory(serviceConfigure: collection =>
            {
                collection.AddPBSWorker(configureWorker);
            }, applicationConfigure: builder =>
            {
                builder.UsePBSWorker(configureTaskMapping);
            }, loggingConfigure: builder =>
            {
                builder.AddProvider(new CategoryMockupLoggerProvider(OutputHelper, FormatLoggerCategory!));
                builder.SetMinimumLevel(LogLevel.Trace);
            });

            return factory;
        }

        protected ConfigurableTestWebFactory CreateWorkerWebFactory(string workerName, params Assembly[] scanAssemblies)
        {
            return CreateWorkerWebFactory(config =>
            {
                config.ScanAssembly = scanAssemblies;
                config.WorkerName = workerName;
                config.WorkerAnnouncement = new WorkerAnnouncement()
                {
                    StepTemplates = new List<WorkerStepTemplate>()
                    {
                        new WorkerStepTemplate
                        {
                            Name = "NullStep",
                            Category = "Demo",
                            Type = "Action",
                            Version = 1
                        }
                    }
                };
                config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
            });
        }

        protected ConfigurableTestWebFactory CreateWorkerWebFactoryForTask<TTask>(string workerName, string templateName, params Assembly[] scanAssemblies) where TTask : ITask
        {
            return CreateWorkerWebFactory(configureWorker: config =>
            {
                config.ScanAssembly = scanAssemblies;
                config.WorkerName = workerName;

                if (!string.IsNullOrEmpty(templateName))
                {
                    config.WorkerAnnouncement = new WorkerAnnouncement()
                    {
                        StepTemplates = new List<WorkerStepTemplate>()
                        {
                            new WorkerStepTemplate
                            {
                                Name = templateName,
                                Category = "Demo",
                                Type = "Action",
                                Version = 1
                            }
                        }
                    };

                    config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
                }
              
            }, configureTaskMapping: builder =>
            {
                if (!string.IsNullOrEmpty(templateName))
                {
                    builder.MapTask<TTask>(templateName);
                }
            });
        }

        protected string? FormatLoggerCategory(string category)
        {
            return category.Split(".", StringSplitOptions.RemoveEmptyEntries).LastOrDefault();
        }
    }
}
