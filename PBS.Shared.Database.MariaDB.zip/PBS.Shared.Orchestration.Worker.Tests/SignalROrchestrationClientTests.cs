﻿using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Logging;
using PBS.Shared.Orchestration.Worker.Clients.SignalR;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Logging;
using PBS.Shared.Testing;
using System;
using System.Globalization;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests
{
    public class SignalROrchestrationClientTests : IClassFixture<TestWebFactory>
    {
        private readonly ITestOutputHelper _outputHelper;
        private readonly TestWebFactory _factory;

        public SignalROrchestrationClientTests(ITestOutputHelper outputHelper, TestWebFactory factory)
        {
            _outputHelper = outputHelper;
            _factory = factory;
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task SignalRClient_WhenConnectionIsDownShouldReconnect_Connected()
        {
            CategoryMockupLogger<SignalROrchestrationClient> logger = new CategoryMockupLogger<SignalROrchestrationClient>(_outputHelper);

            _factory.CreateClient();

            TestServer server = _factory.Server;

            var testableClient = new TestableSignalROrchestrationClient(logger, server.CreateHandler());

            var connectedManualResetEvent = new AsyncManualResetEvent<bool>();

            testableClient.OnConnected += () =>
            {
                connectedManualResetEvent.Set(true);
                return Task.CompletedTask;
            };

            await testableClient.ConnectAsync("http://localhost/ws/1/orchestration");

            await connectedManualResetEvent.WaitAsync();

            Assert.True(testableClient.Connected);

            connectedManualResetEvent.Reset();

            await testableClient.DisconnectAsync();

            Assert.False(testableClient.Connected);

            await connectedManualResetEvent.WaitAsync();

            Assert.True(testableClient.Connected);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task SignalRClient_WhenConnectionIsDisposedShouldNotReconnect_NotConnected()
        {
            CategoryMockupLogger<SignalROrchestrationClient> logger = new CategoryMockupLogger<SignalROrchestrationClient>(_outputHelper);

            _factory.CreateClient();

            TestServer server = _factory.Server;

            var testableClient = new TestableSignalROrchestrationClient(logger, server.CreateHandler());

            var connectedManualResetEvent = new AsyncManualResetEvent<bool>();

            testableClient.OnConnected += () =>
            {
                connectedManualResetEvent.Set(true);
                return Task.CompletedTask;
            };

            await testableClient.ConnectAsync("http://localhost/ws/1/orchestration");

            bool isConnected = await connectedManualResetEvent.WaitAsync();

            Assert.True(testableClient.Connected);
            Assert.True(isConnected);

            connectedManualResetEvent.Reset();

            await testableClient.DisposeAsync();

            Assert.False(testableClient.Connected);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task SignalRClient_WhenSubscribed_ShouldReceiveHeartbeatMessage_MessageReceived()
        {
            CategoryMockupLogger<SignalROrchestrationClient> logger = new CategoryMockupLogger<SignalROrchestrationClient>(_outputHelper);

            _factory.CreateClient();

            TestServer server = _factory.Server;

            var testableClient = new TestableSignalROrchestrationClient(logger, server.CreateHandler());

            string message = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            var messageReceivedManualResetEvent = new AsyncManualResetEvent<bool>();
            var connectedManualResetEvent = new AsyncManualResetEvent<bool>();

            testableClient.Subscribe("Heartbeat", serverMessage =>
            {
                logger.LogInformation("Received message {HeartbeatMessage} on Heartbeat method", serverMessage);

                // check message content, should be same
                Assert.Equal(serverMessage, message);

                messageReceivedManualResetEvent.Set(true);

                return Task.CompletedTask;
            });

            testableClient.OnConnected += () =>
            {
                connectedManualResetEvent.Set(true);
                return Task.CompletedTask;
            };

            await testableClient.ConnectAsync("http://localhost/ws/1/orchestration");

            bool isConnected = await connectedManualResetEvent.WaitAsync();

            Assert.True(testableClient.Connected);
            Assert.True(isConnected);

            await testableClient.SendMessage("Heartbeat", message);

            bool isMessageReceived = await messageReceivedManualResetEvent.WaitAsync();

            await testableClient.DisposeAsync();

            Assert.True(isMessageReceived);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task SignalRClient_WhenSubscribed_ShouldReceiveInvokeTaskMessage_MessageReceived()
        {
            CategoryMockupLogger<SignalROrchestrationClient> logger = new CategoryMockupLogger<SignalROrchestrationClient>(_outputHelper);

            _factory.CreateClient();

            TestServer server = _factory.Server;

            var testableClient = new TestableSignalROrchestrationClient(logger, server.CreateHandler());

            string message = DateTime.Now.ToString(CultureInfo.InvariantCulture);
            var messageReceivedManualResetEvent = new AsyncManualResetEvent<bool>();
            var connectedManualResetEvent = new AsyncManualResetEvent<bool>();

            testableClient.Subscribe("InvokeTask", serverMessage =>
            {
                logger.LogInformation("Received message {InvokeTaskMessage} on InvokeTask method", serverMessage);

                // check message content, should be same
                Assert.Equal(serverMessage, message);

                messageReceivedManualResetEvent.Set(true);

                return Task.CompletedTask;
            });

            testableClient.OnConnected += () =>
            {
                connectedManualResetEvent.Set(true);
                return Task.CompletedTask;
            };

            await testableClient.ConnectAsync("http://localhost/ws/1/orchestration");

            bool isConnected = await connectedManualResetEvent.WaitAsync();

            Assert.True(testableClient.Connected);
            Assert.True(isConnected);

            await testableClient.SendMessage("InvokeTask", message);

            bool isMessageReceived = await messageReceivedManualResetEvent.WaitAsync();

            Assert.True(isMessageReceived);
        }
    }
}
