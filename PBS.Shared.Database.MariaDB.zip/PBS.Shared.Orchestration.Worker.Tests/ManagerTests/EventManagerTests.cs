﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc.Testing;
using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Tests.Common;
using PBS.Shared.Orchestration.Worker.Tests.Common.Handlers;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.ManagerTests
{
    public class EventManagerTests : WorkerTestBase
    {
        public EventManagerTests(ITestOutputHelper outputHelper):base(outputHelper)
        {
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task EventManager_PublishingEventShouldBeReceivedByCorrectEventHandlerForThatEventType_ReturnsSuccess()
        {
            using var webFactory = CreateWorkerWebFactory(workerName: "DemoWorker", scanAssemblies:GetType().Assembly);
         
            IEventManager eventManager = webFactory.Services.GetRequiredService<IEventManager>();

            eventManager.Subscribe<FirstDummyEventHandler>();
            eventManager.Subscribe<SecondDummyEventHandler>();

            FirstDummyEvent firstEvent = new FirstDummyEvent { EventProcessedAutoReceiveEvent = new AutoResetEvent(false) };
            SecondDummyEvent secondEvent = new SecondDummyEvent { EventProcessedAutoReceiveEvent = new AutoResetEvent(false) };

            await eventManager.PublishAsync(firstEvent);
            await eventManager.PublishAsync(secondEvent);

            bool successFirst = firstEvent.EventProcessedAutoReceiveEvent.WaitOne(timeout: TimeSpan.FromSeconds(1));
            bool successSecond = secondEvent.EventProcessedAutoReceiveEvent.WaitOne(timeout: TimeSpan.FromSeconds(1));

            Assert.True(successFirst && firstEvent.Count == 1);
            Assert.True(successSecond && secondEvent.Count == 1);
        }
    }
}
