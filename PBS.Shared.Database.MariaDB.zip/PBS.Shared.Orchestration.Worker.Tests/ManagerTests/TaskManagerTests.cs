﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Orchestration.Worker.Clients;
using PBS.Shared.Orchestration.Worker.Managers;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Registration;
using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.Orchestration.Worker.Tests.Common.Tasks;
using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;
using Xunit.Abstractions;

namespace PBS.Shared.Orchestration.Worker.Tests.ManagerTests
{
    public class TaskManagerTests : WorkerTestBase
    {
        public TaskManagerTests(ITestOutputHelper outputHelper) : base(outputHelper)
        {
        }

        private static (List<PropertyFormat> inputs, List<PropertyFormat> outputs) CreateTestInputsAndOutputs()
        {
            List<PropertyFormat> inputs = new List<PropertyFormat>
            {
                new PropertyFormat { Name = "ShouldSucceed", Types = new List<PropertyType> {new PropertyType {Name = "boolean"}}},
                new PropertyFormat { Name = "ShouldError", Types = new List<PropertyType> {new PropertyType {Name = "boolean"}}}
            };
            List<PropertyFormat> outputs = new List<PropertyFormat>
            {
                new PropertyFormat { Name = "WasSuccessful", Types = new List<PropertyType> {new PropertyType {Name = "boolean"}}},
            };
            return (inputs, outputs);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task TaskManager_WhenInvokingInvalidTaskTypeForStepTemplate_ReturnNull()
        {
            using var webFactory = CreateWorkerWebFactoryForTask<DummyTask>(workerName: "DemoWorker", templateName: "TestStep", scanAssemblies: GetType().Assembly);

            ITaskManager taskManager = webFactory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(new WorkerTaskInvokeRequest { StepInstanceId = "1", StepTemplateName = "InvalidStepTemplateName" });

            Assert.Null(invokeResult);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task TaskManager_WhenInvokingValidTaskTypeForStepTemplateWithSuccessResponse_ReturnsSuccess()
        {
            using var webFactory = CreateWorkerWebFactoryForTask<SuccessDummyTask>(workerName: "DemoWorker", templateName: "SuccessDummyStep", scanAssemblies: GetType().Assembly);

            ITaskManager taskManager = webFactory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(new WorkerTaskInvokeRequest { StepInstanceId = "1", StepTemplateName = "SuccessDummyStep" });

            Assert.NotNull(invokeResult);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Success, invokeResult?.Status);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task TaskManager_WhenInvokingValidTaskTypeForStepTemplateWithErrorResponse_ReturnsFailed()
        {
            using var webFactory = CreateWorkerWebFactoryForTask<FailedDummyTask>(workerName: "DemoWorker", templateName: "FailedDummyStep", scanAssemblies: GetType().Assembly);

            ITaskManager taskManager = webFactory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(new WorkerTaskInvokeRequest { StepInstanceId = "1", StepTemplateName = "FailedDummyStep" });

            Assert.NotNull(invokeResult);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Failed, invokeResult?.Status);
            Assert.NotEmpty(invokeResult?.Errors);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task TaskManager_WhenInvokingTaskDecisionByInputDummyTaskWithInputsForShouldSucceed_ReturnsSuccess()
        {
            (List<PropertyFormat> inputs, List<PropertyFormat> outputs) = CreateTestInputsAndOutputs();

            using var webFactory = CreateWorkerWebFactory(configureWorker: config =>
            {
                config.WorkerName = "DemoWorker";
                config.ScanAssembly = new[] { GetType().Assembly };
                config.WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "Success Step",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                            Inputs = inputs,
                            Outputs = outputs
                        }
                    }
                };
                config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
            }, configureTaskMapping: mappingBuilder =>
            {
                mappingBuilder.MapTask<DecisionByInputDummyTask>("Success Step");
            });

            ITaskManager taskManager = webFactory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeRequest request = new WorkerTaskInvokeRequest
            {
                StepInstanceId = "1",
                StepTemplateName = "Success Step",
                Inputs = new Dictionary<string, PropertyValue>
            {
                {"ShouldSucceed", new PropertyValue {Type = "boolean", Value = true}},
                {"ShouldError", new PropertyValue {Type = "boolean", Value = false}}
            }
            };

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(request);

            Assert.NotNull(invokeResult);
            Assert.NotNull(invokeResult?.Output);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Success, invokeResult!.Status);
            Assert.True(invokeResult.Output!.ContainsKey("WasSuccessful"));
            Assert.Equal(true, invokeResult.Output["WasSuccessful"].Value);
        }

        [Fact]
        [Trait("TestType", "UnitTest")]
        public async Task TaskManager_WhenInvokingTaskDecisionByInputDummyTaskWithInputsForShouldError_ReturnsError()
        {
            (List<PropertyFormat> inputs, List<PropertyFormat> outputs) = CreateTestInputsAndOutputs();

            using var webFactory = CreateWorkerWebFactory(configureWorker: config =>
            {
                config.WorkerName = "DemoWorker";
                config.ScanAssembly = new[] { GetType().Assembly };
                config.WorkerAnnouncement = new WorkerAnnouncement
                {
                    StepTemplates = new List<WorkerStepTemplate>
                    {
                        new WorkerStepTemplate
                        {
                            Name = "Success Step",
                            Type = "Action",
                            Category = "Demo",
                            Version = 1,
                            Inputs = inputs,
                            Outputs = outputs
                        }
                    }
                };
                config.ReplaceService<IOrchestrationClient, NullOrchestrationClient>();
            }, configureTaskMapping: mappingBuilder =>
            {
                mappingBuilder.MapTask<DecisionByInputDummyTask>("Success Step");
            });

            ITaskManager taskManager = webFactory.Services.GetRequiredService<ITaskManager>();

            WorkerTaskInvokeRequest request = new WorkerTaskInvokeRequest
            {
                StepInstanceId = "1",
                StepTemplateName = "Success Step",
                Inputs = new Dictionary<string, PropertyValue>
            {
                { "ShouldSucceed", new PropertyValue {Type = "boolean", Value = false} },
                { "ShouldError", new PropertyValue {Type = "boolean", Value = true} }
            }
            };

            WorkerTaskInvokeResult? invokeResult = await taskManager.InvokeTaskAsync(request);

            Assert.NotNull(invokeResult);
            Assert.NotNull(invokeResult?.Output);
            Assert.Equal(WorkerTaskInvokeRequestStatus.Failed, invokeResult!.Status);
            Assert.NotEmpty(invokeResult?.Errors);
        }
    }
}
