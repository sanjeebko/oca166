﻿using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using System;
using System.Collections.Generic;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests.SchemaTests
{
    public class WorkerTaskInvokeResponseSchemaTest
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<WorkerTaskInvokeResult> tester = new SchemaTester<WorkerTaskInvokeResult>();
            tester.ValidateProperty<WorkerTaskInvokeRequestStatus>("Status");
            tester.ValidateProperty<List<string>>("Errors");
            tester.ValidateProperty<Dictionary<string, PropertyValue>>("Output");
            tester.ValidateProperty<DateTimeOffset>("StartedTimestamp");
            tester.ValidateProperty<DateTimeOffset?>("CompletedTimestamp");
            tester.ValidateUncheckedProperties();
        }
    }
}