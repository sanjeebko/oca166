﻿using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Testing;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests.SchemaTests
{
    public class WorkerAnnounceConfigSchemaTest
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<WorkerAnnouncement> tester = new SchemaTester<WorkerAnnouncement>();
            tester.ValidateProperty<IEnumerable<WorkerStepTemplate>?>("StepTemplates");
            tester.ValidateProperty<WorkerCapabilities?>("WorkerCapabilities");
            tester.ValidateUncheckedProperties();
        }
    }
}