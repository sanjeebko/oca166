﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;
using PBS.Shared.Orchestration.Worker.Models;
using Xunit;
using PBS.Shared.Testing;

namespace PBS.Shared.Orchestration.Worker.Tests.SchemaTests
{
    public class WorkerStepTemplateConfigSchemaTest
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<WorkerStepTemplate> tester = new SchemaTester<WorkerStepTemplate>();
            tester.ValidateProperty<string?>("Name");
            tester.ValidateProperty<int>("Version");
            tester.ValidateProperty<string?>("Type");
            tester.ValidateProperty<string?>("Category");
            tester.ValidateProperty<List<PropertyFormat>?>("Inputs");
            tester.ValidateProperty<List<PropertyFormat>?>("Outputs");
            tester.ValidateUncheckedProperties();
        }
    }
}