﻿using PBS.Shared.Orchestration.Worker.Tasks;
using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Testing;
using System.Collections.Generic;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests.SchemaTests
{
    public class WorkerTaskInvokeRequestSchemaTest
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<WorkerTaskInvokeRequest> tester = new SchemaTester<WorkerTaskInvokeRequest>();
            tester.ValidateProperty<string?>("StepTemplateName");
            tester.ValidateProperty<string?>("StepInstanceId");
            tester.ValidateProperty<Dictionary<string, PropertyValue>>("Inputs");
            tester.ValidateUncheckedProperties();
        }
    }
}
