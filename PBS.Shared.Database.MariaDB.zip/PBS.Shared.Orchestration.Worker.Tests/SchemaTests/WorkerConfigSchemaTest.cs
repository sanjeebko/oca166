﻿using System;
using System.Collections.Generic;
using System.Reflection;
using PBS.Shared.Orchestration.Worker.Models;
using PBS.Shared.Orchestration.Worker.Paths;
using PBS.Shared.Testing;
using Xunit;

namespace PBS.Shared.Orchestration.Worker.Tests.SchemaTests
{
    public class WorkerConfigSchemaTest
    {
        [Fact]
        [Trait("TestType", "UnitTest")]
        public void Test_Schema()
        {
            SchemaTester<WorkerConfig> tester = new SchemaTester<WorkerConfig>();
            tester.ValidateProperty<string?>("WorkerName");
            tester.ValidateProperty<WorkerAnnouncement>("WorkerAnnouncement");
            tester.ValidateProperty<ServicePathsConfig?>("ServicePathsConfig");
            tester.ValidateProperty<IEnumerable<Assembly>>("ScanAssembly");
            tester.ValidateProperty<string>("OrchestrationEngineWebSocketEndpoint");
            tester.ValidateProperty<IReadOnlyDictionary<Type, Type>>("ServiceReplacement");
            tester.ValidateUncheckedProperties();
        }
    }
}