﻿using PBS.Shared.PropertyTypeFormats;
using PBS.Shared.Storage;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Formats
{
    public class AwsS3ConnectionMechanismObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string CredentialsPropertyName = "credentials";
        public const string RegionPropertyName = "region";
        public const string BucketPropertyName = "bucket";
        public const string FormatName = "AwsS3ConnectionMechanism";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
            => new ConfigObjectFormat
            {
                Category = FormatCategories.ConnectionMechanism,
                Name = FormatName,
                DisplayName = "Amazon S3",
                Hint = "A bucket running on Amazon's S3 Platform for storing data",
                Properties = new Dictionary<string, PropertyFormat>
                {
                    {
                        RegionPropertyName, new PropertyFormat
                        {
                            Name = RegionPropertyName,
                            DisplayName = "Region",
                            Hint = "The AWS Region in which the bucket is located",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    },
                                    AcceptedValues = AmazonAws.GetAllRegionNames
                                }
                            }
                        }
                    },
                    {
                        BucketPropertyName, new PropertyFormat
                        {
                            Name = BucketPropertyName,
                            DisplayName = "Bucket",
                            Hint = "The bucket running on Amazon's S3 Platform which will store the data",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    }
                                }
                            }
                        }
                    },
                    {
                        CredentialsPropertyName, new PropertyFormat
                        {
                            Name = CredentialsPropertyName,
                            DisplayName = "Credentials",
                            Hint = "Select the Credentials that will be used to the access bucket. If the bucket is public or otherwise accessible, no credential is required",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = ConfigurationPropertyTypes.BuildConfigurationFormatTypeCompositeKey(AwsS3CredentialObjectFormat.FormatName)
                                }
                            }
                        }
                    }
                },
                ObjectValidators = new Dictionary<string, object>
                {
                    { ValidatorKeys.AmazonS3Connection, ValidatorArgs.Default}
                },
            };

        public ConfigObjectFormat Object => Instance;

    }
}
