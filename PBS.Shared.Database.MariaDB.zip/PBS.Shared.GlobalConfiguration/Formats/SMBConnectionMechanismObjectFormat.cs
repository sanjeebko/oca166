﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Formats
{
    public class SMBConnectionMechanismObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string TargetPathPropertyName = "targetPath";
        public const string CredentialsPropertyName = "credentials";
        public const string FormatName = "SmbConnectionMechanism";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
            => new ConfigObjectFormat
            {
                Category = FormatCategories.ConnectionMechanism,
                Name = FormatName,
                DisplayName = "SMB",
                Hint = "Choose if the Location you are entering refer to an SMB/CIFS connection",
                Properties = new Dictionary<string, PropertyFormat>
                {
                    {
                        TargetPathPropertyName, new PropertyFormat
                        {
                            Name = TargetPathPropertyName,
                            DisplayName = "Path",
                            Hint = "Type the path for the file location you are entering.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    }
                                }
                            }
                        }
                    },
                    {
                        CredentialsPropertyName, new PropertyFormat
                        {
                            Name = CredentialsPropertyName,
                            DisplayName = "Credentials",
                            Hint = "Select the Credentials that will be used to access the path",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = ConfigurationPropertyTypes.BuildConfigurationFormatTypeCompositeKey(SmbCredentialObjectFormat.FormatName),
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    }
                                }
                            }
                        }
                    }

                },
                ObjectValidators = new Dictionary<string, object>
                {
                    { ValidatorKeys.SmbConnection, ValidatorArgs.Default}
                },
            };

        public ConfigObjectFormat Object => Instance;

    }
}
