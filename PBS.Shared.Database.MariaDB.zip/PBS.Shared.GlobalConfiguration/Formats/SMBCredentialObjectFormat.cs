﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Formats
{
    public class SmbCredentialObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string UsernamePropertyName = "username";
        public const string PasswordPropertyName = "password";
        public const string DomainPropertyName = "domain";
        public const string FormatName = "SmbCredential";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
            => new ConfigObjectFormat
            {
                Category = FormatCategories.Credential,
                Name = FormatName,
                DisplayName = "SMB",
                Hint = "Choose if the Credentials you are entering refer to an SMB/CIFS connection",
                Properties = new Dictionary<string, PropertyFormat>
                {
                    {
                        UsernamePropertyName, new PropertyFormat
                        {
                            Name = UsernamePropertyName,
                            DisplayName = "User Name",
                            Flags = new[]{FormatPropertyMetadata.Sensitive},
                            Hint = "Type the Username for the set of Credentials you are entering. It can include uppercase, lowercase, numbers and non-alphanumeric characters.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    }
                                }
                            }
                        }
                    },
                    {
                        PasswordPropertyName, new PropertyFormat
                        {
                            Name = PasswordPropertyName,
                            DisplayName = "Password",
                            Flags = new[]{ FormatPropertyMetadata.Password, FormatPropertyMetadata.Sensitive},
                            Hint = "Type the Password for the set of Credentials you are entering. It can include uppercase, lowercase, numbers and non-alphanumeric characters.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default}
                                    }
                                }
                            }
                        }
                    },
                    {
                        DomainPropertyName, new PropertyFormat
                        {
                            Name = DomainPropertyName,
                            DisplayName = "Domain",
                            Hint = "Type the Domain for the set of Credentials you are entering.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue
                                }
                            }
                        }
                    }
                },
            };

        public ConfigObjectFormat Object => Instance;

    }
}
