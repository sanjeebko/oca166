﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Formats
{
    public class AwsS3CredentialObjectFormat : ITypeFormatInstance<ConfigObjectFormat>
    {
        public const string AccessKeyPropertyName = "accessKey";
        public const string SecretAccessKeyPropertyName = "secretAccessKey";
        public const string FormatName = "AwsS3Credential";

        public static readonly ConfigObjectFormat Instance = CreateInstance();

        private static ConfigObjectFormat CreateInstance()
            => new ConfigObjectFormat
            {
                Category = FormatCategories.Credential,
                Name = FormatName,
                DisplayName = "AWS",
                Hint = "Choose if the Credentials you are entering refer to an AWS connection",
                Properties = new Dictionary<string, PropertyFormat>
                {
                    {
                        AccessKeyPropertyName, new PropertyFormat
                        {
                            Name = AccessKeyPropertyName,
                            DisplayName = "Access Key",
                            Flags = new[]{ FormatPropertyMetadata.Sensitive},
                            Hint = "Type the access key for the set of Credentials you are entering.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default }
                                    },
                                }
                            }
                        }
                    },
                    {
                        SecretAccessKeyPropertyName, new PropertyFormat
                        {
                            Name = SecretAccessKeyPropertyName,
                            DisplayName = "Secret Access Key",
                            Flags = new[]{ FormatPropertyMetadata.Sensitive, FormatPropertyMetadata.Password },
                            Hint = "Type the secret access key for the set of Credentials you are entering.",
                            Types = new []
                            {
                                new PropertyType
                                {
                                    Name = PropertyTypes.StringValue,
                                    Validators = new Dictionary<string, object>
                                    {
                                        { ValidatorKeys.Required, ValidatorArgs.Default }
                                    },
                                }
                            }
                        }
                    }
                },
            };

        public ConfigObjectFormat Object => Instance;
    }
}
