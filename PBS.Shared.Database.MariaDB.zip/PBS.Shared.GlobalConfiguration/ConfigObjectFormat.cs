﻿using PBS.Shared.PropertyTypeFormats;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration
{
    public record ConfigObjectFormat : ITypeFormat
    {
        public string? Name { get; set; }
        public string? Category { get; set; }
        public string? DisplayName { get; set; }
        public IDictionary<string, PropertyFormat> Properties { get; set; } = new Dictionary<string, PropertyFormat>();
        public IDictionary<string, object> ObjectValidators { get; set; } = new Dictionary<string, object>();
        public bool Deprecated { get; set; }
        public string? Hint { get; set; }
    }
}
