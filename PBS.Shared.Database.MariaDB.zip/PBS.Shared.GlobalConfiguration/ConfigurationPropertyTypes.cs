﻿using System;
using System.Text.RegularExpressions;

namespace PBS.Shared.GlobalConfiguration
{
    public static class ConfigurationPropertyTypes
    {
        public const string ConfigurationContext = "Configuration";
        public const string FormatDelimiter = ".";
        public static readonly string FormatPrefix = $"{ConfigurationContext}{FormatDelimiter}";
        public static readonly Regex ConfigurationTypePattern = new Regex($@"{ConfigurationContext}\{FormatDelimiter}(\w+)", RegexOptions.Compiled);

        /// <summary>
        /// Builds composite key for format type using <see cref="ConfigurationContext"/> and <param name="formatType"></param>
        /// </summary>
        /// <param name="formatType">FormatType</param>
        /// <returns>{ConfigurationContext}.{FormatType}</returns>
        public static string BuildConfigurationFormatTypeCompositeKey(string formatType)
        {
            ValidateFormatType(formatType);
            return BuildFormatTypeCompositeKey(ConfigurationContext, formatType);
        }

        /// <summary>
        /// Builds composite key for format type using <param name="context"></param> and <param name="formatType"></param>
        /// </summary>
        /// <param name="context">Context</param>
        /// <param name="formatType">FormatType</param>
        /// <returns>{Context}.{FormatType}</returns>
        public static string BuildFormatTypeCompositeKey(string context, string formatType)
        {
            if (string.IsNullOrWhiteSpace(context))
                throw new ArgumentNullException(nameof(context));
            ValidateFormatType(formatType);
            return $"{context}{(context.EndsWith(FormatDelimiter) ? string.Empty : FormatDelimiter)}{formatType}";
        }

        public static void ValidateFormatType(string formatType)
        {
            if (string.IsNullOrWhiteSpace(formatType))
                throw new ArgumentNullException(nameof(formatType));

            if (formatType.Split(FormatDelimiter, StringSplitOptions.RemoveEmptyEntries).Length != 1)
                throw new InvalidOperationException($"Invalid format type {formatType}");
        }

        /// <summary>
        /// Determines if type value is Configuration Type using the ConfigurationTypePattern <param name="type"></param>
        /// </summary>
        /// <param name="type">Type</param>
        /// <returns>True/False</returns>
        public static bool IsConfigurationType(string? type) => type != null && ConfigurationTypePattern.IsMatch(type);

        /// <summary>
        /// Resolves Configuration Format Type <param name="type"></param>
        /// </summary>
        /// <param name="type">Type</param>
        /// <returns>{FormatType}</returns>
        public static string ResolveConfigurationFormatType(string? type) => IsConfigurationType(type) ? (type?.Replace(FormatPrefix, "") ?? string.Empty) : string.Empty;
    }
}