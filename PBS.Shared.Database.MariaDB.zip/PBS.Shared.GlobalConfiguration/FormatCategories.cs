﻿namespace PBS.Shared.GlobalConfiguration
{
    public static class FormatCategories
    {
        public const string Demo = "demo";
        public const string DummyLocation = "Location";
        public const string StorageLocation = "StorageLocation";
        public const string ConnectionMechanism = "ConnectionMechanism";
        public const string Credential = "Credential";
    }
}
