﻿using PBS.Shared.PropertyTypeFormats;
using System;
using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration
{
    public interface IConfigurationObject
    {
        string? Name { get; set; }
        string? FormatType { get; set; }
        Dictionary<string, PropertyValue> Properties { get; set; }
        DateTimeOffset CreationTime { get; set; }
        DateTimeOffset LastUpdatedTime { get; set; }
        string? Creator { get; set; }
        Lazy<ConfigObjectFormat?> FormatTypeObject { get; }
    }
}