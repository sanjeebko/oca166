﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.PropertyTypeFormats;
using System.Reflection;

namespace PBS.Shared.GlobalConfiguration.Extensions
{
    public static class PropertyTypeRegistrationExtensions
    {
        public static IServiceCollection RegisterConfigurationFormatsAndPropertyTypes(this IServiceCollection collection)
        {
            PropertyTypes.RegisterPropertyTypesFromAssembly(Assembly.GetExecutingAssembly(), ConfigurationPropertyTypes.ConfigurationContext);
            return collection;
        }
    }
}