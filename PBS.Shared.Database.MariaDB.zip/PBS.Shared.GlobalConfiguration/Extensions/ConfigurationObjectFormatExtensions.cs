﻿using PBS.Shared.PropertyTypeFormats;

namespace PBS.Shared.GlobalConfiguration.Extensions
{
    public static class ConfigurationObjectFormatExtensions
    {
        public static PropertyFormat? RetrievePropertyFormatByName(this ConfigObjectFormat format, string key) => format.Properties.TryGetValue(key, out PropertyFormat? value) ? value : null;
    }
}
