﻿using PBS.Shared.PropertyTypeFormats;

namespace PBS.Shared.GlobalConfiguration.Extensions
{
    public static class PropertyValueExtensions
    {
        public static bool IsConfigurationType(this PropertyValue value) => ConfigurationPropertyTypes.IsConfigurationType(value.Type);

        public static string ResolveConfigurationFormatType(this PropertyValue value) => ConfigurationPropertyTypes.ResolveConfigurationFormatType(value.Type);

        public static bool IsConfigurationReference(this PropertyValue value) => DomainObjectReferences.IsDomainObjectReference(value.Reference) &&
                                                                                    DomainObjectReferences.GetDomainFromReference(value.Reference ?? string.Empty) == ConfigurationPropertyTypes.ConfigurationContext;
    }
}
