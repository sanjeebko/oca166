﻿using PBS.Shared.PropertyTypeFormats;

namespace PBS.Shared.GlobalConfiguration.Validations
{
    public interface IConfigObjectPropertyValidator
    {
        IConfigObjectValidationResult Validate(PropertyValue value, PropertyFormat propertyFormat);
    }
}