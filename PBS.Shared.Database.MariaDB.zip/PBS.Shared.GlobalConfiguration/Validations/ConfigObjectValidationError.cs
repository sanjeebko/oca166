﻿namespace PBS.Shared.GlobalConfiguration.Validations
{
    public class ConfigObjectValidationError : IConfigObjectValidationError
    {
        public string? MemberName { get; set; }
        public string? ErrorMessage { get; set; }

        public ConfigObjectValidationError(string memberName, string errorMessage)
        {
            MemberName = memberName;
            ErrorMessage = errorMessage;
        }
        public ConfigObjectValidationError()
        {
        }
    }
}