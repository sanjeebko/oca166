﻿using System.Collections.Generic;

namespace PBS.Shared.GlobalConfiguration.Validations
{
    public interface IConfigObjectValidationResult
    {
        bool IsValid { get; }
        string? ConsolidatedMessage { get; }
        List<IConfigObjectValidationError> ValidationErrors { get; }
    }
}
