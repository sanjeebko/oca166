﻿namespace PBS.Shared.GlobalConfiguration.Validations
{
    public interface IConfigObjectValidator
    {
        IConfigObjectValidationResult Validate(IConfigurationObject configuration);
    }
}