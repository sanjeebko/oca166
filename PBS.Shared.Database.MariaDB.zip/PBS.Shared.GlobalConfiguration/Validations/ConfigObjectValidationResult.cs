﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PBS.Shared.GlobalConfiguration.Validations
{
    public class ConfigObjectValidationResult : IConfigObjectValidationResult
    {
        public List<IConfigObjectValidationError> ValidationErrors { get; } = new List<IConfigObjectValidationError>();

        public bool IsValid => !ValidationErrors.Any();

        public ConfigObjectValidationResult Add(string errorMessage, string memberName)
        {
            ValidationErrors.Add(new ConfigObjectValidationError(memberName, errorMessage));
            return this;
        }

        public string? ConsolidatedMessage
        {
            get
            {
                return !ValidationErrors.Any() ? null : string.Join(Environment.NewLine, ValidationErrors.Select(x => "* " + x.ErrorMessage));
            }
        }

        public IConfigObjectValidationResult AddRange(IEnumerable<IConfigObjectValidationError> validationErrors)
        {
            ValidationErrors.AddRange(validationErrors);
            return this;
        }
    }
}