﻿namespace PBS.Shared.GlobalConfiguration.Validations
{
    public interface IConfigObjectValidationError
    {
        string? MemberName { get; }
        string? ErrorMessage { get; }
    }
}