﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using NLog.Web;

namespace PBS.Shared.Logging.NLogExtensions
{
    public static class NLogServiceCollectionExtensions
    {
        //  Adds just the NLog logging initializer
        public static IServiceCollection AddNLogSharedLoggingProvider(this IServiceCollection services, string serviceName)
            => services
                .AddTransient<ILoggingInitializer, NLogLoggingInitializer>((_) => new NLogLoggingInitializer(serviceName));

        //  Adds all required logging services and the NLog logging initializer
        public static IServiceCollection AddPBSNLogLogging(this IServiceCollection services, string serviceName, string logConfigKey = "logConfig")
            => services
                    .AddLogging()
                    .AddNLogSharedLoggingProvider(serviceName)
                    .AddPBSLogConfigurationService(logConfigKey);

        //  Configure NLog as the logging provider and add all required logging services
        public static IHostBuilder UsePBSNLog(this IHostBuilder builder, string serviceName, string logConfigKey = "logConfig")
            => builder
                .ConfigureLogging(logging => logging.ClearProviders())
                .UseNLog()
                .ConfigureServices(services => services.AddPBSNLogLogging(serviceName, logConfigKey));
    }
}
