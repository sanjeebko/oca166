﻿using NLog;
using NLog.Config;
using NLog.Layouts;
using NLog.Targets;
using NLog.Targets.Wrappers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace PBS.Shared.Logging.NLogExtensions
{
    public enum LogLevelType
    {
        Default,
        EntityCore,
        AspNetCore,
        Microsoft
    }

    public class NLogLoggingInitializer : ILoggingInitializer
    {
        private readonly string _serviceName;

        public NLogLoggingInitializer(string serviceName)
        {
            _serviceName = serviceName;
        }

        public Task InitializeLogging(IEnumerable<Target> targets, CancellationToken cancellationToken = default)
        {
            var loggingConfiguration = new LoggingConfiguration();
            var nlogTargets = CreateNLogTargets(targets);

            // Configure rules. NLog doesn't provide an easy way to support setting different microsoft log levels per target, 
            // so we need to do a small workaround, which makes the rule creation a bit complex. 
            foreach (var (target, nlogTarget) in nlogTargets)
            {
                loggingConfiguration.AddTarget(nlogTarget);
                loggingConfiguration.AddRule(GetLogLevel(target, LogLevelType.EntityCore), LogLevel.Fatal, nlogTarget, "Microsoft.EntityFrameworkCore.*");
                loggingConfiguration.AddRule(GetLogLevel(target, LogLevelType.AspNetCore), LogLevel.Fatal, nlogTarget, "Microsoft.AspNetCore.*");
                loggingConfiguration.AddRule(GetLogLevel(target, LogLevelType.Microsoft), LogLevel.Fatal, nlogTarget, "Microsoft.*");
            }

            // Add final rules for ignoring microsoft logs
            loggingConfiguration.AddRule(LogLevel.Trace, LogLevel.Fatal, new NullTarget(), "Microsoft.EntityFrameworkCore.*", true);
            loggingConfiguration.AddRule(LogLevel.Trace, LogLevel.Fatal, new NullTarget(), "Microsoft.AspNetCore.*", true);
            loggingConfiguration.AddRule(LogLevel.Trace, LogLevel.Fatal, new NullTarget(), "Microsoft.*", true);

            foreach (var (target, nlogTarget) in nlogTargets)
            {
                loggingConfiguration.AddRule(GetLogLevel(target, LogLevelType.Default), LogLevel.Fatal, nlogTarget);
            }

            // Active logging configuration
            LogManager.Configuration = loggingConfiguration;
            LogManager.ReconfigExistingLoggers();

            return Task.CompletedTask;
        }

        private Dictionary<Target, NLog.Targets.Target> CreateNLogTargets(IEnumerable<Target> targets)
        {
            return targets.Select(target => (target, nlogTarget: CreateNLogTarget(target)))
                .Where(targets => targets.nlogTarget != null)
                .ToDictionary(
                    targets => targets.target,
                    targets => targets.nlogTarget!
                );
        }

        private NLog.Targets.Target? CreateNLogTarget(Target target)
        {
            if (!Enum.TryParse(target.Type, true, out TargetType type))
                return null;

            return type switch
            {
                TargetType.Console => CreateConsoleTarget(),
                TargetType.File => CreateFileTarget(target),
                TargetType.JSONFile => CreateJSONFileTarget(target),
                _ => null,
            };
        }

        public Task UpdateLogging(IEnumerable<Target> updatedTargets, CancellationToken cancellationToken = default)
        {
            // Just initialize the logging again and will use the latest config values
            return InitializeLogging(updatedTargets, cancellationToken);
        }

        private NLog.Targets.Target CreateConsoleTarget()
        {
            var consoleTarget = new ColoredConsoleTarget("consoleInner")
            {
                Layout = "${longdate} - ${pad:padding=6:inner=${level}\\:} ${message} (${callsite}:${callsite-linenumber}) ${all-event-properties} ${ndlc} ${exception:format=Message,TargetSite,Source}",
                UseDefaultRowHighlightingRules = false
            };

            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Fatal:", ForegroundColor = ConsoleOutputColor.DarkRed });
            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Error:", ForegroundColor = ConsoleOutputColor.Red });
            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Warn:", ForegroundColor = ConsoleOutputColor.Yellow });
            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Info:", ForegroundColor = ConsoleOutputColor.DarkGreen });
            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Debug:", ForegroundColor = ConsoleOutputColor.Blue });
            consoleTarget.WordHighlightingRules.Add(new ConsoleWordHighlightingRule { Text = "Trace:", ForegroundColor = ConsoleOutputColor.Magenta });

            return new AsyncTargetWrapper("console", consoleTarget);
        }

        private NLog.Targets.Target CreateFileTarget(Target configTarget)
        {
            var fileTarget = new FileTarget("fileLogInner")
            {
                FileName = string.IsNullOrEmpty(configTarget.Filename) ? "logs/service-logs.log" : configTarget.Filename,
                Layout = "${longdate} - ${pad:padding=6:inner=${level}\\:} ${message} (${callsite}:${callsite-linenumber}) ${all-event-properties} ${ndlc} ${exception:format=toString}",
                ArchiveEvery = FileArchivePeriod.Day,
                ArchiveNumbering = ArchiveNumberingMode.Date,
                ArchiveDateFormat = "yyyy-MM-dd",
                MaxArchiveFiles = configTarget.MaxFiles
            };

            return new AsyncTargetWrapper("fileLog", fileTarget);
        }

        private NLog.Targets.Target CreateJSONFileTarget(Target configTarget)
        {
            var jsonFileTarget = new FileTarget("jsonFileLogInner")
            {
                FileName = string.IsNullOrEmpty(configTarget.Filename) ? "logs/service-json-logs.log" : configTarget.Filename,
                Layout = new JsonLayout()
                {
                    SuppressSpaces = true,
                    IncludeAllProperties = true,
                    IncludeMdlc = true,
                    Attributes = {
                            new JsonAttribute("featureName", "${logger}"),
                            new JsonAttribute("timestamp", "${date:universalTime=true:format=o}"),
                            new JsonAttribute("level", "${level:upperCase=true}"),
                            new JsonAttribute("message", "${message}"),
                            new JsonAttribute("serviceName", _serviceName),
                            new JsonAttribute("sourceHint", "${callsite}:${callsite-linenumber}"),
                            new JsonAttribute("threadID", "${threadID}"),
                            new JsonAttribute("pid", "${pid}"),
                            new JsonAttribute("ipAddress", "${aspnet-request-ip}"),
                            new JsonAttribute("hostname", "${aspnet-request-host}"),
                            new JsonAttribute("exception", "${exception:format=ToString}")
                        }
                },
                ArchiveEvery = FileArchivePeriod.Day,
                ArchiveNumbering = ArchiveNumberingMode.Date,
                ArchiveDateFormat = "yyyy-MM-dd",
                MaxArchiveFiles = configTarget.MaxFiles,
            };

            return new AsyncTargetWrapper("jsonFileLog", jsonFileTarget);
        }

        private LogLevel GetLogLevel(Target configTarget, LogLevelType logLevelType)
        {
            string? logLevel = logLevelType switch
            {
                LogLevelType.Default => configTarget.LogLevel,
                LogLevelType.EntityCore => configTarget.EntityCoreLogLevel,
                LogLevelType.AspNetCore => configTarget.AspNetCoreLogLevel,
                LogLevelType.Microsoft => configTarget.MicrosoftLogLevel,
                _ => null,
            };

            return GetLogLevel(logLevel ?? "");
        }

        private LogLevel GetLogLevel(string level)
        {
            return level.ToLower() switch
            {
                "fatal" => LogLevel.Fatal,
                "error" => LogLevel.Error,
                "warn" => LogLevel.Warn,
                "info" => LogLevel.Info,
                "debug" => LogLevel.Debug,
                "trace" => LogLevel.Trace,
                //  Default to fatal if no valid level specified
                _ => LogLevel.Fatal
            };
        }
    }

    public static class LoggerExtensions
    {
        public static Logger WithMetadata(this Logger logger, (string, object)[] metadata) =>
            metadata.Aggregate(logger, (log, pair) =>
                log.WithProperty(pair.Item1, pair.Item2));
    }
}
