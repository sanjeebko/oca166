﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.Configuration;
using PBS.Shared.AccessControl;

namespace PBS.Shared.AccessControlAnnouncement
{
    public static class AccessControlExtensions
    {
            public static IServiceCollection AddAccessControlAnnouncement(this IServiceCollection services)
            {
                services.AddHttpClient("AccessControl");
                services.AddPBSConfigurationValue<AccessControlConfiguration>("AccessControl");
                services.AddSingleton<IAccessControlAnnouncementHandler, AccessControlAnnouncementHandler>();
                return services;
            }
    }
}
