﻿namespace PBS.Shared.AccessControl
{
    public class AccessControlConfiguration
    {
        public string? Host { get; set; }
        public string? Port { get; set; }
        public int? Retries { get; set; }
    }
}
