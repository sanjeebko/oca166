﻿namespace PBS.Shared.AccessControl.Models
{
    public class DomainObject
    {
        public string Name { get; set; } = "";
        public string Uid { get; set; } = "";
    }
}
