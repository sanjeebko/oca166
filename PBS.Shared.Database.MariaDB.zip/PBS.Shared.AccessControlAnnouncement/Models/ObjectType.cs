﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.AccessControl.Models
{
    public class ObjectType
    {
        public IEnumerable<string> ObjectTypeActions { get; set; } = new List<string>();
        public IEnumerable<string> ObjectActions { get; set; } = new List<string>();

        public string Name { get; set; } = "";
        public string Domain { get; set; } = "";

        public Type EFType { get; set; } = typeof(object);

        public Func<IServiceScope, string, string, Task<IEnumerable<DomainObject>>>? LookupFunc { get; set; }
    }
}
