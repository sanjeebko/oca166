﻿using System.Collections.Generic;

namespace PBS.Shared.AccessControlAnnouncement.Models
{
    public interface IAccessControlObject
    {
        public bool NeedsReannounce(Dictionary<string, object> original);
    }
}
