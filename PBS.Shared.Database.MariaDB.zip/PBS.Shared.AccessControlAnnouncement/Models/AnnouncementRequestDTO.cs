﻿using System.Collections.Generic;


namespace PBS.Shared.AccessControl.Models
{
    public class ObjectTypeDTO
    {
        public IEnumerable<string> ObjectTypeActions { get; set; } = new List<string>();
        public IEnumerable<string> ObjectActions { get; set; } = new List<string>();

        public string Name { get; set; } = "";
        public string Domain { get; set; } = "";
        public IEnumerable<DomainObject> Objects { get; set; } = new List<DomainObject>();
    }

    public class AnnouncementRequestDTO
    {
        public string? Service { get; set; }
        public string? Version { get; set; }
        public IEnumerable<ObjectTypeDTO>? ObjectTypes { get; set; }
    }
}
