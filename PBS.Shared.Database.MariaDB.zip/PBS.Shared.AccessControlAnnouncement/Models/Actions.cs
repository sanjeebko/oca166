﻿using System.Collections.Generic;

namespace PBS.Shared.AccessControl.Models
{
    public class Actions
    {
        public IEnumerable<string> ObjectTypeActions { get; }
        public IEnumerable<string> ObjectActions { get; }

        public Actions(IEnumerable<string> objectTypeActions, IEnumerable<string> objectActions)
        {
            ObjectTypeActions = objectTypeActions;
            ObjectActions = objectActions;
        }
    }
}
