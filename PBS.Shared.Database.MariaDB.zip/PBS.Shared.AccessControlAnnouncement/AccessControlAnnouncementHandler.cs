﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using PBS.Shared.AccessControl.Models;
using PBS.Shared.AccessControlAnnouncement.Models;
using PBS.Shared.Audit;
using PBS.Shared.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace PBS.Shared.AccessControl
{
    public delegate void Notify(); 

    public class AccessControlAnnouncementHandler : IAccessControlAnnouncementHandler
    {
        private readonly IHttpClientFactory _clientFactory;
        private readonly IServiceProvider _serviceProvider;
        private readonly ILogger<AccessControlAnnouncementHandler> _logger;

        private readonly string announceEndpoint = "api/1/accesscontrol/permissions/announce";
        private readonly string accessControlHost = "router";
        private readonly string accessControlPort = "80";
        private readonly int announceRetries = 10;

        private string _serviceName = "";
        private string _serviceVersion = "";
        public IEnumerable<ObjectType> ObjectTypes { get; private set; } = new List<ObjectType>();

        public event Notify? AnnouncementSent;

        public AccessControlAnnouncementHandler(IMonitoredConfiguration<AccessControlConfiguration> config, IServiceProvider serviceProvider, IHttpClientFactory clientFactory, ILogger<AccessControlAnnouncementHandler> logger)
        {
            _clientFactory = clientFactory;
            _serviceProvider = serviceProvider;
            _logger = logger;

            AuditDataLayer.SaveChangesCompleted += OnDatabaseSaveAsync;

            LoadServiceNameAndVersionFromAssembly();

            accessControlHost = config.Value?.Host ?? accessControlHost;
            accessControlPort = config.Value?.Port ?? accessControlPort;
            announceRetries = config.Value?.Retries ?? announceRetries;
        }

        public void AddObjectType(Type entityFrameworkType, Actions actions, string name, string domain, Func<IServiceScope, string, string, Task<IEnumerable<DomainObject>>>? objectLookupFunction = null) 
        {
            ObjectTypes = ObjectTypes.Append(
                new ObjectType()
                {
                    ObjectTypeActions = actions.ObjectTypeActions,
                    ObjectActions = actions.ObjectActions,
                    Name = name,
                    Domain = domain,
                    EFType = entityFrameworkType,
                    LookupFunc = objectLookupFunction
                }
            );
        }

        public void AddObjectType<T>(Actions actions, string name, string domain, Func<IServiceScope, string, string, Task<IEnumerable<DomainObject>>>? objectLookupFunction = null)
        {
            AddObjectType(typeof(T), actions, name, domain, objectLookupFunction);
        }

        public void SetServiceNameAndVersion(string name, string version)
        {
            _serviceName = name;
            _serviceVersion = version;
        }

        public async Task<bool> AnnounceAllRegisteredObjectTypes()
        {
            for (int i = 0; i < announceRetries; i++)
            {
                try
                {
                    if (await Announce(ObjectTypes))
                    {
                        _logger.LogInformation("Successfully announced initial permissions (attempt #{})", i);
                        return true;
                    }
                    _logger.LogWarning("Failed to announce initial permissions (attempt #{})", i);
                }
                catch (Exception e)
                {
                    _logger.LogWarning(e, "Unable to announce initial permissions (attempt #{}, retrying)", i);
                }
                await Task.Delay(1000);
            }

            _logger.LogError("Failed to announce initial permissions after {} attempts", announceRetries);
            return false;
        }

        private void LoadServiceNameAndVersionFromAssembly()
        {
            var assembly = Assembly.GetEntryAssembly();
            _serviceName = assembly?.GetCustomAttribute<AssemblyProductAttribute>()?.Product ?? "";
            _serviceVersion  = assembly?.GetCustomAttribute<AssemblyInformationalVersionAttribute>()?.InformationalVersion ?? "";
        }

        private async Task<bool> Announce(IEnumerable<ObjectType> objectTypes)
        {
            if (!objectTypes.Any() || _serviceName == "" || _serviceVersion == "")
            {
                _logger.LogError("Missing required data to generate announcement request. Unable to announce.");
                return false;
            }

            var announceReq = new AnnouncementRequestDTO
            {
                Service = _serviceName,
                Version = _serviceVersion,
                ObjectTypes = await CreateObjectTypeDTOsFromObjectTypes()
            };

            var response = await SendRequest(announceReq);
            AnnouncementSent?.Invoke();

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Access Control Announcement Failed with: {0}", response.ReasonPhrase);
                return false;
            }

            return true;
        }

        private async Task<IEnumerable<ObjectTypeDTO>> CreateObjectTypeDTOsFromObjectTypes()
        {
            IEnumerable<ObjectTypeDTO> objectTypeDTOs = new List<ObjectTypeDTO>();

            using var scope = _serviceProvider.CreateScope();

            foreach (var objType in ObjectTypes)
            {
                IEnumerable<DomainObject> domainObjects = objType.LookupFunc is not null ? await objType.LookupFunc(scope, objType.Name, objType.Domain) : new List<DomainObject>();
                
                objectTypeDTOs = objectTypeDTOs.Append(new ObjectTypeDTO()
                {
                    ObjectTypeActions = objType.ObjectTypeActions,
                    ObjectActions = objType.ObjectActions,
                    Name = objType.Name,
                    Domain = objType.Domain,
                    Objects = domainObjects
                });
            }

            return objectTypeDTOs;
        }

        private async Task<HttpResponseMessage> SendRequest(AnnouncementRequestDTO request)
        {
            var jsonReq = JsonSerializer.Serialize<AnnouncementRequestDTO>(request);

            string requestURI = $"http://{accessControlHost}:{accessControlPort}/{announceEndpoint}";

            var message = new HttpRequestMessage(HttpMethod.Post, requestURI);
            message.Content = new StringContent(jsonReq, Encoding.Default, "application/json");

            using var client = _clientFactory.CreateClient();
            return await client.SendAsync(message);
        }

        private async void OnDatabaseSaveAsync(object? sender, SaveChangesEventArgs args)
        {
            if (!args.Changes.Any(entry => (entry.ChangeState == EntityState.Added) || (entry.ChangeState == EntityState.Deleted) || AccessControlObjectRequestsAnnouncement(entry))) return; 

            if (!args.Changes.Any(entry => ObjectTypes.Any(objType => objType.EFType.IsInstanceOfType(entry.Entity)))) return;

            await Task.Run(() => Announce(ObjectTypes));
        }

        private static bool AccessControlObjectRequestsAnnouncement(EntityChange accessControlObject)
        {
            if (accessControlObject.Entity is null) return false;

            var castEntry = accessControlObject.Entity as IAccessControlObject;

            return castEntry?.NeedsReannounce(accessControlObject.OriginalValues) ?? false;
        }
    }
}
