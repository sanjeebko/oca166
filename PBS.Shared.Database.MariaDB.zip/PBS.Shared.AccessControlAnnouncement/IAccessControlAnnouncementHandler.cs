﻿using Microsoft.Extensions.DependencyInjection;
using PBS.Shared.AccessControl.Models;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace PBS.Shared.AccessControl
{
    public interface IAccessControlAnnouncementHandler
    {
        public event Notify AnnouncementSent;
        public IEnumerable<ObjectType> ObjectTypes { get; }
        public void SetServiceNameAndVersion(string name, string version);
        public void AddObjectType(Type entityFrameworkType, Actions actions, string name, string domain, Func<IServiceScope, string, string, Task<IEnumerable<DomainObject>>>? objectLookupFunction = null);
        public void AddObjectType<T>(Actions actions, string name, string domain, Func<IServiceScope, string, string, Task<IEnumerable<DomainObject>>>? objectLookupFunction = null);
        public Task<bool> AnnounceAllRegisteredObjectTypes();
    }
}
