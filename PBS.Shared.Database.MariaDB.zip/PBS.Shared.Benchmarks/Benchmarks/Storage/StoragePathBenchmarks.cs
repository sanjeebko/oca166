﻿using BenchmarkDotNet.Attributes;
using PBS.Shared.Storage;
using System.Diagnostics.CodeAnalysis;

namespace PBS.Shared.Benchmarks.Benchmarks.Storage
{
    [MinColumn, MaxColumn]
    [MemoryDiagnoser]
    [SuppressMessage("Code Smell", "CA1822: Mark members as static", Justification = "BenchmarkDotNet does not work with static methods and Benchmark attribute")]
    public class StoragePathBenchmarks
    {
        public const string Root = @"/SmbAdapter/8a723fd/";
        public const string Path = @"SmbAdapter/8a723fd/folder/other/file.mp4";

        [Benchmark]
        public void NormalizePath()
        {
            StoragePath.GetNormalizedRelativePath(Root, Path);
        }
    }
}
