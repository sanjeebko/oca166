﻿using BenchmarkDotNet.Attributes;
using PBS.Shared.Storage.FileMonitoring.SMB;
using System;
using System.IO;

namespace PBS.Shared.Benchmarks.Benchmarks.Storage
{
    [MinColumn, MaxColumn]
    [MemoryDiagnoser]
    [InProcess]
    public class DirectoryEnumerationBenchmark
    {
        private static readonly EnumerationOptions EnumerationOptionsRecurse = new() { RecurseSubdirectories = true, IgnoreInaccessible = true };
        private static readonly string RootDirectory = GetRootDirectory();
        private int _counter;
        private string _benchmarkName;

        private static string GetRootDirectory()
        {
            var rootDirectory = new DirectoryInfo(Directory.GetCurrentDirectory());
            while (rootDirectory != null && !File.Exists(Path.Join(rootDirectory.FullName, "CommonLibraries.sln")))
            {
                rootDirectory = rootDirectory.Parent;
            }
            return rootDirectory?.FullName;
        }

        [GlobalCleanup]
        public void GlobalCleanup()
        {
            Console.WriteLine($"{_benchmarkName}:{_counter}");
        }

        [Benchmark]
        public void PollingFileSystemEntryEnumerator_Benchmark()
        {
            _benchmarkName = nameof(PollingFileSystemEntryEnumerator_Benchmark);
            _counter = 0;
            using var enumerator = new PollingFileSystemEntryEnumerator(RootDirectory, null, null, (directory, fileName, length, utc, timeUtc) =>
                {
                    _counter++;
                },
                EnumerationOptionsRecurse);

            while (enumerator.MoveNext())
            {
                // do nothing
            }
        }

        [Benchmark]
        public void DirectoryInfoEnumerateFiles_Benchmark()
        {
            _benchmarkName = nameof(DirectoryInfoEnumerateFiles_Benchmark);
            _counter = 0;
            foreach (var file in new DirectoryInfo(RootDirectory).EnumerateFiles("*", EnumerationOptionsRecurse))
            {
                _counter++;
            }
        }

        [Benchmark]
        public void DirectoryEnumerateFiles_Benchmark()
        {
            _benchmarkName = nameof(DirectoryEnumerateFiles_Benchmark);
            _counter = 0;
            foreach (var path in Directory.EnumerateFiles(RootDirectory, "*", EnumerationOptionsRecurse))
            {
                _counter++;
            }
        }
    }
}
