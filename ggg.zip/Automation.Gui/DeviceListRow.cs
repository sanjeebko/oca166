﻿using Pebble.Shared.Time;

namespace Automation.Gui;

public record DeviceListRow(
    string Id,
    string Track,
    string MediaReference,
    FrameAlignedTimestamp StartTime,
    FrameAlignedTimestamp EndTime,
    FrameAlignedTimeDifference Duration);