﻿using Pebble.Oceans.Automation.Scheduling;
using Pebble.Shared.Time;

namespace Automation.Gui;

public record LinearListRow(
    string Id,
    string Title,
    FrameAlignedTimestamp StartTime,
    FrameAlignedTimestamp EndTime,
    LinearListEventStatus Status,
    string Errors);