﻿using Microsoft.Extensions.Logging;
using NLog.Extensions.Logging;
using Pebble.Logging;
using Pebble.Oceans.Automation.TestHarness;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;

namespace Automation.Gui
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        public static TestHarness TestHarness { get; } = new();

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            LogManager.Initialize(builder =>
            {
                builder
                    .AddFilter("", LogLevel.Trace)
                    .AddNLog();
            });
        }
    }
}
