﻿using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Oceans.Automation.TestHarness.Commands;
using Pebble.Shared.Time;
using System.Collections.Immutable;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;

namespace Automation.Gui;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }

    private const int MaxGridRows = 100;
    private readonly List<string> _commandHistory = new();
    private int _commandHistoryIndex;

    private readonly List<DataGrid> _deviceGrids = new();

    private Timer? _timer;
    private FrameAlignedTimestamp _currentTime;

    private void CommandInput_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter)
            ExecuteCommand(CommandInput.Text);
    }

    private void ExecuteCommand(string command)
    {
        Output.AppendText($">>>{command}\r");
        _commandHistory.Add(command);
        try
        {
            App.TestHarness.ProcessCommand(command);
        }
        catch (Exception ex)
        {
            AddOutputLine($"Error: {ex.Message}");
        }
        CommandInput.SelectAll();
        _commandHistoryIndex = _commandHistory.Count - 1;

        if (App.TestHarness.RequestTermination)
            Close();
    }

    private void Window_Loaded(object sender, RoutedEventArgs e)
    {
        Console.SetOut(new ConsoleWriter(line => Dispatcher.Invoke(() => AddOutputLine(line))));

        CommandInput.Focus();
        App.TestHarness.NewOutputLine += TestHarness_NewOutputLine;
        App.TestHarness.NewFrame += TestHarness_NewFrame;
        App.TestHarness.SchedulingFinished += TestHarness_SchedulingFinished;
        App.TestHarness.AsRunUpdate += TestHarness_AsRunUpdate;
        App.TestHarness.ChannelStatusChange += TestHarness_ChannelStatusChange;
        App.TestHarness.PresentationListReady += TestHarness_PresentationListReady;

        foreach (var device in App.TestHarness.ChannelConfiguration.DeviceChainManifest.Devices)
        {
            var newTab = new TabItem() { Header = device.Role };
            Tabs.Items.Add(newTab);
            var newDataGrid = new DataGrid();
            newTab.Content = newDataGrid;
            _deviceGrids.Add(newDataGrid);

            newDataGrid.AutoGenerateColumns = false;
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "ID", Binding = new Binding("Id") });
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "Track", Binding = new Binding("Track") });
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "Media Reference", Binding = new Binding("MediaReference") });
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "Start Time", Binding = new Binding("StartTime") });
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "End Time", Binding = new Binding("EndTime") });
            newDataGrid.Columns.Add(new DataGridTextColumn() { Header = "Duration", Binding = new Binding("Duration") });
        }

        PopulateChannelStatus();

        _timer = new(OnTimer, null, 0, 200);
    }

    private void TestHarness_PresentationListReady(object? sender, PresentationListEventArgs e)
    {
        PopulatePresentationList(e.PresentationList);
    }

    private void TestHarness_ChannelStatusChange(object? sender, ChannelStateEventArgs e)
        => PopulateChannelStatus(e.ChannelState);

    private void TestHarness_AsRunUpdate(object? sender, EventArgs e)
        => Dispatcher.Invoke(() => AsRunGrid.ItemsSource = App.TestHarness.AsRunLog.Events.Reverse().Take(MaxGridRows).Select(e => e.AsTableRow()));

    private void TestHarness_SchedulingFinished(object? sender, ScheduleListBundleEventArgs e)
        => Dispatcher.Invoke(() =>
        {
            AddOutputLine($"List bundle updated for {e.ListBundle.Timestamp}");
            PopulateLinearList(e.ListBundle.LinearList, e.ListBundle.Errors);
            for (int i = 0; i < _deviceGrids.Count; i++)
                PopulateDeviceList(_deviceGrids[i], e.ListBundle.DeviceLists[i]);
            Playlist.Text = e.ListBundle.Playlist.ToYamlString();

            PopulateAnchor();
            PopulatePresentationList(App.TestHarness.PresentationList);
        });

    private void PopulatePresentationList(PresentationList presentationList)
    {
        Dispatcher.Invoke(() =>
        {
            StringBuilder sb = new();
            var presentationListMarkDown = presentationList.ToMarkDown();
            sb.AppendJoin(Environment.NewLine, presentationListMarkDown);
            if (presentationListMarkDown.Count() < MaxGridRows)
                sb.AppendLine().AppendLine(presentationList.ToYamlString());

            PresentationListText.Text = sb.ToString();
        });
    }

    public void PopulateChannelStatus(ChannelStatus channelState = Pebble.Oceans.Automation.ChannelStatus.Uncued)
    {
        Dispatcher.Invoke(() => ChannelStatus.Content = channelState);
    }

    public void PopulateAnchor()
    {
        AnchorGrid.ItemsSource = null;
        if (App.TestHarness.Anchor is null) return;

        var row = ImmutableArray.CreateBuilder<AnchorRow>();
        var anchor = App.TestHarness.Anchor;
        row.Add(new AnchorRow(
            anchor?.CurrentEventId ?? string.Empty,
            anchor?.StartTime.ToString() ?? string.Empty,
            anchor?.Loops.Length ?? 0,
            anchor?.NextEventId ?? string.Empty));
        AnchorGrid.ItemsSource = row;
    }

    private static void PopulateDeviceList(DataGrid dataGrid, DeviceList deviceList)
    {
        var rows = ImmutableArray.CreateBuilder<DeviceListRow>();
        foreach (var @event in deviceList.Events.Take(MaxGridRows))
        {
            rows.Add(
                new(
                $"{@event.LinearListEvent.Parent.Id}#{@event.LinearListEvent.Parent.MediaEvents.IndexOf(@event.MediaEvent)}",
                @event.MediaEvent.Track ?? string.Empty,
                @event.MediaEvent.MediaReference,
                @event.CalculatedTiming.Start,
                @event.CalculatedTiming.End,
                @event.CalculatedTiming.Duration));
        }
        dataGrid.ItemsSource = rows.ToImmutableArray();
    }

    private void PopulateLinearList(LinearList linearList, ImmutableDictionary<object, IEnumerable<Error>>? errors)
    {
        var rows = ImmutableArray.CreateBuilder<LinearListRow>();
        foreach (var @event in linearList.Events.Take(MaxGridRows))
        {
            switch (@event)
            {
                case ActiveLinearListEvent activeLinearListEvent:
                    string errorMessage = string.Empty;
                    if (errors is not null && errors.TryGetValue(activeLinearListEvent.Parent, out IEnumerable<Error>? err))
                        errorMessage = string.Join(", ", err.Select(e => e.Message));
                    rows.Add(
                        new(
                            activeLinearListEvent.Parent.Id,
                            activeLinearListEvent.Parent.Title,
                            @event.CalculatedTiming.Start,
                            @event.CalculatedTiming.End,
                            @event.LinearListEventStatus,
                            errorMessage));
                    break;

                case IdleLinearListEvent:
                    rows.Add(
                        new(
                            string.Empty,
                            "<<IDLE>>",
                            @event.CalculatedTiming.Start,
                            @event.CalculatedTiming.End,
                            @event.LinearListEventStatus,
                            string.Empty));
                    break;
            }
        }
        LinearListGrid.ItemsSource = rows.ToImmutableArray();
    }

    private void TestHarness_NewFrame(object? sender, Pebble.Service.Automation.TimeEventArgs e)
        => _currentTime = e.Time;

    private void OnTimer(object? state)
        => Dispatcher.Invoke(() =>
        {
            if (_currentTime.TimingSystem is not null)
                TimeLabel.Content = _currentTime.ToString();
            else
                TimeLabel.Content = "--:--:--:--";
        });

    private void TestHarness_NewOutputLine(object? sender, Pebble.Oceans.Automation.TestHarness.LineEventArgs e)
        => Dispatcher.Invoke(() => AddOutputLine(e.Line));

    private void AddOutputLine(string line)
    {
        Output.AppendText(line + '\r');
        Output.ScrollToEnd();
    }

    private void CommandInput_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        switch (e.Key)
        {
            case Key.Up:
                if (_commandHistoryIndex > 0)
                    _commandHistoryIndex--;
                ShowCommandFromHistory();
                break;

            case Key.Down:
                if (_commandHistoryIndex < _commandHistory.Count - 1)
                    _commandHistoryIndex++;
                ShowCommandFromHistory();
                break;
        }

        void ShowCommandFromHistory()
        {
            if (_commandHistoryIndex >= 0 && _commandHistoryIndex < _commandHistory.Count)
                CommandInput.Text = _commandHistory[_commandHistoryIndex];
        }
    }

    private void Window_Closed(object sender, EventArgs e)
    {
        _timer?.Dispose();
    }

    private void StartButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("Start");

    private void StopButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("Stop");

    private void FFButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("FastForward");

    private void FFEndButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("FastForward end");

    private void NextButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("PlayNext");

    private void CueButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("Cue");

    private void UncueButton_Click(object sender, RoutedEventArgs e) => ExecuteCommand("Uncue");

    private void PopulatePlaylistMenu(MenuItem menuItem, FileCollection collection, string command)
    {
        if (menuItem.Visibility != Visibility.Visible)
            return;
        menuItem.Items.Clear();
        foreach (var item in collection)
        {
            var newMenu = new MenuItem() { Header = item.Value };
            newMenu.Click += (s, e) => ExecuteCommand($"{command} {((MenuItem)e.Source).Header}");
            menuItem.Items.Add(newMenu);
        }
        FileMenuItem.UpdateLayout();
    }

    private void LoadPlaylistMenuItem_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        => PopulatePlaylistMenu(LoadPlaylistMenuItem, App.TestHarness.Playlists, "lp");

    private void LoadScenarioMenuItem_IsVisibleChanged(object sender, DependencyPropertyChangedEventArgs e)
        => PopulatePlaylistMenu(LoadScenarioMenuItem, App.TestHarness.ScenarioList, "ls");
}