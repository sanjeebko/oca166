﻿namespace Automation.Gui;

public record AnchorRow(string CurrentEventId, string StartTime, int Loops, string NextEventId);