﻿using System.IO;
using System.Text;

namespace Automation.Gui;

public class ConsoleWriter : TextWriter
{
    private readonly Action<string> _onNewLine;

    public override Encoding Encoding => Encoding.UTF8;

    private readonly StringBuilder _builder = new();

    public ConsoleWriter(Action<string> onNewLine)
    {
        _onNewLine = onNewLine;
    }

    public override void Write(char value)
    {
        if(value == 13 || value == 10)
        {
            string line = _builder.ToString();
            if (line.Length > 0)
            {
                _onNewLine(line);
                _builder.Clear();
            }
        }
        else
            _builder.Append(value);
    }
}
