﻿namespace Pebble.Oceans.Automation.AsRun;

public abstract record ManualActionAsRunEvent(FrameAlignedTimestamp Timestamp) : AsRunEvent(Timestamp)
{
    protected override string GetCategory() => "Manual";
}

public record PlayNextEvent(FrameAlignedTimestamp Timestamp, FrameAlignedTimestamp PlayAt) : ManualActionAsRunEvent(Timestamp)
{
    protected override string GetEventId() => "Play Next";
    protected override string GetMessage() => $"Play next event at {PlayAt}";
}

public record CueEvent(FrameAlignedTimestamp Timestamp, string EventId) : ManualActionAsRunEvent(Timestamp)
{
    protected override string GetEventId() => "Cue";
    protected override string GetMessage() => $"Cue Event {EventId}";
}

public record UncueEvent(FrameAlignedTimestamp Timestamp) : ManualActionAsRunEvent(Timestamp)
{
    protected override string GetEventId() => "Uncue";
    protected override string GetMessage() => "Uncue Playlist";
}