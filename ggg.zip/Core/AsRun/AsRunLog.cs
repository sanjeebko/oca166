﻿namespace Pebble.Oceans.Automation.AsRun
{
    public class AsRunLog
    {
        public event EventHandler<EventArgs>? Changed;

        public ImmutableArray<AsRunEvent> Events { get; private set; } = ImmutableArray<AsRunEvent>.Empty;

        private readonly object _lock = new();

        public void AddEvent(AsRunEvent @event)
        {
            // OPTIMIZATION NOTE: In order to minimize the timing inpact on the calling thread we should just store
            // the new event in a e.g. ConcurrentBag and send a trigger to a task loop that would store the event(s) in
            // the main array and call the changed event which can then contain all the newly added lines in its args
            // As a part of that process we should also be purging all the events older than a preset amount (e.g. 2 days)
            lock(_lock)
            {
                Events = Events.Add(@event);
            }
            Changed?.Invoke(this, EventArgs.Empty);
        }
    }
}
