﻿namespace Pebble.Oceans.Automation.AsRun;

public abstract record AsRunEvent(FrameAlignedTimestamp Timestamp)
{
    public long Id { get; } = Interlocked.Increment(ref _id);

    public AsRunTableRow AsTableRow()
        => new(
            Timestamp,
            GetCategory(),
            GetEventId(),
            GetDevice(),
            GetTrack(),
            GetMediaReference(),
            GetMessage());

    protected virtual string GetCategory() => string.Empty;
    protected virtual string GetEventId() => string.Empty;
    protected virtual string GetMessage() => GetEventId();
    protected virtual string GetMediaReference() => string.Empty;
    protected virtual string GetTrack() => string.Empty;
    protected virtual string GetDevice() => string.Empty;

    private static long _id;
}

public record AsRunTableRow(FrameAlignedTimestamp Timestamp, string Category, string EventId, string Device, string Track, string MediaReference, string Message);