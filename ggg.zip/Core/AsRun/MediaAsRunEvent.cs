﻿namespace Pebble.Oceans.Automation.AsRun;

public abstract record MediaAsRunEvent(FrameAlignedTimestamp Timestamp, DeviceListEvent DeviceListEvent) : AsRunEvent(Timestamp)
{
    protected override string GetCategory() => "Media";
    protected override string GetDevice() => MediaEvent.Device;
    protected override string GetTrack() => MediaEvent.Track ?? string.Empty;
    protected override string GetMediaReference() => MediaEvent.MediaReference;

    public MediaEvent MediaEvent => DeviceListEvent.MediaEvent;
}

public record MediaEventStarted(FrameAlignedTimestamp Timestamp, DeviceListEvent DeviceListEvent) : MediaAsRunEvent(Timestamp, DeviceListEvent)
{
    protected override string GetEventId() => "Event Started";
}

public record MediaEventStopped(FrameAlignedTimestamp Timestamp, DeviceListEvent DeviceListEvent) : MediaAsRunEvent(Timestamp, DeviceListEvent)
{
    protected override string GetEventId() => "Event Stopped";
}