﻿using System.Text;

namespace Pebble;

public class MarkdownTableBuilder
{
    public int ColumnCount { get; private set; } = 1;
    public int RowCount => _rows.Count;

    private readonly List<string[]> _rows = new();
    private string[] _header = Array.Empty<string>();

    public void SetHeader(params string[] columns)
    {
        _header = columns;
        if (_header.Length > ColumnCount)
            ColumnCount = _header.Length;
    }

    public void AddRow(params object[] columns)
    {
        string[] cols = columns.Select(c => c?.ToString() ?? string.Empty).ToArray();
        if (cols.Length > ColumnCount)
            ColumnCount = cols.Length;
        _rows.Add(cols);
    }

    public IEnumerable<string> GetLines()
    {
        var widths = Enumerable.Repeat(3, ColumnCount).ToArray();

        CheckRowWidth(_header, widths);
        for (int r = 0; r < RowCount; r++)
            CheckRowWidth(_rows[r], widths);

        yield return FormatRow(_header, widths);
        yield return FormatRow(widths.Select(n => new string('-', n)).ToArray(), widths);
        for (int r = 0; r < RowCount; r++)
            yield return FormatRow(_rows[r], widths);
    }

    public string GetString() => string.Join(Environment.NewLine, GetLines().ToArray());

    private static void CheckRowWidth(string[] columns, int[] widths)
    {
        for (int c = 0; c < columns.Length; c++)
        {
            int l = columns[c].Length;
            if (l > widths[c])
                widths[c] = l;
        }
    }

    private string FormatRow(string[] columns, int[] widths)
    {
        var sb = new StringBuilder();
        sb.Append("| ");
        for (int c = 0; c < ColumnCount; c++)
        {
            string s = "";
            if (c < columns.Length)
                s = columns[c];
            sb.Append(s.PadRight(widths[c]));
            sb.Append(" |");
            if (c < ColumnCount - 1)
                sb.Append(' ');
        }
        return sb.ToString();
    }
}