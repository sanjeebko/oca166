﻿namespace Pebble.Oceans.Automation.TO_BE_MOVED_TO_SHARED;

public static class MarkDown
{
    public static string H3 => "###";
    public static string Bold(string source) => $"**{source}**";
    public static string Italic(string source) => $"*{source}*";
}