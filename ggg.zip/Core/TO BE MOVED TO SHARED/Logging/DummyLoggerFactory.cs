﻿using Microsoft.Extensions.Logging;

namespace Pebble.Logging;

internal sealed class DummyLoggerFactory : ILoggerFactory
{
    public void AddProvider(ILoggerProvider provider)
    {
        // Method intentionally left empty.
    }

    public ILogger CreateLogger(string categoryName)
    {
        Console.WriteLine($"WARNING: Attempt to create a logger for category {categoryName} before the logging has been initialized");
        return new DummyLogger();
    }

    public void Dispose()
    {
        // Method intentionally left empty.
    }
}
