﻿using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Reflection;

namespace Pebble.Logging
{
    public static class LogManager
    {
        public static bool IsInitialized => Factory is not DummyLoggerFactory;

        public static void Initialize(ILoggerFactory factory)
            => Factory = !IsInitialized
                ? factory
                : throw new AlreadyInitializedException("Logging has already been initialized");

        public static void Initialize(Action<ILoggingBuilder> configure) => Initialize(LoggerFactory.Create(configure));

        public static void Initialize()
        {
            if (!IsInitialized)
                Initialize(builder =>
                {
                    builder
                        .AddFilter("", LogLevel.Debug)
                        .AddConsole();
                });
        }

        public static ILoggerFactory Factory { get; private set; } = new DummyLoggerFactory();

        public static ILogger<T> CreateLogger<T>()
            => Factory.CreateLogger<T>();

        public static ILogger CreateLogger(Type type)
            => Factory.CreateLogger(type);

        public static ILogger CreateLogger(string categoryName)
            => Factory.CreateLogger(categoryName);

        public static ILogger CreateCurrentClassLogger()
        {
            // Get the stack trace - we are interested only in the methods
            MethodBase[] trace = new StackTrace().GetFrames().Select(x => x.GetMethod()).OfType<MethodBase>().ToArray();

            // Locate the current method, in case there is something before it 
            int i = 0;
            while (trace[i].Name != nameof(CreateCurrentClassLogger))
                i++;

            // Take one method above
            i++;

            // If the calling method, go up the stack to find the high-level constructor
            while (trace[i].IsConstructor && trace[i + 1].IsConstructor && IsDerivedType(trace[i + 1].DeclaringType, trace[i].DeclaringType))
                i++;

            // Create and return the logger
            return CreateLogger(trace[i].DeclaringType ?? typeof(object));

            static bool IsDerivedType(Type? type1, Type? type2) => type1?.BaseType != null && type2 != null && (type1.BaseType == type2 || (type1.BaseType.IsGenericType && type1.BaseType.GetGenericTypeDefinition() == type2));
        }

        private static readonly Stopwatch _stopwatch = InitStopwatch();

        private static Stopwatch InitStopwatch()
        {
            var stopwatch = new Stopwatch();
            stopwatch.Start();
            return stopwatch;
        }

        private struct LogItem
        {
            public ILogger Logger;
            public long Time;
            public int ThreadId;
            public LogLevel Level;
            public string Message;
        }

        private static readonly ConcurrentQueue<LogItem> _logQueue = new();

        private static readonly AutoResetEvent _logEvent = new(false);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Blocker Bug", "S2190:Recursion should not be infinite", Justification = "This is a permanent background thread and will be closed on process shutdown")]
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Usage", "CA2254:Template should be a static expression", Justification = "This is a template that is used in every logging attempt through this function")]
        private static void LoggerThread(object? obj)
        {
            while (true)
            {
                while (_logQueue.TryDequeue(out LogItem l))
                    l.Logger.Log(l.Level, $"{l.Time / 1000.0:F3} [{l.ThreadId}] {l.Message}");
                _logEvent.WaitOne(100);
            }
        }

        internal static readonly Thread logThread = InitLogThread(); // MJ: This was made internal to avoid warning over suspected unused field

        private static Thread InitLogThread()
        {
            var thread = new Thread(LoggerThread)
            {
                Name = "LoggerThread",
                IsBackground = true
            };
            thread.Start();
            return thread;
        }

        public static void LogMessage(this ILogger logger, LogLevel level, string message)
        {
            _logQueue.Enqueue(new LogItem()
            {
                Logger = logger,
                Level = level,
                Time = _stopwatch.ElapsedMilliseconds,
                ThreadId = Environment.CurrentManagedThreadId,
                Message = message
            });
            _logEvent.Set();
        }

        public static void LogError(this ILogger logger, string message) => LogMessage(logger, LogLevel.Error, message);
        public static void LogWarning(this ILogger logger, string message) => LogMessage(logger, LogLevel.Warning, message);
        public static void LogInformation(this ILogger logger, string message) => LogMessage(logger, LogLevel.Information, message);
        public static void LogDebug(this ILogger logger, string message) => LogMessage(logger, LogLevel.Debug, message);
        public static void LogTrace(this ILogger logger, string message) => LogMessage(logger, LogLevel.Trace, message);
    }
}
