﻿using Microsoft.Extensions.Logging;


namespace Pebble.Logging;

internal class DummyLogger : ILogger
{
    public sealed class DummyScope : IDisposable
    {
        public void Dispose()
        {
            // Method intentionally left empty.
        }
    }

    public IDisposable BeginScope<TState>(TState state) => new DummyScope();

    public bool IsEnabled(LogLevel logLevel) => true;

    public void Log<TState>(LogLevel logLevel, EventId eventId, TState state, Exception? exception, Func<TState, Exception, string> formatter)
    {
        // Method intentionally left empty.
    }
}
