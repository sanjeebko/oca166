﻿using Microsoft.Extensions.Logging;
using System.Collections.Concurrent;

namespace Pebble.Oceans.Automation.Processors;

public interface IPresentationListProvider : IDisposable
{
    PresentationList GetPresentationList();

    event EventHandler<PresentationListEventArgs>? PresentationListReady;

    void OnSchedulingFinished(object? sender, ScheduleListBundleEventArgs e);
}

public class PresentationListProvider : IPresentationListProvider
{
    private readonly ILogger _logger = Logging.LogManager.CreateCurrentClassLogger();

    private bool _disposedValue;

    private const int MaxQueueLength = 3;

    private TaskCompletionSource<ConcurrentQueue<PresentationListBundle>> _presentationListRequested = new();

    private readonly CancellationTokenSource _presentationListCancelled = new();

    private ConcurrentQueue<PresentationListBundle> ConcurrentQueue { get; } = new();

    private Dictionary<PresentationListBundle, CancellationTokenSource> CancellationTokens { get; } = new();

    private PresentationList? CurrentPresentationList { get; set; }

    public event EventHandler<PresentationListEventArgs>? PresentationListReady;

    public PresentationListProvider()
    {
        _ = PresentationListLoopAsync();
    }

    public PresentationList GetPresentationList()
    {
        return CurrentPresentationList ?? PresentationList.Empty();
    }

    private async Task PresentationListLoopAsync()
    {
        while (!_presentationListCancelled.IsCancellationRequested)
        {
            _ = await _presentationListRequested.Task.WaitAsync(_presentationListCancelled.Token).ConfigureAwait(false);

            ConcurrentQueue.TryPeek(out var presentationListBundle);

            if (presentationListBundle == null)
                return;

            _presentationListRequested = new TaskCompletionSource<ConcurrentQueue<PresentationListBundle>>();

            try
            {
                CurrentPresentationList = await CreateAsync(presentationListBundle, _presentationListCancelled.Token).ConfigureAwait(false);
                PresentationListEventArgs presentationListArgs = new(CurrentPresentationList, presentationListBundle.CurrentLists.Timestamp);
                PresentationListReady?.Invoke(this, presentationListArgs);

                ConcurrentQueue.TryDequeue(out _);
            }
            catch (Exception ex)
            {
                _logger.LogError("Failed to produce presentation list, awaiting next request. Error: {ex.Message}", ex.Message);
            }
        }
    }

    private static async Task<PresentationList> CreateAsync(PresentationListBundle presentationListBundle, CancellationToken cancellation)
    {
        var presentationList = await Task.Run(() => PresentationListProcessor.Execute(presentationListBundle), cancellation)
                                         .ConfigureAwait(false);

        if (cancellation.IsCancellationRequested)
            throw new TaskCanceledException();

        return presentationList;
    }

    public void OnSchedulingFinished(object? sender, ScheduleListBundleEventArgs e)
    {
        Enqueue(new PresentationListBundle(e.ListBundle, e.HistoricalState, e.DeviceListPlayStatusMap));
    }

    private void Enqueue(PresentationListBundle presentationListBundle)
    {
        if (ConcurrentQueue.Count == MaxQueueLength)
        {
            ConcurrentQueue.TryDequeue(out var dequeuedBundle);
            if (dequeuedBundle != null)
            {
                CancellationTokens[dequeuedBundle].Cancel();
                CancellationTokens.Remove(dequeuedBundle);
            }
        }

        ConcurrentQueue.Enqueue(presentationListBundle);

        _presentationListRequested.TrySetResult(ConcurrentQueue);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
                _presentationListCancelled.Cancel();
            _disposedValue = true;
        }
    }

    public void Dispose()
    {
        Dispose(true);

        GC.SuppressFinalize(this);
    }
}