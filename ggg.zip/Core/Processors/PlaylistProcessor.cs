﻿using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Processors;

public class PlaylistProcessor : ProcessorBase
{
    public ChannelConfiguration ChannelConfiguration { get; }

    public PlaylistProcessor(ChannelConfiguration channelConfiguration)
    {
        ChannelConfiguration = channelConfiguration;
    }

    public (LinearList LinearList, ImmutableArray<Error> Errors) Execute(Playlist playlist, Anchor? anchor, FrameAlignedTimestamp currentTime, bool provisionalTiming)
    {
        FrameAlignedTimestamp startTime = SelectStartTime(anchor, currentTime, provisionalTiming);

        var currentEvent = playlist.Events.OfType<PlaylistEvent>()
                                          .FirstOrDefault(e => e.Id == anchor?.CurrentEventId);

        IEnumerable<PlaylistEvent> remainingEvents = SkipUntilNextEvents(playlist, anchor).OfType<PlaylistEvent>();

        if (currentEvent != null && remainingEvents.FirstOrDefault()?.Id != currentEvent.Id)
            remainingEvents = remainingEvents.AsEnumerable().Prepend(currentEvent);

        var fixedEvents = new FixedEventCollection(remainingEvents, startTime);
        var builder = new LinearListBuilder(
            startTime,
            currentTime + ChannelConfiguration.LinearListConfiguration.MaxDuration,
            ChannelConfiguration.LinearListConfiguration.MaxSize);
        PlaylistEvent? previousEvent = null;
        FrameAlignedTimestamp time = startTime;
        foreach (var primaryEvent in remainingEvents)
        {
            if (builder.IsLimitReached)
                break;

            if (time > startTime)
                time -= primaryEvent.Timing.TransitionDuration ?? FrameAlignedTimeDifference.Zero;

            fixedEvents.AdvanceToTime(time);
            if (primaryEvent == fixedEvents.CurrentEvent)
            {
                provisionalTiming = false;
                time = (FrameAlignedTimestamp)fixedEvents.CurrentTime! - (primaryEvent.Timing.TransitionDuration ?? FrameAlignedTimeDifference.Zero);
                fixedEvents.AdvanceOne();
            }

            FrameAlignedTimeDifference duration = primaryEvent.Timing.Duration ?? FrameAlignedTimeDifference.Zero;
            FrameAlignedTimestamp endTime = time + duration;

            if (fixedEvents.AnyEventsBefore(endTime, out FrameAlignedTimestamp? fixedTime))
                endTime = (FrameAlignedTimestamp)fixedTime!;

            if (endTime > currentTime)
                builder.NewPrimary(primaryEvent, time, endTime, provisionalTiming, previousEvent);
            else
                builder.SetTime(endTime);
            time = endTime;
            previousEvent = primaryEvent;
        }
        builder.PadUntilCutoffTime(previousEvent);
        return (builder.Result, fixedEvents.Errors);
    }

    private static FrameAlignedTimestamp SelectStartTime(Anchor? anchor, FrameAlignedTimestamp currentTime, bool provisionalTiming)
    {
        FrameAlignedTimestamp startTime = anchor?.StartTime ?? currentTime;

        if (provisionalTiming)
            return EnsureStartTimeIsNotPast(currentTime, startTime);
        return startTime;

        static FrameAlignedTimestamp EnsureStartTimeIsNotPast(FrameAlignedTimestamp currentTime, FrameAlignedTimestamp startTime)
        => (startTime < currentTime) ? currentTime : startTime;
    }

    private static IEnumerable<PlaylistItem> SkipUntilNextEvents(Playlist playlist, Anchor? anchor)
    {
        if (IsAnchorPointSet(anchor))
        {
            if (!string.IsNullOrEmpty(anchor?.NextEventId))
                return playlist.Events.SkipWhile(e => e.Id != anchor?.NextEventId);
            if (!string.IsNullOrEmpty(anchor?.CurrentEventId))
                return playlist.Events.SkipWhile(e => e.Id != anchor?.CurrentEventId);
        }

        return playlist.Events;
    }

    private static bool IsAnchorPointSet(Anchor? anchor)
        => anchor?.CurrentEventId is not null || anchor?.NextEventId != null;
}