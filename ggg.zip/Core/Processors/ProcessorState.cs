﻿namespace Pebble.Oceans.Automation.Processors;

public enum ProcessorState
{
    Idle, Waiting, Running
}
