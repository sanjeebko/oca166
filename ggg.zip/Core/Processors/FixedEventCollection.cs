﻿
namespace Pebble.Oceans.Automation.Processors
{
    internal class FixedEventCollection
    {
        private readonly (FrameAlignedTimestamp Time, PlaylistItem Event)[] events;
        private int index = 0;

        internal ImmutableArray<Error> Errors { get; }

        public FixedEventCollection(IEnumerable<PlaylistEvent> events, FrameAlignedTimestamp time)
        {
            var errors = ImmutableArray.CreateBuilder<Error>();
            this.events = EnumerateFixedEvents(events, time, errors).ToArray();
            Errors = errors.ToImmutableArray();
        }

        private static IEnumerable<(FrameAlignedTimestamp Time, PlaylistItem Event)> EnumerateFixedEvents(IEnumerable<PlaylistEvent> events, FrameAlignedTimestamp time, ImmutableArray<Error>.Builder errors)
        {
            foreach (var e in events.OfType<PlaylistEvent>().Where(e => e.Timing.Start is FixedTiming))
            {
                FrameAlignedTimestamp startTime = ((FixedTiming)e.Timing.Start).Start;
                if (startTime < time)
                    errors.Add(
                        new(
                            e,
                            $"invalid fixed start time {startTime}, converting into sequential start",
                            Severity.Warning));
                else
                    yield return (startTime + (e.Timing.TransitionDuration ?? FrameAlignedTimeDifference.Zero), e);
            }
        }

        public void Reset()
            => index = 0;

        internal void AdvanceToTime(FrameAlignedTimestamp time)
        {
            while (index < events.Length && events[index].Time < time)
                index++;
        }

        internal PlaylistItem? CurrentEvent => index < events.Length ? events[index].Event : null;

        public FrameAlignedTimestamp? CurrentTime => index < events.Length ? events[index].Time : null;

        internal void AdvanceOne() => index++;

        internal bool AnyEventsBefore(FrameAlignedTimestamp endTime, out FrameAlignedTimestamp? time)
        {
            time = null;
            if (index < events.Length && endTime > events[index].Time)
            {
                time = events[index].Time;
                return true;
            }
            return false;
        }
    }
}