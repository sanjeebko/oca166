﻿namespace Pebble.Oceans.Automation.Processors;

public abstract class ProcessorBase
{
    public ProcessorState State { get; private set; }

    protected void SetState(ProcessorState state)
    {
        State = state;
        manager?.ReportState(this, state);
    }

    private IProcessorManager? manager;

    public void SetManagementInterface(IProcessorManager manager)
    {
        this.manager = manager;
    }
}
