﻿namespace Pebble.Oceans.Automation.Processors;

internal class LinearListBuilder
{
    private FrameAlignedTimestamp _time;
    private readonly FrameAlignedTimestamp _cutoffTime;
    private readonly int _maxSize;
    private readonly ImmutableArray<LinearListEvent>.Builder _builder = ImmutableArray.CreateBuilder<LinearListEvent>();

    internal LinearListBuilder(FrameAlignedTimestamp initialTime, FrameAlignedTimestamp cutoffTime, int maxSize)
    {
        _time = initialTime;
        _cutoffTime = cutoffTime;
        _maxSize = maxSize;
    }

    internal void NewPrimary(PlaylistEvent parent, FrameAlignedTimestamp startTime, FrameAlignedTimestamp endTime, bool provisionalTiming, PlaylistEvent? previousEvent)
    {
        if (startTime > _time)
            _builder.Add(new IdleLinearListEvent(new FrameAlignedTimeInterval(_time, startTime), previousEvent));
        _builder.Add(new ActiveLinearListEvent(parent, new FrameAlignedTimeInterval(startTime, endTime), provisionalTiming));
        _time = endTime;
    }

    internal void PadUntilCutoffTime(PlaylistEvent? previousEvent)
    {
        if (_cutoffTime <= _time)
            return;
        _builder.Add(new IdleLinearListEvent(new FrameAlignedTimeInterval(_time, _cutoffTime), previousEvent));
        _time = _cutoffTime;
    }

    internal LinearList Result => new(_builder.ToImmutableArray());

    public bool IsLimitReached => _builder.Count >= _maxSize || _time >= _cutoffTime;

    internal void SetTime(FrameAlignedTimestamp value) => _time = value;
}