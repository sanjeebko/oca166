﻿using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Processors;

public record PresentationListBundle
    (
        ListBundle CurrentLists,
        HistoricalState HistoricalState,
        Dictionary<DeviceListEvent, DeviceListPlayStatus> DeviceListPlayStatusMap
    );

public static class PresentationListProcessor
{
    public static PresentationList Execute(PresentationListBundle bundle)
    {
        var presentationList = ImmutableArray.CreateBuilder<PresentationListItem>();

        ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> deviceListEvents = bundle.CurrentLists.DeviceLists
            .SelectMany(dl => dl.Events)
            .GroupBy(d => d.LinearListEvent.Parent)
            .ToImmutableDictionary(
                g => g.Key,
                g => g.Select(deviceListEvent => deviceListEvent.MediaEvent
                        .ToPresentationListMediaEvent(deviceListEvent.ToPresentationListDeviceListEvent(GetPlayStateForDeviceListEvent(deviceListEvent, bundle.DeviceListPlayStatusMap)),
                                                                                                        "", ""))
                        .ToImmutableArray());

        ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListLinearListEvent>> linearListEvents = bundle.CurrentLists.LinearList.Events
            .OfType<ActiveLinearListEvent>()
            .GroupBy(e => e.Parent)
            .ToImmutableDictionary(
                g => g.Key,
                g => g.Select(linearListEvent => new PresentationListLinearListEvent(
                    linearListEvent.CalculatedTiming,
                    new PresentationListLinearListEventState(
                        linearListEvent.LinearListEventStatus.ToString(),
                          GetLinearListPlayState(g.Key, deviceListEvents)
                        )))
                    .ToImmutableArray());

        ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> historicalEvents = bundle.HistoricalState.Events
            .GroupBy(h => h.DeviceListEvent.LinearListEvent.Parent)
            .ToImmutableDictionary(
                g => g.Key,
                g => g.Select(historicalEvent => historicalEvent
                        .DeviceListEvent
                        .MediaEvent
                        .ToPresentationListMediaEvent(
                            historicalEvent.DeviceListEvent
                                .ToPresentationListDeviceListEvent(nameof(DeviceListPlayStatus.Played)),
                            "",
                            ""))
                    .ToImmutableArray());

        ImmutableDictionary<PlaylistEvent, IdleLinearListEvent> playlistSuccedingIdleEvents = bundle.CurrentLists.LinearList.Events
            .OfType<IdleLinearListEvent>()
            .Where(i => i.PreviousEvent is not null)
            .ToImmutableDictionary(
                g => g.PreviousEvent!,
                g => g);

        AddFirstIdleEvent(bundle.CurrentLists.LinearList, presentationList);

        foreach (var playlistItem in bundle.CurrentLists.Playlist.Events)
        {
            if (playlistItem is PlaylistEvent playlistEvent)
            {
                ImmutableArray<PresentationListLinearListEvent> presentationLinearListEvents =
                    linearListEvents.TryGetValue(playlistEvent, out var events)
                        ? events
                        : ImmutableArray<PresentationListLinearListEvent>.Empty;

                ImmutableArray<PresentationListLinearListEvent> historicalPresentationLinearListEvents = GetHistoricalStateForPlayListItem(bundle.HistoricalState, playlistEvent);

                PresentationListPlayState playState = GetPlayListItemPlayState(playlistEvent, deviceListEvents, historicalEvents);

                presentationLinearListEvents = presentationLinearListEvents.AddRange(historicalPresentationLinearListEvents);

                ImmutableArray<PresentationListMediaEvent> presentationMediaEvents = GetPresentationListMediaEvents(
                    playlistEvent,
                    deviceListEvents,
                    historicalEvents);

                var presentationListEvent = new PresentationListEvent(playlistEvent.Id,
                                                                        playlistEvent.Title,
                                                                        playlistEvent.Type,
                                                                        new PresentationListState(playState, new PresentationListValidation("")),
                                                                        playlistEvent.Timing,
                                                                        presentationLinearListEvents,
                                                                        presentationMediaEvents
                                                                        );

                presentationList.Add(presentationListEvent);

                AddNextIdleEvent(presentationList, playlistSuccedingIdleEvents, playlistEvent);
            }
        }

        return new PresentationList(bundle.CurrentLists.Playlist.ChannelId,
                                    bundle.CurrentLists.Playlist.Name,
                                    presentationList.ToImmutableArray());
    }

    private static void AddNextIdleEvent(ImmutableArray<PresentationListItem>.Builder presentationList, ImmutableDictionary<PlaylistEvent, IdleLinearListEvent> playlistSuccedingIdleEvents, PlaylistEvent playlistEvent)
    {
        if (playlistSuccedingIdleEvents.ContainsKey(playlistEvent))
        {
            var idle = playlistSuccedingIdleEvents[playlistEvent];
            presentationList.Add(new PresentationListIdleEvent(
                new PresentationListLinearListEvent(
                    idle.CalculatedTiming,
                    new PresentationListLinearListEventState(
                        idle.LinearListEventStatus.ToString(),
                        new PresentationListLinearListEventPlayState(nameof(LinearListEventStatus.Idle), "")))));
        }
    }

    private static void AddFirstIdleEvent(LinearList linearList, ImmutableArray<PresentationListItem>.Builder presentationList)
    {
        var initialIdleEvent = GetFirstIdleEventIfExist(linearList);

        if (initialIdleEvent is not null)
            presentationList.Add(initialIdleEvent);
    }

    private static PresentationListPlayState GetPlayListItemPlayState(PlaylistEvent playlistEvent, ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> deviceListEvents, ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> historicalEvents)
    {
        if (deviceListEvents.TryGetValue(playlistEvent, out var ple))
        {
            var allStatus = ple.Select(a => a.DeviceListEvent?.State.Status ?? string.Empty);
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Playing))))
                return new PresentationListPlayState(nameof(DeviceListPlayStatus.Playing));
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Played))))
                return new PresentationListPlayState(nameof(DeviceListPlayStatus.Played));
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Cued))))
                return new PresentationListPlayState(nameof(DeviceListPlayStatus.Cued));
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Scheduled))))
                return new PresentationListPlayState(nameof(DeviceListPlayStatus.Scheduled));
        }

        if (historicalEvents.TryGetValue(playlistEvent, out var historyEvents))
        {
            return new PresentationListPlayState(nameof(DeviceListPlayStatus.Played));
        }

        return new PresentationListPlayState(nameof(DeviceListPlayStatus.Skipped));
    }

    private static PresentationListLinearListEventPlayState GetLinearListPlayState(PlaylistEvent playlistEvent,
                                                                    ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> deviceListEvents)
    {
        if (deviceListEvents.TryGetValue(playlistEvent, out var ple))
        {
            var allStatus = ple.Select(a => a.DeviceListEvent?.State.Status ?? string.Empty);
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Playing))))
                return new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Playing), "");
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Played))))
                return new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Played), "");
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Cued))))
                return new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Cued), "");
            if (allStatus.Any(a => a.Equals(nameof(DeviceListPlayStatus.Scheduled))))
                return new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Scheduled), "");
        }
        return new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Skipped), "");
    }

    private static string GetPlayStateForDeviceListEvent(DeviceListEvent deviceListEvent, Dictionary<DeviceListEvent, DeviceListPlayStatus> deviceListPlayStatusMap)
    {
        if (deviceListPlayStatusMap.ContainsKey(deviceListEvent))
        {
            return deviceListPlayStatusMap[deviceListEvent].ToString();
        }
        return nameof(DeviceListPlayStatus.Scheduled);
    }

    private static PresentationListIdleEvent? GetFirstIdleEventIfExist(LinearList linearList)
    {
        if (linearList.IsIdle)
            return null;
        if (linearList.Events.Length > 0 && linearList.Events[0] is IdleLinearListEvent idle)
        {
            return new PresentationListIdleEvent(
                new PresentationListLinearListEvent(
                    idle.CalculatedTiming,
                    new PresentationListLinearListEventState(
                        idle.LinearListEventStatus.ToString(),
                        new PresentationListLinearListEventPlayState(nameof(LinearListEventStatus.Idle), ""))));
        }
        return null;
    }

    private static ImmutableArray<PresentationListLinearListEvent> GetHistoricalStateForPlayListItem(HistoricalState historicalState, PlaylistEvent playlistEvent)
    {
        if (!historicalState.Events.Any())
            return ImmutableArray<PresentationListLinearListEvent>.Empty;
        return historicalState.Events.Where(e => e.DeviceListEvent.LinearListEvent.Parent.Id == playlistEvent.Id)
                                                          .Select(historicalEvent => new PresentationListLinearListEvent(historicalEvent.DeviceListEvent.CalculatedTiming,
                                                          new PresentationListLinearListEventState(historicalEvent.DeviceListEvent.LinearListEvent.LinearListEventStatus.ToString(),
                                                                                                   new PresentationListLinearListEventPlayState(nameof(DeviceListPlayStatus.Played), ""))))
                                                          .ToImmutableArray();
    }

    private static ImmutableArray<PresentationListMediaEvent> GetPresentationListMediaEvents(
        PlaylistEvent playListEvent,
        ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> deviceListEvents,
        ImmutableDictionary<PlaylistEvent, ImmutableArray<PresentationListMediaEvent>> historicalEvents)
    {
        if (deviceListEvents.TryGetValue(playListEvent, out var value))
            return value;

        if (historicalEvents.TryGetValue(playListEvent, out value))
        {
            var latestHistoricalEvent = value.LastOrDefault();
            if (latestHistoricalEvent is not null)
                return ImmutableArray.Create(latestHistoricalEvent);
        }

        return playListEvent.MediaEvents.Select(mediaEvent => mediaEvent.ToPresentationListMediaEvent(null, nameof(DeviceListPlayStatus.Skipped), "")).ToImmutableArray();
    }
}