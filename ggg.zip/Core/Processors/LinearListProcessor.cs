﻿using Pebble.Oceans.Automation.Devices;

namespace Pebble.Oceans.Automation.Processors;

public class LinearListProcessor : ProcessorBase
{
    public DeviceConfig DeviceConfig { get; }

    public LinearListProcessor(DeviceConfig deviceConfig)
    {
        DeviceConfig = deviceConfig;
    }

    public (DeviceList DeviceList, ImmutableArray<Error> Errors) Execute(LinearList linearList)
        => (new(
            DeviceConfig.Role,
            linearList.Events.OfType<ActiveLinearListEvent>()
                .Where(e => e.LinearListEventStatus != LinearListEventStatus.Skipped)
                .SelectMany(ProcessEvent)
                .ToImmutableArray()),
            ImmutableArray<Error>.Empty);

    private IEnumerable<DeviceListEvent> ProcessEvent(ActiveLinearListEvent linearListEvent)
        => linearListEvent.Parent.MediaEvents
            .Where(e => e.Device == DeviceConfig.Role)
            .GroupBy(e => e.Track)
            .SelectMany(g => ScheduleTrack(linearListEvent, g));

    private static IEnumerable<DeviceListEvent> ScheduleTrack(ActiveLinearListEvent linearListEvent, IEnumerable<MediaEvent> events)
    {
        FrameAlignedTimeInterval timing = linearListEvent.CalculatedTiming;
        FrameAlignedTimestamp time = timing.Start;

        foreach (var @event in events)
        {
            var startTime = @event.Start.Mode switch
            {
                MediaEventTimingMode.FromParentStart => timing.Start + @event.Start.ValueOrZero,
                MediaEventTimingMode.FromParentEnd => timing.End + @event.Start.ValueOrZero,
                MediaEventTimingMode.Sequential => time + @event.Start.ValueOrZero,
                MediaEventTimingMode.Transition => time - @event.Start.ValueOrZero,
                _ => time
            };

            var endTime = @event.End.Mode switch
            {
                MediaEventTimingMode.FromParentStart => timing.Start + @event.End.ValueOrZero,
                MediaEventTimingMode.FromParentEnd => timing.End + @event.End.ValueOrZero,
                MediaEventTimingMode.Duration => startTime + @event.End.ValueOrZero,
                _ => startTime
            };

            yield return new DeviceListEvent(
                linearListEvent,
                @event,
                new FrameAlignedTimeInterval(
                    startTime,
                    endTime),
                linearListEvent.ProvisionalTiming
                );

            time = endTime;
        }
    }
}