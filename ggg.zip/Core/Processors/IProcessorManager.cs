﻿namespace Pebble.Oceans.Automation.Processors;

public interface IProcessorManager
{
    void ReportState(ProcessorBase processor, ProcessorState state);
}
