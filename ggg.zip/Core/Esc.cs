﻿namespace Pebble;

// FUTURE IMRPOVEMENT: To be replaced with intention based mapping instead of direct colour escape codes

public static class Esc
{
    //https://en.wikipedia.org/wiki/ANSI_escape_code

    public const string BrightYellowFG = "\u001b[38;5;226m";
    public const string YellowFG = "\u001b[38;5;228m";
    public const string BrightCyanFG = "\u001b[38;5;14m";
    public const string WhiteFG = "\u001b[38;5;15m";
    public const string BrightGreenFG = "\u001b[38;5;46m";
    public const string Magenta = "\u001b[35m";
    public const string GreenFG = "\u001b[38;5;2m";
    public const string LightGreenFG = "\u001b[38;5;48m";
    public const string GreenBG = "\u001b[48;5;2m";
    public const string BrightRedFG = "\u001b[38;5;196m";
    public const string BrightRedBG = "\u001b[48;5;196m";
    public const string Reset = "\u001b[0m";
}