﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pebble.Oceans.Automation
{
    public enum Severity { Info, Warning, Error };

    public record Error(object Object, string Message, Severity Severity);
}
