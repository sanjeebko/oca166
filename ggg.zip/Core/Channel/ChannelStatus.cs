﻿namespace Pebble.Oceans.Automation;

public enum ChannelStatus
{
    Uncued,
    Cued,
    Playing,
    Errored
}