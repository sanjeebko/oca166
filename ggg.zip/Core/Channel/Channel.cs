﻿namespace Pebble.Service.Automation;

public record Channel(int Id, string Name, ImmutableArray<string> Requirements);

