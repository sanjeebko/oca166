﻿namespace Pebble.Service.Automation;

public class TimeEventArgs : EventArgs
{
    public TimeEventArgs(FrameAlignedTimestamp time)
    {
        Time = time;
    }

    public FrameAlignedTimestamp Time { get; }
}
