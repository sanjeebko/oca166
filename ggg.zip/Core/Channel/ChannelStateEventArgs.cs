﻿namespace Pebble.Oceans.Automation;

public class ChannelStateEventArgs : EventArgs
{
    public ChannelStatus ChannelState { get; set; }
    public FrameAlignedTimestamp TimeStamp { get; }

    public ChannelStateEventArgs(ChannelStatus channelState, FrameAlignedTimestamp time)
    {
        ChannelState = channelState;
        TimeStamp = time;
    }
}