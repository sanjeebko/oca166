﻿using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation;

public class ScheduleListBundleEventArgs : EventArgs
{
    public ScheduleListBundleEventArgs(ListBundle listBundle, HistoricalState historicalState, Dictionary<DeviceListEvent, DeviceListPlayStatus> deviceListPlayStatusMap)
    {
        ListBundle = listBundle;
        HistoricalState = historicalState;
        DeviceListPlayStatusMap = deviceListPlayStatusMap;
    }

    public ListBundle ListBundle { get; }

    public HistoricalState HistoricalState { get; }

    public Dictionary<DeviceListEvent, DeviceListPlayStatus> DeviceListPlayStatusMap { get; }
}