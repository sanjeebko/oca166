﻿namespace Pebble.Oceans.Automation.Channel;

public record HistoricalEvent(DeviceListEvent DeviceListEvent, string Device, string Media, FrameAlignedTimestamp Start, FrameAlignedTimestamp End)
{
    public HistoricalEvent(DeviceListEvent deviceListEvent) : 
        this(deviceListEvent,"","",FrameAlignedTimestamp.Empty, FrameAlignedTimestamp.Empty)
    {
    }
}

public record HistoricalState(ImmutableArray<HistoricalEvent> Events)
{
    public ImmutableArray<HistoricalEvent> GetEvents(string device)
    {
        return Events.Where(e => 
            e.Device.Equals(device, StringComparison.CurrentCultureIgnoreCase)).
            ToImmutableArray();
    }
}