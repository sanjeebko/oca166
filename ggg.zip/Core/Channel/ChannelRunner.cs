﻿using Microsoft.Extensions.Logging;
using Pebble.Oceans.Automation.AsRun;
using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Clock;
using Pebble.Service.Automation;
using System.Collections.Concurrent;

namespace Pebble.Oceans.Automation;

internal record SchedulingRequest(Playlist Playlist, Anchor? Anchor, FrameAlignedTimestamp CurrentTime);

/// <summary>
/// Class which manages the running of a channel schedule
/// </summary>
public class ChannelRunner : IClockEventReceiver, IDisposable
{
    private readonly ILogger _logger = Logging.LogManager.CreateCurrentClassLogger();

    private Playlist? _playlist;

    private LinearListEvent? _activeEvent;

    private bool _disposedValue;

    private readonly ImmutableArray<string> _primaryDevices;

    private readonly Dictionary<string, MediaEventStarted> _deviceEventStartMap = new();

    private readonly ConcurrentDictionary<DeviceListEvent, DeviceListPlayStatus> _deviceListPlayStatusMap = new();

    public AsRunLogger AsRunLogger { get; set; } = new ConsoleAsRunLogger();

    public ChannelSchedule? ChannelSchedule { get; private set; }

    public ChannelContext ChannelContext { get; init; }

    public FrameAlignedTimestamp Time => ChannelContext.Time;

    public ChannelStatus ChannelState => ChannelContext.ChannelStatus;

    public AnchoredPlaylist AnchoredPlaylist => new(ChannelContext.CurrentPlaylist, ChannelContext.Anchor);

    public ListBundle CurrentLists => ChannelContext.CurrentLists;

    public LinearList LinearList => ChannelContext.CurrentLists.LinearList;

    public ImmutableArray<DeviceList> DeviceLists => ChannelContext.CurrentLists.DeviceLists;

    public PresentationList PresentationList => ChannelContext.PresentationListProvider.GetPresentationList();

    public bool StopOnEmptyLinearList { get; set; } = true;

    public event EventHandler<ScheduleListBundleEventArgs>? SchedulingFinished;
    public event EventHandler<EventArgs>? ScheduleFrameStart;
    public event EventHandler<EventArgs>? ScheduleFrameEnd;
    public event EventHandler<EventArgs>? PlaylistEnd;
    public event EventHandler<TimeEventArgs>? NewFrame;

    private TaskCompletionSource<SchedulingRequest> _schedulingRequested = new();

    private readonly CancellationTokenSource _schedulingCancelled = new();

    public ChannelRunner(ChannelContext channelContext)
    {
        ChannelContext = channelContext;

        ChannelContext.ChannelStatus = ChannelStatus.Uncued;

        _primaryDevices = ChannelContext.ChannelConfiguration.DeviceChainManifest.Devices
            .Where(dv => dv.Primary)
            .Select(dv => dv.Role)
            .ToImmutableArray();
        
        ChannelContext.AsRunLog.Changed += AsRunLog_Changed;
        SchedulingFinished += ChannelContext.PresentationListProvider.OnSchedulingFinished;

        _ = SchedulingLoopAsync();
    }

    public (bool IsCurrentlyPlaying, MediaEventStarted? StartArgs) GetDeviceStartState(string device)
    {
        return _deviceEventStartMap.ContainsKey(device) ? (true, _deviceEventStartMap[device]) : (false, null);
    }

    public void LoadPlaylist(AnchoredPlaylist playlist)
    {
        _logger.LogInformation("Playlist {Name} loaded", playlist.Playlist.Name);

        _playlist = playlist.Playlist;
        ChannelContext.CurrentPlaylist = playlist.Playlist;
        ChannelContext.Anchor = playlist.Anchor;

        RequestScheduling();
    }

    public void LoadPlaylist(Playlist playlist)
    {
        _logger.LogInformation("Playlist {playlist.Name} loaded", playlist.Name);

        _playlist = playlist;
        ChannelContext.CurrentPlaylist = playlist;

        RequestScheduling();
    }

    public void PlayNext()
    {
        var linearList = CurrentLists.LinearList;
        var nextEvent = linearList.Events.OfType<ActiveLinearListEvent>().FirstOrDefault(e => e != _activeEvent);
        if (nextEvent is null)
        {
            _logger.LogError("At the end of the playlist");
            return;
        }

        FrameAlignedTimestamp currentTime = ChannelContext.Time;
        FrameAlignedTimestamp startTime = currentTime + ChannelContext.ChannelConfiguration.Preroll;

        ChannelContext.AsRunLog.AddEvent(nextEvent.Parent.Timing.Start is FixedTiming
            ? new PlayNextEvent(currentTime, nextEvent.CalculatedTiming.Start)
            : new PlayNextEvent(currentTime, startTime));

        ChannelContext.Anchor = new(null, startTime, ImmutableArray<LoopCounter>.Empty, nextEvent.Parent.Id);
        ChannelContext.ChannelStatus = ChannelStatus.Playing;

        RequestScheduling();
    }

    public void OnNewFrame(FrameAlignedTimestamp time)
    {
        ChannelContext.Time = time;
        NewFrame?.Invoke(this, new(time));

        PeriodicScheduleWhenCued(currentTime: time);
    }

    private void PeriodicScheduleWhenCued(FrameAlignedTimestamp currentTime)
    {
        if (ChannelContext.ChannelStatus == ChannelStatus.Cued &&
            currentTime >= ChannelContext.LastSchedulingRequestTime + ChannelContext.ChannelConfiguration.RescheduleTimeDifference)
        {
            RequestScheduling();
        }
    }

    public ChannelStatus Cue(string? eventId)
    {
        if (_playlist == null)
            throw new InvalidOperationException("Playlist is not loaded to the channel.");

        PlaylistEvent? cueEvent = string.IsNullOrEmpty(eventId)
            ? _playlist.Events.OfType<PlaylistEvent>().FirstOrDefault()
            : _playlist.Events.OfType<PlaylistEvent>().FirstOrDefault(e => e.Id == eventId);

        if (cueEvent is null)
            throw new ArgumentException($"Invalid event id: {eventId}.");

        if (ChannelContext.ChannelStatus == ChannelStatus.Uncued)
            ChannelContext.ChannelStatus = ChannelStatus.Cued;

        if (cueEvent.Id == ChannelContext.Anchor?.CurrentEventId && ChannelContext.ChannelStatus == ChannelStatus.Playing)
            return ChannelContext.ChannelStatus;

        ChannelContext.AsRunLog.AddEvent(new CueEvent(ChannelContext.Time, cueEvent.Id));

        _deviceListPlayStatusMap.Clear();

        ChannelContext.Anchor = new Anchor(ChannelContext.Anchor?.CurrentEventId,
            ChannelContext.Anchor?.StartTime,
            ChannelContext.Anchor?.Loops ?? ImmutableArray<LoopCounter>.Empty,
            cueEvent.Id);

        RequestScheduling();
        _logger.LogInformation("Channel is {ChannelState} at Event {Id}", cueEvent.Id, ChannelContext.ChannelStatus);
        return ChannelContext.ChannelStatus;
    }

    private ChannelStatus Uncue(bool reschedule = true)
    {
        if (_playlist == null)
            throw new InvalidOperationException("Playlist is not loaded to the channel.");

        ChannelContext.Anchor = null;
        ChannelContext.ChannelStatus = ChannelStatus.Uncued;

        _deviceListPlayStatusMap.Clear();

        if (reschedule)
            RequestScheduling();

        _logger.LogInformation("Channel is {ChannelContext.ChannelState}.", ChannelContext.ChannelStatus);
        return ChannelContext.ChannelStatus;
    }

    public ChannelStatus ManualUncue(bool reschedule = true)
    {
        ChannelContext.AsRunLog.AddEvent(new UncueEvent(Time));
        return Uncue(reschedule);
    }

   
    public void RequestScheduling()
    {
        if (_schedulingRequested.TrySetResult(
                new SchedulingRequest(
                    ChannelContext.CurrentPlaylist,
                    ChannelContext.Anchor,
                    ChannelContext.Time)))
            ChannelContext.LastSchedulingRequestTime = ChannelContext.Time;
    }

    private async Task SchedulingLoopAsync()
    {
        while (!_schedulingCancelled.IsCancellationRequested)
        {
            var request = await _schedulingRequested.Task.WaitAsync(_schedulingCancelled.Token).ConfigureAwait(false);
            _schedulingRequested = new TaskCompletionSource<SchedulingRequest>();

            if (ChannelContext.Anchor is not null && ChannelContext.Anchor.StartTime > ChannelContext.Time)
            {
                ChannelContext.Anchor = ChannelContext.Anchor with { StartTime = ChannelContext.Time };
                request = request with { Anchor = ChannelContext.Anchor };
            }

            try
            {
                ScheduleListBundleEventArgs bundle = await ScheduleAsync(request, _schedulingCancelled.Token).ConfigureAwait(false);
                ChannelContext.CurrentLists = bundle.ListBundle;

                SchedulingFinished?.Invoke(this, bundle);

                if (bundle.ListBundle.LinearList.IsIdle)
                {
                    Uncue(reschedule: false);
                    PlaylistEnd?.Invoke(this, EventArgs.Empty);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("An error occurred while scheduling. Failed to produce schedule, awaiting next request. Error: {ex.Message}", ex.Message);
            }
        }
    }

    private async Task<ScheduleListBundleEventArgs> ScheduleAsync(SchedulingRequest schedulingRequest, CancellationToken cancellation)
    {
        ScheduleFrameStart?.Invoke(this, EventArgs.Empty);
        try
        {
            (LinearList linearList, ImmutableArray<Error> linearListErrors) = await Task.Run(
                () => ChannelContext.PlaylistProcessor.Execute(schedulingRequest.Playlist, schedulingRequest.Anchor, schedulingRequest.CurrentTime, IsProvisionalTimingEnabled()))
                                                      .ConfigureAwait(false);

            if (cancellation.IsCancellationRequested)
                throw new TaskCanceledException();

            var deviceResults = await Task.WhenAll<(DeviceList DeviceList, ImmutableArray<Error> Errors)>(
                ChannelContext.DeviceSchedulingBranches.Select(branch => Task.Run(
                    () =>
                    {
                        (DeviceList deviceList, ImmutableArray<Error> errors) = branch.LinearListProcessor.Execute(linearList);

                        var controllerList = ChannelContext.ChannelStatus is ChannelStatus.Uncued
                            ? new DeviceList(branch.LinearListProcessor.DeviceConfig.Role, ImmutableArray<DeviceListEvent>.Empty)
                            : deviceList;

                        branch.DeviceController.SetDeviceList(controllerList);

                        UpdateDeviceListStatus(controllerList, deviceList);

                        return (deviceList, errors);
                    }, cancellation))).ConfigureAwait(false);

            var errors = linearListErrors.ToBuilder();
            foreach (var result in deviceResults)
                errors.AddRange(result.Errors);

            ImmutableArray<DeviceList> deviceLists = deviceResults.Select(dr => dr.DeviceList).ToImmutableArray();

            var currentListBundle = new ListBundle(
                schedulingRequest.CurrentTime,
                schedulingRequest.Playlist,
                linearList,
                deviceLists,
                errors.GroupBy(error => error.Object).ToImmutableDictionary(error => error.Key, v => v as IEnumerable<Error>));

            return new ScheduleListBundleEventArgs(currentListBundle,
                                           ChannelContext.HistoricalState,
                                           _deviceListPlayStatusMap.ToDictionary(kvp => kvp.Key, kvp => kvp.Value, _deviceListPlayStatusMap.Comparer));
        }
        finally
        {
            ScheduleFrameEnd?.Invoke(this,EventArgs.Empty);
        }
    }

    private bool IsProvisionalTimingEnabled()
      => ChannelContext.ChannelStatus == ChannelStatus.Cued;

    private void UpdateDeviceListStatus(DeviceList deviceListSentToDevice, DeviceList completeDeviceList)
    {
        foreach (var deviceListEvent in deviceListSentToDevice.Events.ToArray())
        {
            if (HasDeviceListEventStarted(deviceListSentToDevice, deviceListEvent))
                RecordDeviceListState(deviceListEvent, DeviceListPlayStatus.Playing);
            else
                RecordDeviceListState(deviceListEvent, DeviceListPlayStatus.Cued);
        }

        foreach (var deviceListEvent in completeDeviceList.Events.Except(deviceListSentToDevice.Events).ToArray())
        {
            RecordDeviceListState(deviceListEvent, DeviceListPlayStatus.Scheduled);
        }

        bool HasDeviceListEventStarted(DeviceList deviceList, DeviceListEvent deviceListEvent)
        {
            return _deviceEventStartMap.ContainsKey(deviceList.DeviceName) && _deviceEventStartMap[deviceList.DeviceName].DeviceListEvent == deviceListEvent;
        }
    }

    private void AsRunLog_Changed(object? sender, EventArgs e)
    {
        var lastEvent = (sender as AsRun.AsRunLog)?.Events.LastOrDefault() as MediaAsRunEvent;
        if (lastEvent is null)
            return;
        bool isPrimary = IsPrimaryEvent(lastEvent.MediaEvent);

        // MJ: Temporary hooks into the original as-run logging system are added here
        switch (lastEvent)
        {
            case MediaEventStarted startEvent:
                ChannelContext.ChannelStatus = ChannelStatus.Playing;
                AsRunLogger.AsRunLogCreated(
                    this,
                    new AsRunLogStartEventArgs(
                        startEvent.DeviceListEvent,
                        startEvent.Timestamp));

                RecordStartEventForHistorical(startEvent);
                RecordDeviceListState(startEvent.DeviceListEvent, DeviceListPlayStatus.Playing);

                if (isPrimary)
                    RequestRescheduleForStartEvent(startEvent);
                break;

            case MediaEventStopped endEvent:

                AsRunLogger.AsRunLogCreated(
                    this,
                    new AsRunLogEndEventArgs(
                        endEvent.DeviceListEvent,
                        endEvent.Timestamp));

                RecordEndEventForHistorical(endEvent);
                RecordDeviceListState(endEvent.DeviceListEvent, DeviceListPlayStatus.Played);

                if (isPrimary)
                    RequestRescheduleForEndEvent(endEvent);

                break;
        }
        void RecordStartEventForHistorical(MediaEventStarted startEvent)
        {
            var deviceId = startEvent.MediaEvent.Device;

            if (!_deviceEventStartMap.ContainsKey(deviceId))
            {
                _deviceEventStartMap[deviceId] = startEvent;
            }
        }

        void RequestRescheduleForStartEvent(MediaEventStarted startEvent)
        {
            if (startEvent.DeviceListEvent.LinearListEvent == _activeEvent)
                return;

            _activeEvent = startEvent.DeviceListEvent.LinearListEvent;

            ChannelContext.Anchor = new(startEvent.DeviceListEvent.LinearListEvent.Parent.Id,
                startEvent.DeviceListEvent.LinearListEvent.CalculatedTiming.Start,
                ImmutableArray<LoopCounter>.Empty,
                _playlist?.GetNextPlaylistEventId(startEvent.DeviceListEvent.LinearListEvent.Parent, LinearList.Events));

            RequestScheduling();
        }
        void RequestRescheduleForEndEvent(MediaEventStopped endEvent)
        {
            var nextLinearEvent = ChannelContext.CurrentLists.LinearList.Events
                .SkipWhile(e => e != endEvent.DeviceListEvent.LinearListEvent)
                .Skip(1)
                .FirstOrDefault();
            if (nextLinearEvent is IdleLinearListEvent || ChannelContext.ChannelStatus is ChannelStatus.Uncued)
                RequestScheduling();
        }

        void RecordEndEventForHistorical(MediaEventStopped endEvent)
        {
            var deviceId = endEvent.DeviceListEvent.MediaEvent.Device;

            if (!_deviceEventStartMap.ContainsKey(deviceId)) return;

            var startEvent = _deviceEventStartMap[deviceId];
            _deviceEventStartMap.Remove(deviceId);

            var media = endEvent.DeviceListEvent.MediaEvent.MediaReference;

            var newList = ChannelContext.HistoricalState.Events
                .Append(new HistoricalEvent(endEvent.DeviceListEvent, deviceId, media, startEvent.Timestamp, endEvent.Timestamp));

            ChannelContext.HistoricalState = new HistoricalState(newList.ToImmutableArray());
        }
    }

    private void RecordDeviceListState(DeviceListEvent deviceListEvent, DeviceListPlayStatus status)
    {
        _deviceListPlayStatusMap[deviceListEvent] = status;
    }

    private bool IsPrimaryEvent(MediaEvent mediaEvent)
           => _primaryDevices.Contains(mediaEvent.Device);

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _schedulingCancelled.Cancel();
            }
            _disposedValue = true;
        }
    }
    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }
}


