﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Processors;

namespace Pebble.Oceans.Automation;

public class ChannelContext
{
    private ChannelStatus _channelStatus;

    public FrameAlignedTimestamp Time { 
        get; 
        internal set;
    } = FrameAlignedTimestamp.Zero;

    public Playlist CurrentPlaylist { get; internal set; } = new(string.Empty, string.Empty, ImmutableArray<PlaylistItem>.Empty);
    public Anchor? Anchor { get; set; }
    public ChannelConfiguration ChannelConfiguration { get; init; }

    public ListBundle CurrentLists { get; internal set; } = new(
        FrameAlignedTimestamp.Zero,
        new("", "", ImmutableArray<PlaylistItem>.Empty),
        new(ImmutableArray<LinearListEvent>.Empty),
        ImmutableArray<DeviceList>.Empty,
        ImmutableDictionary<object, IEnumerable<Error>>.Empty);

    public FrameAlignedTimestamp LastSchedulingRequestTime { get; internal set; } = FrameAlignedTimestamp.Zero;
    public HistoricalState HistoricalState { get; internal set; } = new(ImmutableArray<HistoricalEvent>.Empty);

    public ChannelStatus ChannelStatus
    {
        get => _channelStatus;
        set
        {
            _channelStatus = value;
            ChannelStatusChanged?.Invoke(this, new ChannelStateEventArgs(value, Time));
        }
    }

    public event EventHandler<ChannelStateEventArgs>? ChannelStatusChanged;
    public DeviceChain CurrentDeviceChain { get; }
    public PlaylistProcessor PlaylistProcessor { get; }
    public IPresentationListProvider PresentationListProvider { get; }
    public AsRun.AsRunLog AsRunLog { get; } = new();

    // This should be considered as a temporary placeholder to be replaced by a more elaborate schedule processing graph
    // that will allow us to create a processing tree that would encapsulate custom processors
    public ImmutableArray<(LinearListProcessor LinearListProcessor, DeviceController DeviceController)> DeviceSchedulingBranches { get; }
    public ImmutableArray<DeviceController> DeviceControllers => DeviceSchedulingBranches
        .Select(branch => branch.DeviceController).ToImmutableArray();

    public ChannelContext(ChannelConfiguration channelConfiguration)
    {
        ChannelConfiguration = channelConfiguration;

        CurrentDeviceChain = new DeviceChain(
            ChannelConfiguration.DeviceChainManifest.Devices.Select(
                deviceConfig => new Device(deviceConfig, new Node(""), deviceConfig.Role, deviceConfig.Type)).ToImmutableArray());

        PlaylistProcessor = new PlaylistProcessor(ChannelConfiguration);
        PresentationListProvider = new PresentationListProvider();

        DeviceSchedulingBranches = ChannelConfiguration.DeviceChainManifest.Devices
            .Select(device => (new LinearListProcessor(device), DeviceController.Create(device, AsRunLog)))
            .ToImmutableArray();
    }
}