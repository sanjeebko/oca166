﻿using Pebble.Oceans.Automation.Devices;

namespace Pebble.Oceans.Automation.Channel;

public record ChannelConfiguration(DeviceChainManifest DeviceChainManifest,
    LinearListConfiguration LinearListConfiguration, FrameAlignedTimeDifference RescheduleTimeDifference)
{
    public FrameAlignedTimeDifference Preroll => DeviceChainManifest.Devices.Max(dc => dc.Preroll);
}

public record LinearListConfiguration(int MaxSize,
    FrameAlignedTimeDifference MaxDuration);