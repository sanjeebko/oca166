﻿namespace Pebble.Oceans.Automation.Devices;

public record Node(string Name);

public class Device
{
    public DeviceConfig DeviceConfig { get; }
    public Node Node { get; }
    public string Name { get; }
    public string Type { get; }

    public static Device Default => new(DeviceConfig.Default, new Node(string.Empty), string.Empty, string.Empty);

    public Device(DeviceConfig deviceConfig, Node node, string name, string type)
    {
        DeviceConfig = deviceConfig;
        Node = node;
        Name = name;
        Type = type;
    }
}