﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Devices;

[GenerateSerialization]
public record DeviceChainManifest(string Name, ImmutableArray<DeviceConfig> Devices)
{
    public static DeviceChainManifest Default
        => new(
            "Default",
            ImmutableArray.Create<DeviceConfig>(
                new DeviceConfig(
                    "Video",
                    "Video",
                    true,
                    new(5),
                    new(
                        "Default",
                        ""))));

    public FrameAlignedTimeDifference GetPreroll()
    {
        FrameAlignedTimeDifference result = Devices.Max(device => device.Preroll);
        return result.FrameCount < 1
            ? new(1)
            : result;
    }
}

public record DeviceConfig(string Type, string Role, bool Primary, FrameAlignedTimeDifference Preroll, DeviceConfigController Controller)
{
    public static DeviceConfig Default { get; } = new(string.Empty, string.Empty, true, FrameAlignedTimeDifference.Zero,
        new DeviceConfigController(string.Empty, string.Empty));
}

public record DeviceConfigController(string Type, string FileName);