﻿using Microsoft.Extensions.Logging;
using Pebble.Oceans.Automation.AsRunLog;

namespace Pebble.Oceans.Automation.Devices;

public class DummyDeviceController : DeviceController
{
    private readonly ILogger _logger = Logging.LogManager.CreateCurrentClassLogger();

    public DummyDeviceController(DeviceConfig deviceConfig, AsRun.AsRunLog asRunLog)
        : base(deviceConfig, asRunLog)
    {
    }

    public override void SetDeviceList(DeviceList deviceList)
    {
        base.SetDeviceList(deviceList);
        _logger.LogTrace("Device list for {Device} received", DeviceConfig.Role);
    }
}