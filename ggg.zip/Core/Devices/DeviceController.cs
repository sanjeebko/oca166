﻿using Pebble.Oceans.Automation.Clock;
using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.AsRun;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Pebble.Oceans.Automation.Devices;

public abstract class DeviceController : IClockEventReceiver
{
    protected DeviceController(DeviceConfig deviceConfig, AsRun.AsRunLog asRunLog)
    {
        DeviceConfig = deviceConfig;
        _asRunLog = asRunLog;
    }

    public delegate void EventHandler<in AsRunEventArgs>(object source, AsRunEventArgs asRunEventArgs);

    public DeviceConfig DeviceConfig { get; }

    private static readonly ImmutableDictionary<string, Type> _deviceControllerTypes = GetDeviceControllerTypes();
    private readonly AsRun.AsRunLog _asRunLog;

    public DeviceList DeviceList { get; private set; } = new DeviceList("", ImmutableArray<DeviceListEvent>.Empty);

    private DeviceListEvent? PlayingEvent { get; set; }

    private static ImmutableDictionary<string, Type> GetDeviceControllerTypes()
        => ReflectionHelper.GetAllLoadedTypes()
            .Where(type => !type.IsAbstract && type.IsAssignableTo(typeof(DeviceController)))
            .ToImmutableDictionary(type => type.Name.Replace("DeviceController", "", StringComparison.InvariantCultureIgnoreCase));

    public static DeviceController Create(DeviceConfig deviceConfig, AsRun.AsRunLog asRunLog)
    {
        if (_deviceControllerTypes.TryGetValue(deviceConfig.Controller.Type, out Type? type))
        {
            return type.GetConstructor(new Type[] { typeof(DeviceConfig), typeof(AsRun.AsRunLog) })
                  ?.Invoke(new object[] { deviceConfig, asRunLog }) as DeviceController
                  ?? throw new SchedulingException($"Cannot create an instance of type \"{type.Name}\"");
        }

        throw new SchedulingException($"Unknown device controller type \"{deviceConfig.Controller.Type}\"");
    }

    public virtual void SetDeviceList(DeviceList deviceList)
    {
        DeviceList = deviceList;
    }

    public virtual void OnNewFrame(FrameAlignedTimestamp time)
    {
        DeviceList currentDeviceList = DeviceList;

        var @event = currentDeviceList.Events
            .FirstOrDefault(e => !e.ProvisionalTiming && e.CalculatedTiming.Contains(time));

        if (@event is null)
            Stop(time);
        else
            PlayEvent(time, @event);
    }

    protected virtual void PlayEvent(FrameAlignedTimestamp timestamp, DeviceListEvent deviceListEvent)
    {
        if (PlayingEvent == deviceListEvent)
            return;
        if (PlayingEvent is not null)
            _asRunLog.AddEvent(new MediaEventStopped(timestamp, PlayingEvent));
        PlayingEvent = deviceListEvent;
        _asRunLog.AddEvent(new MediaEventStarted(timestamp, PlayingEvent));
    }

    protected virtual void Stop(FrameAlignedTimestamp timestamp)
    {
        if (PlayingEvent is not null)
            _asRunLog.AddEvent(new MediaEventStopped(timestamp, PlayingEvent));
        PlayingEvent = null;
    }
}