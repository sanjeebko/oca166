﻿namespace Pebble.Oceans.Automation.Devices;

public class DeviceChain
{
    public ImmutableArray<Device> Devices { get; }

    public DeviceChain(ImmutableArray<Device> devices)
    {
        Devices = devices;
    }
}