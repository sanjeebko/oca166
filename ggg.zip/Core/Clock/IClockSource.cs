﻿namespace Pebble.Oceans.Automation.Clock;

public interface IClockSource
{
    FrameAlignedTimestamp GetTimestamp();

    void Subscribe(IClockEventReceiver destination);
    void Unsubscribe(IClockEventReceiver destination);
}
