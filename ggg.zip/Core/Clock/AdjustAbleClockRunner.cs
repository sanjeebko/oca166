﻿namespace Pebble.Oceans.Automation.Clock;

public class AdjustAbleClockRunner : ClockRunner
{
    public AdjustAbleClockRunner(ClockSource clockSource, ChannelRunner channelRunner) : base(clockSource, channelRunner)
    {
    }

    public void UpdateTime(FrameAlignedTimestamp newTime)
    {
        SetClockMode(ClockMode.Stopped);
        ClockSource.SetTime(newTime);
    }

    public void Stop() => SetClockMode(ClockMode.Stopped);

    public void SetClockMode(ClockMode clockMode)
    {
        if (clockMode == ClockMode)
            return;

        ClockMode = clockMode;
        switch (ClockMode)
        {
            case ClockMode.Stopped:
                ClockSource.Stop();
                break;

            case ClockMode.RealTime:
                ClockSource.RealTime = true;
                ClockSource.Start();
                break;

            default:
                ClockSource.RealTime = false;
                ClockSource.Start();
                break;
        }
    }
}