﻿namespace Pebble.Oceans.Automation.Clock;

public interface IClockEventReceiver
{
    void OnNewFrame(FrameAlignedTimestamp time);
}