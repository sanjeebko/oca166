﻿
namespace Pebble.Oceans.Automation.Clock;

public enum ClockMode
{
    Stopped,
    RealTime,
    FastForwardToNextEvent,
    FastForwardToEndOfPlaylist
}

public class ClockRunner : IDisposable
{
    protected readonly ClockSource ClockSource;
    private bool _disposedValue;

    public ClockRunner(ClockSource clockSource, ChannelRunner channelRunner)
    {
        ClockSource = clockSource;
        ClockSource.SetTime(new FrameAlignedTimestamp(DateTime.UtcNow));

        var listOfClockSourceUpdates = new List<IClockEventReceiver>
        {
            channelRunner
        };

        listOfClockSourceUpdates.AddRange(channelRunner.ChannelContext.DeviceControllers);
        SubscribeClockSource(listOfClockSourceUpdates.ToImmutableArray());

        channelRunner.ScheduleFrameStart += ChannelRunnerScheduleFrameStart;
        channelRunner.ScheduleFrameEnd += ChannelRunnerScheduleFrameEnd;
        channelRunner.PlaylistEnd += ChannelRunnerPlaylistEnd;
    }

    public void Start()
    {
        ClockMode = ClockMode.RealTime;
        ClockSource.Start();
    }

    private void ChannelRunnerScheduleFrameEnd(object? sender, EventArgs e)
    {
        if (ClockMode == ClockMode.FastForwardToNextEvent)
            ClockMode = ClockMode.RealTime;
        ClockSource.RealTime = ClockMode == ClockMode.RealTime;
    }

    private void ChannelRunnerPlaylistEnd(object? sender, EventArgs e)
    {
        if (StopOnPlaylistEnd)
        {
            ClockSource.Stop();
        }
    }

    private void ChannelRunnerScheduleFrameStart(object? sender, EventArgs e)
    {
        ClockSource.RealTime = true;
    }

    protected ClockMode ClockMode { get; set; }

    public bool StopOnPlaylistEnd { get; init; }

    private void SubscribeClockSource(ImmutableArray<IClockEventReceiver> receivers)
    {
        foreach (var clockEventReceiver in receivers)
        {
            ClockSource.Subscribe(clockEventReceiver);
        }
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                ClockSource.Dispose();
            }
            _disposedValue = true;
        }
    }

    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }
}
