﻿using System.Diagnostics;

namespace Pebble.Oceans.Automation.Clock;

public class ClockSource : IClockSource, IDisposable
{
    private struct AnchorPoint
    {
        internal readonly long TickCount;
        internal readonly FrameAlignedTimestamp Timestamp;

        public AnchorPoint(long tickCount, FrameAlignedTimestamp timestamp)
        {
            TickCount = tickCount;
            Timestamp = timestamp;
        }
    }

    private AnchorPoint _anchor;
    private bool _disposedValue;
    private readonly Stopwatch _stopwatch = new();
    private readonly Task _frameTickTask;
    private FrameAlignedTimestamp _lastFrameCount;
    private bool _shutdown;

    public bool RealTime { get; set; } = true;

    public bool IsRunning { get; private set; }

    public void Start() => IsRunning = true;

    public void Stop() => IsRunning = false;

    public FrameBasedTimingSystem TimingSystem { get; }

    public ClockSource(FrameBasedTimingSystem? timingSystem = null)
    {
        TimingSystem = timingSystem ?? FrameBasedTimingSystem.Current;
        _stopwatch.Start();
        ResetAnchor(FrameAlignedTimestamp.Zero);
        _frameTickTask = FrameTick();
    }

    internal void SetTime(FrameAlignedTimestamp timestamp)
    {
        if (timestamp.TimingSystem != TimingSystem)
            throw new ArgumentException("Incompatible timing system", nameof(timestamp));
        _lastFrameCount = timestamp;
        ResetAnchor(timestamp);
        OnNewFrame(timestamp);
    }

    private void ResetAnchor(FrameAlignedTimestamp timestamp)
    {
        _anchor = new(_stopwatch.ElapsedTicks, timestamp);
    }

    public FrameAlignedTimestamp GetTimestamp() 
        => _anchor.Timestamp
            .AddFrames((_stopwatch.ElapsedTicks - _anchor.TickCount) * TimingSystem.FrameRate.Rate / TimingSystem.FrameRate.Scale / Stopwatch.Frequency);

    private readonly List<IClockEventReceiver> _subscriptions = new();

    public void Subscribe(IClockEventReceiver destination)
    {
        lock (_subscriptions)
            _subscriptions.Add(destination);
    }

    public void Unsubscribe(IClockEventReceiver destination)
    {
        lock (_subscriptions)
            _subscriptions.Remove(destination);
    }

    private async Task FrameTick()
    {
        while (!_shutdown)  // We could switch to event based closing of the clock source in the future
        {
            if(IsRunning)
                if (RealTime)
                {
                    await Task.Delay(1).ConfigureAwait(false);
                    FrameAlignedTimestamp frameCount = GetTimestamp();
                    if (frameCount > _lastFrameCount)
                    {
                        _lastFrameCount = frameCount;
                        OnNewFrame(frameCount);
                    }
                }
                else
                {
                    _lastFrameCount = _lastFrameCount.NextFrame();
                    _anchor = new(_stopwatch.ElapsedTicks, _lastFrameCount);
                    OnNewFrame(_lastFrameCount);
                }
            else
            {
                await Task.Delay(10).ConfigureAwait(false);
                ResetAnchor(_lastFrameCount);
            }
        }
    }

    private void OnNewFrame(FrameAlignedTimestamp frameCount)
    {
        lock (_subscriptions)
            foreach (IClockEventReceiver subscription in _subscriptions)
                try
                {
                    subscription.OnNewFrame(frameCount); // We could make concurrent async calls in the future
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Exception in clock thread: {ex}");
                }
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!_disposedValue)
        {
            if (disposing)
            {
                _shutdown = true;
                _frameTickTask.Wait();
                _frameTickTask.Dispose();
            }
            _disposedValue = true;
        }
    }

    public void Dispose()
    {
        Dispose(disposing: true);
        GC.SuppressFinalize(this);
    }
}