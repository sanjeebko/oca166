﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[GenerateSerialization]
public record AnchoredPlaylist(Playlist Playlist, Anchor? Anchor = null)
{
    public IEnumerable<string> ToMarkDown()
        => Anchor is not null ? Anchor.ToMarkDown().Concat(Playlist.ToMarkDown()) : Playlist.ToMarkDown();

    public string ToFormattedString(SaveOutputFileFormat format) => format switch
    {
        SaveOutputFileFormat.json => this.ToJsonString(),
        SaveOutputFileFormat.md => string.Join("\r\n", ToMarkDown()),
        SaveOutputFileFormat.yaml => this.ToYamlString(),
        _ => this.ToYamlString()
    };
}

public record Anchor(string? CurrentEventId, FrameAlignedTimestamp? StartTime, ImmutableArray<LoopCounter> Loops, string? NextEventId)
{
    public IEnumerable<string> ToMarkDown()
    {
        var md = new MarkdownTableBuilder();
        md.SetHeader("Type", "Current Event Id", "StartTime", "Loops", "Next Event Id");
        md.AddRow("Anchor", CurrentEventId ?? string.Empty, StartTime.ToString() ?? string.Empty, Loops.Length, NextEventId ?? string.Empty);
        return md.GetLines();
    }
}

public record LoopCounter(string Id, int Count);