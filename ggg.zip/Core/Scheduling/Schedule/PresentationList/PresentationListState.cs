﻿namespace Pebble.Oceans.Automation.Scheduling;

public record PresentationListState(PresentationListPlayState Play, PresentationListValidation Validation);

public record PresentationListPlayState(string Status);

public record PresentationListValidation(string Status);