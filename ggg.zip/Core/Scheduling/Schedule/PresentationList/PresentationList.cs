﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[GenerateSerialization]
public record PresentationList(string ChannelId, string Name, ImmutableArray<PresentationListItem> Items)
{
    public string ToFormattedString(SaveOutputFileFormat format) => format switch
    {
        SaveOutputFileFormat.json => this.ToJsonString(),
        SaveOutputFileFormat.md => string.Join("\r\n", ToMarkDown()),
        SaveOutputFileFormat.yaml => this.ToYamlString(),
        _ => this.ToJsonString()
    };

    public IEnumerable<string> ToMarkDown()
    {
        var md = new MarkdownTableBuilder();
        md.SetHeader("ID", "Title", "Type", "Device", "Start time", "End time", "Duration", "Media Reference", "Track", "PL Event Play Status", "LL Event Schedule Status", "DL Event Status", "Validation status");

        foreach (var playListItem in Items)
        {
            switch (playListItem)
            {
                case PresentationListEvent ple:
                    foreach (var mediaEvent in ple.MediaEvents)
                    {
                        md.AddRow(ple.Id,
                                  ple.Title,
                                  ple.Type,
                                  mediaEvent.Device,
                                  mediaEvent.DeviceListEvent?.CalculatedTiming.Start.ToString() ?? string.Empty,
                                  mediaEvent.DeviceListEvent?.CalculatedTiming.End.ToString() ?? string.Empty,
                                  mediaEvent.DeviceListEvent?.CalculatedTiming.Duration.ToString() ?? string.Empty,
                                  mediaEvent.MediaReference,
                                  mediaEvent.Track ?? string.Empty,
                                  ple.State.Play.Status,
                                  ple.LinearListEvents.LastOrDefault()?.State.SchedulingStatus ?? nameof(DeviceListPlayStatus.Skipped),
                                  mediaEvent.DeviceListEvent?.State.Status ?? nameof(DeviceListPlayStatus.Skipped),
                                  ple.State.Validation.Status);
                    }

                    break;

                case PresentationListIdleEvent pli:

                    md.AddRow(pli.Id,
                     pli.Title,
                     pli.Type,
                     string.Empty,
                     pli.LinearListEvent.CalculatedTiming.Start,
                     pli.LinearListEvent.CalculatedTiming.End,
                     pli.LinearListEvent.CalculatedTiming.Duration,
                     string.Empty,
                     string.Empty,
                     pli.LinearListEvent.State.PlayState.Status,
                     pli.LinearListEvent.State.SchedulingStatus,
                     string.Empty,
                     string.Empty);
                    break;
            }
        }

        return md.GetLines();
    }

    internal static PresentationList Empty()
        => new("", "", ImmutableArray.Create<PresentationListItem>());
}