﻿namespace Pebble.Oceans.Automation.Scheduling;

public record PresentationListMediaEvent(string Type,
    string Device,
    string? Track,
    string MediaReference,
    bool Primary,
    MediaEventTiming Start,
    MediaEventTiming End,
    PresentationListDeviceListEvent? DeviceListEvent,
    PresentationListMediaEventState State,
    FrameAlignedTimeDifference? Duration = null,
    FrameAlignedTimeDifference? SOM = null);

public record PresentationListMediaEventState(PresentationListMediaEventValidation Validation);

public record PresentationListMediaEventValidation(string Status, string Description);

public record PresentationListDeviceListEvent(FrameAlignedTimeInterval CalculatedTiming,
                                              PresentationListDeviceListEventState State);

public record PresentationListDeviceListEventState(string Status);