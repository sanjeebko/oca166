﻿namespace Pebble.Oceans.Automation.Scheduling;

public static class PresentationListExtensions
{
    public static PresentationListDeviceListEvent ToPresentationListDeviceListEvent(this DeviceListEvent deviceListEvent, string status = "")
    => new(deviceListEvent.CalculatedTiming, new PresentationListDeviceListEventState(status));

    public static PresentationListMediaEvent ToPresentationListMediaEvent(this MediaEvent mediaEvent,
                                                                          PresentationListDeviceListEvent? presentationListDeviceListEvent,
                                                                          string validationStatus = "",
                                                                          string validationDescription = "")
     => new(mediaEvent.Type,
            mediaEvent.Device,
            mediaEvent.Track,
            mediaEvent.MediaReference,
            mediaEvent.Primary,
            mediaEvent.Start,
            mediaEvent.End,
            presentationListDeviceListEvent,
            new PresentationListMediaEventState(
                new PresentationListMediaEventValidation(validationStatus, validationDescription)),
            mediaEvent.Duration,
            SOM: FrameAlignedTimeDifference.Zero);
}