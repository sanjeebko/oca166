﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[PossibleChild("Type", "event", typeof(PresentationListEvent))]
[PossibleChild("Type", "idle", typeof(PresentationListIdleEvent))]
public abstract record PresentationListItem(string Id, string Title, string Type);

public record PresentationListEvent(string Id,
                                    string Title,
                                    string Type,
                                    PresentationListState State,
                                    Timing Timing,
                                    ImmutableArray<PresentationListLinearListEvent> LinearListEvents,
                                    ImmutableArray<PresentationListMediaEvent> MediaEvents) : PresentationListItem(Id, Title, Type);
public record PresentationListIdleEvent(PresentationListLinearListEvent LinearListEvent) : PresentationListItem("", "", "idle");

public record PresentationListLinearListEvent(FrameAlignedTimeInterval CalculatedTiming,
                                              PresentationListLinearListEventState State);

public record PresentationListLinearListEventState(string SchedulingStatus,
                                                    PresentationListLinearListEventPlayState PlayState);
public record PresentationListLinearListEventPlayState(string Status, string Description);