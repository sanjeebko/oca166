﻿namespace Pebble.Oceans.Automation.Scheduling;

public class PresentationListEventArgs : EventArgs
{
    public PresentationList PresentationList { get; }

    public FrameAlignedTimestamp TimeStamp { get; }

    public PresentationListEventArgs(PresentationList presentationList, FrameAlignedTimestamp timestamp)
    {
        PresentationList = presentationList;
        TimeStamp = timestamp;
    }
}
