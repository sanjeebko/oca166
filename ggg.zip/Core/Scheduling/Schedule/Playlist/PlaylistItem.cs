﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[PossibleChild("Type", "event", typeof(PlaylistEvent))]
[PossibleChild("Type", "group", typeof(PlaylistGroup))]
public abstract record PlaylistItem(string Id, string Title, string Type);

public record PlaylistEvent(string Id, string Title, Timing Timing, ImmutableArray<MediaEvent> MediaEvents) : PlaylistItem(Id, Title, "event");
public record PlaylistGroup(string Id, string Title, ImmutableArray<PlaylistItem> Items, Loop? Loop = null) : PlaylistItem(Id, Title, "group");