﻿namespace Pebble.Oceans.Automation.Scheduling;

public record Loop(int? LoopCount = null, bool? Infinite = null);