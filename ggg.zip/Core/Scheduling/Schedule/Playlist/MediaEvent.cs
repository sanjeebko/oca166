﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

public record MediaEvent(
    string Type,
    string Device,
    string? Track,
    string MediaReference,
    bool Primary,
    MediaEventTiming Start,
    MediaEventTiming End,
    FrameAlignedTimeDifference? Duration = null);

[DoNotSerializeFields(nameof(ValueOrZero))]
public record MediaEventTiming(
    MediaEventTimingMode Mode,
    FrameAlignedTimeDifference? Value = null)
{
    public FrameAlignedTimeDifference ValueOrZero => Value ?? FrameAlignedTimeDifference.Zero;
}

public enum MediaEventTimingMode
{
    Sequential,
    FromParentStart,
    FromParentEnd,
    Duration,
    Transition
}