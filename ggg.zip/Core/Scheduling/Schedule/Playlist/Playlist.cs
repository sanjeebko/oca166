﻿using System.Text;

namespace Pebble.Oceans.Automation.Scheduling;

/// <summary>
/// Record representing a list of <see cref="PlaylistEvent"/> to be scheduled by a channel
/// </summary>
/// <param name="ChannelId">The channel id</param>
/// <param name="Name">The play list name</param>
/// <param name="Events">The list of events to schedule</param>
public record Playlist(string ChannelId, string Name, ImmutableArray<PlaylistItem> Events)
{
    public IEnumerable<string> ToMarkDown()
    {
        IList<string> result = new List<string>
        {
            $"ChannelId = {ChannelId}\r\n",
            $"Name = {Name}\r\n"
        };

        var md = new MarkdownTableBuilder();
        md.SetHeader("Indent", "ID", "Title", "Start time", "End time", "Type");
        StringBuilder indent = new();
        foreach (var @event in Events)
        {
            switch (@event)
            {
                case PlaylistEvent pEvent:
                    md.AddRow(indent, pEvent.Id, pEvent.Title, pEvent.Timing.Start, pEvent.Timing.End.ToString(), "Primary");
                    break;

                case PlaylistGroup gEvent:
                    indent.Append('-');
                    foreach (PlaylistItem gSubEvent in gEvent.Items)
                    {
                        var pEvent = gSubEvent as PlaylistEvent;
                        if (pEvent is not null)
                            md.AddRow(indent, gEvent.Id, gEvent.Title, pEvent.Timing.Start.ToString(), pEvent.Timing.End.ToString(), "Primary");
                    }
                    indent = indent.Remove(indent.Length - 1, 1);
                    break;
            }
        }

        return result.Concat(md.GetLines());
    }

    public string? GetNextPlaylistEventId(PlaylistItem? currentEvent, ImmutableArray<LinearListEvent> linearListEvents)
    {
        if (!Events.Any(e => e == currentEvent))
            return Events.Length > 0 ? Events[0].Id : null;

        var activeLinearListItems = linearListEvents.OfType<ActiveLinearListEvent>()
                                                    .Where(e => e.LinearListEventStatus != LinearListEventStatus.Idle)
                                                    .ToImmutableArray();
        var selectedLinearList = activeLinearListItems.FirstOrDefault(l => l.Parent.Id == currentEvent?.Id);
        if (selectedLinearList is null)
            return Events.Length > 0 ? Events[0].Id : null;

        int selectedLinearListIndex = activeLinearListItems.IndexOf(selectedLinearList);
        if (activeLinearListItems.Length > selectedLinearListIndex + 1)
            return activeLinearListItems[selectedLinearListIndex + 1].Parent.Id;

        return null;
    }
}