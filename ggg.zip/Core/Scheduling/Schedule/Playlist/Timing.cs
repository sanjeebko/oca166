using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

public record Timing(TimingMode Start, TimingMode End, FrameAlignedTimeDifference? Duration, FrameAlignedTimeDifference? TransitionDuration = null);

[PossibleChild("Type", "fixed", typeof(FixedTiming))]
[PossibleChild("Type", "sequential", typeof(SequentialTiming))]
public abstract record TimingMode(string Type);
public record FixedTiming(FrameAlignedTimestamp Start) : TimingMode("fixed");
public record SequentialTiming() : TimingMode("sequential");