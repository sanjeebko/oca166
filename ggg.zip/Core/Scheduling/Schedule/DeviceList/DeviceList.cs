﻿using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Scheduling;

public record DeviceList(string DeviceName, ImmutableArray<DeviceListEvent> Events)
{
    public IEnumerable<string> ToMarkDown(ImmutableArray<HistoricalEvent> historicalEvents)
    {
        var md = new MarkdownTableBuilder();

        var eventsToLog = historicalEvents.Select(historical => (historical.DeviceListEvent, HistoricalEvent: historical)).ToList();

        eventsToLog.AddRange(Events.Select(e => (e, new HistoricalEvent(e))));

        md.SetHeader("ID", "Track", "Media Reference", "Start time", "End time", "Duration", "Actual Played", "Played Duration");

        foreach (var @event in eventsToLog)
        {
            md.AddRow(
                $"{@event.DeviceListEvent.LinearListEvent.Parent.Id}#{@event.DeviceListEvent.LinearListEvent.Parent.MediaEvents.IndexOf(@event.DeviceListEvent.MediaEvent)}",
                @event.DeviceListEvent.MediaEvent.Track ?? string.Empty,
                @event.DeviceListEvent.MediaEvent.MediaReference,
                @event.DeviceListEvent.CalculatedTiming.Start,
                @event.DeviceListEvent.CalculatedTiming.End,
                @event.DeviceListEvent.CalculatedTiming.Duration,
                @event.HistoricalEvent.Start.FrameCount > 0 ? @event.HistoricalEvent.Start : string.Empty,
                @event.HistoricalEvent.End.FrameCount > 0
                    ? @event.HistoricalEvent.End - @event.HistoricalEvent.Start
                    : string.Empty);
        }

        return md.GetLines();
    }

    private IEnumerable<string> ToMarkDown()
    {
        var md = new MarkdownTableBuilder();
        md.SetHeader("ID", "Track", "Media Reference", "Start time", "End time", "Duration");
        foreach (var @event in Events)
        {
            md.AddRow($"{@event.LinearListEvent.Parent.Id}#{@event.LinearListEvent.Parent.MediaEvents.IndexOf(@event.MediaEvent)}",
                      @event.MediaEvent.Track ?? string.Empty,
                      @event.MediaEvent.MediaReference,
                      @event.CalculatedTiming.Start,
                      @event.CalculatedTiming.End,
                      @event.CalculatedTiming.Duration);
        }

        return md.GetLines();
    }
    public ReferenceDeviceList ToReference()
    {
        return new ReferenceDeviceList(Events.Select(e => e.ToReference()).ToImmutableArray());
    }
    public string ToFormattedString(SaveOutputFileFormat format) => format switch
    {
        SaveOutputFileFormat.json => ToReference().ToJsonString(),
        SaveOutputFileFormat.md => string.Join("\r\n", ToMarkDown()),
        SaveOutputFileFormat.yaml => ToReference().ToYamlString(),
        _ => ToReference().ToYamlString()
    };
}