﻿namespace Pebble.Oceans.Automation.Scheduling;

public record ReferenceDeviceListEvent(string ParentId, FrameAlignedTimeInterval CalculatedTiming);