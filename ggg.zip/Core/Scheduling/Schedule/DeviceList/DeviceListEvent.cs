﻿namespace Pebble.Oceans.Automation.Scheduling;

public record DeviceListEvent(ActiveLinearListEvent LinearListEvent, MediaEvent MediaEvent, FrameAlignedTimeInterval CalculatedTiming, bool ProvisionalTiming)
{
    public ReferenceDeviceListEvent ToReference()
    {
        return new ReferenceDeviceListEvent(LinearListEvent.Parent.Id, CalculatedTiming);
    }
}