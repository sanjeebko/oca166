﻿namespace Pebble.Oceans.Automation.Scheduling;

public enum DeviceListPlayStatus
{
    Scheduled,
    Cued,
    Playing,
    Played,
    Skipped
}