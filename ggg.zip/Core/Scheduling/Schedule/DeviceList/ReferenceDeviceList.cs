﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[GenerateSerialization]
public record ReferenceDeviceList(ImmutableArray<ReferenceDeviceListEvent> Events);