﻿namespace Pebble.Oceans.Automation.Scheduling;

public record IdleLinearListEvent(FrameAlignedTimeInterval CalculatedTiming, PlaylistEvent? PreviousEvent) : LinearListEvent(CalculatedTiming)
{
    public override LinearListEventStatus LinearListEventStatus => LinearListEventStatus.Idle;

    internal override ReferenceLinearListEvent ToReference()
        => new ReferenceIdleLinearListEvent(CalculatedTiming);
}