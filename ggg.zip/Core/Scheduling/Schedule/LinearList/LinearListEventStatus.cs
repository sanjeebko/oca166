﻿namespace Pebble.Oceans.Automation.Scheduling;

public enum LinearListEventStatus
{
    Normal,
    Shortened,
    Extended,
    Skipped,
    Idle,
    Generated
}