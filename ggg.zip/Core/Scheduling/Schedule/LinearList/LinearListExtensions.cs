﻿namespace Pebble.Oceans.Automation.Scheduling;

public static class LinearListExtensions
{
    public const int LinearListMax = 15000;

    public static bool IsFull(this IList<LinearListEvent> linearListEvents) => linearListEvents.Count >= LinearListMax;
}
