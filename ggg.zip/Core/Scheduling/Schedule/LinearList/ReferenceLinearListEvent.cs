﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

[DefaultChild(typeof(ReferencePrimaryLinearListEvent))]
[PossibleChild(nameof(Type), "Primary", typeof(ReferencePrimaryLinearListEvent))]
[PossibleChild(nameof(Type), "Idle", typeof(ReferenceIdleLinearListEvent))]
public abstract record ReferenceLinearListEvent(string Type, FrameAlignedTimeInterval CalculatedTiming, LinearListEventStatus LinearListEventStatus);

[DoNotSerializeFields(nameof(ReferencePrimaryLinearListEvent.Type))]
[FieldOrder(nameof(ReferencePrimaryLinearListEvent.ParentId))]
public record ReferencePrimaryLinearListEvent(string ParentId, FrameAlignedTimeInterval CalculatedTiming, LinearListEventStatus LinearListEventStatus)
    : ReferenceLinearListEvent("Primary", CalculatedTiming, LinearListEventStatus);

public record ReferenceIdleLinearListEvent(FrameAlignedTimeInterval CalculatedTiming)
    : ReferenceLinearListEvent("Idle", CalculatedTiming, LinearListEventStatus.Idle);
