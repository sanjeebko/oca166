﻿namespace Pebble.Oceans.Automation.Scheduling;

public abstract record LinearListEvent(FrameAlignedTimeInterval CalculatedTiming)
{
    public abstract LinearListEventStatus LinearListEventStatus { get; }

    internal abstract ReferenceLinearListEvent ToReference();
}