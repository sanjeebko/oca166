﻿namespace Pebble.Oceans.Automation.Scheduling;

public record ActiveLinearListEvent(PlaylistEvent Parent, FrameAlignedTimeInterval CalculatedTiming, bool ProvisionalTiming = false) : LinearListEvent(CalculatedTiming)
{
    public override LinearListEventStatus LinearListEventStatus
    {
        get
        {
            var duration = CalculatedTiming.Duration.FrameCount;
            if (duration == 0)
                return LinearListEventStatus.Skipped;
            var expected = Parent.Timing.Duration?.FrameCount ?? 0;
            if (duration == expected)
                return LinearListEventStatus.Normal;
            if (duration < expected)
                return LinearListEventStatus.Shortened;
            return LinearListEventStatus.Extended;
        }
    }

    internal override ReferenceLinearListEvent ToReference()
        => new ReferencePrimaryLinearListEvent(Parent.Id, CalculatedTiming, LinearListEventStatus);
}