﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Scheduling;

/// <summary>
/// Record representing a list of <see cref="LinearListEvent"/>
/// </summary>
/// <param name="Events">The <see cref="Events"/> for this list</param>
public record LinearList(ImmutableArray<LinearListEvent> Events)
{
    public IEnumerable<string> ToMarkDown(ImmutableDictionary<object, IEnumerable<Error>>? errors = null)
    {
        var md = new MarkdownTableBuilder();
        md.SetHeader("ID", "Title", "Start time", "End time", "Status", "Errors");
        foreach (var @event in Events)
        {
            switch (@event)
            {
                case ActiveLinearListEvent primaryLinearListEvent:
                    string errorMessage = string.Empty;
                    if (errors is not null && errors.TryGetValue(primaryLinearListEvent.Parent, out IEnumerable<Error>? err))
                    {
                        errorMessage = String.Join(", ", err.Select(e => e.Message));
                    }
                    md.AddRow(
                        primaryLinearListEvent.Parent.Id,
                        primaryLinearListEvent.Parent.Title,
                        @event.CalculatedTiming.Start,
                        @event.CalculatedTiming.End,
                        @event.LinearListEventStatus,
                        errorMessage);
                    break;

                case IdleLinearListEvent:
                    md.AddRow(string.Empty, "<<IDLE>>", @event.CalculatedTiming.Start, @event.CalculatedTiming.End, @event.LinearListEventStatus);
                    break;
            }
        }
        return md.GetLines();
    }

    public ReferenceLinearList ToReference()
    {
        return new ReferenceLinearList(Events.Select(e => e.ToReference()).ToImmutableArray());
    }
    public string ToFormattedString(SaveOutputFileFormat format) => format switch
    {
        SaveOutputFileFormat.json => ToReference().ToJsonString(),
        SaveOutputFileFormat.md => string.Join("\r\n", ToMarkDown()),
        SaveOutputFileFormat.yaml => ToReference().ToYamlString(),
        _ => ToReference().ToYamlString()
    };

    public bool IsIdle => !Events.OfType<ActiveLinearListEvent>().Any();
}

/// <summary>
/// The linear list containing ID references to the complex events (as opposed to direct record pointers). This model should be used for (de)serialization purposes.
/// </summary>
/// <param name="Events"></param>
[GenerateSerialization]
public record ReferenceLinearList(ImmutableArray<ReferenceLinearListEvent> Events);