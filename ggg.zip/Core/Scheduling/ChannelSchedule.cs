﻿namespace Pebble.Oceans.Automation.Scheduling;

/// <summary>
/// Contains all the lists that represent a Schedule of broadcast events for a single Channel Instance
/// </summary>
public record ChannelSchedule(Playlist ComplexList,
                              ImmutableDictionary<string, ImmutableArray<LinearListEvent>> ComplexListState,
                              LinearList LinearList,
                              ImmutableArray<DeviceList> DeviceLists);
