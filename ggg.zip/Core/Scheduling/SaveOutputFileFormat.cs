﻿namespace Pebble.Oceans.Automation.Scheduling
{
    public enum SaveOutputFileFormat
    {
        yaml,
        json,
        md
    }
}