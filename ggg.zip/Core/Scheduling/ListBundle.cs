﻿namespace Pebble.Oceans.Automation.Scheduling;

public record ListBundle(
    FrameAlignedTimestamp Timestamp,
    Playlist Playlist,
    LinearList LinearList,
    ImmutableArray<DeviceList> DeviceLists,
    ImmutableDictionary<object, IEnumerable<Error>> Errors);