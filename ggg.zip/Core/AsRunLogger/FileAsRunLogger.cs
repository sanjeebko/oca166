﻿using System.Text;

namespace Pebble.Oceans.Automation.AsRunLog;

public class FileAsRunLogger : AsRunLogger
{
    private const string DateFormat = "yyyyMMdd";
    private const string HeaderText = "{\"AsRunLogEvents\": [ ";
    private const string FooterText = "]}";
    public const string DefaultLogFolder = "AsRunLogger";

    private readonly object _listLocker = new();
    private readonly object _fileLocker = new();
    private readonly bool _saveOnDemand;
    private readonly int _blankFileLength;
    private readonly int _offset;

    public string LogFile { get; init; }

    private ImmutableList<AsRunLogEvent> AsRunLogEvents { get; set; }

    public FileAsRunLogger(string path, string name = "FileAsRunLogger", string prefix = "", string postfix = "", string extension = "json", bool saveToFile = false) : base(name)
    {
        try
        {
            if (!Directory.Exists(path))
                Directory.CreateDirectory(path);
        }
        catch (Exception)
        {
            path = Path.Join(Directory.GetCurrentDirectory(), DefaultLogFolder);
        }

        if (string.IsNullOrEmpty(prefix))
            prefix = Name;

        string fileName = $"{prefix}_{DateTime.Now.ToString(DateFormat)}{postfix}.{extension}";
        LogFile = Path.Join(path, fileName);

        _saveOnDemand = saveToFile;

        _blankFileLength = HeaderText.Length + FooterText.Length + (Environment.NewLine.Length * 2);
        _offset = FooterText.Length + Environment.NewLine.Length;

        AsRunLogEvents = ImmutableList.Create<AsRunLogEvent>();

        CreateAsRunLogFile();
    }

    private void CreateAsRunLogFile()
    {
        if (File.Exists(LogFile))
            return;

        lock (_fileLocker)
        {
            using StreamWriter file = File.AppendText(LogFile);

            file.WriteLine(HeaderText);
            file.WriteLine(FooterText);
        }
    }

    protected override void Log(AsRunLogEvent asRunLogEvent)
    {
        lock (_listLocker)
        {
            AsRunLogEvents = AsRunLogEvents.Add(asRunLogEvent);
        }

        if (!_saveOnDemand)
        {
            Task.Run(() => SaveAsRunLog());
        }
    }

    public void SaveAsRunLog()
    {
        lock (_listLocker)
        {
            if (AsRunLogEvents.Count == 0)
                return;

            StringBuilder stringBuilder = new();

            if (IsEmptyLog(LogFile, _blankFileLength))
            {
                stringBuilder.Append(AsRunLogEvents[0].ToJson());
                AsRunLogEvents = AsRunLogEvents.RemoveAll(item => item == AsRunLogEvents[0]);
            }

            const string itemSeparator = ",";
            foreach (var message in AsRunLogEvents)
            {
                _ = stringBuilder.AppendLine(itemSeparator).Append(message.ToJson());
                AsRunLogEvents = AsRunLogEvents.RemoveAll(item => item == message);
            }

            stringBuilder.AppendLine().Append(FooterText);
            string log = stringBuilder.ToString();

            WriteLogToFile(log);
        }
    }

    private void WriteLogToFile(string log)
    {
        lock (_fileLocker)
        {
            using FileStream fs = new(LogFile, FileMode.Open, FileAccess.ReadWrite);

            fs.Seek(-_offset, SeekOrigin.End);
            byte[] buffer = Encoding.UTF8.GetBytes(log);

            fs.Write(buffer, 0, buffer.Length);
        }
    }

    private static bool IsEmptyLog(string logFile, int blankFileLength)
    {
        FileInfo file = new(logFile);
        return !file.Exists || file.Length <= blankFileLength;
    }
}