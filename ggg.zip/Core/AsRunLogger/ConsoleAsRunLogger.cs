﻿namespace Pebble.Oceans.Automation.AsRunLog;

public class ConsoleAsRunLogger : AsRunLogger
{
    public ConsoleAsRunLogger(string name = "ConsoleAsRunLogger") : base(name)
    {
    }

    protected override void Log(AsRunLogEvent asRunLogEvent)
    {
        Console.WriteLine($"[{asRunLogEvent.DeviceController} - AsRun]:{asRunLogEvent.ToJson()}");
    }
}