﻿namespace Pebble.Oceans.Automation.AsRunLog;

public class AsRunEventArgs : EventArgs
{
    public string EventType { get; set; }
    public DeviceListEvent DeviceListEvent { get; set; }
    public FrameAlignedTimestamp EventTime { get; set; }

    protected AsRunEventArgs(DeviceListEvent deviceListEvent, FrameAlignedTimestamp eventTime)
    {
        DeviceListEvent = deviceListEvent;
        EventTime = eventTime;
        EventType = "AsRunEvent";
    }
}

public class AsRunLogStartEventArgs : AsRunEventArgs
{
    public AsRunLogStartEventArgs(DeviceListEvent deviceListEvent, FrameAlignedTimestamp startTime) : base(deviceListEvent, startTime)
    {
        EventType = "Start";
    }
}

public class AsRunLogEndEventArgs : AsRunEventArgs
{
    public AsRunLogEndEventArgs(DeviceListEvent deviceListEvent, FrameAlignedTimestamp endTime) : base(deviceListEvent, endTime)
    {
        EventType = "End";
    }
}