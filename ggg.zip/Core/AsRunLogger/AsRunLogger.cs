﻿using Pebble.Oceans.Automation.Devices;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.AsRunLog;

public interface IAsRunLogger
{
    string Name { get; set; }

    void AsRunLogCreated(object source, AsRunEventArgs asRunEventArgs);
}

public abstract class AsRunLogger : IAsRunLogger
{
    public string Name { get; set; }
    public const string DateTimeFormat = "dd/MM/yyyy HH:mm:ss";

    protected AsRunLogger(string name = "AsRunLogger")
    {
        Name = name;
    }

    protected abstract void Log(AsRunLogEvent asRunLogEvent);

    public void AsRunLogCreated(object source, AsRunEventArgs asRunEventArgs)
    {
        string deviceController = asRunEventArgs.DeviceListEvent.MediaEvent.Device;
        AsRunLogEvent message = asRunEventArgs switch
        {
            AsRunLogStartEventArgs startArgs => new AsRunLogEvent
            (EventType: startArgs.EventType,
                DeviceController: deviceController,
                Id: $"{startArgs.DeviceListEvent.LinearListEvent.Parent.Id}#{startArgs.DeviceListEvent.LinearListEvent.Parent.MediaEvents.IndexOf(startArgs.DeviceListEvent.MediaEvent)}",

                Time: startArgs.EventTime.ToString(),
                MediaReference: startArgs.DeviceListEvent.MediaEvent.MediaReference,
                Track: startArgs.DeviceListEvent.MediaEvent.Track ?? string.Empty),

            AsRunLogEndEventArgs endArgs => new AsRunLogEvent
            (
                EventType: endArgs.EventType,
                DeviceController: deviceController,
                Id: $"{endArgs.DeviceListEvent.LinearListEvent.Parent.Id}#{endArgs.DeviceListEvent.LinearListEvent.Parent.MediaEvents.IndexOf(endArgs.DeviceListEvent.MediaEvent)}",
                Time: endArgs.EventTime.ToString(),
                MediaReference: endArgs.DeviceListEvent.MediaEvent.MediaReference,
                Track: endArgs.DeviceListEvent.MediaEvent.Track ?? string.Empty
            ),

            _ => throw new NotImplementedException($"{nameof(asRunEventArgs)} is not supported."),
        };

        Log(message);
    }
}

[GenerateSerialization]
public record AsRunLogEvent(string EventType, string DeviceController, string Id, string Time, string MediaReference, string Track);

public static class AsRunLogMessageHelper
{
    public static string ToJson(this AsRunLogEvent message)
    {
        return message.ToJsonString();
    }

    public static string ToYaml(this AsRunLogEvent message)
    {
        return message.ToYamlString();
    }
}

public enum AsRunLoggerType
{
    Console,
    File,
}