Test Schedule Framework 
  

Introduction
============

This document outlines the proposed design of the scheduling test framework. The framework will load scenario files which contains references to commands will be executed at specific points in time relative to the start time of the initial event in a playlist file. The following section describe the format of the scenario file along with the classes and data structures involved in the implementation.  

Scenario File
-------------
The format of the ScenarioFile will be:
```yaml
Scenario:
 Name: <name>
 InitialTime: <timecode>
 DisableFasterRealTime: <true/false> 
 StopOnError: <true/false> 
 DumpLevel: <dump level>
 Playlists: 
   - Name: <playlist name>
      Yaml: <yaml of playlist>
      Path: <path of playlist>
 Linearlists: 
   - Name: <linear list name>
      Path: <path of linear list>
 Commands:
    - Command: <command name>
       Time: <FrameAlignedTimeDifference>  
  ```

The structure of the file is that it contains references to one or more playlist files through either a Path or Yaml property and a reference name (‘PL1’), one or more Linear list references through a Path property and Name, and a list of commands. The ScenarioTestRunner will subscribe to the ClockSource onFrame handler and will look for Commands in its list with a matching FrameAlignedTimedifference property. Commands will refer to either play lists or linear lists through a Name reference and can define operations to be done on the linear list. Operations return an expected linear list to be compared with the Channel Schedule LinearListReference. The following is an example ScenarioFile:

```yaml
Name: End to End Scenario- Sequential Events only
InitialTime: 2021-10-04 10:00:00:00
DisableFasterRealTime: false
StopOnError: false
Playlists:
- Name: "PL1"
   Path: Playlists/SequentialEventsOnly.yaml
LinearLists:
- Name: "LL1"
   Path: LinearLists/SequentialEventsOnly.yaml
Commands:
- Time: 00:00:00:00
   Command: PlayListLoad
   Path: "PL1"
- Time: 00:00:00:00
  Command: TestLinearListShouldBe
  LinearList:
    Name: "LL1"
- Time: 00:00:30:00
  Command: TestLinearListShouldBe
  LinearList:
    Name: "LL1"
    Operations:
    - Operation: RemoveFirst
      Count: 1
- Time: 00:01:20:00
  Command: TestLinearListShouldBe
  LinearList:
    Name: "LL1"
    Operations:
    - Operation: RemoveFirst
      Count: 2
- Time: 00:10:00:00
   Command: TestLinearListShouldBeEmpty
```

  This example will perform the following steps:

| Time    | Command Action              | Description                                                                                                          |
|-------------|-----------------------------|----------------------------------------------------------------------------------------------------------------------|
| 00:00:00:00 | Playlistload                | Load the play list referenced by id PL1                                                                              |
| 00:00:00:00 | TestLinearListShouldBe      | Compare the current channel schedule linear list to that linear list referenced by LL1                               |
| 00:00:30:00 | TestLinearListShouldBe      | Compare the current channel schedule linear list to that referenced by LL1 after having removed the first event      |
| 00:01:20:00 | TestLinearListShouldBe      | Compare the current channel schedule linear list to that referenced by LL1 after having removed the first two events |
| 00:10:00:00 | TestLinearListShouldBeEmpty | Check that the current channel schedule linear list is empty                                                         |

Class Diagram
-------------

![Class Diagram](./images/class_diagram.png)

###   

### ScenarioTestRunner


The ScenarioTestRunner is the top level class involved in orchestrating the running of execution of scenario files. It will be given a directory or list of scenario files which it will deserialize into a list of ScenarioTest objects which it will then run. The ScenarioTestRunner also contains these properties:

*   ClockSource: Used to track the current timecode through subscribing to the on frame event
*   ILogger: Logging the sequence of steps carried out
*   Context: Class containing items related to the state of the scenario being tested. Includes the ChannelRunner and current ScenarioTest. The context is passed to each command in its Execute method
*   TestResults: A list of TestResult items based on the return value of the Execute call for each Command 

### ScenarioTest

ScenarioTests are deserialized from scenario files. They contain the following properties:

*    Name: the scenario test name
*    InitialTime: The initial time that the test is being set through the clocksource. This will be a FrameAlignedTimestamp
*    DisableFasterRealTime: Flag to disable faster than real time processing 
*    StopOnError: Flag to determine whether the first test failure should cause the run to      stop  
*    Enum that determines how much of the resulting comparison expected / current linear lists are saved  to file (i.e. None,All,ErrorOnly)  
*    A list of ScenarioPlaylists which can have either their Yaml property or Path property set and a AnchoredPlaylist property initialised by either property
*    A list of ScenarioLinearlists which having a Path property and a LinearListReference property

### ScenarioPlaylist

A ScenarioTest instance will have one more ScenarioPlaylist items through its Playlist property. They can be configured by either a file path or a serialized Yaml AnchoredPlaylist. The Playlist property will be set accordingly to which property (Path / Yaml) has been set.

### ScenarioLinearList

A ScenarioTest instance will have one more ScenarioLinearList items through its Linearlist property. The LinearlistReference will be set to a LinearlistReference type via the Path property.

### ScenarioCommands

A ScenarioTest instance will have one more ScenarioCommand items through its Commands property. There will be several subtypes of Commands which will carry out more specific actions.  Each command will have Initialise / Execute methods. Initialise is where each Command has the opportunity to check its properties and determine whether they are valid or throw an exception if the Command has been incorrectly configured. The Execute method will receive a Context instance containing the current ScenarioTest instance, allowing each Command to refer to the appropriate Playlist / LinearList item. 

### Operations

Specific derived Commands will have a list of one or more Operations configured. An Operation will have an Execute method which will perform specific actions in derived types, such as removing x amount of events from a LinearlistReference parameter and returning a new instance.

### Context

The ScenarioTestRunner maintains a Context object which contains the ChannelRunner and current ScenarioTest item. This is passed to each Commands Execute method.


