using Pebble.Oceans.Automation.Test.Framework;
using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using Pebble.Serialization;
using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Oceans.Automation.Test;

public class PlaylistSerialization
{
    private static string GetYamlScheduleName(string testName) => $"..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}.." +
                                                                  $"{Path.DirectorySeparatorChar}Playlist{Path.DirectorySeparatorChar}Data{Path.DirectorySeparatorChar}{testName}_Schedule.yaml";

    public static IEnumerable<object[]> GetTestCases()
        => SamplePlaylistCollection
            .Playlists
            .Where(p => File.Exists(GetYamlScheduleName(p.Name)))
            .Select(p => new object[] { p.Name! });

    private static string GetYaml(SamplePlaylist test)
        => File.ReadAllText(GetYamlScheduleName(test.Name));

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Serialization")]
    [MemberData(nameof(GetTestCases))]
    public void TestYamlSerialization(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);
        string yaml = GetYaml(test);

        test.Playlist.ToYamlString().RemoveCR().Should().Be(yaml.RemoveCR());
    }

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Serialization")]
    [MemberData(nameof(GetTestCases))]
    public void TestYamlDeserialization(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);
        var playlist = GetYaml(test).ToYaml().ToAnchoredPlaylist();

        // IMPORTANT: Without RespectingRuntimeTypes the comparison of polymorphic types happens on the abstract class level
        // and all the details get disregarded
        playlist.Should().BeEquivalentTo(test.Playlist, opts => opts.RespectingRuntimeTypes());
    }
}