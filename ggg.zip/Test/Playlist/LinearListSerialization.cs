using Pebble.Oceans.Automation.Test.Framework;
using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using Pebble.Serialization;
using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Service.Automation.Test;

public class LinearListSerialization
{
    private static string GetYamlName(string testName) => @$"..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}.." +
             $"{Path.DirectorySeparatorChar}Playlist{Path.DirectorySeparatorChar}Data{Path.DirectorySeparatorChar}{testName}_Linear.yaml";

    public static IEnumerable<object[]> GetTestCases()
        => SamplePlaylistCollection
            .Playlists
            .Where(p => File.Exists(GetYamlName(p.Name)))
            .Select(p => new object[] { p.Name! });

    private static string GetYaml(SamplePlaylist test)
        => File.ReadAllText(GetYamlName(test.Name));

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Serialization")]
    [MemberData(nameof(GetTestCases))]
    public void TestYamlSerialization(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);
        string yaml = GetYaml(test);

        test.LinearList?.ToYamlString().RemoveCR().Should().Be(yaml.RemoveCR());
    }

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Serialization")]
    [MemberData(nameof(GetTestCases))]
    public void TestYamlDeserialization(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);
        var linearList = GetYaml(test).ToYaml().ToReferenceLinearList();

        // IMPORTANT: Without RespectingRuntimeTypes the comparison of polymorphic types happens on the abstract class level
        // and all the details get disregarded
        linearList.Should().BeEquivalentTo(test.LinearList, opts => opts.RespectingRuntimeTypes());
    }
}