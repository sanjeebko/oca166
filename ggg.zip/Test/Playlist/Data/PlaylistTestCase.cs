﻿using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Oceans.Automation.Test.Playlist.Data
{
    public abstract class PlaylistTestCase
    {
        public abstract string YamlFileName { get; }
        public abstract AnchoredPlaylist Playlist { get; }
    }
}