﻿using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Processors;
using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Test.Playlist;

public class TestLinearListProcessor
{
    public static IEnumerable<object[]> GetTestCases()
        => SamplePlaylistCollection
            .Playlists
            .Where(x => x.LinearList is not null && x.DeviceList is not null)
            .Select(p => new object[] { p.Name! });

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Scheduling")]
    [MemberData(nameof(GetTestCases))]
    public void TestLinearToDeviceList(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);
        var playlistProcessor = new PlaylistProcessor(new(DeviceChainManifest.Default,
                                                          new LinearListConfiguration(
                                                              test.MaxLinearListSize,
                                                              FrameAlignedTimeDifference.Parse("48:00:00:00"))
                                                          , FrameAlignedTimeDifference.Parse("00:00:05:00")));
        var linearListProcessor = new LinearListProcessor(new DeviceConfig("Video", "Video&Audio", true, FrameAlignedTimeDifference.Zero, new("", "")));

        var linearList = playlistProcessor
            .Execute(
                test.Playlist.Playlist,
                test.Playlist.Anchor,
                test.Time,
                false)
            .LinearList;

        var deviceList = linearListProcessor.Execute(linearList).DeviceList.ToReference();

        string expectedFileName = @$"Compare\{testCase}.DeviceList.Expected.yaml";
        string calculatedFileName = @$"Compare\{testCase}.DeviceList.Calculated.yaml";
        Directory.CreateDirectory("Compare");
        File.Delete(calculatedFileName);
        File.Delete(expectedFileName);
        try
        {
            deviceList.Should().BeEquivalentTo(test.DeviceList, opts => opts.RespectingRuntimeTypes());
        }
        catch
        {
            File.WriteAllText(expectedFileName, test.DeviceList!.ToYamlString());
            File.WriteAllText(calculatedFileName, deviceList.ToYamlString());
            throw;
        }
    }
}