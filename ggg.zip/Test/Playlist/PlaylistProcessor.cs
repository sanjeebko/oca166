﻿using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Processors;
using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using Pebble.Oceans.Automation.Scheduling;
using System.Diagnostics;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;
using System;
using System.Collections.Immutable;

namespace Pebble.Oceans.Automation.Test.Playlist;

public class TestPlaylistProcessor
{
    private readonly PlaylistProcessor _playlistProcessor;

    public TestPlaylistProcessor()
    {
        _playlistProcessor = new PlaylistProcessor(new(
                 DeviceChainManifest.Default,
                 new(1000000, FrameAlignedTimeDifference.Parse("48:00:00:00")),
                 FrameAlignedTimeDifference.Parse("00:00:05:00")));
    }

    public static IEnumerable<object[]> GetTestCases()
        => SamplePlaylistCollection
            .Playlists
            .Where(x => x.LinearList is not null)
            .Select(p => new object[] { p.Name! });

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Scheduling")]
    [MemberData(nameof(GetTestCases))]
    public void TestComplexToLinear(string testCase)
    {
        var test = SamplePlaylistCollection.GetPlaylist(testCase);

        Stopwatch sw = Stopwatch.StartNew();

        var linearList = _playlistProcessor.Execute(
            test.Playlist.Playlist,
            test.Playlist.Anchor,
            test.Time,
            false).LinearList.ToReference();

        sw.Stop();
        string s = $"playlistProcessor.Execute took {sw.ElapsedMilliseconds}ms";

        string expectedFileName = @$"Compare\{testCase}.LinearList.Expected.yaml";
        string calculatedFileName = @$"Compare\{testCase}.LinearList.Calculated.yaml";
        Directory.CreateDirectory("Compare");
        File.Delete(calculatedFileName);
        File.Delete(expectedFileName);
        try
        {
            linearList.Should().BeEquivalentTo(test.LinearList, opts => opts.RespectingRuntimeTypes());
        }
        catch
        {
            File.WriteAllText(expectedFileName, test.LinearList!.ToYamlString());
            File.WriteAllText(calculatedFileName, linearList.ToYamlString());
            throw;
        }
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Scheduling")]
    public void WhenAnAnchoredPlaylistIsLoadedAndAnchorIsSetToSecondEvent_ThenTheLinearListShouldSkipFirstEvent()
    {
        var startTime = FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00"));
        var testPlaylist = GetPlaylistWithSequentialEvents(startTime);

        var currentEvent = testPlaylist.Playlist.Events.Skip(1).FirstOrDefault();
        var currentTime = startTime + FrameAlignedTimeDifference.Parse("00:00:30:00");
        Anchor anchor = new(
             currentEvent?.Id,
             currentTime,
             ImmutableArray<LoopCounter>.Empty,
             null);

        (LinearList linearList, _) = _playlistProcessor.Execute(testPlaylist.Playlist, anchor, currentTime, false);

        linearList.Events.OfType<ActiveLinearListEvent>().Count().Should().Be(testPlaylist.Playlist.Events.Length - 1, "Because linearlist should skip the first event.");
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Scheduling")]
    public void WhenAPlaylistIsLoadedAndNextItemIsLastEvent_ThenTheLinearListShouldContainLastEventOnly()
    {
        var startTime = FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00"));
        var testPlaylist = GetPlaylistWithSequentialEvents(startTime);

        Anchor anchor = new(null, null, ImmutableArray<LoopCounter>.Empty, testPlaylist.Playlist.Events.LastOrDefault()!.Id);

        (LinearList linearList, _) = _playlistProcessor.Execute(testPlaylist.Playlist, anchor, startTime, false);

        linearList.Events.OfType<ActiveLinearListEvent>().Count().Should().Be(1, "Because linearlist should contain only the last event.");

        testPlaylist.Playlist.Events.TakeLast(1)
            .Any(e => e.Id == linearList.Events
                                        .OfType<ActiveLinearListEvent>().FirstOrDefault(l => l.Parent.Id == e.Id)?.Parent.Id)
            .Should().BeTrue("because the only event available in the linearlist should match the last playlist event");
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Scheduling")]
    public void WhenAPlaylistIsLoadedAndAnchorNextEventIsSetToTheFirstEvent_ThenTheLinearListShouldContainAllEvents()
    {
        var startTime = FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00"));
        var testPlaylist = GetPlaylistWithSequentialEvents(startTime);

        Anchor anchor = testPlaylist.Anchor!;

        (LinearList linearList, _) = _playlistProcessor.Execute(testPlaylist.Playlist, anchor, startTime, false);

        testPlaylist.Playlist.Events
            .Any(e => e.Id == linearList.Events
                                        .OfType<ActiveLinearListEvent>().FirstOrDefault(l => l.Parent.Id == e.Id)?.Parent.Id)
            .Should().BeTrue("because linearlist should contains all the events from the playlist.");
    }

    private static AnchoredPlaylist GetPlaylistWithSequentialEvents(FrameAlignedTimestamp startTime)
    {
        SimplePlaylistGenerator _sampleBasicPlaylistGenerator = new(
            "BBC2",
            "Test Playlist",
            5,
            FrameAlignedTimeDifference.Parse("00:00:30:00"),
            false);
        return _sampleBasicPlaylistGenerator
            .GetSequentialEventsAnchoredPlaylist(startTime);
    }
}