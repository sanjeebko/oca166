﻿using Automation.Test.Framework;
using BenchmarkDotNet.Running;
using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Oceans.Automation.Test.Framework;
using Pebble.Oceans.Automation.Test.Framework.Benchmark;
using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using Pebble.Oceans.Automation.Test.Framework.Scenario;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;
using Pebble.Serialization;
using System;
using System.Collections.Immutable;
using System.Text;
using System.Threading.Tasks;
using Pebble.Oceans.Automation.Clock;
using Xunit.Sdk;

namespace Pebble.Oceans.Automation.Test;

public class GivenAChannel
{
    private const string TestPlaylistWithSkipEvents = "FixedEventMiddle_Overrun After 35 seconds";
    private const string TestPlaylistWithIdleEvents = "FixedEventMiddle_Underrun";
    private const string TestPlaylistWithSecondaries = "SequentialEventsWithSecondaries";
    private const string TestPlaylistSequentialEventsOnly = "SequentialEventsOnly";

    private const int TestTimeoutMs = 1000;
    private readonly ChannelRunner _channelRunner;
    private readonly AdjustAbleClockRunner _clockRunner;
    private readonly DirectoryInfo _resultsDirectory = new(Path.Combine(Directory.GetCurrentDirectory(), "Integration Tests Results"));

    private static LinearListConfiguration LinearListConfiguration =>
                 new(10000,
                  FrameAlignedTimeDifference.Parse("48:00:00:00"));

    private readonly DeviceChainManifest _deviceChainManifest =
                new("PresentationList Test",
                    new List<DeviceConfig> {
                        new("Video", "Video&Audio", true, new FrameAlignedTimeDifference(5), new DeviceConfigController("Dummy", "")),
                        new("Graphics", "Main Graphics", true, new FrameAlignedTimeDifference(8), new DeviceConfigController("Dummy", "")),
                        new("Graphics", "SD Graphics", true, new FrameAlignedTimeDifference(8), new DeviceConfigController("Dummy", "")),
                        new("Graphics", "HD Graphics", true, new FrameAlignedTimeDifference(8), new DeviceConfigController("Dummy", "")),
                        new("Subtitles", "DVB Subtitles", true, new FrameAlignedTimeDifference(8), new DeviceConfigController("Dummy", ""))
                    }.ToImmutableArray());

    public GivenAChannel()
    {
        ChannelConfiguration channelConfiguration = new(_deviceChainManifest,
        new LinearListConfiguration(10000,
        FrameAlignedTimeDifference.Parse("48:00:00:00")),
        FrameAlignedTimeDifference.Parse("00:00:05:00"));

        _channelRunner = new ChannelRunner(new ChannelContext(channelConfiguration));
        _clockRunner = new AdjustAbleClockRunner(new ClockSource(), _channelRunner);
    }

    [Theory]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Valid", "All")]
    [MemberData(nameof(GetTestCases))]
    public void WhenBasicSchedulingScenariosAreExecuted_ThenTheLinearListIsCorrect(string file)
    {
        var fullPath = Path.Join(Directory.GetCurrentDirectory(), ScenarioList.ScenarioFolder, file);
        var result = new ScenarioTestRunner(
            new ConsoleLogger(),
            new TestRunnerConfig(_resultsDirectory.FullName))
            .RunScenario(fullPath, LinearListConfiguration).ToList();

        ScenarioTest scenario = File.ReadAllText(fullPath).ToYaml().ToScenarioTest();

        scenario.Commands.Length.Should().Be(result.Count);

        if (result.Any(r => r.Failed))
        {
            MarkdownTableBuilder table = new();
            table.SetHeader("Time", "Test", "Pass/Fail", "Reason");
            foreach (TestRecord record in result)
                table.AddRow(
                    record.Command?.TimeCode.ToString() ?? string.Empty,
                    record.Command?.GetType().Name ?? string.Empty,
                    record.Result,
                    record.Error.Replace(Environment.NewLine, "; ")[..Math.Min(50, record.Error.Length)]);
            var failures = result.Where(r => r.Failed).ToArray();
            var output = new StringBuilder();
            if (failures.Length > 0)
                output.Append(failures.Length).Append(" test").Append(failures.Length > 1 ? "s" : string.Empty).Append(" ha").Append(failures.Length > 1 ? "ve" : "s").AppendLine(" failed");
            else
                output.AppendLine("All tests have passed");
            output.AppendLine(table.GetString());
            output.AppendLine();
            foreach (var failure in failures)
            {
                output.Append(failure.Command?.TimeCode).Append("  ").AppendLine(failure.Command?.Command);
                output.AppendLine(failure.Error);
            }
            throw new XunitException(output.ToString());
        }
    }

    [Fact]
    [Trait("TestType", "BenchmarkTest")]
    [Trait("Subdomain", "Benchmark-Scenario")]
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Blocker Code Smell", "S2699:Tests should include assertions", Justification = "Benchmark Test Runner is executed via XUnit but not as an integration test")]
    public void WhenBenchmarkRunnerIsCalled_ThenBenchmarkAllScenarios()
    {
        BenchmarkRunner
            .Run<BenchmarkedScenarioTestRunner>(BenchmarkConfigurationHelper
                                                .BenchmarkScenarioConfiguration);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "PresentationList")]
    public void WhenAPlaylistWithSecondariesIsLoaded_ThenThePresentationListShouldMatchExpected()
    {
        SamplePlaylist testPlayList = GetTestPlaylistWithSecondaries();
      
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitPresentationListReady().Wait(TestTimeoutMs);
        var firstId = testPlayList.Playlist.Playlist.Events.OfType<PlaylistEvent>()?.FirstOrDefault()?.Id;
        _channelRunner.Cue(firstId);
        WaitPresentationListReady().Wait(TestTimeoutMs);

        PresentationList expectedPresentationList = GetPresentationListFile(GetExpectedPresentationList(TestPlaylistWithSecondaries));

        PresentationList resultPresentationList = _channelRunner.PresentationList;

        resultPresentationList.Should().BeEquivalentTo(expectedPresentationList);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "PresentationList")]
    public void WhenAPlaylistWithIdleEventIsLoaded_ThenThePresentationListShouldContainIdleEvent()
    {
        SamplePlaylist testPlayList = GetTestPlaylistWithIdleEvents();
       
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitPresentationListReady().Wait(TestTimeoutMs);

        PresentationList expectedPresentationList = GetPresentationListFile(GetExpectedPresentationList(TestPlaylistWithIdleEvents));
        var expectedIdleEvents = expectedPresentationList.Items.OfType<PresentationListIdleEvent>();

        PresentationList resultPresentationList = _channelRunner.PresentationList;
        var resultIdleEvents = resultPresentationList.Items.OfType<PresentationListIdleEvent>();

        resultIdleEvents.Should().BeEquivalentTo(expectedIdleEvents);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "PresentationList")]
    public void WhenAPlaylistWithSkippedEventIsLoaded_ThenThePresentationListShouldContainSkippedEvent()
    {
        SamplePlaylist testPlayList = GetTestPlaylistWithSkipEvents();
      
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitPresentationListReady().Wait(TestTimeoutMs);

        PresentationList expectedPresentationList = GetPresentationListFile(GetExpectedPresentationList(TestPlaylistWithSkipEvents.Replace(" ", "")));

        var expectedSkippedEvents = expectedPresentationList.Items.OfType<PresentationListEvent>()
            .Where(p => string.Equals(p.State.Play.Status, "skipped", StringComparison.OrdinalIgnoreCase));

        PresentationList resultPresentationList = _channelRunner.PresentationList;

        var resultSkippedEvents = resultPresentationList.Items.OfType<PresentationListEvent>()
            .Where(p => string.Equals(p.State.Play.Status, "skipped", StringComparison.OrdinalIgnoreCase));
        resultSkippedEvents.Should().BeEquivalentTo(expectedSkippedEvents);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "ChannelState")]
    public void WhenCreated_ThenTheChannelStateIsUnCued()
    {
        _channelRunner.ChannelContext.ChannelStatus.Should().Be(ChannelStatus.Uncued);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "ChannelState")]
    [Trait("Subdomain", "LoadPlaylist")]
    public void WhenFirstPlaylistIsLoaded_ThenTheChannelStateIsUnCued()
    {
        SamplePlaylist testPlayList = GetTestPlaylistSequentialEventsOnly();
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.ChannelStatus.Should().Be(ChannelStatus.Uncued);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "LoadPlaylist")]
    public void WhenAPlaylistIsLoadedOnAnUncuedChannel_ThenTheAnchorPointShouldBeNull()
    {
        SamplePlaylist testPlayList = GetTestPlaylistSequentialEventsOnly();
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.Anchor.Should().BeNull();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "LoadPlaylist")]
    public void WhenAnAnchoredAPlaylistIsLoadedOnAnUncuedChannel_ThenTheAnchorPointShouldBeSet()
    {
        SamplePlaylist testPlayList = GetTestPlaylistSequentialEventsOnly();
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.Anchor.Should().NotBeNull();
        _channelRunner.ChannelContext.Anchor!.CurrentEventId.Should().NotBeNullOrEmpty();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "LoadPlaylist")]
    public void WhenAnAnchoredPlaylistIsLoadedOnAnUncuedChannel_ThenTheDeviceListShouldBeLoadedToTheListBundle()
    {
        SamplePlaylist testPlayList = GetTestPlaylistSequentialEventsOnly();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().NotBeEmpty();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    [Trait("Subdomain", "ChannelState")]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenTheChannelStateIsCued()
    {
        SamplePlaylist testPlayList = GetTestPlaylistSequentialEventsOnly();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlayList.Playlist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.ChannelStatus.Should().Be(ChannelStatus.Cued);
    }

    [Theory]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    [MemberData(nameof(GetNonGroupTestPlayLists))]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenCurrentEventIDInAnchorIsNull(string testCase)
    {
        var testPlayList = SamplePlaylistCollection.GetPlaylist(testCase);

        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();
       
        _clockRunner.UpdateTime(testPlayList.Playlist.Anchor!.StartTime!.Value);
        _channelRunner.LoadPlaylist(testPlayList.Playlist.Playlist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlayList.Playlist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.Anchor.Should().NotBeNull();
        _channelRunner.ChannelContext.Anchor!.CurrentEventId.Should().BeNull();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenNextEventIDInTheAnchorIsCalculated()
    {
        var testPlaylist = GetGeneratedTestPlaylist();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
     
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.Anchor.Should().NotBeNull();
        _channelRunner.ChannelContext.Anchor!.NextEventId.Should().NotBeNullOrEmpty();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenDeviceControllerReceivesDeviceListEvents()
    {
        var testPlaylist = GetGeneratedTestPlaylist();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
     
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.CurrentLists.LinearList.Events.Should().NotBeEmpty();

        var deviceEventCountMap = _channelRunner.ChannelContext.DeviceSchedulingBranches.Where(branch => branch.DeviceController.DeviceList.Events.Length > 0)
            .Select(branch => new { Name = branch.DeviceController.DeviceConfig.Role, Count = branch.DeviceController.DeviceList.Events.Length });
        deviceEventCountMap.Should().NotBeNull();
        _ = deviceEventCountMap.Any(d => d.Count > 0);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "UnCue")]
    public void WhenACuedChannelisUncued_ThenNextEventIdIsNull()
    {
        var testPlaylist = GetGeneratedTestPlaylist();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
      
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.ManualUncue();
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.Anchor?.NextEventId.Should().BeNull();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "UnCue")]
    public void WhenACuedChannelisUncued_ThenChannelStatusShouldBeUncued()
    {
        var testPlaylist = GetGeneratedTestPlaylist();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
      
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.FirstOrDefault()!.Id);
        WaitScheduleComplete().Wait(TestTimeoutMs);
        _channelRunner.ManualUncue();
        WaitScheduleComplete().Wait(TestTimeoutMs);

        _channelRunner.ChannelContext.ChannelStatus.Should().Be(ChannelStatus.Uncued);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    [Trait("Subdomain", "PresentationList")]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenAllTheDeviceListEventsAreCued()
    {
        var testPlaylist = GetGeneratedTestPlaylist();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
       
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitPresentationListReady().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.FirstOrDefault()!.Id);
        WaitPresentationListReady().Wait(TestTimeoutMs);

        var mediaEvents = _channelRunner.PresentationList.Items.OfType<PresentationListEvent>().SelectMany(p => p.MediaEvents);

        foreach (var deviceListStatus in mediaEvents.Select(e => e.DeviceListEvent?.State.Status))
        {
            deviceListStatus.Should().BeEquivalentTo(nameof(DeviceListPlayStatus.Cued));
        }
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("Subdomain", "Cue")]
    [Trait("Subdomain", "PresentationList")]
    public void WhenAnEventIsCuedOnAnUncuedChannel_ThenPrecedingEventsAreSkipped()
    {
        var testPlaylist = GetGeneratedTestPlaylist();
        _channelRunner.ChannelContext.CurrentLists.DeviceLists.Should().BeEmpty();

        _clockRunner.UpdateTime(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
       
        _channelRunner.LoadPlaylist(testPlaylist);
        WaitPresentationListReady().Wait(TestTimeoutMs);
        _channelRunner.Cue(testPlaylist.Playlist.Events.Skip(2).FirstOrDefault()?.Id);
        WaitPresentationListReady().Wait(TestTimeoutMs);

        var mediaEventsMap = _channelRunner.PresentationList.Items.OfType<PresentationListEvent>().Select(p => new { p.Id, p.MediaEvents });
        var mediaEvents = mediaEventsMap.OrderBy(m => m.Id).SelectMany(e => e.MediaEvents);
        var deviceListPlayStatus = mediaEvents.Select(m => m.DeviceListEvent?.State).ToArray();

        deviceListPlayStatus[0].Should().BeNull("because skipped mediaEvents do not have deviceListEvent");
        deviceListPlayStatus[1].Should().BeNull("because skipped mediaEvents do not have deviceListEvent");
        deviceListPlayStatus[2]!.Status.Should().BeEquivalentTo(nameof(DeviceListPlayStatus.Cued));
    }

    private Task WaitScheduleComplete()
    {
        TaskCompletionSource taskCompletionSource = new();
        _channelRunner.SchedulingFinished += (sender, e) => taskCompletionSource.TrySetResult();

        return taskCompletionSource.Task;
    }

    private Task WaitPresentationListReady()
    {
        TaskCompletionSource taskCompletionSource = new();
        _channelRunner.ChannelContext.PresentationListProvider.PresentationListReady += (sender, e) => taskCompletionSource.TrySetResult();

        return taskCompletionSource.Task;
    }

    public static IEnumerable<object[]> GetTestCases()
        => ScenarioList.FileNames().Select(file => new object[] { file });

    public static IEnumerable<object[]> GetNonGroupTestPlayLists()
    => SamplePlaylistCollection
            .Playlists
            .Where(p => !p.Playlist.Playlist.Events.OfType<PlaylistGroup>().Any()
                        && File.Exists(GetYamlScheduleName(p.Name)))
            .Select(p => new object[] { p.Name! });

    private static string GetYamlScheduleName(string testName) => $"..{Path.DirectorySeparatorChar}..{Path.DirectorySeparatorChar}.." +
                                                                      $"{Path.DirectorySeparatorChar}Playlist{Path.DirectorySeparatorChar}Data{Path.DirectorySeparatorChar}{testName}_Schedule.yaml";

    private static SamplePlaylist GetTestPlaylistWithSecondaries()
           => SamplePlaylistCollection.GetPlaylist(TestPlaylistWithSecondaries);

    private static SamplePlaylist GetTestPlaylistWithIdleEvents()
        => SamplePlaylistCollection.GetPlaylist(TestPlaylistWithIdleEvents);

    private static SamplePlaylist GetTestPlaylistWithSkipEvents()
                => SamplePlaylistCollection.GetPlaylist(TestPlaylistWithSkipEvents);

    private static string GetExpectedPresentationList(string name)
     => Path.Combine(Directory.GetCurrentDirectory(), "PresentationList", "Data", name + ".json");

    private static PresentationList GetPresentationListFile(string file)
    => File.ReadAllText(file).ToJson().ToPresentationList();

    private static SamplePlaylist GetTestPlaylistSequentialEventsOnly()
                => SamplePlaylistCollection.GetPlaylist(TestPlaylistSequentialEventsOnly);

    private static AnchoredPlaylist GetGeneratedTestPlaylist()
    {
        SimplePlaylistGenerator sampleBasicPlaylistGenerator = new(
            "BBC2",
            "Test Playlist",
            5,
            FrameAlignedTimeDifference.Parse("00:00:30:00"),
            false);

        return sampleBasicPlaylistGenerator
            .GetSequentialEventsAnchoredPlaylist(FrameAlignedTimestamp.Parse(DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss:00")));
    }
}