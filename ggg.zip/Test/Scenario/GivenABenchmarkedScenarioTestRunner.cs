﻿using Automation.Test.Framework;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;
using Pebble.Oceans.Automation.Test.Framework.Benchmark;

namespace Pebble.Oceans.Automation.Test.Scenario;

[Collection("Benchmark test")]
public class GivenABenchmarkedScenarioTestRunner
{
    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Benchmark-TestFramework")]
    public void WhenExecutedWithBenchmarkRunner_ThenSummaryIncludesResultForEachTest()
    {
        Summary summary = BenchmarkRunner
         .Run<BenchmarkedScenarioTestRunner>(BenchmarkConfigurationHelper
                                                .BenchmarkTestFrameworkConfiguration);
        summary.BenchmarksCases.Should().HaveCount(2);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Benchmark-TestFramework")]
    public void WhenBenchmarkRunnerIsCalled_ThenTheBenchmarkReportsSuccessAreReturned()
    {
        Summary summary = BenchmarkRunner
            .Run<BenchmarkedScenarioTestRunner>(BenchmarkConfigurationHelper
                                                .BenchmarkTestFrameworkConfiguration);

        summary.Reports.All(report => report.Success).Should().BeTrue();
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "Benchmark-TestFramework")]
    public void WhenBenchmarkRunnerIsCalled_ThenTheBenchmarkGeneratesExporterFiles()
    {
        DirectoryInfo directoryInfo = new(BenchmarkConfigurationHelper.TestArtifactsReportPath);
        if (directoryInfo.Exists)
        {
            directoryInfo.Delete(true);
        }
        Directory.CreateDirectory(BenchmarkConfigurationHelper.TestArtifactsReportPath);
        _ = BenchmarkRunner
            .Run<BenchmarkedScenarioTestRunner>(BenchmarkConfigurationHelper
                                                .BenchmarkTestFrameworkConfiguration);

        directoryInfo.Exists.Should().BeTrue();
        directoryInfo.GetFiles().Any(file => file.FullName.EndsWith(".json")).Should().BeTrue();
        directoryInfo.GetFiles().Any(file => file.FullName.EndsWith(".html")).Should().BeTrue();
    }
}