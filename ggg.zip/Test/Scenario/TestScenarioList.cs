﻿namespace Pebble.Service.Automation.Test;

public static class TestScenarioList
{
    private static readonly string RootPath = $"Scenario{Path.DirectorySeparatorChar}TestScenarioFiles{Path.DirectorySeparatorChar}";

    internal static string DumpAllFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}DumpAllScenario.yaml");
    }

    internal static string DumpErrorFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}DumpErrorsScenario.yaml");
    }

    internal static string StopOnErrorFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}DumpErrorsStopOnErrorScenario.yaml");
    }

    internal static string InvalidReferenceFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}InvalidReferenceScenario.yaml");
    }

    internal static string InvalidYamlFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), $@"{RootPath}InvalidYamlScenario.yaml");
    }

    internal static string SkipFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}SkipScenario.yaml");
    }

    internal static string FileReferencePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}FileReferencesScenario.yaml");
    }

    internal static string InvalidFileReferenceFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), @$"{RootPath}InvalidFileReferenceScenario.yaml");
    }

    internal static string AsRunLogWithErrorEventScenarioFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), $"{RootPath}AsRunLogWithErrorInEventScenario.yaml");
    }

    internal static string AsRunLogWithMultiDeviceAndTimeCodeScenarioFilePath()
    {
        return Path.Join(Directory.GetCurrentDirectory(), $"{RootPath}AsRunLogWithMultiDeviceAndTimeCodeScenario.yaml");
    }
}