﻿using Pebble.Oceans.Automation.Test.Framework.Scenario;
using Pebble.Serialization;
using Pebble.Service.Automation.Test;
using System.Collections.Immutable;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Oceans.Automation.Channel;
using Pebble.Logging;

namespace Pebble.Oceans.Automation.Test;

public class GivenAScenarioTestRunner
{
    private readonly DirectoryInfo _resultsDirectory = new(Path.Combine(Directory.GetCurrentDirectory(), "Integration Tests Results"));

    private static LinearListConfiguration LinearListConfiguration =>
                 new(10000,
                  FrameAlignedTimeDifference.Parse("48:00:00:00"));

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Dump", "All")]
    public void WhenRunScenarioIsCalledWithScenarioDumpSetToAll_ThenTheExpectedRecordsAreDumped()
    {
        var dumpAllFilesDirPath = Path.Join(_resultsDirectory.FullName, "DumpAllScenario");

        if (Directory.Exists(dumpAllFilesDirPath))
        {
            Directory.Delete(dumpAllFilesDirPath, true);
        }

        RunScenario(ImmutableArray.Create(TestScenarioList.DumpAllFilePath()));

        ScenarioTest dumpAllScenario = File.ReadAllText(TestScenarioList.DumpAllFilePath()).ToYaml().ToScenarioTest();

        IEnumerable<FileInfo> dumpScenarioFiles = _resultsDirectory.GetFiles("*.*", SearchOption.AllDirectories)
            .Where(f => f.DirectoryName!.Contains(dumpAllScenario.Name)).ToList();

        //files (expected and actual) should equal 2x number of commands except the playlist and the 'ShouldBeEmpty' command only dumps 1 file
        var expectedFilesCount = 2 * dumpAllScenario.Commands.Length - 3;
        dumpScenarioFiles.Count().Should().Be(expectedFilesCount, "Because the number of files should be the number of expected commands");

        var commandIds = dumpAllScenario.Commands.Select(c => c.Id).Skip(1).ToList(); //skip playlist command

        var commandFolders = dumpScenarioFiles.Select(f => f.Directory!.Name).Distinct();

        commandIds.Should().BeEquivalentTo(commandFolders, "Because the expected commands should be dumped to a matching folder");

        dumpScenarioFiles.Select(f => File.ReadAllText(f.FullName))
            .Select(c => c.ToYaml().ToReferenceLinearList())
            .Should().NotContainNulls("Because each dump file should contain a valid linear list");
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Dump", "Error")]
    public void WhenRunScenarioIsCalledWithScenarioDumpSetToError_ThenTheExpectedErrorRecordIsDumped()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.DumpErrorFilePath()));

        result.IsSuccess.Should().BeFalse();
        result.NumFailures.Should().Be(1);

        ScenarioTest dumpErrorScenario = File.ReadAllText(TestScenarioList.DumpErrorFilePath()).ToYaml().ToScenarioTest();

        IEnumerable<FileInfo> dumpScenarioFiles = _resultsDirectory.GetFiles("*.*", SearchOption.AllDirectories)
            .Where(f => f.DirectoryName!.Contains(dumpErrorScenario.Name)).ToList();

        var errorFolders = dumpScenarioFiles.Select(f => f.Directory!.Name).Distinct().ToList();

        errorFolders.Should().HaveCount(1, "Because only one command was in error");

        var failedRecord = result.Records.First(r => r.Result == TestResult.Fail);

        errorFolders.First().Should().Be(failedRecord.Id, "Because only the failed record should be dumped");
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Dump", "Error")]
    [Trait("StopOnError", "True")]
    public void WhenRunScenarioIsCalledWithStopOnErrorIsTrue_ThenTheRemainingScenarioAreNotRun()
    {
        var files = new List<string>
        {
            TestScenarioList.StopOnErrorFilePath(),
            TestScenarioList.DumpErrorFilePath()
        };

        var result = RunScenario(files.ToImmutableArray());

        ScenarioTest stopOnErrorScenario = File.ReadAllText(TestScenarioList.StopOnErrorFilePath()).ToYaml().ToScenarioTest();

        var stopOnErrorRecords = result.Records.Where(r => r.ScenarioName == "DumpErrorsStopOnErrorScenario");

        var numRecordNotRun = stopOnErrorRecords.Count(r => r.Result == TestResult.NotRun);
        numRecordNotRun.Should().Be(stopOnErrorScenario.Commands.Length - 2,
            "Because all except 2 of the stop on error scenario should not have run");
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    public void WhenRunScenarioIsCalledWithAnInvalidYamlScenarioFile_ThenNoResultsAreReturnedForThatScenario()
    {
        var files = new List<string>
        {
            TestScenarioList.InvalidYamlFilePath(),
            TestScenarioList.DumpErrorFilePath()
        };

        var result = RunScenario(files.ToImmutableArray());
        ScenarioTest dumpErrorScenario = File.ReadAllText(TestScenarioList.DumpErrorFilePath()).ToYaml().ToScenarioTest();
        result.Records.Count(t => t.ScenarioName == dumpErrorScenario.Name).Should().Be(dumpErrorScenario.Commands.Length,
            "Because the valid scenario file should have been processed");
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Valid", "Error")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatHasAnInvalidReference_ThenTheExpectedResultsAreReturned()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.InvalidReferenceFilePath()));

        result.NumFailures.Should().Be(1);

        var invalidScenario = result.Records.Where(r => r.ScenarioName == "InvalidScenario").ToList();

        invalidScenario.Count(r => r.Result == TestResult.Fail).Should().Be(1);
        invalidScenario.Count(r => r.Result == TestResult.NotRun).Should().Be(3);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("File", "false")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatHasAnInvalidFileReference_ThenTheExpectedResultIsReturned()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.InvalidFileReferenceFilePath()));

        result.IsSuccess.Should().BeFalse("Because the scenario contained an invalid file reference");
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("Skip", "true")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatIsIsMarkedAsSkip_ThenTheResultsAreNotRun()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.SkipFilePath()));
        result.Records.All(r => r.Result == TestResult.NotRun).Should().BeTrue();
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("File", "true")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatHasFileReferences_ThenTheScenarioPasses()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.FileReferencePath()));

        var errorList = result.Records.Select(result => result.Error).Where(error => !string.IsNullOrEmpty(error));
        errorList.Should().BeEmpty();
    }

    [Fact]
    [Trait("Subdomain", "AsRunLog")]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("File", "true")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatHasAsRunLogFileReferences_ThenTheScenarioPasses()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.AsRunLogWithMultiDeviceAndTimeCodeScenarioFilePath()));

        var errorList = result.Records.Select(result => result.Error).Where(error => !string.IsNullOrEmpty(error));
        errorList.Should().BeEmpty();
        result.Records.Length.Should().Be(4, "Because the scenario file has 4 commands");
    }

    [Fact]
    [Trait("Subdomain", "AsRunLog")]
    [Trait("TestType", "IntegrationTest")]
    [Trait("Subdomain", "ScenarioTestRunner")]
    [Trait("File", "true")]
    public void WhenRunScenarioIsCalledWithAScenarioFileThatHasAsRunLogMessageError_ThenTheExpectedFileIsCreated()
    {
        var result = RunScenario(ImmutableArray.Create(TestScenarioList.AsRunLogWithErrorEventScenarioFilePath()));

        var errorList = result.Records.Select(result => result.Error).Where(error => !string.IsNullOrEmpty(error));
        errorList.Should().NotBeEmpty("Because AsRunLog messages in Scenario file has an error on purpose.");
        foreach (AsRunLogTestRecord record in result.Records.Where(a => a is AsRunLogTestRecord))
        {
            File.Exists(record?.ExpectedAsRunLogFile).Should().BeTrue();
        }
    }

    private ScenarioTestResults RunScenario(ImmutableArray<string> files)
    {
        return new ScenarioTestRunner(new ConsoleLogger(), new TestRunnerConfig(_resultsDirectory.FullName)).RunScenarios(files, LinearListConfiguration);
    }

    static GivenAScenarioTestRunner()
    {
        LogManager.Initialize();
    }
}