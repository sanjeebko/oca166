# Automation Channel Service

The Automation Service provides Schedule Execution, Scheduling, Validation, and Device Control functionality for a single Channel Instance. It is assigned an Channel and activity by the Channel Control Service (still be to built).