﻿using System.Collections.Generic;
using System.Collections.Immutable;
using System.IO;
using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Serialization;
using Pebble.Shared.Time;

namespace Channel.Test;

internal static class TestUtils
{
    internal static ChannelRunner GetChannelRunner()
    {
        var deviceChainManifest = new DeviceChainManifest("Automation Web", new List<DeviceConfig>
        {
            new DeviceConfig(
                "Video",
                "Video&Audio",
                true,
                new(5),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "Main Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "SD Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "HD Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Subtitles",
                "DVB Subtitles",
                true,
                new(8),
                new(
                    "Dummy",""))
        }.ToImmutableArray());

        ChannelConfiguration channelConfiguration = new(deviceChainManifest,
            new LinearListConfiguration(10000,
                FrameAlignedTimeDifference.Parse("48:00:00:00")), FrameAlignedTimeDifference.Parse("00:00:05:00"));

        return new ChannelRunner(new ChannelContext(channelConfiguration));
    }

    internal static Playlist GetTestPlaylist()
    {
        var testPlaylist = File.ReadAllText(Path.Join(Directory.GetCurrentDirectory(),
            @$"TestFiles{Path.DirectorySeparatorChar}TestPlaylist.json"));

        return testPlaylist.ToJson().ToPlaylist();
    }
}