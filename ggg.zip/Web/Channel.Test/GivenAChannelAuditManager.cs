﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Automation.Channel.Web.AuditNotification;
using Automation.Channel.Web.Controllers;
using FluentAssertions;
using Microsoft.Extensions.Logging;
using Moq;
using PBS.Shared.Audit;
using Pebble.Oceans.Automation;

using Xunit;

namespace Channel.Test;

public class GivenAChannelAuditManager
{
    private readonly ChannelRunner _runner = TestUtils.GetChannelRunner();
    private readonly IChannelAuditManager _sut;
    private readonly int _timeOutMs = 2000;

    public GivenAChannelAuditManager()
    {
        _sut = new ChannelAuditManager(_runner, Mock.Of<ILogger<IChannelAuditManager>>());
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("ChannelAuditManager", "AuditNotification")]
    public void WhenAChannelPlaylistIsLoadedOnce_ThenAuditUpdateNotificationIsRaisedWithTheExpectedAudit()
    {
        var playlist = TestUtils.GetTestPlaylist();

        var are = new AutoResetEvent(false);

        string endpoint = $"api/1/automation/channels/{playlist.ChannelId}/status";
        AuditManagerEventArgs auditManagerEventArgs = new(new UpdateAuditOutputDTO(), endpoint);

        _sut.OnAuditUpdate += (sender, args) =>
        {
            are.Set();
            auditManagerEventArgs = args;
        };

        _runner.LoadPlaylist(playlist);

        var wasAuditNotificationRaised = are.WaitOne(timeout: TimeSpan.FromSeconds(1));

        wasAuditNotificationRaised.Should().BeTrue();
        auditManagerEventArgs.Should().NotBeNull();

        auditManagerEventArgs.AuditOutputDto.Type.Should().Be("insert");
        auditManagerEventArgs.Endpoint.Should().Be($"api/1/automation/channels/{playlist.ChannelId}/schedule");

        PresentationListDto? pl = auditManagerEventArgs.AuditOutputDto.Data as PresentationListDto;

        pl.Should().NotBeNull();
        pl!.Id.Should().Be(playlist.ChannelId);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("ChannelAuditManager", "AuditNotification")]
    public void WhenAChannelPlaylistIsLoadedTwice_ThenAuditUpdateNotificationIsRaisedWithTheExpectedAudit()
    {
        var playlist = TestUtils.GetTestPlaylist();

        _runner.LoadPlaylist(playlist);
        WaitPresentationListAuditManagerUpdateReady(_sut).Wait(_timeOutMs);

        _runner.LoadPlaylist(playlist);

        var task = WaitPresentationListAuditManagerUpdateReady(_sut);
        var wasAuditNotificationRaised = task.Wait(_timeOutMs);
        wasAuditNotificationRaised.Should().BeTrue();

        var auditManagerEventArgs = task.Result;

        auditManagerEventArgs.Should().NotBeNull();
        auditManagerEventArgs.Type.Should().Be("update");

        PresentationListDto? pl = auditManagerEventArgs.Data as PresentationListDto;

        pl.Should().NotBeNull();
        pl!.Id.Should().Be(playlist.ChannelId);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("ChannelAuditManager", "AuditNotification")]
    public void WhenAChannelIsCued_ThenAuditUpdateNotificationIsRaisedWithTheExpectedAuditForChannelState()
    {
        var playlist = TestUtils.GetTestPlaylist();

        _runner.LoadPlaylist(playlist);
        WaitPresentationListAuditManagerUpdateReady(_sut).Wait(_timeOutMs);

        var task = WaitChannelStateAuditManagerUpdateReady(_sut);
        _runner.Cue(null);

        var wasAuditNotificationRaised = task.Wait(_timeOutMs);
        wasAuditNotificationRaised.Should().BeTrue();

        var auditManagerEventArgs = task.Result;

        auditManagerEventArgs.Should().NotBeNull();
        auditManagerEventArgs.AuditOutputDto.Type.Should().Be("update");
        auditManagerEventArgs.Endpoint.Should().Be($"api/1/automation/channels/{playlist.ChannelId}/status");

        ChannelStatus? cs = null;
        if (auditManagerEventArgs.AuditOutputDto.Data is ChannelStateDto dto)
        {
            cs = dto.State.Status;
        }

        cs.Should().NotBeNull();
        cs!.Should().Be(ChannelStatus.Cued);
    }

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("ChannelAuditManager", "AuditNotification")]
    public void WhenACuedChannelIsPlaying_ThenAuditUpdateNotificationIsRaisedWithTheExpectedAuditForChannelState()
    {
        var playlist = TestUtils.GetTestPlaylist();

        _runner.LoadPlaylist(playlist);
        WaitPresentationListAuditManagerUpdateReady(_sut).Wait(_timeOutMs);

        _runner.Cue(null);
        WaitPresentationListAuditManagerUpdateReady(_sut).Wait(_timeOutMs);

        var task = WaitChannelStateAuditManagerUpdateReady(_sut);
        _runner.PlayNext();

        var wasAuditNotificationRaised = task.Wait(_timeOutMs);
        wasAuditNotificationRaised.Should().BeTrue();

        var auditManagerEventArgs = task.Result;

        auditManagerEventArgs.Should().NotBeNull();
        auditManagerEventArgs.AuditOutputDto.Type.Should().Be("update");
        auditManagerEventArgs.Endpoint.Should().Be($"api/1/automation/channels/{playlist.ChannelId}/status");

        ChannelStatus? cs = null;
        if (auditManagerEventArgs.AuditOutputDto.Data is ChannelStateDto dto)
        {
            cs = dto.State.Status;
        }

        cs.Should().NotBeNull();
        cs!.Should().Be(ChannelStatus.Playing);
    }

    private static Task<UpdateAuditOutputDTO> WaitPresentationListAuditManagerUpdateReady(IChannelAuditManager channelAuditManager)
    {
        TaskCompletionSource<UpdateAuditOutputDTO> taskCompletionSource = new();
        channelAuditManager.OnAuditUpdate += (sender, args) =>
        {
            if (args.AuditOutputDto.Data is PresentationListDto)
                taskCompletionSource.TrySetResult(args.AuditOutputDto);
        };

        return taskCompletionSource.Task;
    }

    private static Task<AuditManagerEventArgs> WaitChannelStateAuditManagerUpdateReady(IChannelAuditManager channelAuditManager)
    {
        TaskCompletionSource<AuditManagerEventArgs> taskCompletionSource = new();
        channelAuditManager.OnAuditUpdate += (sender, args) =>
        {
            if (args.AuditOutputDto.Data is ChannelStateDto)
                taskCompletionSource.TrySetResult(args);
        };

        return taskCompletionSource.Task;
    }
}