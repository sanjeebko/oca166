﻿using System.Collections.Immutable;
using System.Text.Json;
using Automation.Channel.Web.AuditNotification;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Moq;
using PBS.Shared.Audit;
using Pebble.Oceans.Automation.Scheduling;
using Xunit;

namespace Channel.Test;

public class GivenAAutomationChannelNotification
{
    private readonly UpdateAuditOutputDTO _auditOutputDto = new()
    {
        AuditId = 1,
        Type = "insert",
        Data = new PresentationList("A Channel Id", "BBC", ImmutableArray<PresentationListItem>.Empty)
    };

    [Fact]
    [Trait("TestType", "IntegrationTest")]
    [Trait("NotificationProvider", "AuditNotification")]
    public void WhenChannelAuditRaisesAnAuditNotificationEvent_ThenTheAuditEventIsQueuedWithTheExpectedAudit()
    {
        Mock<IChannelAuditManager> auditManagerMock = new();
        Mock<IQueueManager> queueManagerMock = new();

        var jsonOptions = Options.Create(new JsonOptions());

        _ = new NotificationProvider(auditManagerMock.Object,
            queueManagerMock.Object,
            Mock.Of<ILogger<NotificationProvider>>(),
            jsonOptions);

        const string endpoint = "api/1/automation/channels/bbc/schedule";
        AuditManagerEventArgs testAuditManagerEventArgs = new(_auditOutputDto, endpoint);

        var auditNotification = new AuditNotification(testAuditManagerEventArgs.Endpoint,
            new[] { testAuditManagerEventArgs.AuditOutputDto });

        string calledQueueMsg = string.Empty;

        queueManagerMock.Setup(q => q.SendToQueue(It.IsAny<string>()))
            .Callback((string s) => calledQueueMsg = s);

        auditManagerMock.Raise(a => a.OnAuditUpdate += null, testAuditManagerEventArgs);

        var expectedQueuedAuditJson = JsonSerializer.Serialize(auditNotification,
            jsonOptions.Value.JsonSerializerOptions);

        calledQueueMsg.Should().Be(expectedQueuedAuditJson);
    }
}