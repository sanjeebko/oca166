using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq;
using Automation.Channel.Web.Controllers;
using FluentAssertions;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Xunit;
using Moq;
using Pebble.Oceans.Automation.Scheduling;
using System.Threading;
using Automation.Channel.Web.AuditNotification;
using PBS.Shared.Audit;
using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.Clock;

namespace Channel.Test;

public class GivenAAutomationChannelController
{
    private readonly AutomationChannelController _sut;
    private readonly Mock<IChannelAuditManager> _auditManagerMock = new();

    private readonly UpdateAuditOutputDTO _testAuditOutputDto = new()
    {
        AuditId = 1,
        Data = new PresentationList("A channel", "Test", ImmutableArray<PresentationListItem>.Empty)
    };

    public GivenAAutomationChannelController()
    {
        _sut = new AutomationChannelController(Mock.Of<ILogger<AutomationChannelController>>(),
            TestUtils.GetChannelRunner(), _auditManagerMock.Object);
    }

    public static IEnumerable<object[]> TestPlaylistData =>
        new List<object[]>
        {
            new object[] { "", "BBC", ImmutableArray<PlaylistItem>.Empty },
            new object[] { "", "BBC", TestUtils.GetTestPlaylist().Events }
        };

    [Theory]
    [MemberData(nameof(TestPlaylistData))]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "GET")]
    public void WhenGetScheduleIsCalledWithAnInvalidPlaylist_ThenBadRequestIsReturned(string channelId, string name, ImmutableArray<PlaylistItem> events)
    {
        var result = _sut.AssignPlaylist(new Playlist(channelId, name, events));

        result.Should().BeOfType<BadRequestResult>();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "GET")]
    public void WhenGetScheduleIsCalledWithNoPlaylistLoaded_ThenAnEmptyListIsReturned()
    {
        var result = _sut.GetSchedule("0") as OkObjectResult;

        result.Should().BeOfType<OkObjectResult>();

        var presentationList = result!.Value as PresentationList;

        presentationList.Should().NotBeNull();

        presentationList!.Items.Length.Should().Be(0);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "GET")]
    public void WhenPostIsCalledWithASchedule_TheExpectedPresentationListIsReturnedWhenGetIsCalled()
    {
        var playlist = TestUtils.GetTestPlaylist();

        var postScheduleReturnResult = _sut.AssignPlaylist(playlist) as OkResult;

        postScheduleReturnResult.Should().BeOfType<OkResult>();

        Thread.Sleep(1000);

        var getScheduleResult = _sut.GetSchedule("0") as OkObjectResult;

        getScheduleResult.Should().NotBeNull();

        var presentationList = getScheduleResult!.Value as PresentationList;

        presentationList.Should().NotBeNull();

        presentationList!.Name.Should().Be(playlist.Name);
        presentationList.ChannelId.Should().Be(playlist.ChannelId);
        presentationList.Items.Length.Should().Be(playlist.Events.Length + 1); //include idle
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "GET")]
    [Trait("AutomationChannelController", "AUDIT")]
    public void WhenThereIsNoAuditAndGetAuditIsCalled_ThenAnEmptyListIsReturned()
    {
        var results = _sut.GetAllAudits("0") as OkObjectResult;

        results.Should().NotBeNull();

        var audits = results!.Value as IEnumerable<UpdateAuditOutputDTO>;
        audits.Should().BeEmpty();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "GET")]
    [Trait("AutomationChannelController", "AUDIT")]
    public void WhenThereIsAnAuditAndGetAuditIsCalled_ThenTheExpectedAuditIsReturned()
    {
        _auditManagerMock.Setup(a => a.GetAuditRecord()).Returns(_testAuditOutputDto);

        var results = _sut.GetAllAudits("0") as OkObjectResult;

        results.Should().NotBeNull();

        var audit = results!.Value as IEnumerable<UpdateAuditOutputDTO>;
        audit!.FirstOrDefault().Should().BeEquivalentTo(_testAuditOutputDto);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "CUE")]
    [Trait("AutomationChannelController", "NO PLAYLIST")]
    public void WhenThereIsNoPlaylistAndCueIsCalled_ThenABadRequestIsReturned()
    {
        var result = _sut.Cue("0", "1");
        result.Should().BeOfType<BadRequestResult>();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "CUE")]
    [Trait("AutomationChannelController", "INVALID EVENT ID")]
    public void WhenThereIsAPlaylistLoadedAndCueIsCalledWithAnInvalidEventId_ThenABadRequestIsReturned()
    {
        var playlist = TestUtils.GetTestPlaylist();

        _sut.AssignPlaylist(playlist);

        var result = _sut.Cue("0", "Invalid Id");
        result.Should().BeOfType<BadRequestResult>();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "CUE")]
    [Trait("AutomationChannelController", "INVALID EVENT ID")]
    public void WhenThereIsAPlaylistLoadedAndCueIsCalledWithAValidEventId_ThenTheCuedStatusIsReturned()
    {
        var playlist = TestUtils.GetTestPlaylist();
        _sut.AssignPlaylist(playlist);

        var result = _sut.Cue("0", playlist.Events[0].Id) as OkObjectResult;
        var channelState = GetStateFromOkObjectResult(result);

        channelState.Should().NotBeNull();

        channelState!.State.Status.Should().Be(ChannelStatus.Cued);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "UNCUE")]
    [Trait("AutomationChannelController", "NO PLAYLIST")]
    public void WhenThereIsNoPlaylistLoadedAndUncueIsCalled_ThenABadRequestIsReturned()
    {
        var result = _sut.Uncue("0");
        result.Should().BeOfType<BadRequestResult>();
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "UNCUE")]
    [Trait("AutomationChannelController", "NO PLAYLIST")]
    public void WhenTheChannelIsUncuedAndUncueIsCalled_ThenTheUnCuedStatusIsReturned()
    {
        _sut.AssignPlaylist(TestUtils.GetTestPlaylist());

        var result = _sut.Uncue("0") as OkObjectResult;

        result.Should().NotBeNull();

        var channelState = GetStateFromOkObjectResult(result);

        channelState.Should().NotBeNull();

        channelState!.State.Status.Should().Be(ChannelStatus.Uncued);
    }

    [Fact]
    [Trait("TestType", "UnitTest")]
    [Trait("AutomationChannelController", "POST")]
    [Trait("AutomationChannelController", "UNCUE")]
    public void WhenAChannelIsCuedAndUncueIsCalled_ThenTheUnCuedStatusIsReturned()
    {
        var playlist = TestUtils.GetTestPlaylist();
        _sut.AssignPlaylist(playlist);

        _sut.Cue("0", playlist.Events[0].Id);
        var result = _sut.Uncue("0") as OkObjectResult;

        result.Should().NotBeNull();

        var channelState = GetStateFromOkObjectResult(result);

        channelState.Should().NotBeNull();

        channelState!.State.Status.Should().Be(ChannelStatus.Uncued);
    }

    private static ChannelStateDto? GetStateFromOkObjectResult(OkObjectResult? result) =>
        result?.Value as ChannelStateDto ?? null;
}