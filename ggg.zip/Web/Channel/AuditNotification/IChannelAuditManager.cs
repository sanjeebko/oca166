﻿using PBS.Shared.Audit;

namespace Automation.Channel.Web.AuditNotification;

public interface IChannelAuditManager
{
    event EventHandler<AuditManagerEventArgs> OnAuditUpdate;
    UpdateAuditOutputDTO? GetAuditRecord();
}