﻿using Automation.Channel.Web.Controllers;
using PBS.Shared.Audit;
using PBS.Shared.Audit.DataLayer;
using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Serialization.Generator;
using System.Collections.Immutable;

namespace Automation.Channel.Web.AuditNotification;

public class ChannelAuditManager : IChannelAuditManager
{
    private readonly ILogger<IChannelAuditManager> _logger;
    private readonly ChannelRunner _channelRunner;
    private UpdateAuditOutputDTO? _auditOutputDtO;

    public ChannelAuditManager(ChannelRunner channelRunner, ILogger<IChannelAuditManager> logger)
    {
        _logger = logger;
        _channelRunner = channelRunner;
        _channelRunner.ChannelContext.PresentationListProvider.PresentationListReady += PresentationListProvider_PresentationListReady;
        _channelRunner.ChannelContext.ChannelStatusChanged += ChannelContext_ChannelStatusChanged;
    }

    public event EventHandler<AuditManagerEventArgs>? OnAuditUpdate;

    public UpdateAuditOutputDTO? GetAuditRecord()
    {
        return _auditOutputDtO;
    }

    private void ChannelContext_ChannelStatusChanged(object? sender, ChannelStateEventArgs e)
    {
        var auditOutputDto = new UpdateAuditOutputDTO
        {
            Type = "update",
            AuditId = e.TimeStamp.FrameCount,
            Data = new ChannelStateDto(_channelRunner.ChannelContext.CurrentPlaylist.ChannelId, e.ChannelState),
            ItemId = "0"
        };

        _auditOutputDtO = auditOutputDto;
        var endpoint = $"api/1/automation/channels/{_channelRunner.ChannelContext.CurrentPlaylist.ChannelId}/status";
        OnAuditUpdate?.Invoke(this, new AuditManagerEventArgs(auditOutputDto, endpoint));
    }

    private void PresentationListProvider_PresentationListReady(object? sender, PresentationListEventArgs e)
    {
        var presentationList = _channelRunner.PresentationList;
        _logger.LogInformation("Creating audit record for channel id {Channel Id} name {Channel Name}", presentationList.ChannelId, presentationList.Name);

        var auditOutputDto = new UpdateAuditOutputDTO
        {
            Type = _auditOutputDtO is null ? "insert" : "update",
            AuditId = e.TimeStamp.FrameCount,
            Data = new PresentationListDto(presentationList.ChannelId, presentationList.Name, presentationList.Items),
            ItemId = "0"
        };

        _auditOutputDtO = auditOutputDto;
        var endpoint = $"api/1/automation/channels/{_channelRunner.ChannelContext.CurrentPlaylist.ChannelId}/schedule";
        OnAuditUpdate?.Invoke(this, new AuditManagerEventArgs(auditOutputDto, endpoint));
    }
}

public class AuditManagerEventArgs : EventArgs
{
    public AuditManagerEventArgs(UpdateAuditOutputDTO updateAuditOutput, string endpoint)
    {
        AuditOutputDto = updateAuditOutput;
        Endpoint = endpoint;
    }

    public UpdateAuditOutputDTO AuditOutputDto { get; }

    public string Endpoint { get; }
}

[GenerateSerialization]
public record PresentationListDto() : IIdTypeDTO
{
    public string Id { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public ImmutableArray<PresentationListItem> Items { get; set; }

    public PresentationListDto(string id, string name, ImmutableArray<PresentationListItem> items) : this()
    {
        Id = id;
        Name = name;
        Items = items;
    }
}