﻿
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using PBS.Shared.Audit;

namespace Automation.Channel.Web.AuditNotification;

public class NotificationProvider
{
    private readonly IQueueManager _queueManager;
    private readonly ILogger<NotificationProvider> _logger;
    private readonly JsonSerializerOptions _jsonOptions;

    public NotificationProvider(IChannelAuditManager channelAuditManager,
        IQueueManager queueManager, 
        ILogger<NotificationProvider> logger,
        IOptions<JsonOptions> jsonOptions)
    {
        _queueManager = queueManager;
        _logger = logger;
        _jsonOptions = jsonOptions.Value.JsonSerializerOptions;
        channelAuditManager.OnAuditUpdate += ChannelAuditManagerOnChannelAuditUpdate;
    }
    
    private void ChannelAuditManagerOnChannelAuditUpdate(object? sender, AuditManagerEventArgs e)
    {
        _logger.LogInformation("Posting notification for audit record {Audit Id}",e.AuditOutputDto.AuditId);

        SendNotifications(new[]
            {new PBS.Shared.Audit.AuditNotification(e.Endpoint, new List<UpdateAuditOutputDTO> {e.AuditOutputDto})});
    }

    private void SendNotifications(IEnumerable<PBS.Shared.Audit.AuditNotification> notifications)
    {
        foreach (var notification in notifications)
        {
            var message = JsonSerializer.Serialize(notification, _jsonOptions);
            _queueManager.SendToQueue(message);
        }
    }
}