using System.Text.Json.Serialization;
using Automation.Channel.Web;
using Automation.Channel.Web.Extensions;
using PBS.Shared.Configuration;
using PBS.Shared.Logging.NLogExtensions;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddAutomationChannelServices();

builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.Converters.Add(new Converter());
    options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
});

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Host.ConfigureDefaultAppConfiguration(args);
builder.Host.UsePBSNLog("Automation Channel Service");

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

Host.CreateDefaultBuilder(args)
    .ConfigureHostConfiguration(hostConfig =>
    {
    });

app.UseAuthorization();

app.MapControllers();

app.Run();