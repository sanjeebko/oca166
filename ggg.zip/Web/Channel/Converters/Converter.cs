﻿using Pebble.Serialization;
using System.Text.Json;

namespace Automation.Channel.Web;

public class Converter : System.Text.Json.Serialization.JsonConverter<object>
{
    public override bool CanConvert(Type typeToConvert)
    {
        if (typeToConvert is null)
            throw new ArgumentNullException(nameof(typeToConvert));
        return JsonSerializationHelper.CanSerialize(typeToConvert);
    }

    public override object Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        => JsonDocument.ParseValue(ref reader).RootElement.ToString().ToJson().To(typeToConvert);

    public override void Write(Utf8JsonWriter writer, object value, JsonSerializerOptions options)
    {
        string json = JsonSerializationHelper.ToJsonValue(value, value.GetType()).ToString();
        JsonDocument.Parse(json).WriteTo(writer);
    }
}