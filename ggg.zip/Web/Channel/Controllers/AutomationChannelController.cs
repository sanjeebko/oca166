using System.Collections.Immutable;
using Automation.Channel.Web.AuditNotification;
using Microsoft.AspNetCore.Mvc;
using PBS.Shared.Audit;
using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.Scheduling;

namespace Automation.Channel.Web.Controllers;

[ApiController]
[Route("api/1/automation")]
[ApiVersion(BaseVersion)]
public class AutomationChannelController : ControllerBase
{
    private const string BaseVersion = "1.0";

    private readonly ILogger<AutomationChannelController> _logger;
    private readonly ChannelRunner _channelRunner;
    private readonly IChannelAuditManager _auditManager;

    public AutomationChannelController(ILogger<AutomationChannelController> logger,
        ChannelRunner channelRunner,
        IChannelAuditManager auditManager)
    {
        _logger = logger;
        _channelRunner = channelRunner;
        _auditManager = auditManager;
    }

    [HttpGet("healthCheck")]
    public IActionResult HealthCheck()
    {
        _logger.LogInformation("Health check called");
        return Ok();
    }

    [HttpGet("channels/{channelId}/schedule")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult GetSchedule([FromRoute] string channelId)
    {
        _logger.LogInformation("Get schedule called");

        return new OkObjectResult(_channelRunner.PresentationList);
    }

    [HttpPost("channels/{channelId}/schedule")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult AssignPlaylist([FromBody] Playlist playlist)
    {
        if (string.IsNullOrEmpty(playlist.ChannelId) || playlist.Events.Length == 0)
        {
            return new BadRequestResult();
        }

        _logger.LogInformation("POST schedule called");
        _channelRunner.LoadPlaylist(playlist);

        return Ok();
    }

    [HttpGet("channels/{channelId}/schedule/audit")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult GetAllAudits([FromRoute] string channelId)
    {
        return GetMissedAudits(channelId, 0);
    }

    [HttpGet("/channels/{channelId}/schedule/audit/{auditId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status500InternalServerError)]
    public IActionResult GetMissedAudits([FromRoute] string channelId, [FromRoute] long auditId)
    {
        var audit = _auditManager.GetAuditRecord();

        var list = audit is not null ? ImmutableArray.Create(audit) :
            ImmutableArray<UpdateAuditOutputDTO>.Empty;

        return new OkObjectResult(list);
    }

    [HttpPost("channels/{channelId}/cue/{eventId}")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult Cue([FromRoute] string channelId, [FromRoute] string eventId)
    {
        try
        {
            _logger.LogInformation("Channel Cue called for {Channel Id} to {Event Id}", channelId, eventId);

            _channelRunner.Cue(eventId);

            return new OkObjectResult(GetChannelStateDto(channelId));
        }
        catch
        {
            return new BadRequestResult();
        }
    }

    [HttpPost("channels/{channelId}/uncue")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    [ProducesResponseType(StatusCodes.Status400BadRequest)]
    public IActionResult Uncue([FromRoute] string channelId)
    {
        try
        {
            _logger.LogInformation("Channel uncue called for {Channel Id}", channelId);

            _channelRunner.ManualUncue();

            return new OkObjectResult(GetChannelStateDto(channelId));
        }
        catch
        {
            return new BadRequestResult();
        }
    }

    [HttpPost("channels/{channelId}/playnext")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult PlayNext([FromRoute] string channelId)
    {
        _logger.LogInformation("Channel playnext called for {Channel Id}", channelId);

        _channelRunner.PlayNext();

        return new OkResult();
    }

    [HttpGet("channels/{channelId}/status")]
    [ProducesResponseType(StatusCodes.Status200OK)]
    public IActionResult Status([FromRoute] string channelId)
    {
        _logger.LogInformation("Channel ChannelStatus called for {Channel Id}", channelId);

        return new OkObjectResult(new ChannelStateDto(channelId, _channelRunner.ChannelContext.ChannelStatus));
    }

    private ChannelStateDto GetChannelStateDto(string channelId) =>
        new(channelId, _channelRunner.ChannelState);
}