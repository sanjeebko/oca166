﻿using Automation.Channel.Web.AuditNotification;

namespace Automation.Channel.Web;

public sealed class NotificationHostedService : BackgroundService
{
    /// <summary>
    /// Service to bootstrap the <see cref="NotificationProvider"/> so that it can register its event handler
    /// </summary>
    /// <param name="provider"></param>
    public NotificationHostedService(NotificationProvider provider)
    {
            
    }

    protected override Task ExecuteAsync(CancellationToken stoppingToken)
    {
        return Task.CompletedTask;
    }
}