﻿using System.Collections.Immutable;
using Automation.Channel.Web.AuditNotification;
using PBS.Shared.Audit;
using PBS.Shared.Configuration;
using PBS.Shared.MessageQueue.RabbitMQ;
using Pebble.Oceans.Automation;
using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Clock;
using Pebble.Oceans.Automation.Devices;
using Pebble.Shared.Time;

namespace Automation.Channel.Web.Extensions;

public static class ServiceExtensions
{
    public static IServiceCollection AddAutomationChannelServices(this IServiceCollection services)
    {
        var channelRunner = GetChannelRunner();
        var clockRunner = new ClockRunner(new ClockSource(), channelRunner);
        clockRunner.Start();

        services.AddSingleton(channelRunner);
        services.AddSingleton<IQueueManager, QueueManager>();
        services.AddSingleton<NotificationProvider>();
        services.AddSingleton<IChannelAuditManager, ChannelAuditManager>();
        services.AddPBSConfigurationManager();
        services.AddRabbitMQ();
        services.AddHostedService<NotificationHostedService>();

        return services;
    }
    
    private static ChannelRunner GetChannelRunner()
    {
        var deviceChainManifest = new DeviceChainManifest("Automation Web", new List<DeviceConfig>
        {
            new DeviceConfig(
                "Video",
                "Video&Audio",
                true,
                new(5),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "Main Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "SD Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Graphics",
                "HD Graphics",
                true,
                new(8),
                new(
                    "Dummy","")),
            new DeviceConfig(
                "Subtitles",
                "DVB Subtitles",
                true,
                new(8),
                new(
                    "Dummy",""))
        }.ToImmutableArray());

        ChannelConfiguration channelConfiguration = new(deviceChainManifest,
            new LinearListConfiguration(10000,
                FrameAlignedTimeDifference.Parse("48:00:00:00")),
            FrameAlignedTimeDifference.Parse("00:00:05:00"));

        var runner = new ChannelRunner(new ChannelContext(channelConfiguration))
        {
            StopOnEmptyLinearList = false
        };
        return runner;
    }
}