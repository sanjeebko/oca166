﻿using PBS.Shared.Audit.DataLayer;
using Pebble.Oceans.Automation;
using Pebble.Serialization.Generator;

namespace Automation.Channel.Web.Controllers;

[GenerateSerialization]
public record ChannelStateDto() : IIdTypeDTO
{
    public ChannelState State { get; set; } = ChannelState.Empty();

    public string Id { get; set; } = string.Empty;

    public ChannelStateDto(string id, ChannelStatus status) : this()
    {
        Id = id;
        State = new ChannelState(status);
    }
}

public record ChannelState(ChannelStatus Status)
{
    public static ChannelState Empty() => new(ChannelStatus.Uncued);
}