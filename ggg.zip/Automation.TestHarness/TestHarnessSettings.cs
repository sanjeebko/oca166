﻿using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.TestHarness;

[GenerateSerialization]
public record TestHarnessSettings(
    ListDumpFormat ListDumpFormat, 
    SaveOutputFileFormat SaveOutputFormat,
    string SaveLocation,
    AsRunLoggerType AsRunLogger)
{
    public static TestHarnessSettings Default { get; } 
        = new TestHarnessSettings(
            ListDumpFormat.Markdown,
            SaveOutputFileFormat.yaml,
            "Save",
            AsRunLoggerType.Console);
}