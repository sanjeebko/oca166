﻿using Pebble.Oceans.Automation.TestHarness.Commands;

namespace Pebble.Oceans.Automation.TestHarness;

public class PlaylistCollection : FileCollection
{
    public PlaylistCollection() : base("Playlists")
    {
    }
}