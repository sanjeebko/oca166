﻿using System.Text.RegularExpressions;
using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class DisplayPresentationList : Command
{
    public override string Name => "DisplayPresentationList|dpl";

    public override string Description => "Shows the current Presentation List in selected formatting";

    public override Regex Regex => new(@"^(?>DisplayPresentationList|dpl)(\s+(?'value'.+))?$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        var match = Regex.Match(commandLine);
        Execute(context, match.Groups["value"].Value);
    }

    public static void Execute(TestHarness context, string? format)
    {
        if (format is not null)
        {
            Set setCommand = new();
            setCommand.Execute($"set ListDumpFormat {format}", context);
        }

        if (context.Settings.ListDumpFormat == ListDumpFormat.Off)
            return;

        Console.WriteLine($"{Esc.BrightYellowFG}Presentation List{Esc.Reset}:");

        switch (context.Settings.ListDumpFormat)
        {
            case ListDumpFormat.Json:
                Console.WriteLine(context.ChannelRunner.PresentationList.ToJsonString());
                break;

            case ListDumpFormat.Yaml:
                Console.WriteLine(context.ChannelRunner.PresentationList.ToYamlString());
                break;

            case ListDumpFormat.Markdown:
                Console.WriteLine(string.Join("\r\n", context.ChannelRunner.PresentationList.ToMarkDown()));
                break;
        }
    }
}