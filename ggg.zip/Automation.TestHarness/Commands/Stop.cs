﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Stop : Command
{
    public override string Name => "Stop";

    public override string Description => "Stops the clock";

    public override Regex Regex => new("^stop", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.ClockRunner.Stop();
        context.OutputLine("Clock stopped");
    }
}
