﻿using Pebble.Oceans.Automation.Scheduling;
using Pebble.Serialization;
using Pebble.Shared.Time;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class LoadPlaylist : Command
{
    public override string Name => "LoadPlaylist|lp";

    public override string Description => "Loads the playlist and passes it to the channel runner";

    public override Regex Regex => new(@"^(?>LoadPlaylist|lp)\s+(.+)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        string filename = GetParams(commandLine).First();
        if (int.TryParse(filename, out int index) && context.Playlists.FileLists.TryGetValue(index, out string? s))
            filename = s!;
        if (!filename.Contains('\\'))
            filename = $@"{context.Playlists.FolderName}\{filename}";
        if (!filename.EndsWith(".yaml"))
            filename += ".yaml";
        if (!File.Exists(filename))
            context.OutputLine($"File {filename} doesn't exist");
        else
        {
            context.OutputLine($"Loading the playlist from {filename}");

            AnchoredPlaylist anchoredPlaylist = File.ReadAllText(filename)
                                       .ToYaml()
                                       .ToAnchoredPlaylist();
            if (anchoredPlaylist.Anchor?.StartTime is not null)
                context.ClockRunner.UpdateTime((FrameAlignedTimestamp)anchoredPlaylist.Anchor.StartTime);

            context.ChannelRunner.LoadPlaylist(anchoredPlaylist);
        }
    }
}