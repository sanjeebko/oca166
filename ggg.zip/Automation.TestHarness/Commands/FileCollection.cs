﻿using System.Collections;

namespace Pebble.Oceans.Automation.TestHarness.Commands
{
    public abstract class FileCollection : IEnumerable<KeyValuePair<int, string>>
    {
        protected FileCollection(string folderName)
        {
            FolderName = folderName;
            Refresh();
        }

        public string FolderName { get; }

        public ImmutableDictionary<int, string> FileLists { get; private set; } = ImmutableDictionary<int, string>.Empty;

        public IEnumerator<KeyValuePair<int, string>> GetEnumerator() => FileLists.GetEnumerator();

        IEnumerator IEnumerable.GetEnumerator() => FileLists.GetEnumerator();

        public void Refresh()
        {
            if (!Directory.Exists(FolderName))
                Directory.CreateDirectory(FolderName);
            int index = 1;
            FileLists = Directory.GetFiles(FolderName)
                .Where(f => Path.GetExtension(f).Equals(".yaml", StringComparison.OrdinalIgnoreCase))
                .ToImmutableDictionary(_ => index++);
        }

        public int Count => FileLists.Count;
    }
}
