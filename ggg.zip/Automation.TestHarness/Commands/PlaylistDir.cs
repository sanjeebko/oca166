﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class PlaylistDir : Command
{
    public override string Name => "Dir-p";

    public override string Description => "List the playlists in the playlist folder";

    public override Regex Regex => new(@"^dir-p$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.Playlists.Refresh();
        if (context.Playlists.Count == 0)
            context.OutputLine("No playlists found");
        else
            foreach (var playlist in context.Playlists)
                context.OutputLine($"{Esc.BrightYellowFG}#{playlist.Key}{Esc.Reset} - {playlist.Value}");
    }
}