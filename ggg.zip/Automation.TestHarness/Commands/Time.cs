﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Time : Command
{
    public override string Name => "Time";

    public override string Description => "Displays the current time";

    public override Regex Regex => new("^time$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context) 
        => context.OutputLine($"{Esc.YellowFG}{context.ChannelRunner.Time}{Esc.Reset}");
}
