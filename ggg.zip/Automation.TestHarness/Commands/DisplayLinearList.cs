﻿using System.Text.RegularExpressions;
using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class DisplayLinearList : Command
{
    public override string Name => "DisplayLinearList|ll";

    public override string Description => "Shows the current linear list in selected formatting";

    public override Regex Regex => new(@"^(?>DisplayLinearList|ll)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        Execute(context);
    }

    public static void Execute(TestHarness context)
    {
        if (context.Settings.ListDumpFormat == ListDumpFormat.Off)
            return;

        DisplayAnchorPoint(context);

        context.OutputLine($"{Esc.BrightYellowFG}LinearList{Esc.Reset}:");

        switch (context.Settings.ListDumpFormat)
        {
            case ListDumpFormat.Json:

                context.OutputLine(context.ChannelRunner.LinearList.ToReference().ToJsonString());
                break;

            case ListDumpFormat.Yaml:
                context.OutputLine(context.ChannelRunner.LinearList.ToReference().ToYamlString());
                break;

            case ListDumpFormat.Markdown:
                foreach (string line in context.ChannelRunner.LinearList.ToMarkDown(context.ChannelRunner.CurrentLists.Errors))
                    context.OutputLine(line);
                break;
        }
    }

    private static void DisplayAnchorPoint(TestHarness context)
    {
        if (context.ChannelRunner.ChannelContext.Anchor is null) return;

        context.OutputLine($"{Esc.BrightYellowFG}Anchor{Esc.Reset}:");

        switch (context.Settings.ListDumpFormat)
        {
            case ListDumpFormat.Json:

                context.OutputLine(context.ChannelRunner.ChannelContext.Anchor.ToJsonString());
                break;

            case ListDumpFormat.Yaml:
                context.OutputLine(context.ChannelRunner.ChannelContext.Anchor.ToYamlString());
                break;

            case ListDumpFormat.Markdown:
                var mdTable = context.ChannelRunner.ChannelContext.Anchor.ToMarkDown();
                if (mdTable != null)
                    foreach (string line in mdTable)
                        context.OutputLine(line);

                break;
        }
    }
}