﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class PlayNext : Command
{
    public override string Name => "Play Next";

    public override string Description => "Plays the next event in the linear list";

    public override Regex Regex => new("^PlayNext|pn|next$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.OutputLine("Issuing Play Next");
        context.ChannelRunner.PlayNext();
    }
}
