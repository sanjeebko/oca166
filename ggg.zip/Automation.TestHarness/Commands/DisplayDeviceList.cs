﻿using System.Text.RegularExpressions;
using Pebble.Oceans.Automation.Scheduling;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class DisplayDeviceList : Command
{
    public override string Name => "DisplayDeviceList|dl";

    public override string Description => "Shows the current Device List in selected formatting";

    public override Regex Regex => new(@"^(?>DisplayDeviceList|dl)\s+(.+)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        Execute(context, GetParams(commandLine).First());
    }

    public static void Execute(TestHarness context, string deviceName)
    {
        var list = context.ChannelRunner.DeviceLists
            .FirstOrDefault(list => list.DeviceName.Equals(deviceName, StringComparison.InvariantCultureIgnoreCase));

        if (list is null)
        {
            context.OutputLine($"Device \"{deviceName}\" not found!!!");
            return;
        }

        if (context.Settings.ListDumpFormat == ListDumpFormat.Off)
            return;

        var deviceStartState = context.ChannelRunner.GetDeviceStartState(deviceName);

        context.OutputLine($"{Esc.BrightYellowFG}DeviceList{Esc.Reset} [{Esc.BrightCyanFG}{deviceName}{Esc.Reset}]:");

        if (deviceStartState.IsCurrentlyPlaying)
        {
            context.OutputLine($"{Esc.BrightGreenFG}Currently playing: {deviceStartState.StartArgs?.DeviceListEvent.MediaEvent.MediaReference}{Esc.Reset} " +
                                     $"Started at {Esc.WhiteFG}{deviceStartState.StartArgs?.Timestamp}{Esc.Reset}");
        }

        var historicalEvents = context.
            ChannelRunner.
            ChannelContext.
            HistoricalState.
            GetEvents(deviceName);

        switch (context.Settings.ListDumpFormat)
        {
            case ListDumpFormat.Json:
                context.OutputLine(list.ToReference().ToJsonString());
                break;

            case ListDumpFormat.Yaml:
                context.OutputLine(list.ToReference().ToYamlString());
                break;

            case ListDumpFormat.Markdown:
                foreach (string line in list.ToMarkDown(historicalEvents))
                    context.OutputLine(line);
                break;
        }
    }
}