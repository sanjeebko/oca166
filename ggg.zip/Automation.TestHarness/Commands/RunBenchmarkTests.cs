﻿using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Filters;
using BenchmarkDotNet.Running;
using Pebble.Oceans.Automation.Test.Framework.Benchmark;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class RunBenchmarkTests : Command
{
    public override string Name => "RunBenchmark|bm";

    public override string Description => "Run benchmark tests";

    public override Regex Regex => new(@"^(?>runbenchmark|bm)\s*$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        BenchmarkRunner.Run<BenchmarkedScenarioTestRunner>(Configuration);
    }

    private static ManualConfig Configuration => ManualConfig.Create(DefaultConfig.Instance)
                                                             .WithOptions(ConfigOptions.DisableLogFile)
                                                             .AddFilter(new AllCategoriesFilter(new[] { "Benchmark Scenario" }));
}