﻿using System.Text.RegularExpressions;
using Pebble.Oceans.Automation.Channel;
using Pebble.Shared.Time;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class ExecuteScenario : Command
{
    public override string Name => "ExecuteScenario|es";

    public override string Description => "Load scenario(s) and execute them";

    public override Regex Regex => new(@"^(?>ExecuteScenario|es)\s+(?'scenarios'\S+)\s*(?'outputflag'[-o]\S+)?\s*(?'outputfile'\S+)?", RegexOptions);

    private static readonly LinearListConfiguration LinearListConfiguration = new(10000,
        FrameAlignedTimeDifference.Parse("48:00:00:00"));

    public override void Execute(string commandLine, TestHarness context)
    {
        Match match = Regex.Match(commandLine);

        List<string> scenarioFiles = new();

        if (match.Groups["scenarios"].Success)
        {
            var scenarios = match.Groups["scenarios"].Value;

            var elems = scenarios.Split(",");

            foreach (var elem in elems)
            {
                if (Directory.Exists(elem))
                {
                    scenarioFiles.AddRange(new DirectoryInfo(elem).GetFiles().Select(f => f.FullName));
                }
                else
                {
                    var file = DetermineFile(elem);

                    if (!File.Exists(file))
                    {
                        context.OutputLine($"Could not load file {file}");
                        continue;
                    }

                    scenarioFiles.Add(file);
                }
            }

            if (!scenarioFiles.Any())
            {
                context.OutputLine("No valid scenario files specified");
                return;
            }

            var results =
                context.ScenarioTestRunner.RunScenarios(scenarioFiles.ToImmutableArray(), LinearListConfiguration);

            context.OutputLine($"{Esc.BrightCyanFG}**Results**{Esc.Reset}");

            var markDownLines = results.ToMarkDown().ToList();

            foreach (var line in markDownLines)
            {
                context.OutputLine(line);
            }

            if (match.Groups["outputflag"].Success &&
                match.Groups["outputfile"].Success)
            {
                var outputFileInfo = new FileInfo(match.Groups["outputfile"].Value);

                if (outputFileInfo.Directory is { Exists: false })
                {
                    outputFileInfo.Directory.Create();
                }

                File.WriteAllLines(outputFileInfo.FullName, markDownLines);

                context.OutputLine($"Output saved to {Esc.GreenFG}{outputFileInfo.FullName}{Esc.Reset} ");
            }

            string DetermineFile(string filename)
            {
                if (int.TryParse(filename, out int index) &&
                    context.ScenarioList.FileLists.TryGetValue(index, out string? s))
                    filename = s;
                if (!filename.Contains('\\'))
                    filename = $@"{context.ScenarioList.FolderName}\{filename}";
                if (!filename.EndsWith(".yaml"))
                    filename += ".yaml";

                return filename;
            }
        }
    }
}