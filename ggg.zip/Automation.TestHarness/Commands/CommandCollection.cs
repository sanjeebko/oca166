﻿using System.Reflection;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public static class CommandCollection
{
    public static ImmutableArray<Command> Commands { get; } =
        Assembly
           .GetExecutingAssembly()
           .GetTypes()
           .Where(t => t.IsAssignableTo(typeof(Command)) && !t.IsAbstract)
           .Select(t => t.GetConstructor(Type.EmptyTypes)?.Invoke(null) as Command ?? throw new Exception($"Error creating command {t.Name}"))
           .ToImmutableArray();

    public static void ProcessCommand(string commandLine, TestHarness context)
    {
        var command = Commands.FirstOrDefault(c => c.Regex.IsMatch(commandLine));
        if (command == null)
        {
            context.OutputLine("Unrecognized command");
            return;
        }
        command.Execute(commandLine, context);
    }
}