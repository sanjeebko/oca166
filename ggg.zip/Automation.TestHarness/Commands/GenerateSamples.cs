﻿using Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class GenerateSamples : Command
{
    public override string Name => "GeneratePlaylistSamples|GenSamples";

    public override string Description => "Creates a set of sample playlists in the Playlist folder";

    public override Regex Regex => new(@"^(?>GeneratePlaylistSamples|GenSamples)(?>\s+(-f))*$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        SamplePlaylistCollection.GeneratePlaylistFiles(context.Playlists.FolderName, HasSwitch(commandLine, "-f"));
    }
}
