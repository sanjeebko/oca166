﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public abstract class Command
{
    public abstract string Name { get; }
    public abstract string Description { get; }
    public abstract Regex Regex { get; }

    protected RegexOptions RegexOptions { get; } = RegexOptions.IgnoreCase | RegexOptions.Singleline | RegexOptions.Compiled;

    public abstract void Execute(string commandLine, TestHarness context);

    protected bool HasSwitch(string commandLine, string @switch)
        => GetParams(commandLine)
            .Any(s => s.Equals(@switch, StringComparison.OrdinalIgnoreCase));

    protected IEnumerable<string> GetParams(string commandLine)
        => Regex.Match(commandLine).Groups.Values
                .Skip(1)
                .Select(g => g.Value);
}
