﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Cue : Command
{
    public override string Name => "Cue";

    public override string Description => "Cue the selected playlist event in the channel runner";

    public override Regex Regex => new(@"^(?>cue)(\s+(?'eventid'.+))?$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        var match = Regex.Match(commandLine);

        var eventId = match.Groups["eventid"].Value;
        context.ChannelRunner.Cue(eventId);
    }
}