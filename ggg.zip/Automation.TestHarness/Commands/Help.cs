﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Help : Command
{
    public override string Name => "Help|?";

    public override string Description => "Displays this list";

    public override Regex Regex => new(@"^(?>help|\?)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        foreach (var s in CommandCollection.Commands.Select(c => $"{c.Name}: {c.Description}").OrderBy(x => x))
            context.OutputLine(s);
    }
}
