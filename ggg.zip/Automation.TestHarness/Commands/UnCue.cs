﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Uncue : Command
{
    public override string Name => "Uncue";

    public override string Description => "Uncue the channel runner";

    public override Regex Regex => new("^(?>uncue)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    => context.ChannelRunner.ManualUncue();
}