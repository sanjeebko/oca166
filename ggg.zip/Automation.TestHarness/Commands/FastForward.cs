﻿using System.Text.RegularExpressions;
using Pebble.Oceans.Automation.Clock;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class FastForward : Command
{
    public override string Name => "FastForward|ff";

    public override string Description => "Runs the clock faster than real-time";

    public override Regex Regex => new(@"^(?>FastForward|ff)(?>\s+(end))*$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.ClockRunner.SetClockMode(
            HasSwitch(commandLine, "end") 
                ? ClockMode.FastForwardToEndOfPlaylist 
                : ClockMode.FastForwardToNextEvent);
    }
}
