﻿using System.Reflection;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Set : Command
{
    public override string Name => "Set";

    public override string Description => "Sets variables value";

    public override Regex Regex => new(@"^set\s*(?'var'\S+)*\s*(?'value'\S+)*$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        var match = Regex.Match(commandLine);

        if (match.Groups["value"].Success)
            SetVariable(context, match.Groups["var"].Value, match.Groups["value"].Value);
        else if (match.Groups["var"].Success)
            DumpVariable(context, match.Groups["var"].Value);
        else
            DumpAll(context);
    }

    private static void SetVariable(TestHarness context, string variableName, string value)
    {
        var property = GetProperty(context, variableName);
        if (property is null)
            return;
        try
        {
            property.SetValue(context.Settings, ConvertType(value, property));
            context.SaveSettings();
        }
        catch (InvalidCastException invalidCastException)
        {
            context.OutputLine($"Error setting variable {variableName}:\n{invalidCastException.Message}");
        }
        catch (FormatException formatException)
        {
            context.OutputLine($"Error setting variable {variableName}:\n{formatException.Message}");
        }
        catch (OverflowException overflowException)
        {
            context.OutputLine($"Error setting variable {variableName}:\n{overflowException.Message}");
        }
    }

    private static object ConvertType(string value, PropertyInfo property)
    {
        if (property.PropertyType.IsEnum)
            return Enum.Parse(property.PropertyType, value, true);
        return Convert.ChangeType(value, property.PropertyType);
    }

    private static void DumpVariable(TestHarness context, string variableName)
    {
        var property = GetProperty(context, variableName);
        if (property is not null)
            context.OutputLine($"{variableName}={property.GetValue(context.Settings)}");
    }

    private static PropertyInfo? GetProperty(TestHarness context, string variableName)
    {
        PropertyInfo? propertyInfo = typeof(TestHarnessSettings).GetProperty(variableName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);
        if (propertyInfo is null)
            context.OutputLine($"{variableName} is not a valid property name");
        return propertyInfo;
    }

    private static void DumpAll(TestHarness context)
    {
        foreach (string property in typeof(TestHarnessSettings).GetProperties(BindingFlags.Instance | BindingFlags.Public).Select(p => p.Name))
            DumpVariable(context, property);
    }
}