﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Exit : Command
{
    public override string Name => "Exit|Quit";

    public override string Description => "Exits the application";

    public override Regex Regex => new("^(?>exit|quit)$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.RequestTermination = true;
    }
}
