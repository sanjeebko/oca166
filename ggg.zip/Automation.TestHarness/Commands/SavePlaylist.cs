﻿using Pebble.Oceans.Automation.Scheduling;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class SavePlaylist : Command
{
    public override string Name => "SavePlaylist|sp";

    public override string Description => "Saves playlist to disk";

    public override Regex Regex => new(@"^(?>SavePlaylist|sp)\s+(?'filename'\S+)\s+(?'format'json|md|yaml)\s*|(?'filename1'\S+)(?'ext'\.json|\.md|\.yaml)+\s*$", RegexOptions);

    private readonly ImmutableArray<string> _validOutputFormats = ImmutableArray.Create(".json", ".yaml", ".md");

    public override void Execute(string commandLine, TestHarness context)
    {
        if (!context.ChannelRunner.AnchoredPlaylist.Playlist.Events.Any())
        {
            context.OutputLine("Error: Playlist is empty.");
            return;
        }

        Match match = Regex.Match(commandLine);

        if (match.Success)
        {
            string defaultSavedFolder = context.Settings.SaveLocation;
            string filename = string.Empty;
            string format = string.Empty;
            string extension = string.Empty;

            if (match.Groups["format"].Success)
            {
                filename = match.Groups["filename"].Value;
                format = match.Groups["format"].Value;
                extension = $".{format}";
            }
            else if (match.Groups["ext"].Success)
            {
                filename = match.Groups["filename1"].Value;
                extension = match.Groups["ext"].Value;
                if (_validOutputFormats.Any(x => extension!.EndsWith(x)))
                    format = extension.Replace(".", "");
            }

            if (string.IsNullOrEmpty(format))
                format = context.Settings.SaveOutputFormat.ToString();
            SaveOutputFileFormat saveOutputFileFormat = (SaveOutputFileFormat)Enum.Parse(typeof(SaveOutputFileFormat), format);

            GenerateFile(defaultSavedFolder, $"{filename}.playlist.{format}", true, context.ChannelRunner.AnchoredPlaylist.ToFormattedString(saveOutputFileFormat), context);
            GenerateFile(defaultSavedFolder, $"{filename}.linearlist.{format}", true, context.ChannelRunner.LinearList.ToFormattedString(saveOutputFileFormat), context);
            foreach (var deviceList in context.ChannelRunner.DeviceLists)
                GenerateFile(defaultSavedFolder, $"{filename}.devicelist.{deviceList.DeviceName}.{format}", true, deviceList.ToFormattedString(saveOutputFileFormat), context);

            var presentationList = context.ChannelRunner.PresentationList;
            GenerateFile(defaultSavedFolder, $"{filename}.presentationlist.{format}", true, presentationList.ToFormattedString(saveOutputFileFormat), context);
            return;
        }

        context.OutputLine("Error: Syntax is not correct.");
    }

    private static void GenerateFile(string path, string saveFileName, bool overwrite, string? content, TestHarness context)
    {
        if (content is null)
            return;
        if (!Directory.Exists(path))
            Directory.CreateDirectory(path);
        string fileName = $@"{path}\{saveFileName}";
        if (!overwrite && File.Exists(fileName))
        {
            context.OutputLine($"File {fileName} already exists, skipping");
            return;
        }
        context.OutputLine($"Generating File {fileName}");
        File.WriteAllText(fileName, content);
    }
}