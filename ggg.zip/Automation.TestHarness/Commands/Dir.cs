﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Dir : Command
{
    public override string Name => "Dir";

    public override string Description => "List the playlist and/or scenario";

    public override Regex Regex => new(@"^(?>dir)(?>\s+(?'value'-\w))*$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        if (HasSwitch(commandLine, "-p"))
        {
            new PlaylistDir().Execute(commandLine, context);
            return;
        }

        if (HasSwitch(commandLine, "-s"))
        {
            new ScenarioDir().Execute(commandLine, context);
            return;
        }

        var match = Regex.Match(commandLine);
        if (match.Groups["value"].Success)
        {
            context.OutputLine($"{match.Groups["value"].Value} switch is not supported.");
            return;
        }
        new PlaylistDir().Execute(commandLine, context);
        new ScenarioDir().Execute(commandLine, context);
    }
}