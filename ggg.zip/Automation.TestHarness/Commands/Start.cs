﻿using Pebble.Oceans.Automation.AsRunLog;
using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class Start : Command
{
    public override string Name => "Start";

    public override string Description => "Starts the clock";

    public override Regex Regex => new("^start$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        if (context.Playlists is null)
        {
            throw new CommandException("Playlist not loaded.");
        }

        context.ChannelRunner.AsRunLogger = context.Settings.AsRunLogger switch
        {
            AsRunLoggerType.Console => new ConsoleAsRunLogger(),
            AsRunLoggerType.File => new FileAsRunLogger(Path.Join(Directory.GetCurrentDirectory(), "AsRunLogger")),
            _ => new ConsoleAsRunLogger(),
        };

        var channelState = context.ChannelRunner.ChannelContext.ChannelStatus;

        if (channelState is not ChannelStatus.Uncued)
        {
            context.ClockRunner.Start();
            return;
        }

        throw new CommandException($"Error starting a channel. Channel state is {channelState}.");
    }
}