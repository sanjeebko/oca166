﻿using System.Text.RegularExpressions;

namespace Pebble.Oceans.Automation.TestHarness.Commands;

public class ScenarioDir : Command
{
    public override string Name => "Dir-s";

    public override string Description => "List the scenarios in the scenario folder";

    public override Regex Regex => new(@"^dir-s$", RegexOptions);

    public override void Execute(string commandLine, TestHarness context)
    {
        context.Playlists.Refresh();
        if (context.Playlists.Count == 0)
            context.OutputLine("No playlists found");
        else
            foreach (var scenario in context.ScenarioList)
                context.OutputLine($"{Esc.BrightYellowFG}#{scenario.Key}{Esc.Reset} - {scenario.Value}");
    }
}