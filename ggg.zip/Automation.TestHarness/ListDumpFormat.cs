﻿namespace Pebble.Oceans.Automation.TestHarness;

public enum ListDumpFormat
{
    Off,
    Json,
    Yaml,
    Markdown
}