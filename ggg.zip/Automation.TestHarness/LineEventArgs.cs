﻿namespace Pebble.Oceans.Automation.TestHarness;

public class LineEventArgs : EventArgs
{
    public LineEventArgs(string line)
    {
        Line = line;
    }

    public string Line { get; }
}
