﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Clock;
using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.Scheduling;
using Pebble.Oceans.Automation.Test.Framework.Scenario;
using Pebble.Oceans.Automation.TestHarness.Commands;
using Pebble.Serialization;
using Pebble.Shared.Time;

namespace Pebble.Oceans.Automation.TestHarness;

public class TestHarness
{
    private const string SettingsFileName = "TestHarnessSettings.yaml";

    public event EventHandler<ScheduleListBundleEventArgs>? SchedulingFinished;

    public event EventHandler<TimeEventArgs>? NewFrame;

    public event EventHandler<LineEventArgs>? NewOutputLine;

    public event EventHandler<EventArgs>? AsRunUpdate;

    public event EventHandler<ChannelStateEventArgs>? ChannelStatusChange;

    public event EventHandler<PresentationListEventArgs>? PresentationListReady;

    public bool RequestTermination { get; set; }

    public TestHarnessSettings Settings { get; }

    internal ChannelRunner ChannelRunner { get; }

    public ChannelConfiguration ChannelConfiguration { get; }

    public ScenarioTestRunner ScenarioTestRunner { get; }

    public PlaylistCollection Playlists { get; } = new();

    public ScenarioListCollection ScenarioList { get; } = new();

    public AsRun.AsRunLog AsRunLog => ChannelRunner.ChannelContext.AsRunLog;

    public PresentationList PresentationList => ChannelRunner.PresentationList;

    public Anchor? Anchor => ChannelRunner.ChannelContext.Anchor;

    public ChannelStatus ChannelStatus => ChannelRunner.ChannelContext.ChannelStatus;
    public AdjustAbleClockRunner ClockRunner { get; }

    public TestHarness()
    {
        // MJ: At this stage I am hardcoding this and not using Processor management - to be changed in the future
        ChannelConfiguration = new ChannelConfiguration(
            File.ReadAllText("DeviceChainManifest.yaml").ToYaml().ToDeviceChainManifest(),
            new LinearListConfiguration(
                10000,
                FrameAlignedTimeDifference.Parse("48:00:00:00")),
            FrameAlignedTimeDifference.Parse("00:00:02:00"));

        ChannelRunner = new(new(ChannelConfiguration));
        ClockRunner = new AdjustAbleClockRunner(new ClockSource(), ChannelRunner){StopOnPlaylistEnd = true};
        ScenarioTestRunner =
            new(new ConsoleLogger(), new TestRunnerConfig("ConsoleScenarioDumps"));
        
        ChannelRunner.SchedulingFinished += ChannelRunner_SchedulingFinished;
        ChannelRunner.NewFrame += ChannelRunner_NewFrame;
        ChannelRunner.ChannelContext.AsRunLog.Changed += AsRunLog_Changed;
        ChannelRunner.ChannelContext.ChannelStatusChanged += ChannelStatus_Changed;
        ChannelRunner.ChannelContext.PresentationListProvider.PresentationListReady += PresentationListProvider_PresentationListReady;

        if (File.Exists(SettingsFileName))
            Settings = File.ReadAllText(SettingsFileName).ToYaml().ToTestHarnessSettings();
        else
            Settings = TestHarnessSettings.Default;
    }

    internal void SaveSettings() => File.WriteAllText(SettingsFileName, Settings.ToYamlString());

    private void AsRunLog_Changed(object? sender, EventArgs e)
    {
        try
        {
            AsRunUpdate?.Invoke(sender, e);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception occurred in AsRunUpdate event handler: {ex}");
        }
    }

    private void ChannelStatus_Changed(object? sender, ChannelStateEventArgs e)
    {
        try
        {
            ChannelStatusChange?.Invoke(sender, e);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception occurred in ChannelStatus event handler: {ex}");
        }
    }

    internal void OutputLine(string s)
    {
        try
        {
            NewOutputLine?.Invoke(this, new(s));
        }
        catch (Exception e)
        {
            Console.WriteLine($"Exception occurred in NewOutputLine event handler: {e}");
        }
    }

    private void ChannelRunner_NewFrame(object? sender, TimeEventArgs e)
    {
        try
        {
            NewFrame?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception occurred in NewFrame event handler: {ex}");
        }
    }

    private void ChannelRunner_SchedulingFinished(object? sender, ScheduleListBundleEventArgs e)
    {
        try
        {
            SchedulingFinished?.Invoke(this, e);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception occurred in SchedulingFinished event handler: {ex}");
        }
    }

    private void PresentationListProvider_PresentationListReady(object? sender, PresentationListEventArgs e)
    {
        try
        {
            PresentationListReady?.Invoke(sender, e);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Exception occurred in PresentationListProvider event handler: {ex}");
        }
    }

    public void ProcessCommand(string commandLine) => CommandCollection.ProcessCommand(commandLine, this);
}