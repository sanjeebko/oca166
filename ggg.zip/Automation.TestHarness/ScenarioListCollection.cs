﻿using Pebble.Oceans.Automation.TestHarness.Commands;

namespace Pebble.Oceans.Automation.TestHarness;

public class ScenarioListCollection : FileCollection
{
    public ScenarioListCollection() : base("ScenarioFiles")
    {
    }
}