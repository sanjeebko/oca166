﻿using Pebble.Logging;
using Pebble.Oceans.Automation.TestHarness.Commands;

namespace Pebble.Oceans.Automation.TestHarness;

internal static class Program
{
    private static void Main(string[] args)
    {
        LogManager.Initialize();

        long lastFrameCount = 0;
        TestHarness testHarness = new();

        testHarness.SchedulingFinished += ChannelRunner_SchedulingFinished;
        testHarness.NewFrame += ChannelRunner_NewFrame;
        testHarness.NewOutputLine += TestHarness_NewOutputLine;

        while (!testHarness.RequestTermination)
        {
            Console.Write(">");
            string commandLine = (Console.ReadLine() ?? string.Empty).Trim();
            try
            {
                testHarness.ProcessCommand(commandLine);
            }
            catch (Exception ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"An error has occured while processing command {commandLine}");
                Console.WriteLine(ex.ToString());
                Console.ResetColor();
            }
        }

        void ChannelRunner_SchedulingFinished(object? sender, ScheduleListBundleEventArgs e)
        {
            DisplayLinearList.Execute(testHarness);
            foreach (string deviceName in e.ListBundle.DeviceLists.Select(list => list.DeviceName))
                DisplayDeviceList.Execute(testHarness, deviceName);

            DisplayPresentationList.Execute(testHarness, testHarness.Settings.ListDumpFormat.ToString());
        }

        void ChannelRunner_NewFrame(object? sender, TimeEventArgs e)
        {
            if (e.Time.AsTimecode().EndsWith("00") || Math.Abs(e.Time.FrameCount - lastFrameCount) > 10)
                Console.WriteLine($"Time: {Esc.BrightYellowFG}{e.Time}{Esc.Reset}");
            lastFrameCount = e.Time.FrameCount;
        }

        void TestHarness_NewOutputLine(object? sender, LineEventArgs e)
        {
            Console.WriteLine(e.Line);
        }
    }
}