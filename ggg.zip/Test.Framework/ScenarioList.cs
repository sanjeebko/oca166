﻿namespace Pebble.Oceans.Automation.Test.Framework;

public static class ScenarioList
{
    public static string ScenarioFolder => $"{Path.DirectorySeparatorChar}ScenarioFiles";

    public static ImmutableArray<string> Files()
    {
        var scenarioPath = Path.Join(Directory.GetCurrentDirectory(), ScenarioFolder);
        return Directory.GetFiles(scenarioPath).ToImmutableArray();
    }

    public static ImmutableArray<string> FileNames()
    {
        return Files().Select(f => new FileInfo(f).Name).ToImmutableArray();
    }
}