﻿namespace Pebble.Oceans.Automation.Test.Framework
{
    public static class StringHelper
    {
        public static string RemoveCR(this string source)
        {
            return source.Replace("\r", "");
        }
    }
}
