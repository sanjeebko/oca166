﻿namespace Pebble.Oceans.Automation.Test.Framework
{
    public static class ReferenceLinearListHelpers
    {
        public static ReferenceLinearList Empty { get; } = new ReferenceLinearList(ImmutableArray<ReferenceLinearListEvent>.Empty);

        public static ReferenceLinearList SkipEvents(this ReferenceLinearList list, int value)
            => new(list.Events.Skip(value).ToImmutableArray());

        public static ReferenceLinearList ApplyOffset(this ReferenceLinearList list, FrameAlignedTimeDifference value)
            => new(list.Events.Select(e => e with { CalculatedTiming = new FrameAlignedTimeInterval(e.CalculatedTiming.Start + value, e.CalculatedTiming.Duration) }).ToImmutableArray());

        public static ReferenceLinearList RebaseAt(this ReferenceLinearList list, FrameAlignedTimestamp value)
            => ApplyOffset(list, value - list.Events.First().CalculatedTiming.Start);

        public static ReferenceLinearList AdjustLastIdleEndTime(this ReferenceLinearList list, FrameAlignedTimestamp value)
        {
            if (list.Events.Last() is ReferenceIdleLinearListEvent idle)
                return new ReferenceLinearList(
                    list.Events.SetItem(
                        list.Events.Length - 1,
                        new ReferenceIdleLinearListEvent(
                            new FrameAlignedTimeInterval(
                                idle.CalculatedTiming.Start,
                                value))));
            throw new SchedulingException("Last event in linear list is not idle");
        }

        public static ReferenceLinearList AdjustLastIdleEndTimeBy(this ReferenceLinearList list,
            FrameAlignedTimeDifference duration)
        {
            if (list.Events.Last() is ReferenceIdleLinearListEvent idle)
                return new ReferenceLinearList(
                    list.Events.SetItem(
                        list.Events.Length - 1,
                        new ReferenceIdleLinearListEvent(
                            new FrameAlignedTimeInterval(
                                idle.CalculatedTiming.Start,
                                idle.CalculatedTiming.End + duration))));
            return list;
        }

        public static ReferenceLinearList RemoveEventsAfter(this ReferenceLinearList list, FrameAlignedTimestamp value)
            => new(list.Events.Where(e => e.CalculatedTiming.Start < value).ToImmutableArray());
    }
}