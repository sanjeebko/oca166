﻿namespace Pebble.Oceans.Automation.Test.Framework;

public static class ReferenceDeviceListHelpers
{
    public static ReferenceDeviceList Empty { get; } = new ReferenceDeviceList(ImmutableArray<ReferenceDeviceListEvent>.Empty);

    public static ReferenceDeviceList SkipEvents(this ReferenceDeviceList list, int value)
        => new(list.Events.Skip(value).ToImmutableArray());

    public static ReferenceDeviceList ApplyOffset(this ReferenceDeviceList list, FrameAlignedTimeDifference value)
        => new(list.Events.Select(e => e with { CalculatedTiming = new FrameAlignedTimeInterval(e.CalculatedTiming.Start + value, e.CalculatedTiming.Duration) }).ToImmutableArray());

    public static ReferenceDeviceList RebaseAt(this ReferenceDeviceList list, FrameAlignedTimestamp value)
        => ApplyOffset(list, value - list.Events.First().CalculatedTiming.Start);

    public static ReferenceDeviceList RemoveEventsAfter(this ReferenceDeviceList list, FrameAlignedTimestamp value)
        => new(list.Events.Where(e => e.CalculatedTiming.Start < value).ToImmutableArray());
}