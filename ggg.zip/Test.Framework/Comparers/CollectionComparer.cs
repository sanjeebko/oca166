﻿using System.Text;

namespace Pebble.Oceans.Automation.Test.Framework.Comparers
{
    internal abstract class CollectionComparer<T> where T: class
    {
        public ImmutableArray<T> Expected { get; }
        public ImmutableArray<T> Actual { get; }
        public int MaxDiffDumped { get; }

        public string Result { get; }

        public bool IsDifferent { get; protected set; }

        protected virtual string CollectionName => "Collection";

        protected CollectionComparer(
            ImmutableArray<T> expected, 
            ImmutableArray<T> actual, 
            int maxDiffDumped = 4,
            Func<ImmutableArray<T>, ImmutableArray<T>, int>? processBeginning = null)
        {
            Expected = expected;
            Actual = actual;
            MaxDiffDumped = maxDiffDumped;

            var output = new StringBuilder();

            if (Expected.Length != Actual.Length)
            {
                IsDifferent = true;
                output.AppendLine($"{CollectionName} lengths are different; Expected {Expected.Length}; Actual {Actual.Length}");
            }
            int index = 0;
            if (processBeginning is not null)
                index = processBeginning.Invoke(Expected, Actual);
            while (index < Actual.Length && index < Expected.Length && Actual[index] == Expected[index])
                index++;
            if (index > 0)
                output.AppendLine($"First {index} entries are equal");

            int diffCount = 0;
            while (index < Actual.Length && index < Expected.Length)
            {
                if (!Actual[index].Equals(Expected[index]))
                {
                    IsDifferent = true;
                    diffCount++;
                    if (diffCount <= MaxDiffDumped)
                    { 
                        output.AppendLine($"Entry #{index + 1} differs in the following properties");
                        foreach (var property in typeof(T).GetProperties())
                        {
                            var actualValue = property.GetValue(Actual[index]);
                            var expectedValue = property.GetValue(Expected[index]);
                            if (!actualValue?.Equals(expectedValue) ?? true)
                            {
                                output.AppendLine($"   {property.Name}:");
                                output.AppendLine($"      Expected: {expectedValue}");
                                output.AppendLine($"      Actual: {actualValue}");
                            }
                        }
                    }
                }
                index++;
            }
            if (diffCount > MaxDiffDumped)
                output.AppendLine($"{diffCount - MaxDiffDumped} more difference(s)");
            if (!IsDifferent)
                output.AppendLine($"{CollectionName}s are equivalent");
            Result = output.ToString();
        }

        protected virtual void ProcessBeginning(ref int index)
        { }
    }
}