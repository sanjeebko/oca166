﻿using Pebble.Oceans.Automation.AsRunLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pebble.Oceans.Automation.Test.Framework.Comparers
{
    internal class LinearListComparer : CollectionComparer<ReferenceLinearListEvent>
    {
        public LinearListComparer(ReferenceLinearList expected, ReferenceLinearList actual, bool ignoreLastIdleEventEndTime = true, int maxDiffDumped = 4)
            : base(
                  PrepareEvents(expected, ignoreLastIdleEventEndTime),
                  PrepareEvents(actual, ignoreLastIdleEventEndTime),
                  maxDiffDumped)
        {
            IgnoreLastIdleEventEndTime = ignoreLastIdleEventEndTime;
        }

        private static ImmutableArray<ReferenceLinearListEvent> PrepareEvents(ReferenceLinearList list, bool ignoreLastIdleEventEndTime)
        {
            int lastIndex = list.Events.Length - 1;
            if (lastIndex >= 0 && ignoreLastIdleEventEndTime && list.Events.Last() is ReferenceIdleLinearListEvent idleEvent)
                return list.Events.SetItem(
                    lastIndex, 
                    idleEvent with 
                    { 
                        CalculatedTiming = new FrameAlignedTimeInterval(
                            idleEvent.CalculatedTiming.Start, 
                            FrameAlignedTimeDifference.Zero) 
                    });
            return list.Events;
        }

        public bool IgnoreLastIdleEventEndTime { get; }

        protected override string CollectionName => "Linear list";
    }
}
