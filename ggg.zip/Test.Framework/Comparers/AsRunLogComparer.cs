﻿using Pebble.Oceans.Automation.AsRunLog;

namespace Pebble.Oceans.Automation.Test.Framework.Comparers
{
    internal class AsRunLogComparer: CollectionComparer<AsRunLogEvent>
    {
        public AsRunLogComparer(IEnumerable<AsRunLogEvent> expected, IEnumerable<AsRunLogEvent> actual, int firstEventStartTolerance = 5, int maxDiffDumped = 4)
            : base(
                  Sort(expected), 
                  Sort(actual), 
                  maxDiffDumped,
                  processBeginning: (expected, actual) =>
                  {
                      // MJ: For the time being we must allow some tolerance on the start time of the first event
                      if (actual.Length > 0 &&
                          expected.Length > 0 &&
                          actual[0] with { Time = String.Empty } == expected[0] with { Time = String.Empty } &&
                          Math.Abs((FrameAlignedTimestamp.Parse(actual[0].Time) - FrameAlignedTimestamp.Parse(expected[0].Time)).FrameCount) <= firstEventStartTolerance)
                          return 1;
                      return 0;
                  })
        {
            FirstEventStartTolerance = firstEventStartTolerance;
        }

        private static ImmutableArray<AsRunLogEvent> Sort(IEnumerable<AsRunLogEvent> log)
            => log.OrderBy(e => e.Time).ThenBy(e => e.Track).ThenBy(e => e.EventType).ToImmutableArray();

        public int FirstEventStartTolerance { get; }

        protected override string CollectionName => "As-Run log";
    }
}
