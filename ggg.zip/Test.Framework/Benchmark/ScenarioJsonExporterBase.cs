﻿using BenchmarkDotNet.Environments;
using BenchmarkDotNet.Loggers;
using BenchmarkDotNet.Reports;
using System.Text.Json;

namespace BenchmarkDotNet.Exporters.Json;

public abstract class ScenarioJsonExporterBase : JsonExporterBase
{
    protected override string FileExtension => "json";

    private bool ExcludeMeasurements { get; }
    private bool ExcludeMetrics { get; }

    protected ScenarioJsonExporterBase(bool excludeMetrics = false, bool excludeMeasurements = false)
    {
        ExcludeMetrics = excludeMetrics;
        ExcludeMeasurements = excludeMeasurements;
    }

    public override void ExportToLog(Summary summary, ILogger logger)
    {
        var environmentInfo = new
        {
            HostEnvironmentInfo.BenchmarkDotNetCaption,
            summary.HostEnvironmentInfo.BenchmarkDotNetVersion,
            OsVersion = summary.HostEnvironmentInfo.OsVersion.Value,
            ProcessorName = ProcessorBrandStringHelper.Prettify(summary.HostEnvironmentInfo.CpuInfo.Value),
            summary.HostEnvironmentInfo.CpuInfo.Value?.PhysicalProcessorCount,
            summary.HostEnvironmentInfo.CpuInfo.Value?.PhysicalCoreCount,
            summary.HostEnvironmentInfo.CpuInfo.Value?.LogicalCoreCount,
            summary.HostEnvironmentInfo.RuntimeVersion,
            summary.HostEnvironmentInfo.Architecture,
            summary.HostEnvironmentInfo.HasAttachedDebugger,
            summary.HostEnvironmentInfo.HasRyuJit,
            summary.HostEnvironmentInfo.Configuration,
            DotNetCliVersion = summary.HostEnvironmentInfo.DotNetSdkVersion.Value,
            summary.HostEnvironmentInfo.ChronometerFrequency,
            HardwareTimerKind = summary.HostEnvironmentInfo.HardwareTimerKind.ToString()
        };

        var benchmarks = summary.Reports.Select(report => GetBenchmarkData(report));

        var options = new JsonSerializerOptions { WriteIndented = true };
        logger.WriteLine(JsonSerializer.Serialize(new Dictionary<string, object>
        {   { "CreatedDate",DateTime.Now.ToString("yyyy/MM/dd HH:mm:ss")},
            { "Title", summary.Title },
            { "HostEnvironmentInfo", environmentInfo },
            { "Benchmarks", benchmarks }
        }, options));
    }

    private Dictionary<string, object> GetBenchmarkData(BenchmarkReport report)
    {
        string methodName = report.BenchmarkCase.Descriptor.WorkloadMethod.Name;
        string discriptorName = report.BenchmarkCase.Descriptor.Type.FullName ?? "";
        string fullMethod = $"{discriptorName}.{methodName}";
        string fullName = FullNameProvider.GetBenchmarkName(report.BenchmarkCase);
        string fileName = fullName[fullMethod.Length..]
                                  .Replace("(fileName: \"", "")
                                  .Replace("\")", "");
        var data = new Dictionary<string, object>
            {
                { "DisplayInfo", report.BenchmarkCase.DisplayInfo },
                { "Namespace", report.BenchmarkCase.Descriptor.Type.Namespace??"" },
                { "TypeFullName", discriptorName},
                { "Method", methodName },
                { "MethodTitle", report.BenchmarkCase.Descriptor.WorkloadMethodDisplayInfo },
                { "Parameters", report.BenchmarkCase.Parameters.PrintInfo },
                { "ScenarioFile", fileName},
                { "FullName", fullName }, // do NOT remove this property, it is used for xunit-performance migration
                { "Statistics",(report.ResultStatistics is null)?"": new{
                                    report.ResultStatistics.Mean,
                                    report.ResultStatistics.Max,
                                    report.ResultStatistics.Median,
                                    report.ResultStatistics.N,
                                    report.ResultStatistics.StandardError,
                                    report.ResultStatistics.StandardDeviation,
                                    report.ResultStatistics.Variance,
                                    report.ResultStatistics.Skewness,
                                    report.ResultStatistics.Kurtosis,
                                    report.ResultStatistics.Percentiles}
                }
            };

        if (report.BenchmarkCase.Config.HasMemoryDiagnoser())
        {
            data.Add("Memory", new
            {
                report.GcStats.Gen0Collections,
                report.GcStats.Gen1Collections,
                report.GcStats.Gen2Collections,
                report.GcStats.TotalOperations,
                BytesAllocatedPerOperation = report.GcStats.GetBytesAllocatedPerOperation(report.BenchmarkCase)
            });
        }

        if (!ExcludeMeasurements)
        {
            // We construct Measurements manually, so that we can have the IterationMode enum as text, rather than an integer
            data.Add("Measurements",
                report.AllMeasurements.Select(m => new
                {
                    IterationMode = m.IterationMode.ToString(),
                    IterationStage = m.IterationStage.ToString(),
                    m.LaunchIndex,
                    m.IterationIndex,
                    m.Operations,
                    m.Nanoseconds
                }));
        }

        if (!ExcludeMetrics && report.Metrics.Count > 0)
        {
            data.Add("Metrics", report.Metrics.Values);
        }
        return data;
    }
}