﻿using Automation.Test.Framework;
using BenchmarkDotNet.Attributes;
using BenchmarkDotNet.Diagnosers;
using BenchmarkDotNet.Engines;
using Pebble.Oceans.Automation.Test.Framework.Scenario;

namespace Pebble.Oceans.Automation.Test.Framework.Benchmark;

[MemoryDiagnoser]
[CpuDiagnoser]
[ScenarioJsonExporter("-scenario", excludeMetrics: false, excludeMeasurements: true)]
[HtmlExporter]
[SimpleJob(RunStrategy.Monitoring, launchCount: 1)]
[IterationCount(10)]
public class BenchmarkedScenarioTestRunner
{
    private readonly ScenarioTestRunner _scenarioTestRunner;

    private string ScenarioFolder { get; }

    public BenchmarkedScenarioTestRunner()
    {
        ScenarioFolder = BenchmarkConfigurationHelper.GetScenarioFolder();
        _scenarioTestRunner = new ScenarioTestRunner(
            new ConsoleLogger(),
            new TestRunnerConfig("BenchmarkLog"));
    }

    [Benchmark]
    [BenchmarkCategory("Benchmark Scenario")]
    [ArgumentsSource(nameof(GetFilesFromDirectory))]
    public void RunScenarios(string fileName)
    {
        string fullFileName = Path.Combine(ScenarioFolder, fileName);

        if (!FileExist(fullFileName))
            return;
        var results = _scenarioTestRunner.RunScenario(fullFileName,
                                                          BenchmarkConfigurationHelper.LinearListConfiguration);
        results.ToList().ForEach(result =>
        {
            if (result.Result == TestResult.Fail)
            {
                Console.WriteLine(result.Error);
            }
        });
    }

    [Benchmark]
    [BenchmarkCategory("Benchmark Test Framework")]
    [ArgumentsSource(nameof(GetSampleScenarios))]
    public void RunScenarioSample(string fileName)
    {
        string fullFileName = Path.Combine(ScenarioFolder, fileName);

        if (!FileExist(fullFileName))
        {
            return;
        }
        _scenarioTestRunner.RunScenario(fullFileName,
                                        BenchmarkConfigurationHelper.LinearListConfiguration);
    }

    public static bool FileExist(string file)
    {
        bool exist = File.Exists(file);
        if (!exist)
        {
            Console.WriteLine($"Error, File not found {file}");
        }

        return exist;
    }

    public static IEnumerable<string> GetSampleScenarios()
    => BenchmarkConfigurationHelper
        .BenchmarkTestScenarios;

    public static IEnumerable<string> GetFilesFromDirectory()
        => BenchmarkConfigurationHelper
            .BenchmarkScenarios;
}