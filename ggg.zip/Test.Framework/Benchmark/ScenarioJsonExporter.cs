﻿namespace BenchmarkDotNet.Exporters.Json;

public class ScenarioJsonExporter : ScenarioJsonExporterBase
{
    public static readonly IExporter Brief = new ScenarioJsonExporter("-brief", excludeMetrics: false, excludeMeasurements: true);
    public static readonly IExporter Full = new ScenarioJsonExporter("-full", excludeMetrics: false, excludeMeasurements: false);
    public static readonly IExporter BriefCompressed = new ScenarioJsonExporter("-brief-compressed", excludeMetrics: false, excludeMeasurements: true);
    public static readonly IExporter FullCompressed = new ScenarioJsonExporter("-full-compressed", excludeMetrics: false, excludeMeasurements: false);

    public static readonly IExporter Default = FullCompressed;

    protected override string FileNameSuffix { get; } = string.Empty;

    public ScenarioJsonExporter(string fileNameSuffix = "", bool excludeMetrics = false, bool excludeMeasurements = false) : base(excludeMetrics, excludeMeasurements)
    {
        FileNameSuffix = fileNameSuffix;
    }

    public static IExporter Custom(string fileNameSuffix = "", bool excludeMetrics = false, bool excludeMeasurements = false) =>
        new ScenarioJsonExporter(fileNameSuffix, excludeMetrics, excludeMeasurements);
}