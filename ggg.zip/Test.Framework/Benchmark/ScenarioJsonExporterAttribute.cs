﻿using BenchmarkDotNet.Exporters;
using BenchmarkDotNet.Exporters.Json;

namespace BenchmarkDotNet.Attributes;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Assembly, AllowMultiple = true)]
public class ScenarioJsonExporterAttribute : ExporterConfigBaseAttribute
{
    private ScenarioJsonExporterAttribute(IExporter exporter) : base(exporter)
    {
    }

    public ScenarioJsonExporterAttribute(string fileNameSuffix = "", bool excludeMetrics = false, bool excludeMeasurements = false)
        : this(new ScenarioJsonExporter(fileNameSuffix, excludeMetrics, excludeMeasurements))
    {
    }
}