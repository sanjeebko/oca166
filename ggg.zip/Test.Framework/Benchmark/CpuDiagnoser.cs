using BenchmarkDotNet.Analysers;
using BenchmarkDotNet.Columns;
using BenchmarkDotNet.Configs;
using BenchmarkDotNet.Engines;
using BenchmarkDotNet.Exporters;
using BenchmarkDotNet.Loggers;
using BenchmarkDotNet.Reports;
using BenchmarkDotNet.Running;
using BenchmarkDotNet.Validators;
using System.Diagnostics;

namespace BenchmarkDotNet.Diagnosers
{
    [AttributeUsage(AttributeTargets.All, AllowMultiple = false)]
    public class CpuDiagnoserAttribute : Attribute, IConfigSource
    {
        public IConfig Config { get; }

        public CpuDiagnoserAttribute()
        {
            Config = ManualConfig.CreateEmpty().AddDiagnoser(new CpuDiagnoser());
        }
    }

    public class CpuDiagnoser : IDiagnoser
    {
        private readonly Process _proc;
        private long _userStart, _userEnd;
        private long _privStart, _privEnd;

        public CpuDiagnoser()
        {
            _proc = Process.GetCurrentProcess();
        }

        public IEnumerable<string> Ids => new[] { "CPU" };

        public IEnumerable<IExporter> Exporters => Array.Empty<IExporter>();

        public IEnumerable<IAnalyser> Analysers => Array.Empty<IAnalyser>();

        public void DisplayResults(ILogger logger)
        {
        }

        public RunMode GetRunMode(BenchmarkCase benchmarkCase)
        {
            return RunMode.NoOverhead;
        }

        public void Handle(HostSignal signal, DiagnoserActionParameters parameters)
        {
            if (signal == HostSignal.BeforeActualRun)
            {
                _userStart = _proc.UserProcessorTime.Ticks;
                _privStart = _proc.PrivilegedProcessorTime.Ticks;
            }
            if (signal == HostSignal.AfterActualRun)
            {
                _userEnd = _proc.UserProcessorTime.Ticks;
                _privEnd = _proc.PrivilegedProcessorTime.Ticks;
            }
        }

        public IEnumerable<Metric> ProcessResults(DiagnoserResults results)
        {
            yield return new Metric(CpuUserMetricDescriptor.Instance, (_userEnd - _userStart) * 100d / results.TotalOperations);
            yield return new Metric(CpuPrivilegedMetricDescriptor.Instance, (_privEnd - _privStart) * 100d / results.TotalOperations);
        }

        public IEnumerable<ValidationError> Validate(ValidationParameters validationParameters)
        {
            yield break;
        }

        private class CpuUserMetricDescriptor : IMetricDescriptor
        {
            internal static readonly IMetricDescriptor Instance = new CpuUserMetricDescriptor();

            public string Id => "CPU User Time";
            public string DisplayName => Id;
            public string Legend => Id;
            public string NumberFormat => "0.##";
            public UnitType UnitType => UnitType.Time;
            public string Unit => "ns";
            public bool TheGreaterTheBetter => false;
            public int PriorityInCategory => 1;
        }

        private class CpuPrivilegedMetricDescriptor : IMetricDescriptor
        {
            internal static readonly IMetricDescriptor Instance = new CpuPrivilegedMetricDescriptor();

            public string Id => "CPU Privileged Time";
            public string DisplayName => Id;
            public string Legend => Id;
            public string NumberFormat => "0.##";
            public UnitType UnitType => UnitType.Time;
            public string Unit => "ns";
            public bool TheGreaterTheBetter => false;
            public int PriorityInCategory => 1;
        }
    }
}