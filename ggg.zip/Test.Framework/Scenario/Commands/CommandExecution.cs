﻿using FluentAssertions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands
{
    internal abstract class CommandExecution
    {
        protected CommandExecution(ScenarioCommand command, FrameAlignedTimestamp initialTimestamp)
        {
            Command = command;
            Timestamp = initialTimestamp + command.TimeCode;
        }

        internal FrameAlignedTimestamp Timestamp { get; }

        internal ScenarioCommand Command { get; }

        internal TestRecord? Result { get; set; }

        internal bool Executed => Result is not null;

        internal void Execute(ScenarioContext scenarioContext)
        {
            if (Executed)
                return;
            if (!CanExecute(scenarioContext))
                return;
            Result = DoExecute(scenarioContext);
        }

        internal virtual bool CanExecute(ScenarioContext scenarioContext)
            => scenarioContext.ChannelRunner.Time >= Timestamp;

        internal abstract TestRecord DoExecute(ScenarioContext scenarioContext);

        public TestRecord CreateFailRecord(string scenarioName, string error, ReferenceLinearList? expected,
            ReferenceLinearList? actual)
        {
            return new LinearListTestRecord(scenarioName, Command, Command.Id, TestResult.Fail, error, expected, actual);
        }

        public TestRecord CreateFailRecord(string scenarioName, string error, AsRunLog? expected, AsRunLog? actual)
        {
            return new AsRunLogTestRecord(scenarioName, Command, Command.Id, TestResult.Fail, error, expected, actual);
        }

        protected static TestRecord CreateFailRecord(string scenarioName, string error)
        {
            return new TestRecord(scenarioName, null, null, TestResult.Fail, error);
        }

        protected TestRecord CreatePassRecord(string scenarioName)
        {
            return new TestRecord(scenarioName, Command, Command.Id, TestResult.Pass);
        }

        protected TestRecord CreatePassRecord(string scenarioName, ReferenceLinearList? referenceLinearList, ReferenceLinearList? channelReferenceLinearList)
        {
            return new LinearListTestRecord(scenarioName, Command, Command.Id, TestResult.Pass, string.Empty, referenceLinearList, channelReferenceLinearList);
        }

        protected TestRecord CreatePassRecord(string scenarioName, AsRunLog? expectedAsRunLogMessage, AsRunLog? channelAsRunLogMessage)
        {
            return new AsRunLogTestRecord(scenarioName, Command, Command.Id, TestResult.Pass, string.Empty, expectedAsRunLogMessage, channelAsRunLogMessage);
        }

        public static ImmutableDictionary<Type, ConstructorInfo> Constructors { get; } =
            Assembly
               .GetExecutingAssembly()
               .GetTypes()
               .Where(t => t.IsAssignableTo(typeof(CommandExecution)) && !t.IsAbstract)
               .Select(t => t.GetConstructors().First())
               .Where(c => HasCompatibleParameters(c))
               .ToImmutableDictionary(
                    c => c.GetParameters().First().ParameterType,
                    c => c);

        private static bool HasCompatibleParameters(ConstructorInfo constructor)
        {
            ParameterInfo[] parameters = constructor.GetParameters();
            if (parameters.Length != 2)
                return false;
            return
                parameters[0].ParameterType.IsAssignableTo(typeof(ScenarioCommand)) &&
                parameters[1].ParameterType == typeof(FrameAlignedTimestamp);
        }

        internal static CommandExecution Create(ScenarioCommand command, FrameAlignedTimestamp initialTimestamp)
        {
            if (!Constructors.TryGetValue(command.GetType(), out ConstructorInfo? value))
                throw new ScenarioException("Cannot create command execution wrapper for type {type}");
            return (CommandExecution)value.Invoke(new object[] { command, initialTimestamp });
        }

        protected bool AreListsReady(ScenarioContext scenarioContext)
            // Scheduling happens as a result of a play command issued on the frame
            // so the results cannot be seen until the next frame
            => scenarioContext.ChannelRunner.Time > Timestamp && scenarioContext.ListsReadyFor >= Timestamp;
    }

    internal abstract class CommandExecution<T> : CommandExecution where T : ScenarioCommand
    {
        protected CommandExecution(T command, FrameAlignedTimestamp initialTimestamp)
            : base(command, initialTimestamp)
        {
            Command = command;
        }

        internal new T Command { get; }

    }
}