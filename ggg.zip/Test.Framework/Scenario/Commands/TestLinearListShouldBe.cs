using Pebble.Oceans.Automation.Test.Framework.Comparers;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

public record TestLinearListShouldBe(
    FrameAlignedTimeDifference TimeCode, 
    ScenarioCommandLinearListParams LinearList) 
    : ScenarioCommand(nameof(TestLinearListShouldBe), TimeCode);

internal class TestLinearListShouldBeExecution : CommandExecution<TestLinearListShouldBe>
{
    public TestLinearListShouldBeExecution(TestLinearListShouldBe command, FrameAlignedTimestamp initialTimestamp)
        : base(command, initialTimestamp)
    { }

    internal override bool CanExecute(ScenarioContext scenarioContext)
        => AreListsReady(scenarioContext);

    internal override TestRecord DoExecute(ScenarioContext scenarioContext)
    {
        ReferenceLinearList? channelReferenceLinearList = null;

        var scenarioLinearList = scenarioContext.
            ScenarioTest.
            GetLinearList(Command.LinearList.Name);

        if (scenarioLinearList is null)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                $"invalid linear list reference: {Command.LinearList.Name}");
        }

        var referenceLinearList = scenarioLinearList.ReferenceLinearList;

        try
        {
            if (referenceLinearList is null)
            {
                return CreateFailRecord(scenarioContext.ScenarioTest.Name, "Reference linear list is null");
            }

            foreach (var operation in Command.LinearList.Operations)
            {
                referenceLinearList = operation.Execute(referenceLinearList, Command.TimeCode);
            }

            channelReferenceLinearList = scenarioContext.GetListBundleFor(Timestamp).LinearList
                   .ToReference();

            var comparer = new LinearListComparer(referenceLinearList, channelReferenceLinearList);
            if (comparer.IsDifferent)
                return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                                        comparer.Result,
                                        referenceLinearList,
                                        channelReferenceLinearList);
            else
                return CreatePassRecord(scenarioContext.ScenarioTest.Name,
                                        referenceLinearList,
                                        channelReferenceLinearList);
        }
        catch (Exception e)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                e.Message,
                referenceLinearList,
                channelReferenceLinearList);
        }
    }
}