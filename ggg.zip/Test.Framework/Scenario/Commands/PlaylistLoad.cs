﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

public record PlaylistLoad(
    string Name,
    FrameAlignedTimeDifference TimeCode,
    ScenarioCommandPlayListParams? PlayList,
    ScenarioCommandLinearListParams? LinearList)
    : ScenarioCommand(nameof(PlaylistLoad), TimeCode);

internal class PlaylistLoadExecution : CommandExecution<PlaylistLoad>
{
    private const int TimeoutMs = 2000;

    public PlaylistLoadExecution(PlaylistLoad command, FrameAlignedTimestamp initialTimestamp)
        : base(command, initialTimestamp)
    { }

    internal override TestRecord DoExecute(ScenarioContext scenarioContext)
    {
        var scenarioPlaylist = scenarioContext.
            ScenarioTest.
            Playlists.
            FirstOrDefault(p => p.Name == Command.Name);

        if (scenarioPlaylist is null)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                $"invalid playlist reference: {Command.Name}");
        }

        try
        {
            scenarioContext.ChannelRunner.LoadPlaylist(scenarioPlaylist.Playlist!);
            WaitScheduleReady(scenarioContext.ChannelRunner).Wait(TimeoutMs);

            scenarioContext.ChannelRunner.Cue(null);
            WaitScheduleReady(scenarioContext.ChannelRunner).Wait(TimeoutMs);

            scenarioContext.ChannelRunner.PlayNext();
            WaitScheduleReady(scenarioContext.ChannelRunner).Wait(TimeoutMs);

            return CreatePassRecord(scenarioContext.ScenarioTest.Name);
        }
        catch (Exception e)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name, e.Message);
        }
    }

    private static Task WaitScheduleReady(ChannelRunner channelRunner)
    {
        TaskCompletionSource taskCompletionSource = new();
        channelRunner.ChannelContext.PresentationListProvider.PresentationListReady += (sender, e) => taskCompletionSource.TrySetResult();

        return taskCompletionSource.Task;
    }
}