﻿using FluentAssertions;
using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Test.Framework.Comparers;
using Pebble.Serialization;
using System.Json;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

public record TestAsRunLogShouldBe(
    FrameAlignedTimeDifference TimeCode,
    ScenarioCommandAsRunLogParams AsRunLog)
    : ScenarioCommand(nameof(TestAsRunLogShouldBe), TimeCode);

internal class TestAsRunLogShouldBeExecution : CommandExecution<TestAsRunLogShouldBe>
{
    public TestAsRunLogShouldBeExecution(TestAsRunLogShouldBe command, FrameAlignedTimestamp initialTimestamp)
        : base(command, initialTimestamp)
    { }

    internal override TestRecord DoExecute(ScenarioContext scenarioContext)
    {
        AsRunLog? expectedAsRunLogEvents = scenarioContext
        .ScenarioTest
        .GetAsRunLog(Command.AsRunLog.Name)?
        .AsRunLogEvents;

        if (expectedAsRunLogEvents is null)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                $"Invalid AsRunLog reference: {Command.AsRunLog.Name}");
        }


        if (scenarioContext.ChannelRunner.AsRunLogger is not FileAsRunLogger asRunLogger)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                     "AsRunLogger is not available");
        }

        var asRunLogFileName = asRunLogger.LogFile;

        if (!File.Exists(asRunLogFileName))
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                    $"Invalid AsRunLog File: {asRunLogFileName}");
        }

        AsRunLog? channelAsRunLogEvents = null;

        try
        {
            asRunLogger.SaveAsRunLog();
            channelAsRunLogEvents = GetAsRunLog(asRunLogFileName);

            if (channelAsRunLogEvents is null)
                return CreateFailRecord(scenarioContext.ScenarioTest.Name, $"AsRun log events for the Device {Command.AsRunLog.Device} could not be parsed", expectedAsRunLogEvents, null);

            var deviceAsRunLogEvents = channelAsRunLogEvents.AsRunLogEvents.Where(m => m.DeviceController == Command.AsRunLog.Device).ToList();

            var comparer = new AsRunLogComparer(expectedAsRunLogEvents.AsRunLogEvents, deviceAsRunLogEvents);
            if (comparer.IsDifferent)
                return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                                        comparer.Result,
                                        expectedAsRunLogEvents,
                                        new AsRunLog(deviceAsRunLogEvents.ToImmutableArray()));
            else
                return CreatePassRecord(scenarioContext.ScenarioTest.Name,
                                        expectedAsRunLogEvents,
                                        new AsRunLog(deviceAsRunLogEvents.ToImmutableArray()));
        }
        catch (Exception e)
        {
            var deviceAsRunLogEvents = channelAsRunLogEvents?.AsRunLogEvents.Where(m => m.DeviceController == Command.AsRunLog.Device);

            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                                    e.Message,
                                    expectedAsRunLogEvents,
                                    new AsRunLog((deviceAsRunLogEvents ?? Array.Empty<AsRunLogEvent>()).ToImmutableArray()));
        }

        static AsRunLog? GetAsRunLog(string asRunLogFileName)
        {
            JsonValue? jsonValue = File.ReadAllText(asRunLogFileName).ToJson();
            return jsonValue.ToAsRunLog();
        }
    }
}