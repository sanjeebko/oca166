﻿using Pebble.Oceans.Automation.Test.Framework.Scenario.Operations;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

[PossibleChild("Command", nameof(TestLinearListShouldBeEmpty), typeof(TestLinearListShouldBeEmpty))]
[PossibleChild("Command", nameof(TestLinearListShouldBe), typeof(TestLinearListShouldBe))]
[PossibleChild("Command", nameof(TestAsRunLogShouldBe), typeof(TestAsRunLogShouldBe))]
[PossibleChild("Command", nameof(PlaylistLoad), typeof(PlaylistLoad))]
public abstract record ScenarioCommand(string Command,
                                       FrameAlignedTimeDifference TimeCode)
{
    public string Id
        => @$"{GetType().Name} {TimeCode.ToString()
            .Replace(":", "-")
            .Replace(".", "-")}";
}

public record ScenarioCommandLinearListParams(string Name, ImmutableArray<OperationBase> Operations);
public record ScenarioCommandAsRunLogParams(string Name, string Device);
public record ScenarioCommandPlayListParams(string Name, ImmutableArray<OperationBase> Operations);