﻿using FluentAssertions;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

public record TestLinearListShouldBeEmpty(
    FrameAlignedTimeDifference TimeCode) 
    : ScenarioCommand(nameof(TestLinearListShouldBeEmpty), TimeCode);

internal class TestLinearListShouldBeEmptyExecution : CommandExecution<TestLinearListShouldBeEmpty>
{
    public TestLinearListShouldBeEmptyExecution(TestLinearListShouldBeEmpty command, FrameAlignedTimestamp initialTimestamp)
        : base(command, initialTimestamp)
    { }

    internal override bool CanExecute(ScenarioContext scenarioContext)
        => AreListsReady(scenarioContext);

    internal override TestRecord DoExecute(ScenarioContext scenarioContext)
    {
        ReferenceLinearList? channelReferenceLinearList = null;

        try
        {
            channelReferenceLinearList = scenarioContext.GetListBundleFor(Timestamp).LinearList
                   .ToReference();

            channelReferenceLinearList.Events.Length.Should()
                .Be(channelReferenceLinearList.Events.Last() is ReferenceIdleLinearListEvent ? 1 : 0);

            return CreatePassRecord(scenarioContext.ScenarioTest.Name, null, channelReferenceLinearList);
        }
        catch (Exception e)
        {
            return CreateFailRecord(scenarioContext.ScenarioTest.Name,
                e.Message,
                null,
                channelReferenceLinearList);
        }
    }
}