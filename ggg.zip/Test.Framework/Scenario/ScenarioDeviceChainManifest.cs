﻿using Pebble.Oceans.Automation.Devices;
using Pebble.Serialization;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record ScenarioDeviceChainManifest(string Name, DeviceChainManifest? Yaml, string? Path)
{
    public DeviceChainManifest? DeviceChainManifest { get; private set; }

    public void Init(ScenarioTest scenarioTest)
    {
        int propertyCheckCount = 0;

        propertyCheckCount += !string.IsNullOrEmpty(Path) ? 1 : 0;
        propertyCheckCount += Yaml is not null ? 1 : 0;

        switch (propertyCheckCount)
        {
            case 0:
                throw new ArgumentException($"Yaml or Path not set for command {nameof(ScenarioDeviceChainManifest)}");
            case > 1:
                throw new ArgumentException($"Only Yaml or Path can be set for command {nameof(ScenarioDeviceChainManifest)}");
        }

        DeviceChainManifest = Yaml ?? File.ReadAllText(Path!).ToYaml().ToDeviceChainManifest();
    }
}