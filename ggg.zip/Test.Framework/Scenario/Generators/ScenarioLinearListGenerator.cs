﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

[PossibleChild("Name", nameof(SimpleLinearListGenerator), typeof(SimpleLinearListGenerator))]
public abstract record ScenarioLinearListGenerator(string ChannelId,
    string PlaylistName,
    int EventCount,
    bool Fixed,
    FrameAlignedTimeDifference Duration)
{
    public abstract ReferenceLinearList GetReferenceLinearList(FrameAlignedTimestamp startTime, LinearListConfiguration linearListConfiguration);
}