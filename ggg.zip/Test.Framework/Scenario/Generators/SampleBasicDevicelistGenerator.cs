﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

public record SampleBasicDevicelistGenerator(string ChannelId, string PlaylistName, int EventCount, FrameAlignedTimeDifference Duration, FrameAlignedTimestamp StartTime)
    : BasePlaylistGenerator(ChannelId, PlaylistName, EventCount, Duration, StartTime)
{
    public ReferenceDeviceList GetReferenceDeviceList(ReferenceLinearList referenceLinearList)
    {
        var referenceDeviceListEvents = ImmutableArray.CreateBuilder<ReferenceDeviceListEvent>();
        FrameAlignedTimestamp currentFrameAlignedTimestamp = StartTime;
        foreach (ReferenceLinearListEvent events in referenceLinearList.Events)
        {
            switch (events)
            {
                case ReferencePrimaryLinearListEvent primaryLinearListEvent:
                    referenceDeviceListEvents.Add(
                        new ReferenceDeviceListEvent(primaryLinearListEvent.ParentId,
                            primaryLinearListEvent.CalculatedTiming));
                    break;
            }
            currentFrameAlignedTimestamp += Duration;
        }
        return new ReferenceDeviceList(referenceDeviceListEvents.ToImmutable());
    }
}
