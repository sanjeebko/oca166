﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

public record SimplePlaylistGenerator(string ChannelId,
    string PlaylistName,
    int EventCount,
    FrameAlignedTimeDifference Duration,
    bool Fixed) : ScenarioPlaylistGenerator(ChannelId, PlaylistName, EventCount, Duration, Fixed)
{
    public AnchoredPlaylist GetSequentialEventsAnchoredPlaylist(FrameAlignedTimestamp startTime) => GetAnchoredPlaylist(startTime, "Sequential", "Seq");

    public AnchoredPlaylist GetFixedEventsAnchoredPlaylist(FrameAlignedTimestamp startTime) => GetAnchoredPlaylist(startTime, "Fixed", "Fix");

    public override AnchoredPlaylist GetAnchoredPlaylist(FrameAlignedTimestamp startTime, string eventType, string eventTypeCode)
    {
        if (EventCount < 1)
            throw new ArgumentException($"{nameof(EventCount)} can not be less than 1.");

        FrameAlignedTimestamp currentFrameAlignedTimestamp = startTime;

        var complexListEvents = ImmutableArray.CreateBuilder<PlaylistItem>();

        for (int i = 1; i <= EventCount; i++)
        {
            var complexListEvent = new PlaylistEvent(
                $"{eventTypeCode}{i}",
                $"{eventType} Event {i}",
                new Timing(
                    Fixed ? new FixedTiming(currentFrameAlignedTimestamp) : new SequentialTiming(),
                    new SequentialTiming(),
                    Duration),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                $"Video{i}.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd))));

            complexListEvents.Add(complexListEvent);
            if (Fixed)
                currentFrameAlignedTimestamp += Duration;
        }

        var playlist = new Playlist(
            ChannelId,
            PlaylistName,
            complexListEvents.ToImmutableArray()
        );

        return new AnchoredPlaylist(playlist, null);
    }
}