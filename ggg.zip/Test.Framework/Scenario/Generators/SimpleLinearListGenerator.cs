﻿using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

public record SimpleLinearListGenerator(string ChannelId,
                                   string PlaylistName,
                                   int EventCount,
                                   bool Fixed,
                                   FrameAlignedTimeDifference Duration
                                   ) : ScenarioLinearListGenerator(ChannelId, PlaylistName, EventCount, Fixed, Duration)
{
    public override ReferenceLinearList GetReferenceLinearList(FrameAlignedTimestamp startTime,
                                                                LinearListConfiguration linearListConfiguration)
    {
        var referenceLinearListEvents = ImmutableArray.CreateBuilder<ReferenceLinearListEvent>();
        FrameAlignedTimestamp currentFrameAlignedTimestamp = startTime;

        for (int i = 1; i <= EventCount; i++)
        {
            referenceLinearListEvents.Add(
                new ReferencePrimaryLinearListEvent($"Event{i}",
                    new FrameAlignedTimeInterval(currentFrameAlignedTimestamp, Duration),
                    LinearListEventStatus.Normal));
            currentFrameAlignedTimestamp += Duration;
        }

        FrameAlignedTimeDifference idleDuration = startTime + linearListConfiguration.MaxDuration - currentFrameAlignedTimestamp;
        if (idleDuration > FrameAlignedTimeDifference.Zero)
        {
            referenceLinearListEvents.Add
                (new ReferenceIdleLinearListEvent(
                    new FrameAlignedTimeInterval(currentFrameAlignedTimestamp, idleDuration)
                    )
                );
        }

        return new ReferenceLinearList(
            referenceLinearListEvents.ToImmutable()
            );
    }

    public ReferenceLinearList GetLinearListFromPlaylist(AnchoredPlaylist anchoredPlaylist, FrameAlignedTimestamp currentTime)
    {
        var referenceLinearListEvents = ImmutableArray.CreateBuilder<ReferenceLinearListEvent>();

        FrameAlignedTimestamp currentFrameAlignedTimestamp = anchoredPlaylist.Anchor?.StartTime is null
            ? currentTime
            : (FrameAlignedTimestamp)anchoredPlaylist.Anchor.StartTime;

        foreach (PlaylistItem events in anchoredPlaylist.Playlist.Events)
        {
            referenceLinearListEvents.Add(
                new ReferencePrimaryLinearListEvent(
                    events.Id,
                    new FrameAlignedTimeInterval(currentFrameAlignedTimestamp, Duration),
                    LinearListEventStatus.Normal));
            currentFrameAlignedTimestamp += Duration;
        }

        return new ReferenceLinearList(
            referenceLinearListEvents.ToImmutable()
        );
    }
}