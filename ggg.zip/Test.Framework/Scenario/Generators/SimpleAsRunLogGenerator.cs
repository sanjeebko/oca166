﻿using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Channel;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

public record SimpleAsRunLogGenerator(
    int EventCount,
    string Device,
    FrameAlignedTimeDifference EventDuration,
    FrameAlignedTimeDifference TotalDuration,
    FrameAlignedTimeDifference FirstEventStartCorrection) : ScenarioAsRunLogGenerator(EventCount, Device, EventDuration, TotalDuration)
{
    public override AsRunLog GetScenarioAsRunLogEvents(
        FrameAlignedTimestamp startTime,
        LinearListConfiguration linearListConfiguration)
    {
        var asRunLogEvents = ImmutableArray.CreateBuilder<AsRunLogEvent>();
        FrameAlignedTimestamp currentFrameAlignedTimestamp = startTime;

        FrameAlignedTimeInterval endTime = new(startTime, TotalDuration);

        for (int index = 1; index <= EventCount; index++)
        {
            if (endTime.Contains(currentFrameAlignedTimestamp))
            {
                asRunLogEvents.Add(new AsRunLogEvent("Start",
                                               $"{Device}",
                                               $"Event{index}#0",
                                               $"{currentFrameAlignedTimestamp + (index == 1 ? FirstEventStartCorrection : FrameAlignedTimeDifference.Zero)}",
                                               $"Video{index}.mxf",
                                               ""));
            }
            currentFrameAlignedTimestamp += EventDuration;

            if (endTime.Contains(currentFrameAlignedTimestamp))
            {
                asRunLogEvents.Add(new AsRunLogEvent("End",
                                             "Video&Audio",
                                             $"Event{index}#0",
                                             $"{currentFrameAlignedTimestamp}",
                                             $"Video{index}.mxf",
                                             ""));
            }
        }

        return new AsRunLog(asRunLogEvents.ToImmutable());
    }
}