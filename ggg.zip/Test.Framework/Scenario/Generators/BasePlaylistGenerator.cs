﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

public abstract record BasePlaylistGenerator(string ChannelId,
    string PlaylistName,
    int EventCount,
    FrameAlignedTimeDifference Duration,
    FrameAlignedTimestamp StartTime);