﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

[PossibleChild("Name", nameof(SimplePlaylistGenerator), typeof(SimplePlaylistGenerator))]
public abstract record ScenarioPlaylistGenerator(string ChannelId,
    string PlaylistName,
    int EventCount,
    FrameAlignedTimeDifference Duration,
    bool Fixed)
{
    public abstract AnchoredPlaylist GetAnchoredPlaylist(FrameAlignedTimestamp startTime, string eventType, string eventTypeCode);
}