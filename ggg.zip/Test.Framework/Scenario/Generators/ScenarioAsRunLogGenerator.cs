﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

[PossibleChild("Name", nameof(SimpleAsRunLogGenerator), typeof(SimpleAsRunLogGenerator))]
public abstract record ScenarioAsRunLogGenerator(
    int EventCount,
    string Device,
    FrameAlignedTimeDifference EventDuration,
    FrameAlignedTimeDifference TotalDuration)
{
    public abstract AsRunLog GetScenarioAsRunLogEvents(FrameAlignedTimestamp startTime, LinearListConfiguration linearListConfiguration);
}