using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Devices;
using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Clock;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;
using Pebble.Serialization;
using Pebble.Service.Automation;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public class ScenarioTestRunner
{
    private const int TestTimeoutMs = 20000;
    private const int MaxListHistory = 100;

    private readonly ILogger _logger;
    private readonly ScenarioTestFilesWriter _scenarioTestFilesWriter;

    private readonly List<ListBundle> _listHistory = new();

    public ScenarioTestRunner(ILogger logger, TestRunnerConfig testRunnerConfig)
    {
        _logger = logger;
        _scenarioTestFilesWriter = new ScenarioTestFilesWriter(testRunnerConfig.DumpFolder);
    }

    public ScenarioTestResults RunScenarios(ImmutableArray<string> scenarioFiles, LinearListConfiguration linearListConfiguration)
    {
        List<TestRecord> testRecords = new();

        foreach (var file in scenarioFiles)
        {
            try
            {
                testRecords.AddRange(RunScenario(file, linearListConfiguration));
            }
            catch (Exception e)
            {
                _logger.LogError($"Error found for file {file}", e);
                testRecords.Add(new TestRecord($"Error found for file {file}, error: {e.Message}"));
            }
        }

        return new ScenarioTestResults(testRecords.ToImmutableArray());
    }

    public IEnumerable<TestRecord> RunScenario(string file, LinearListConfiguration linearListConfiguration, string asRunLogPath = "")
    {
        ScenarioTest scenarioTest = GetScenarioTestFile(file);
        scenarioTest.Init(linearListConfiguration);

        if (scenarioTest.Skip)
        {
            _logger.LogMessage($"Skipping scenario '{scenarioTest.Name}'");
            List<TestRecord> testRecords = new();
            testRecords.AddRange(GenerateNotRunTestRecords(scenarioTest.Commands, scenarioTest.Name, 0));

            return testRecords;
        }

        return RunCommands(linearListConfiguration, asRunLogPath, scenarioTest);
    }

    private IEnumerable<TestRecord> RunCommands(LinearListConfiguration linearListConfiguration, string asRunLogPath, ScenarioTest scenarioTest)
    {
        CommandExecution[] commandsToRun = scenarioTest.Commands
            .Select(c => CommandExecution.Create(c, scenarioTest.InitialTime))
            .ToArray();
        DeviceChainManifest deviceChain = scenarioTest.DeviceChainManifest.DeviceChainManifest!;

        AsRunLogger asRunLogger = GetAsRunLogger(asRunLogPath, scenarioTest, scenarioTest.Commands);

        using ChannelRunner channelRunner =
            new(new ChannelContext(
                    new ChannelConfiguration(deviceChain, linearListConfiguration, FrameAlignedTimeDifference.Parse("00:00:05:00"))));

        using AdjustAbleClockRunner clockRunner = new AdjustAbleClockRunner(new ClockSource(), channelRunner);

        channelRunner.AsRunLogger = asRunLogger;
        ScenarioContext scenarioContext = new(clockRunner, channelRunner, scenarioTest, ImmutableArray<ListBundle>.Empty, FrameAlignedTimestamp.Zero);

        _logger.LogMessage($"Executing scenario '{scenarioTest.Name}'");

        TaskCompletionSource finishedTrigger = new();
        InitializeChannelRunner();
        finishedTrigger.Task.Wait(TestTimeoutMs);

        if (scenarioTest.StopOnError)
        {
            bool afterError = false;
            foreach (var command in commandsToRun)
            {
                if (afterError && !command.Executed)
                    command.Result = new TestRecord(
                        scenarioTest.Name,
                        command.Command,
                        command.Command.Id,
                        TestResult.NotRun);
                afterError |= command.Result is not null && command.Result!.Result == TestResult.Fail;
            }
        }

        foreach (var command in commandsToRun)
            if (!command.Executed)
                command.Result = new TestRecord(
                    scenarioTest.Name,
                    command.Command,
                    command.Command.Id,
                    TestResult.Fail,
                    $"{command.Command.Id} was not run");

        return commandsToRun.Select(c => c.Result!);

        void ChannelRunner_NewFrame(object? sender, TimeEventArgs e)
        {
            if (finishedTrigger.Task.IsCompleted)
                return;

            FrameAlignedTimestamp currentListTime = scenarioContext.ChannelRunner.CurrentLists.Timestamp;
            FrameAlignedTimestamp scheduleRequestTime = scenarioContext.ChannelRunner.ChannelContext.LastSchedulingRequestTime;
            if (scenarioContext.ChannelRunner.CurrentLists.Timestamp > FrameAlignedTimestamp.Zero)
            {
                if (_listHistory.Count == 0 || currentListTime > _listHistory[^1].Timestamp)
                {
                    _listHistory.Add(scenarioContext.ChannelRunner.CurrentLists);
                    while (_listHistory.Count > MaxListHistory)
                        _listHistory.RemoveAt(0);
                    scenarioContext = scenarioContext with { ListHistory = _listHistory.ToImmutableArray() };
                }

                bool schedulingInProgress = currentListTime < scheduleRequestTime;
                scenarioContext = scenarioContext with
                {
                    ListsReadyFor = schedulingInProgress ? scheduleRequestTime : scenarioContext.ChannelRunner.Time
                };
            }

            var remainingCommands = commandsToRun.Where(c => !c.Executed).ToImmutableArray();

            if (remainingCommands.Length == 0)
            {
                finishedTrigger.SetResult();
                return;
            }

            foreach (var command in remainingCommands)
                if (command.CanExecute(scenarioContext))
                    try
                    {
                        command.Execute(scenarioContext);

                        if (command.Executed)
                        {
                            TestRecord testResult = command.Result!;

                            _scenarioTestFilesWriter.WriteResult(scenarioTest, command.Command, testResult);

                            if (testResult.Result == TestResult.Fail && scenarioTest.StopOnError)
                            {
                                finishedTrigger.SetResult();
                                return;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        _logger.LogError("Error processing scenario", ex);
                    }
        }

        void InitializeChannelRunner()
        {
            channelRunner.NewFrame += ChannelRunner_NewFrame;
            channelRunner.StopOnEmptyLinearList = false;
            clockRunner.UpdateTime(scenarioTest.InitialTime - deviceChain.GetPreroll());
            clockRunner.SetClockMode(scenarioTest.DisableFasterRealTime
                ? ClockMode.RealTime
                : ClockMode.FastForwardToEndOfPlaylist);
        }
    }

    private static ScenarioTest GetScenarioTestFile(string file)
        => File.ReadAllText(file).ToYaml().ToScenarioTest();

    private static AsRunLogger GetAsRunLogger(string asRunLogPath, ScenarioTest scenarioTest, IEnumerable<ScenarioCommand> commandsToRun)
    {
        if (commandsToRun.Any(x => x.Command == nameof(TestAsRunLogShouldBe)))
        {
            if (string.IsNullOrEmpty(asRunLogPath) || !Directory.Exists(asRunLogPath))
                asRunLogPath = Path.Join(Directory.GetCurrentDirectory(), FileAsRunLogger.DefaultLogFolder);
            return new FileAsRunLogger(asRunLogPath,
                                       prefix: $"ScenarioTest_{scenarioTest.Name.Replace(" ", "")}",
                                       postfix: $"{DateTime.Now:HHmmss}",
                                       saveToFile: true);
        }

        return new ConsoleAsRunLogger("ConsoleAsRunLogger");
    }

    private static IEnumerable<TestRecord> GenerateNotRunTestRecords(ImmutableArray<ScenarioCommand> commands, string scenarioName, int from)
    {
        if (from < 0 || from >= commands.Length)
        {
            return new List<TestRecord>();
        }

        return commands.Skip(from).Select(c => new TestRecord(scenarioName, c, c.Id, TestResult.NotRun));
    }
}