﻿using System.Runtime.Serialization;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario
{
    [Serializable]
    public class ScenarioException : Exception
    {
        public ScenarioException()
        {
        }

        public ScenarioException(string? message) : base(message)
        {
        }

        public ScenarioException(string? message, Exception? innerException) : base(message, innerException)
        {
        }

        protected ScenarioException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}
