﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public interface ILogger
{
    void LogMessage(string message);

    void LogError(string message, Exception e);
}

public class ConsoleLogger : ILogger
{
    public void LogMessage(string message)
    {
        Console.WriteLine($"{DateTime.UtcNow} {message}");
    }

    public void LogError(string message, Exception e)
    {
        Console.WriteLine($"{DateTime.UtcNow} {message} {e.Message}");
    }
}