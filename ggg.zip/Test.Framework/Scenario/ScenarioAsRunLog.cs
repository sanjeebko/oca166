﻿using Pebble.Oceans.Automation.AsRunLog;
using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;
using Pebble.Serialization;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record ScenarioAsRunLog(string Name,
     AsRunLog? Yaml,
     ScenarioAsRunLogGenerator? Generator,
    string? Path)
{
    public AsRunLog? AsRunLogEvents { get; private set; }

    public void Init(ScenarioTest scenarioTest, LinearListConfiguration linearListConfiguration)
    {
        int propertyCheckCount = 0;

        propertyCheckCount += !string.IsNullOrEmpty(Path) ? 1 : 0;
        propertyCheckCount += Yaml is not null ? 1 : 0;
        propertyCheckCount += Generator is not null ? 1 : 0;

        switch (propertyCheckCount)
        {
            case 0:
                throw new ArgumentException($"Yaml, Path or Generator not set for command {nameof(ScenarioAsRunLog)}");
            case > 1:
                throw new ArgumentException($"Only Yaml, Path or Generator can be set for command {nameof(ScenarioAsRunLog)}");
        }

        if (Yaml is not null)
        {
            AsRunLogEvents = Yaml;
        }
        else if (Generator is not null)
        {
            AsRunLogEvents = Generator.GetScenarioAsRunLogEvents(scenarioTest.InitialTime, linearListConfiguration);
        }
        else
        {
            AsRunLogEvents = File.ReadAllText(Path!)
                .ToYaml()
                .ToAsRunLog();
        }
    }
}

[GenerateSerialization]
public record AsRunLog(ImmutableArray<AsRunLogEvent> AsRunLogEvents);