﻿using Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

internal class ScenarioTestFilesWriter
{
    private readonly string _sessionDirectory;

    public ScenarioTestFilesWriter(string sessionDirectory)
    {
        _sessionDirectory = sessionDirectory;
    }

    public void WriteResult(ScenarioTest scenarioTest, ScenarioCommand scenarioCommand, TestRecord testRecord)
    {
        if (!scenarioTest.DumpLevel.ShouldDumpRecord(testRecord))
            return;

        string recordFolder = GetRecordFolder(testRecord);

        switch (testRecord)
        {
            case LinearListTestRecord linearListTestRecord:
                WriteLinearListResult(scenarioCommand, recordFolder, linearListTestRecord);
                break;

            case AsRunLogTestRecord asRunLogTestRecord:
                WriteAsRunLogResult(scenarioCommand, recordFolder, asRunLogTestRecord);
                break;
        }
    }

    private static void WriteAsRunLogResult(ScenarioCommand scenarioCommand, string recordFolder, AsRunLogTestRecord asRunLogTestRecord)
    {
        (string asRunLogName, string deviceName) = scenarioCommand switch
        {
            TestAsRunLogShouldBe testAsRunLogShouldBe => (testAsRunLogShouldBe.AsRunLog.Name, testAsRunLogShouldBe.AsRunLog.Device.Replace(" ", "")),
            _ => throw new NotImplementedException()
        };

        if (asRunLogTestRecord.Expected is not null)
        {
            var fileName = Path.Combine(recordFolder, $"ExpectedAsRunLog_{asRunLogName}_{deviceName}.yaml");
            asRunLogTestRecord.ExpectedAsRunLogFile = fileName;
            CreateFile(fileName, asRunLogTestRecord.Expected.ToYamlString());
        }

        if (asRunLogTestRecord.Actual is not null)
        {
            var fileName = Path.Combine(recordFolder, $"ChannelAsRunLog_{asRunLogName}_{deviceName}.yaml");
            asRunLogTestRecord.ChannelAsRunLogFile = fileName;
            CreateFile(fileName, asRunLogTestRecord.Actual.ToYamlString());
        }
    }

    private static void WriteLinearListResult(ScenarioCommand scenarioCommand, string recordFolder, LinearListTestRecord linearListTestRecord)
    {
        if (linearListTestRecord.Expected is not null)
        {
            string linearListName = scenarioCommand switch
            {
                TestLinearListShouldBe testLinearListShouldBe => testLinearListShouldBe.LinearList.Name,
                _ => throw new NotImplementedException()
            };
            var fileName = Path.Combine(recordFolder, $"Expected Scenario Linear List {linearListName}.yaml");
            CreateFile(fileName, linearListTestRecord.Expected.ToYamlString());
        }

        if (linearListTestRecord.Actual is not null)
        {
            var fileName = Path.Combine(recordFolder, "Channel Scenario Linear List.yaml");
            CreateFile(fileName, linearListTestRecord.Actual.ToYamlString());
        }
    }

    private static void CreateFile(string fileName, string? content)
        => File.WriteAllText(fileName, content);

    private string GetRecordFolder(TestRecord testRecord)
    {
        string recordFolder = Path.Combine(_sessionDirectory,
            $"{testRecord.ScenarioName}",
            $"{testRecord.Id}");
        if (Directory.Exists(recordFolder))
            Directory.Delete(recordFolder, true);

        Directory.CreateDirectory(recordFolder);
        return recordFolder;
    }
}