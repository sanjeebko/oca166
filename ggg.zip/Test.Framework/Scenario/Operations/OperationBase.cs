﻿using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Operations;

[PossibleChild("Operation", nameof(RemoveFirst), typeof(RemoveFirst))]
[PossibleChild("Operation", nameof(GetRange), typeof(GetRange))]
[PossibleChild("Operation", nameof(AdjustLastIdleEndTime), typeof(AdjustLastIdleEndTime))]
public abstract record OperationBase(string Operation)
{
    public abstract ReferenceLinearList Execute(ReferenceLinearList referenceLinearlist,
        FrameAlignedTimeDifference operationTimecode);
}