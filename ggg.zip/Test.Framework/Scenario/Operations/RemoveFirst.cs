﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Operations;

public record RemoveFirst(int Count) : OperationBase(nameof(RemoveFirst))
{
    public override ReferenceLinearList Execute(ReferenceLinearList referenceLinearlistEvents,
        FrameAlignedTimeDifference operationTimecode)
    {
        if (Count <= 0 || Count > referenceLinearlistEvents.Events.Length)
        {
            throw new ScenarioException($"{nameof(RemoveFirst)}:{operationTimecode} invalid count:{Count}");
        }

        return new ReferenceLinearList(
            ImmutableArray.Create(
                referenceLinearlistEvents.Events,
                Count,
                referenceLinearlistEvents.Events.Length - Count));
    }
}
