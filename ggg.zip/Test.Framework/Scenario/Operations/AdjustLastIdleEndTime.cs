﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Operations;

public record AdjustLastIdleEndTime(FrameAlignedTimeDifference Value) : OperationBase(nameof(AdjustLastIdleEndTime))
{
    public override ReferenceLinearList Execute(ReferenceLinearList referenceLinearlist, FrameAlignedTimeDifference operationTimecode) 
        => referenceLinearlist.Events.LastOrDefault() is ReferenceIdleLinearListEvent lastEvent
            ? referenceLinearlist.AdjustLastIdleEndTime(lastEvent.CalculatedTiming.End + Value)
            : referenceLinearlist;
}
