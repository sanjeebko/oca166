﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario.Operations;

public record GetRange(int From, int Count) : OperationBase(nameof(GetRange))
{
    public override ReferenceLinearList Execute(ReferenceLinearList referenceLinearlistEvents,
        FrameAlignedTimeDifference operationTimecode)
    => new ReferenceLinearList(referenceLinearlistEvents.Events
            .Skip(From)
            .Take(Count)
            .ToImmutableArray());
}