﻿using Pebble.Oceans.Automation.Clock;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record ScenarioContext(
    ClockRunner ClockRunner,
    ChannelRunner ChannelRunner,
    ScenarioTest ScenarioTest,
    ImmutableArray<ListBundle> ListHistory,
    FrameAlignedTimestamp ListsReadyFor)
{
    public ListBundle GetListBundleFor(FrameAlignedTimestamp time)
    {
        int n = ListHistory.Length - 1;
        while (n > 0 && ListHistory[n - 1].Timestamp >= time)
            n--;
        return ListHistory[n];
    }
}