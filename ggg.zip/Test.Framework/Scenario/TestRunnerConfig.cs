﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record TestRunnerConfig(string DumpFolder);

