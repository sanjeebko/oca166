﻿using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;
using Pebble.Serialization;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record ScenarioPlaylist(string Name, AnchoredPlaylist? Yaml, ScenarioPlaylistGenerator? Generator, string? Path)
{
    public AnchoredPlaylist? Playlist { get; private set; }

    public void Init(ScenarioTest scenarioTest)
    {
        int propertyCheckCount = 0;

        propertyCheckCount += !string.IsNullOrEmpty(Path) ? 1 : 0;
        propertyCheckCount += Yaml is not null ? 1 : 0;
        propertyCheckCount += Generator is not null ? 1 : 0;

        switch (propertyCheckCount)
        {
            case 0:
                throw new ArgumentException($"Yaml, Path or Generator not set for command {nameof(ScenarioLinearList)}");
            case > 1:
                throw new ArgumentException($"Only Yaml, Path or Generator can be set for command {nameof(ScenarioLinearList)}");
        }

        if (Yaml is not null)
        {
            Playlist = Yaml;
        }
        else if (Generator is not null)
        {
            Playlist = Generator.GetAnchoredPlaylist(scenarioTest.InitialTime, "Sequential", "Event");
        }
        else
        {
            Playlist = File.ReadAllText(Path!)
                .ToYaml()
                .ToAnchoredPlaylist();
        }
    }
}