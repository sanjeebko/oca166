﻿using Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record TestRecord(string ScenarioName, ScenarioCommand? Command,  string? Id, TestResult Result,
    string Error)
{
    public TestRecord(string ScenarioName, ScenarioCommand? Command, string? Id, TestResult Result) : this(ScenarioName, Command, Id, Result, string.Empty)
    {
    }

    public TestRecord(string error) : this(string.Empty, null, string.Empty, TestResult.Fail, error)
    {
    }

    public virtual bool ShouldDump()
    {
        return false;
    }

    public bool Failed => !string.IsNullOrEmpty(Error);

    public override string ToString() => $"Scenario file: {new FileInfo(ScenarioName).Name} Id: {Id} Result:{Result} Error:{Error}";
}

public record LinearListTestRecord(string ScenarioName, ScenarioCommand Command, string? Id, TestResult Result,
    string Error, ReferenceLinearList? Expected, ReferenceLinearList? Actual) : TestRecord(ScenarioName, Command, Id, Result, Error)
{
    public override bool ShouldDump() => Expected is not null || Actual is not null;
}

public record AsRunLogTestRecord(string ScenarioName, ScenarioCommand Command, string? Id, TestResult Result,
    string Error, AsRunLog? Expected, AsRunLog? Actual) : TestRecord(ScenarioName, Command, Id, Result, Error)
{
    public string? ExpectedAsRunLogFile { get; set; }
    public string? ChannelAsRunLogFile { get; set; }

    public override bool ShouldDump() => Expected is not null || Actual is not null;
}