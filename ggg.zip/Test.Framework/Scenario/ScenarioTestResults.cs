﻿using Pebble.Oceans.Automation.TO_BE_MOVED_TO_SHARED;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public enum TestResult
{
    NotRun,
    Pass,
    Fail
}

public record ScenarioTestResults(ImmutableArray<TestRecord> Records)
{
    private readonly Exception? _exception;

    public ScenarioTestResults(Exception ex) : this(ImmutableArray<TestRecord>.Empty)
    {
        _exception = ex;
    }

    public bool IsSuccess => Records.All(t => t.Result == TestResult.Pass) && _exception == null;

    public int NumFailures => Records.Count(p => p.Result == TestResult.Fail);

    public IEnumerable<IGrouping<TestResult, TestRecord>> GroupByStatus() => from r in Records
                                                                             group r by r.Result;

    public IEnumerable<string> ToMarkDown()
    {
        List<string> results = new();

        foreach (var scenarioGroup in Records.GroupBy(r => r.ScenarioName))
        {
            var md = new MarkdownTableBuilder();
            md.SetHeader("Id", "TestResult");

            var scenarioLines = new List<string> { $"{MarkDown.H3} {scenarioGroup.Key}" };

            foreach (var testRecord in scenarioGroup)
            {
                switch (testRecord.Result)
                {
                    case TestResult.NotRun:
                        md.AddRow(testRecord.Id!, $"{MarkDown.Italic(nameof(TestResult.NotRun))}");
                        break;

                    case TestResult.Pass:
                        md.AddRow(testRecord.Id!, $"{TestResult.Pass}");
                        break;

                    case TestResult.Fail:
                        md.AddRow(testRecord.Id!, $"{MarkDown.Bold(nameof(TestResult.Fail))}");
                        break;

                    default:
                        md.AddRow(testRecord.Id!, $"{MarkDown.Bold("--")}");
                        break;
                }
            }

            scenarioLines.AddRange(md.GetLines());

            scenarioLines.Add(Environment.NewLine);

            results.AddRange(scenarioLines);
        }

        return results;
    }
}