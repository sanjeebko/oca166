﻿namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public enum DumpLevel
{
    None,
    Error,
    All
}

public static class DumpLevelExtensions
{
    public static bool ShouldDumpRecord(this DumpLevel dumpLevel, TestRecord testRecord)
    {
        return (testRecord.ShouldDump() && (dumpLevel == DumpLevel.All))
                || (dumpLevel == DumpLevel.Error && !string.IsNullOrEmpty(testRecord.Error));
    }
}