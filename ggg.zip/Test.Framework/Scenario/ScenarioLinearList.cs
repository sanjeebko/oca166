﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;
using Pebble.Serialization;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

public record ScenarioLinearList(string Name, ReferenceLinearList? Yaml, ScenarioLinearListGenerator? Generator, string? Path)
{
    public ReferenceLinearList? ReferenceLinearList { get; private set; }

    public void Init(ScenarioTest scenarioTest, LinearListConfiguration linearListConfiguration)
    {
        int propertyCheckCount = 0;

        propertyCheckCount += !string.IsNullOrEmpty(Path) ? 1 : 0;
        propertyCheckCount += Yaml is not null ? 1 : 0;
        propertyCheckCount += Generator is not null ? 1 : 0;

        switch (propertyCheckCount)
        {
            case 0:
                throw new ArgumentException($"Yaml, Path or Generator not set for command {nameof(ScenarioLinearList)}");
            case > 1:
                throw new ArgumentException($"Only Yaml, Path or Generator can be set for command {nameof(ScenarioLinearList)}");
        }

        if (Yaml is not null)
        {
            ReferenceLinearList = Yaml;
        }
        else if (Generator is not null)
        {
            ReferenceLinearList = Generator.GetReferenceLinearList(scenarioTest.InitialTime, linearListConfiguration);
        }
        else
        {
            ReferenceLinearList = File.ReadAllText(Path!)
                .ToYaml()
                .ToReferenceLinearList();
        }
    }
}