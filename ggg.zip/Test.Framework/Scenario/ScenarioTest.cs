﻿using Pebble.Oceans.Automation.Channel;
using Pebble.Oceans.Automation.Test.Framework.Scenario.Commands;
using Pebble.Serialization.Generator;

namespace Pebble.Oceans.Automation.Test.Framework.Scenario;

[GenerateSerialization]
public record ScenarioTest(string Name, FrameAlignedTimestamp InitialTime, bool DisableFasterRealTime,
    DumpLevel DumpLevel, bool StopOnError, bool Skip,
    ScenarioDeviceChainManifest DeviceChainManifest,
    ImmutableArray<ScenarioPlaylist> Playlists,
    ImmutableArray<ScenarioLinearList> LinearLists,
    ImmutableArray<ScenarioAsRunLog> AsRunLogs,
    ImmutableArray<ScenarioCommand> Commands)
{
    public void Init(LinearListConfiguration linearListConfiguration)
    {
        DeviceChainManifest.Init(this);

        //do any initialisation on member properties which rely on scenario test properties
        foreach (var scenarioLinearList in LinearLists)
        {
            scenarioLinearList.Init(this, linearListConfiguration);
        }

        foreach (var scenarioPlaylist in Playlists)
        {
            scenarioPlaylist.Init(this);
        }
        foreach (var asRunLog in AsRunLogs)
        {
            asRunLog.Init(this, linearListConfiguration);
        }
    }

    public ScenarioLinearList? GetLinearList(string name)
    {
        return LinearLists.FirstOrDefault(p => p.Name == name);
    }

    public ScenarioAsRunLog? GetAsRunLog(string name)
    {
        return AsRunLogs.FirstOrDefault(asRunLog => asRunLog.Name == name);
    }
}