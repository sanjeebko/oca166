﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

public abstract class SamplePlaylist
{
    public abstract string Name { get; }

    public abstract AnchoredPlaylist Playlist { get; }

    public virtual ReferenceLinearList? LinearList { get; } = null;
    public virtual ReferenceDeviceList? DeviceList { get; }

    public virtual int MaxLinearListSize => 10000;

    public virtual FrameAlignedTimestamp Time
        => (Playlist.Anchor?.StartTime) ?? FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00");

    internal void GeneratePlaylistFile(string path = ".", bool overwrite = false)
        => GenerateFile(path, overwrite, Playlist?.ToYamlString());

    internal void GenerateLinearlistFile(string path = ".", bool overwrite = false)
        => GenerateFile(path, overwrite, LinearList?.ToYamlString());

    internal void GenerateDevicelistFile(string path = ".", bool overwrite = false)
        => GenerateFile(path, overwrite, DeviceList?.ToYamlString());

    private void GenerateFile(string path, bool overwrite, string? content)
    {
        if (content is null)
            return;
        if (!Directory.Exists(path))
            Directory.CreateDirectory(path);
        string fileName = $@"{path}\{Name}.yaml";
        if (!overwrite && File.Exists(fileName))
        {
            Console.WriteLine($"File {fileName} already exists, skipping");
            return;
        }
        Console.WriteLine($"Generating File {fileName}");
        File.WriteAllText(fileName, content);
    }
}