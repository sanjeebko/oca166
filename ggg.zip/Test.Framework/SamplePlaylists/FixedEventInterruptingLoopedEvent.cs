﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class LoopedFixedEventInterruptingLoopedEventEvent : SamplePlaylist
{
    public override string Name => "FixedEventInterruptingLoopedEvent";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Scheduling.Playlist(
                "Pebble",
                "A single event looped group followed by a fixed event interrupting the loop",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistGroup(
                        "G1",
                        "Looped group",
                        ImmutableArray.Create<PlaylistItem>(
                            new PlaylistEvent(
                                "Looped",
                                "Looped Event",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray<MediaEvent>.Empty)
                            ),
                        new Loop(8)),
                    new PlaylistEvent(
                        "Following1",
                        "Fixed Event",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2021-10-04 10:01:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )),
            new Anchor(
                "Looped",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray.Create<LoopCounter>(
                    new LoopCounter("G1", 1)), ""));
}