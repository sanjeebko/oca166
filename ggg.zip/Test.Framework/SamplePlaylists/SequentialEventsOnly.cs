﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class SequentialEventsOnly : SamplePlaylist
{
    public override string Name => "SequentialEventsOnly";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event 1",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video1.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq2",
                        "Sequential Event 2",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video2.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq3",
                        "Sequential Event 3",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video3.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd))))
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                                new ReferencePrimaryLinearListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:30:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Seq3",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:20:00"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:40:00"),
                        FrameAlignedTimestamp.Parse("2021-10-06 10:00:00:00")))
                ));

    public override ReferenceDeviceList? DeviceList
        => new(
            ImmutableArray.Create(
                new ReferenceDeviceListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00"))),
                    new ReferenceDeviceListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:30:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00"))),
                new ReferenceDeviceListEvent(
                    "Seq3",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:20:00"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00")))
                ));
}

internal class SequentialEventsOnlyAfter1Minute : SequentialEventsOnly
{
    public override string Name => "SequentialEventsOnly After 1 minute";

    public override FrameAlignedTimestamp Time => base.Time + FrameAlignedTimeDifference.Parse("00:01:00:00");

    public override ReferenceLinearList? LinearList
        => base.LinearList!
            .SkipEvents(1)
            .AdjustLastIdleEndTime(FrameAlignedTimestamp.Parse("2021-10-06 10:01:00:00"));

    public override ReferenceDeviceList? DeviceList
        => base.DeviceList!
                .SkipEvents(1);
}

internal class SequentialEventsOnlyAfter1Hour : SequentialEventsOnly
{
    public override string Name => "SequentialEventsOnly After 1 hour";

    public override FrameAlignedTimestamp Time => base.Time + FrameAlignedTimeDifference.Parse("01:00:00:00");

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:40:00"),
                        FrameAlignedTimestamp.Parse("2021-10-06 11:00:00:00")))
                ));

    public override ReferenceDeviceList? DeviceList
        => base.DeviceList!
                .SkipEvents(3);
}