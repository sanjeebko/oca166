namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class FixedEventStartingAtSequentialEvent_End : SamplePlaylist
{
    public override string Name => "FixedEventStartingAtSequentialEvent_End";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new(
                "Pebble",
                "Fixed event Starting At Sequential Event at the end",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event 1",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video1.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq2",
                        "Sequential Event 2",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video2.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq3",
                        "Sequential Event 3",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video3.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2021-10-04 18:32:50:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video4.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd))))
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 18:32:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:20:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Seq3",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:50:00"),
                        FrameAlignedTimeDifference.Parse("00:00:00:00")),
                    LinearListEventStatus.Skipped),
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:50:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:33:20:00"),
                        FrameAlignedTimeDifference.Parse("47:58:40:00")))
                ));

    public override ReferenceDeviceList? DeviceList
        => new(
            ImmutableArray.Create(
                new ReferenceDeviceListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00"))),
                new ReferenceDeviceListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:20:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00"))),
                new ReferenceDeviceListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 18:32:50:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")))
                ));
}