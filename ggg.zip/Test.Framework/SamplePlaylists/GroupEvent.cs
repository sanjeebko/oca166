﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class GroupEvent : SamplePlaylist
{
    public override string Name => "GroupEvent";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Scheduling.Playlist(
                "HRT1",
                "Playlist with groups",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistGroup(
                        "G1",
                        "Event Trio",
                        ImmutableArray.Create<PlaylistItem>(
                            new PlaylistEvent(
                                "Seq1",
                                "Grouped Event 1",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistEvent(
                                "Seq2",
                                "Grouped Event 2",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:50:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistEvent(
                                "Seq3",
                                "Grouped Event 3",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray<MediaEvent>.Empty))),
                    new PlaylistEvent(
                        "Following1",
                        "Sequential Event 4",
                        new(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:02:00:00")),
                        ImmutableArray<MediaEvent>.Empty))),
            new Anchor(
                "G1",
                FrameAlignedTimestamp.Parse("2021-10-04 18:37:30:00"),
                ImmutableArray<LoopCounter>.Empty, ""));
}