﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class SequentialEventsWithTransitions : SamplePlaylist
{
    public override string Name => "Sequential events with transitions";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event 1",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00"),
                            FrameAlignedTimeDifference.Parse("00:00:03:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Seq2",
                        "Sequential Event 2",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00"),
                            FrameAlignedTimeDifference.Parse("00:00:01:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Seq3",
                        "Sequential Event 3",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:20:00"),
                            FrameAlignedTimeDifference.Parse("00:00:00:05")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Seq4",
                        "Sequential Event 4",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                                new ReferencePrimaryLinearListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:29:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Seq3",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:18:20"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Seq4",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:01:38:20"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:02:08:20"),
                        FrameAlignedTimestamp.Parse("2021-10-06 10:00:00:00")))
                ));
}