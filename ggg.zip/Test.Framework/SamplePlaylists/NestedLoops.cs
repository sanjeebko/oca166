﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class NestedLoops : SamplePlaylist
{
    public override string Name => "NestedLoops";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Scheduling.Playlist(
                "Pebble",
                "Two nested loops",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistGroup(
                        "G1",
                        "Looped group",
                        ImmutableArray.Create<PlaylistItem>(
                            new PlaylistEvent(
                                "Looped1",
                                "Looped Event",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistGroup(
                                "G2",
                                "Nested looped group",
                                ImmutableArray.Create<PlaylistItem>(
                                    new PlaylistEvent(
                                        "Looped2",
                                        "Nested Looped Event",
                                        new Timing(
                                            new SequentialTiming(),
                                            new SequentialTiming(),
                                            FrameAlignedTimeDifference.Parse("00:00:40:00")),
                        ImmutableArray<MediaEvent>.Empty)
                                    ),
                                new Loop(8)),
                            new PlaylistEvent(
                                "Following1",
                                "Sequential Event",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:10:00")),
                        ImmutableArray<MediaEvent>.Empty)
                                    ),
                        new Loop(3)),
                    new PlaylistEvent(
                        "Following2",
                        "Sequential Event",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )),
            new Anchor(
                "Looped",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray.Create<LoopCounter>(
                    new LoopCounter("G1", 2),
                    new LoopCounter("G2", 5)), ""));
}