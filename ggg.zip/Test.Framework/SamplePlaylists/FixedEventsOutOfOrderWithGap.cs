namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class FixedEventsOutOfOrderWithGap : SamplePlaylist
{
    public override string Name => "FixedEventsOutOfOrderWithGap";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new(
                "Pebble",
                "Fixed events out of order with Gaps",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-01-21 10:00:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video1.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Fixed2",
                        "Fixed Event 2",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-01-21 10:02:30:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:01:00:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video2.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Fixed3",
                        "Fixed Event 3",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-01-21 09:55:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:02:00:00")),
                        ImmutableArray.Create<MediaEvent>(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video3.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd))))
                    )),
            new Anchor(
                "Fixed1",
                FrameAlignedTimestamp.Parse("2022-01-21 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2022-01-21 10:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-01-21 10:00:30:00"),
                        FrameAlignedTimeDifference.Parse("00:02:00:00"))),
                new ReferencePrimaryLinearListEvent(
                    "Fixed2",
                    new(
                        FrameAlignedTimestamp.Parse("2022-01-21 10:02:30:00"),
                        FrameAlignedTimeDifference.Parse("00:01:00:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Fixed3",
                    new(
                        FrameAlignedTimestamp.Parse("2022-01-21 10:03:30:00"),
                        FrameAlignedTimeDifference.Parse("00:02:00:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-01-21 10:05:30:00"),
                        FrameAlignedTimeDifference.Parse("47:54:30:00")))
                ));

    public override ReferenceDeviceList? DeviceList => new ReferenceDeviceList(
        ImmutableArray.Create<ReferenceDeviceListEvent>(
             new ReferenceDeviceListEvent("Fixed1",
                 new(FrameAlignedTimestamp.Parse("2022-01-21 10:00:00:00"),
                     FrameAlignedTimeDifference.Parse("00:00:30:00"))),
            new ReferenceDeviceListEvent("Fixed2",
                 new(FrameAlignedTimestamp.Parse("2022-01-21 10:02:30:00"),
                        FrameAlignedTimeDifference.Parse("00:01:00:00"))),
            new ReferenceDeviceListEvent("Fixed3",
                 new(FrameAlignedTimestamp.Parse("2022-01-21 10:03:30:00"),
                        FrameAlignedTimeDifference.Parse("00:02:00:00")))
            ));
}