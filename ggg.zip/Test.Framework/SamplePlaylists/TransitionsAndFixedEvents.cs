﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class TransitionsAndFixedEvents_Aligned : SamplePlaylist
{
    public override string Name => "Fixed event with transition";

    public override FrameAlignedTimestamp Time => FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00");

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Fixed2",
                        "Fixed Event 2",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:29:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00"),
                            FrameAlignedTimeDifference.Parse("00:00:01:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Fixed2",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:29:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:01:19:00"),
                        FrameAlignedTimestamp.Parse("2022-02-16 15:00:00:00")))
                ));
}

internal class TransitionsAndFixedEvents_Overlap : SamplePlaylist
{
    public override string Name => "Fixed event with transition with an overlap";

    public override FrameAlignedTimestamp Time => FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00");

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Fixed2",
                        "Fixed Event 2",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:29:10")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00"),
                            FrameAlignedTimeDifference.Parse("00:00:01:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Fixed2",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:29:10"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:01:19:10"),
                        FrameAlignedTimestamp.Parse("2022-02-16 15:00:00:00")))
                ));
}
internal class TransitionsAndFixedEvents_NoOverlap : SamplePlaylist
{
    public override string Name => "Fixed event with transition without an overlap";

    public override FrameAlignedTimestamp Time => FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00");

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Fixed2",
                        "Fixed Event 2",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00"),
                            FrameAlignedTimeDifference.Parse("00:00:01:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferencePrimaryLinearListEvent(
                    "Fixed2",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:01:20:00"),
                        FrameAlignedTimestamp.Parse("2022-02-16 15:00:00:00")))
                ));
}
internal class TransitionsAndFixedEvents_Gap : SamplePlaylist
{
    public override string Name => "Fixed event with transition with a gap";

    public override FrameAlignedTimestamp Time => FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00");

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Fixed1",
                        "Fixed Event 1",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistEvent(
                        "Fixed2",
                        "Fixed Event 2",
                        new Timing(
                            new FixedTiming(FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:05")),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00"),
                            FrameAlignedTimeDifference.Parse("00:00:01:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )));

    public override ReferenceLinearList? LinearList
        => new(
            ImmutableArray.Create<ReferenceLinearListEvent>(
                new ReferencePrimaryLinearListEvent(
                    "Fixed1",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:00:30:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:00"),
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:05"))),
                new ReferencePrimaryLinearListEvent(
                    "Fixed2",
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:00:30:05"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00")),
                    LinearListEventStatus.Normal),
                new ReferenceIdleLinearListEvent(
                    new(
                        FrameAlignedTimestamp.Parse("2022-02-14 15:01:20:05"),
                        FrameAlignedTimestamp.Parse("2022-02-16 15:00:00:00")))
                ));
}