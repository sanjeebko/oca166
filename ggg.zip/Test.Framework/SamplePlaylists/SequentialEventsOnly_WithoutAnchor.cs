﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class SequentialEventsOnly_WithoutAnchor : SequentialEventsOnly
{
    public override string Name => "SequentialEventsOnly without anchor";

    public override AnchoredPlaylist Playlist => base.Playlist with { Anchor = null };

    public override ReferenceLinearList? LinearList => base.LinearList!.RebaseAt(Time);
    public override ReferenceDeviceList? DeviceList => base.DeviceList!.RebaseAt(Time);
}

internal class SequentialEventsOnly_WithAnchor_After1Minute : SequentialEventsOnly_WithoutAnchor
{
    public override string Name => "SequentialEventsOnly without anchor after 1 minute";

    public override FrameAlignedTimestamp Time => base.Time + FrameAlignedTimeDifference.Parse("00:01:00:00");
}