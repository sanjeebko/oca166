﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class LoopedGroup : SamplePlaylist
{
    public override string Name => "LoopedGroup";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Scheduling.Playlist(
                "Pebble",
                "A looped group followed by a sequential event",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistGroup(
                        "G1",
                        "Looped group",
                        ImmutableArray.Create<PlaylistItem>(
                            new PlaylistEvent(
                                "Looped1",
                                "Looped Event 1",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistEvent(
                                "Looped2",
                                "Looped Event 2",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:10:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistEvent(
                                "Looped3",
                                "Looped Event 3",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:01:00:00")),
                        ImmutableArray<MediaEvent>.Empty),
                            new PlaylistEvent(
                                "Looped4",
                                "Looped Event 4",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:5:00")),
                        ImmutableArray<MediaEvent>.Empty)
                            ),
                        new Loop(8)),
                    new PlaylistEvent(
                        "Following1",
                        "Sequential Event",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));
}