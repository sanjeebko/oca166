using Pebble.Oceans.Automation.Test.Framework.Scenario.Generators;

namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class TenThousandSequentialEventsOnly : SamplePlaylist
{
    public override string Name => nameof(TenThousandSequentialEventsOnly);

    private readonly SimplePlaylistGenerator _sampleBasicPlaylistGenerator = new("BBC2",
                                                                                      "Today's Playlist",
                                                                                      10000,
                                                                                      FrameAlignedTimeDifference.Parse("00:00:01:00"),
                                                                                      false
                                                                                      );

    private readonly SimpleLinearListGenerator _sampleBasicLinearlistGenerator = new("BBC2",
                                                                                          "Today's Playlist",
                                                                                          10000,
                                                                                          false,
                                                                                          FrameAlignedTimeDifference.Parse("00:00:01:00")
                                                                                          );

    private readonly SampleBasicDevicelistGenerator _sampleBasicDevicelistGenerator = new("BBC2",
                                                                                          "Today's Playlist",
                                                                                          10000,
                                                                                          FrameAlignedTimeDifference.Parse("00:00:01:00"),
                                                                                          FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"));

    public override AnchoredPlaylist Playlist =>
        _sampleBasicPlaylistGenerator.GetSequentialEventsAnchoredPlaylist(FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"));

    public override ReferenceLinearList? LinearList => new(
        _sampleBasicLinearlistGenerator.GetLinearListFromPlaylist(Playlist, FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00")).Events.Append(new ReferenceIdleLinearListEvent(new
            FrameAlignedTimeInterval(FrameAlignedTimestamp.Parse("2021-10-04 12:46:40:00"), FrameAlignedTimestamp.Parse("2021-10-06 10:00:00:00")))).ToImmutableArray());

    public override ReferenceDeviceList? DeviceList =>
        _sampleBasicDevicelistGenerator.GetReferenceDeviceList(LinearList!);

    public override int MaxLinearListSize => 10000;
}