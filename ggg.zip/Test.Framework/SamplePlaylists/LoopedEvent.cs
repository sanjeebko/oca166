﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class LoopedEvent : SamplePlaylist
{
    public override string Name => "LoopedEvent";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Scheduling.Playlist(
                "Pebble",
                "A single event looped group followed by a sequential event",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty),
                    new PlaylistGroup(
                        "G1",
                        "Looped group",
                        ImmutableArray.Create<PlaylistItem>(
                            new PlaylistEvent(
                                "Looped",
                                "Looped Event",
                                new Timing(
                                    new SequentialTiming(),
                                    new SequentialTiming(),
                                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray<MediaEvent>.Empty)
                            ),
                        new Loop(3)),
                    new PlaylistEvent(
                        "Following1",
                        "Sequential Event",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:30:00")),
                        ImmutableArray<MediaEvent>.Empty)
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));
}