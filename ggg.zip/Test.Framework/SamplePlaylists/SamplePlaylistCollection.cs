﻿using System.Reflection;

namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

public static class SamplePlaylistCollection
{
    public const string Namespace = "Pebble.Oceans.Automation.Test.Framework.SamplePlaylists";

    public static ImmutableArray<SamplePlaylist> Playlists { get; } =
        Assembly
           .GetExecutingAssembly()
           .GetTypes()
           .Where(t => t.IsAssignableTo(typeof(SamplePlaylist)) && !t.IsAbstract && t.Namespace == Namespace)
           .Select(t => t.GetConstructor(Type.EmptyTypes)?.Invoke(null) as SamplePlaylist ?? throw new Exception($"Error creating sample playlist {t.Name}"))
           .ToImmutableArray();

    public static void GeneratePlaylistFiles(string path = ".", bool overwrite = false)
    {
        foreach (var playlist in Playlists)
            playlist.GeneratePlaylistFile(path, overwrite);
    }

    public static void GenerateLinearlistFiles(string path = ".", bool overwrite = false)
    {
        foreach (var playlist in Playlists)
            playlist.GenerateLinearlistFile(path, overwrite);
    }

    public static void GenerateDevicelistFiles(string path = ".", bool overwrite = false)
    {
        foreach (var playlist in Playlists)
            playlist.GenerateDevicelistFile(path, overwrite);
    }

    public static SamplePlaylist GetPlaylist(string name)
        => Playlists.FirstOrDefault(t => t.Name == name)
            ?? throw new Exception($"Sample playlist {name} not found");
}