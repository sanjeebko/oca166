﻿namespace Pebble.Oceans.Automation.Test.Framework.SamplePlaylists;

internal class SequentialEventsWithSecondaries : SamplePlaylist
{
    public override string Name => "SequentialEventsWithSecondaries";

    public override AnchoredPlaylist Playlist { get; } =
        new(
            new Playlist(
                "BBC2",
                "Today's playlist",
                ImmutableArray.Create<PlaylistItem>(
                    new PlaylistEvent(
                        "Seq1",
                        "Sequential Event 1",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:05:30:00")),
                        ImmutableArray.Create(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video1.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Graphics",
                                "Main Graphics",
                                "Logo",
                                "Logo.tga",
                                false,
                                new(MediaEventTimingMode.FromParentStart, FrameAlignedTimeDifference.Parse("00:00:00:15")),
                                new(MediaEventTimingMode.FromParentEnd, FrameAlignedTimeDifference.Parse("-00:00:00:15"))),
                            new MediaEvent(
                                "Graphics",
                                "Main Graphics",
                                "Lower3rd",
                                "Title1.png",
                                false,
                                new(MediaEventTimingMode.FromParentStart, null),
                                new(MediaEventTimingMode.Duration, FrameAlignedTimeDifference.Parse("00:01:00:00"))),
                            new MediaEvent(
                                "Graphics",
                                "Main Graphics",
                                "Lower3rd",
                                "Title2.png",
                                false,
                                new(MediaEventTimingMode.Sequential, FrameAlignedTimeDifference.Parse("00:00:03:00")),
                                new(MediaEventTimingMode.Duration, FrameAlignedTimeDifference.Parse("00:01:00:00"))),
                            new MediaEvent(
                                "Graphics",
                                "Main Graphics",
                                "Lower3rd",
                                "Title3.png",
                                false,
                                new(MediaEventTimingMode.Transition, FrameAlignedTimeDifference.Parse("00:00:00:15")),
                                new(MediaEventTimingMode.Duration, FrameAlignedTimeDifference.Parse("00:01:00:00"))),
                            new MediaEvent(
                                "Graphics",
                                "SD Graphics",
                                "Logo",
                                "SdLogo.tga",
                                false,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Subtitle",
                                "DVB Subtitles",
                                "Eng",
                                "Trailer1.eng.pac",
                                false,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Subtitle",
                                "DVB Subtitles",
                                "Ger",
                                "Trailer1.ger.pac",
                                false,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Audio",
                                "Voice Over",
                                "Eng",
                                "Trailer1.eng.wav",
                                false,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Audio",
                                "Voice Over",
                                "Ger",
                                "Trailer1.ger.wav",
                                false,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq2",
                        "Sequential Event 2",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:50:00")),
                        ImmutableArray.Create(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video2.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)))),
                    new PlaylistEvent(
                        "Seq3",
                        "Sequential Event 3",
                        new Timing(
                            new SequentialTiming(),
                            new SequentialTiming(),
                            FrameAlignedTimeDifference.Parse("00:00:20:00")),
                        ImmutableArray.Create(
                            new MediaEvent(
                                "Video",
                                "Video&Audio",
                                null,
                                "Video3.mxf",
                                true,
                                new(MediaEventTimingMode.FromParentStart),
                                new(MediaEventTimingMode.FromParentEnd)),
                            new MediaEvent(
                                "Graphics",
                                "Main Graphics",
                                "Logo",
                                "Logo.tga",
                                false,
                                new(MediaEventTimingMode.FromParentStart, FrameAlignedTimeDifference.Parse("-00:00:00:15")),
                                new(MediaEventTimingMode.FromParentEnd, FrameAlignedTimeDifference.Parse("00:00:00:15")))))
                )),
            new Anchor(
                "Seq1",
                FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                ImmutableArray<LoopCounter>.Empty, ""));

    public override ReferenceLinearList? LinearList
        => new(
        ImmutableArray.Create<ReferenceLinearListEvent>(
            new ReferencePrimaryLinearListEvent(
                "Seq1",
                new(
                    FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                    FrameAlignedTimeDifference.Parse("00:05:30:00")),
                LinearListEventStatus.Normal),
                            new ReferencePrimaryLinearListEvent(
                "Seq2",
                new(
                    FrameAlignedTimestamp.Parse("2021-10-04 10:05:30:00"),
                    FrameAlignedTimeDifference.Parse("00:00:50:00")),
                LinearListEventStatus.Normal),
            new ReferencePrimaryLinearListEvent(
                "Seq3",
                new(
                    FrameAlignedTimestamp.Parse("2021-10-04 10:06:20:00"),
                    FrameAlignedTimeDifference.Parse("00:00:20:00")),
                LinearListEventStatus.Normal),
            new ReferenceIdleLinearListEvent(
                new(
                    FrameAlignedTimestamp.Parse("2021-10-04 10:06:40:00"),
                    FrameAlignedTimeDifference.Parse("47:53:20:00")))
            ));

    public override ReferenceDeviceList? DeviceList
        => new(
            ImmutableArray.Create(
                new ReferenceDeviceListEvent(
                    "Seq1",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:00:00:00"),
                        FrameAlignedTimeDifference.Parse("00:05:30:00"))),
                    new ReferenceDeviceListEvent(
                    "Seq2",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:05:30:00"),
                        FrameAlignedTimeDifference.Parse("00:00:50:00"))),
                new ReferenceDeviceListEvent(
                    "Seq3",
                    new(
                        FrameAlignedTimestamp.Parse("2021-10-04 10:06:20:00"),
                        FrameAlignedTimeDifference.Parse("00:00:20:00")))
                ));
}